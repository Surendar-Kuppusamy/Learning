import React, { Suspense, lazy, useEffect, useCallback } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { BrowserRouter as Router, HashRouter } from "react-router-dom";
import { Amplify, DataStore, Auth, API, Predicates, Hub, Logger, graphqlOperation, SQLiteAdapter, ServiceWorker, syncExpression } from "aws-amplify";
import { toast } from 'react-toastify';
import { siteLoader, getCPABusinessIDs, setSessionValue, setNotifcationAlert, setDatastore, getCurrentUser, logoutUser, autoLogoutUser, autoSignInUser, resetState } from '../slices/globalSlice';
import { getCPACompanyDetails, reloadBusinessList, setBusinessList } from '../slices/cpaSlice';
import Loader from '../components/Loader';
import { ADMIN_START_ROUTE_PATH, BUSINESS_START_ROUTE_PATH, CPA_START_ROUTE_PATH, GRAPHQL_MAXIMUM_LIMIT, GRAPHQL_UNLIMITED_LIMIT } from '../constants/GlobalConstants';
import { CPACompany, TeamMemberUser, CPAUser, CompanyUser, Category, Receipt, Account, Client, PaymentMode, Invoice, InvoiceItem, Report, SubscriptionPlans, Subscriptions, Messages, ChatInfo, Terms } from "../models";
import { listCPACompanies } from '../graphql/queries';
import { getDataViaGraphql, getComapnyOptions } from '../slices/Functions/CommonFunctions';


const Header        =   React.lazy(() => import('../layouts/Header'));
const AdminHeader   =   React.lazy(() => import('../layouts/AdminHeader'));
const Footer        =   React.lazy(() => import('../layouts/Footer'));
const Sidebar       =   React.lazy(() => import('../layouts/Sidebar'));
const AdminSidebar  =   React.lazy(() => import('../layouts/AdminSidebar'));
const AllRoutes     =   React.lazy(() => import('../routes/AllRoutes'));
const LogoutUser    =   React.lazy(() => import('../pages/auth/LogoutUser'));

var dataStoreHubListener    =   null;
var subscriptionQ           =   null;

function RouterOutlet() {

    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    const logger = new Logger('My-Logger');

    const dispatch      =   useDispatch();
    const globalState   =   useSelector(state => state.global);

	const listener = async(data) => {
		switch (data.payload.event) {
			case 'signIn':
				logger.info('user signed in');
				console.log('user signed in');
                //dispatch(setUserAuthenticated(true));
                console.log(data?.payload?.data?.signInUserSession?.idToken?.payload);
                if(data?.payload?.data?.signInUserSession?.idToken?.payload) {
                    dispatch(autoSignInUser({'username': data?.payload?.data?.username, 'user_detail': data?.payload?.data?.signInUserSession?.idToken?.payload}));
                }
				/* dispatch(siteLoader(true));
				DataStore.start(); */
				break;
			case 'signUp':
				logger.info('user signed up');
				console.log('user signed up');
				break;
			case 'signOut':
				logger.info('user signed out');
				console.log('user signed out');
                //Hub.remove("datastore", dataStoreListener);
                //dispatch(getCurrentUser());
                /* localStorage.setItem("LogoutAllTabs", true);
                localStorage.removeItem("LogoutAllTabs"); */
                console.log('Clear');
                Hub.remove("datastore", dataStoreListener);
                //dispatch(setSessionValue(true));
                dispatch(autoLogoutUser())
                    .unwrap()
                    .then(data => {        
                        console.log('autoLogoutUser', data);
                    })
                    .catch(e => {
                        console.log('autoLogoutUser error find', e.message);
                    });
				break;
			case 'signIn_failure':
				logger.error('user sign in failed');
				console.log('user sign in failed');
				break;
			case 'tokenRefresh':
				logger.info('token refresh succeeded');
				console.log('token refresh succeeded');
                console.log(data.payload);
				break;
			case 'tokenRefresh_failure':
				logger.error('token refresh failed');
				console.log('token refresh failed');
                dispatch(logoutUser({}));
				break;
			case 'autoSignIn':
				logger.info('Auto signin success');
				console.log('Auto signin success');
                /* console.log(data?.payload?.data?.signInUserSession?.idToken?.payload);
                if(data?.payload?.data?.signInUserSession?.idToken?.payload) {
                    dispatch(autoSignInUser({'username': data?.payload?.data?.username, 'user_detail': data?.payload?.data?.signInUserSession?.idToken?.payload}))              
                } */
				break;
            case 'autoSignIn_failure':
                logger.error('Auto Sign In after Sign Up failed');
                break;
			case 'configured':
				logger.info('the Auth module is configured');
				console.log('the Auth module is configured');
		}
	}

    const showNotification = (notificationDetail) => {

        console.log("Show notification...", notificationDetail);

        // create a new notification
        const notification = new Notification(notificationDetail["title"], {
            body:   notificationDetail["message"],
            icon:   `${process.env.PUBLIC_URL}/images/logo.svg`
        });

        // close the notification after 10 seconds
        setTimeout(() => {
            notification.close();
        }, 20 * 1000);

        notification.addEventListener('click', () => {
            console.log("Notification Click event", notificationDetail);
        });
    }

    const startNotificationEventListener    =   async() => {

        if(globalState["user_detail"]["sub"] !== undefined && globalState["user_detail"]["sub"] !== '' && globalState["is_cpa_authenticated"] && globalState["is_user_authenticated"]) {
            console.log("Checking notification...");

            let granted = false;

            console.log("Notification.permission", Notification.permission);
            if(Notification.permission === 'granted') {
                granted = true;
            } else if (Notification.permission !== 'denied') {
                Notification.requestPermission().then(permission => {
                    granted = (permission === 'granted') ? true : false;
                    console.log("Notification Status 2 ...", permission);
                    if(permission !== 'granted') {
                        dispatch(setNotifcationAlert(true));
                    } else {
                        dispatch(setNotifcationAlert(false));
                    }
                });
                
            }
            

            if(Notification.permission !== 'granted') {
                dispatch(setNotifcationAlert(true));
            } else {
                dispatch(setNotifcationAlert(false));
            }

            console.log("Notification Status 1 ...", granted);

            if(subscriptionQ !== null) {
                subscriptionQ.unsubscribe();
            }
            
            subscriptionQ = DataStore.observe(
                Messages,
                m => m.userId("eq", globalState["user_detail"]["sub"])
              ).subscribe(msg => {
                console.log("Observer Query 1", msg.opType);
                console.log("Observer Query 2", msg.element);

                if(msg.opType === "INSERT") {
                    console.log("Triggerred notification ...");
                    const message = msg.element;
                    if(globalState["notificarion_alert"] === '') {
                        console.log("Called notification ...");
                        showNotification(message);
                    }
                }
            });

            console.log("Observer running");
        } else if(subscriptionQ !== null) {
            subscriptionQ.unsubscribe();
        }
    }

    const dataStoreListener = (hubData) => {
        try {
            const  { event, data } = hubData.payload;
            /* console.log('Listining'); */
            console.log('Event ==>', event);
            console.log('Data ==>', data);

            if((event == 'storageSubscribed' || event == 'networkStatus'/*  || event == 'modelSynced' */) && !globalState['site_loader']) {
                console.log('Set loader true', globalState['site_loader']);
                dispatch(siteLoader(true));
            }
            if(event == 'ready'/*  && globalState['site_loader'] */) {
                console.log('Datastore is ready');
                startNotificationEventListener();
                dispatch(setDatastore(true));
                if(globalState["root_path"] === '/cpa') {

                    dispatch(reloadBusinessList({ id: globalState?.user_detail?.sub, realod: false }));

                    /* dispatch(getCPACompanyDetails({ id: globalState?.user_detail?.sub, data: globalState['is_datastore_ready'] }))
                        .unwrap()
                        .then(data => {
                            console.log('Dashboard Response Data', data);
                            if(data !== undefined && data['companyDetails'] !== undefined) {
                                getComapnyOptions(data['companyDetails']).then(businessList => {
                                    dispatch(setBusinessList(businessList));
                                });
                            }
                        })
                        .catch(e => {
                            console.log('error find', e.message);
                            //toast.error(e.message, {theme: "colored"});
                        }); */
                }
            }
        } catch(e) {
            console.log(e, 'Cant listen datastore');
        }
	}

    useEffect(() => {

        startNotificationEventListener();

        if(globalState['first_load']) {

            Hub.listen('auth', listener);

            dispatch(getCurrentUser())
                .unwrap()
                .then(data => {
                    console.log('Initial API', data);
                    //startNotificationEventListener();
                })
                .catch(e => {
                    console.log('error find', e.message);
                });
        }
        
    }, [0]);


    useEffect(() => {

        if(globalState?.is_user_authenticated && !globalState?.is_datastore_ready && globalState?.sync_datastore) {

            if(globalState['root_path'] === CPA_START_ROUTE_PATH) {

                const variables    =   {
                    filter: {
                        or: [
                            {
                                cpaID: {
                                    eq: globalState['user_detail']['sub']
                                }
                            },
                            {
                                email: {
                                    eq: globalState['user_detail']["email"]
                                }
                            }
                        ]
                    },
                    limit: GRAPHQL_UNLIMITED_LIMIT
                }

                const customCompanyID   =   (globalState['user_detail']['custom:company_id'] !== undefined)
                                                ? globalState['user_detail']['custom:company_id']
                                                : "000";


                
                dispatch(getCPABusinessIDs())
                    .unwrap()
                    .then(businessIDs => {
                        console.log("businessIDs", businessIDs);
                        syncDatastore(globalState['root_path'], ['0', ...businessIDs, customCompanyID]);
                    })
                    .catch(e => {
                        console.log('Something went wrong on  getCPABusinessIDs ', e.message);
                        syncDatastore(globalState['root_path'], ['0', customCompanyID]);
                    });

                /* getDataViaGraphql(listCPACompanies, "listCPACompanies", variables).then(cpaCompanies =>{
                    console.log('getDataViaGraphql', cpaCompanies);
                    const businessIDs       =   cpaCompanies.map(business => business.refCID);
                    syncDatastore(globalState['root_path'], ['0', ...businessIDs, customCompanyID]);
                }).catch((err) => {
                    console.log('getDataViaGraphql error', err);
                    syncDatastore(globalState['root_path'], ['0', customCompanyID]);
                }); */
            } else if(globalState['root_path'] === BUSINESS_START_ROUTE_PATH) {
                syncDatastore(globalState['root_path'], ['0']);
            } else if(globalState['root_path'] === ADMIN_START_ROUTE_PATH) {
                syncDatastore(globalState['root_path'], ['0']);
            }
        }

	},[globalState["is_user_authenticated"], globalState["is_datastore_ready"], globalState["sync_datastore"]]);

    useEffect(() => {
        console.log('globalState change ', globalState);
    }, [globalState])

    const syncDatastore =   async(rootPath, businessIDs)  => {

        try {

            console.log('syncDatastore', rootPath, businessIDs, globalState);

            Hub.listen("datastore", dataStoreListener);

            if(globalState?.is_user_authenticated && !globalState?.is_datastore_ready) {

                console.log("Comes inside the datastore listerner");

                await DataStore.configure({
                    errorHandler: error => {
                        console.error('Unrecoverable error', error);
                        //await Auth.signOut();
                        dispatch(setSessionValue(true));
                        //dispatch(logoutUser());
                        //Hub.remove('datastore', dataStoreListener);
                        console.log('DataStore Configuration Error', error.message, error.errorInfo, error.recoverySuggestion);
                    },
                    storageAdapter: SQLiteAdapter,
                    syncExpressions: [
                        syncExpression(Account, () => {
                            if(rootPath === CPA_START_ROUTE_PATH) {
                                const tempbusinessID    =   businessIDs;
                                return account => account.or(
                                    ac => {
                                        tempbusinessID.forEach(bid => ac.addedBy('eq', bid));
                                    }
                                )/* .isActive('eq', true) */;
                            } else if(rootPath === BUSINESS_START_ROUTE_PATH) {
                                return account => account.addedBy('eq', globalState?.user_detail?.sub)/* .isActive('eq', true) */;
                            } else if(rootPath === ADMIN_START_ROUTE_PATH) {
                                return account => account.id('eq', "000");
                            } else {
                                return account => account.id('eq', "000");
                            }
                        }),
                        syncExpression(Category, () => {
                            if(rootPath === CPA_START_ROUTE_PATH) {
                                const tempbusinessID    =   businessIDs;
                                return category => category.or(
                                    ca => {
                                        tempbusinessID.forEach(bid => ca.addedBy('eq', bid));
                                    }
                                )/* .isActive('eq', true) */;
                            } else if(rootPath === BUSINESS_START_ROUTE_PATH) {
                                return category => category.addedBy('eq', globalState?.user_detail?.sub)/* .isActive('eq', true) */;
                            } else if(rootPath === ADMIN_START_ROUTE_PATH) {
                                return category => category.id('eq', "000");
                            } else {
                                return category => category.id('eq', "000");
                            }
                        }),
                        syncExpression(Receipt, () => {
                            return receipt => receipt.id('eq', "000");
                            //return receipt => receipt.id('eq', '0');
                            /* if(rootPath === ADMIN_START_ROUTE_PATH) {
                                return receipt => receipt.id('eq', "000");
                            } else {
                                return receipt => Predicates.ALL;
                            } */
                        }),
                        syncExpression(CompanyUser, () => {
                            console.log('Sync process 123 .....');
                            if(rootPath === CPA_START_ROUTE_PATH) {
                                const tempbusinessID    =   [...businessIDs];
                                return companyUser => companyUser.or(
                                    cu => {
                                        tempbusinessID.forEach(bid => cu.id('eq', bid));
                                    }
                                )/* .isActive('eq', true) */;
                            } else if(rootPath === BUSINESS_START_ROUTE_PATH) {
                                return companyUser => companyUser.id('eq', globalState?.user_detail?.sub)/* .isActive('eq', true) */;
                            } else if(rootPath === ADMIN_START_ROUTE_PATH) {
                                return companyUser => companyUser.id('eq', "000");
                            } else {
                                return companyUser => companyUser.id('eq', "000");
                            }
                        }),
                        syncExpression(CPACompany, () => {
                            if(rootPath === CPA_START_ROUTE_PATH) {
                                return cpaCompany => cpaCompany.or(
                                    cc => [
                                        cc.cpaID('eq', globalState?.user_detail?.sub),
                                        cc.email('eq', globalState?.user_detail?.email)
                                    ]
                                )/* .isDeleted('eq', false) */;
                            } else if(rootPath === BUSINESS_START_ROUTE_PATH) {
                                return cpaCompany => cpaCompany.refCID('eq', globalState?.user_detail?.sub)/* .isDeleted('eq', false) */;
                            } else if(rootPath === ADMIN_START_ROUTE_PATH) {
                                return cpaCompany => cpaCompany.id('eq', "000");
                            } else {
                                return cpaCompany => cpaCompany.id('eq', "000");
                            }
                        }),
                        syncExpression(TeamMemberUser, () => {
                            if(rootPath === CPA_START_ROUTE_PATH) {
                                return teamMember => teamMember.id('eq', '000');
                            } else if(rootPath === BUSINESS_START_ROUTE_PATH) {
                                return teamMember => teamMember.id('eq', '000');
                            } else if(rootPath === ADMIN_START_ROUTE_PATH) {
                                return teamMember => teamMember.id('eq', "000");
                            } else {
                                return teamMember => teamMember.id('eq', "000");
                            }
                        }),
                        syncExpression(CPAUser, () => {
                            if(rootPath === CPA_START_ROUTE_PATH) {
                                return cpaUser => cpaUser.id('eq', globalState?.user_detail?.sub)/* .isActive('eq', true) */;
                            } else if(rootPath === BUSINESS_START_ROUTE_PATH) {
                                return cpaUser => cpaUser.id('eq', '000');
                            } else if(rootPath === ADMIN_START_ROUTE_PATH) {
                                return cpaUser => cpaUser.id('eq', "000");
                            } else {
                                return cpaUser => cpaUser.id('eq', "000");
                            }
                        }),
                        syncExpression(Client, () => {
                            if(rootPath === CPA_START_ROUTE_PATH) {
                                return client => client.id('eq', '000');
                            } else if(rootPath === BUSINESS_START_ROUTE_PATH) {
                                return client => client.id('eq', '000');
                            } else if(rootPath === ADMIN_START_ROUTE_PATH) {
                                return client => client.id('eq', '000');
                            } else {
                                return client => client.id('eq', '000');
                            }
                        }),
                        syncExpression(PaymentMode, () => {
                            if(rootPath === CPA_START_ROUTE_PATH) {
                                return paymentMode => paymentMode.id('eq', '000');
                            } else if(rootPath === BUSINESS_START_ROUTE_PATH) {
                                return paymentMode => paymentMode.id('eq', '000');
                            } else if(rootPath === ADMIN_START_ROUTE_PATH) {
                                return paymentMode => paymentMode.id('eq', '000');
                            } else {
                                return paymentMode => paymentMode.id('eq', '000');
                            }
                        }),
                        syncExpression(InvoiceItem, () => {
                            if(rootPath === CPA_START_ROUTE_PATH) {
                                return invoiceItem => invoiceItem.id('eq', '000');
                            } else if(rootPath === BUSINESS_START_ROUTE_PATH) {
                                return invoiceItem => invoiceItem.id('eq', '000');
                            } else if(rootPath === ADMIN_START_ROUTE_PATH) {
                                return invoiceItem => invoiceItem.id('eq', '000');
                            } else {
                                return invoiceItem => invoiceItem.id('eq', '000');
                            }
                        }),
                        syncExpression(Invoice, () => {
                            if(rootPath === CPA_START_ROUTE_PATH) {
                                return invoice => invoice.id('eq', '000');
                            } else if(rootPath === BUSINESS_START_ROUTE_PATH) {
                                return invoice => invoice.id('eq', '000');
                            } else if(rootPath === ADMIN_START_ROUTE_PATH) {
                                return invoice => invoice.id('eq', '000');
                            } else {
                                return invoice => invoice.id('eq', '000');
                            }
                        }),
                        syncExpression(Report, () => {
                            if(rootPath === CPA_START_ROUTE_PATH) {
                                return report => report.addedBy('eq', globalState?.user_detail?.sub);
                            } else if(rootPath === BUSINESS_START_ROUTE_PATH) {
                                return report => report.addedBy('eq', globalState?.user_detail?.sub);
                            } else if(rootPath === ADMIN_START_ROUTE_PATH) {
                                return report => report.id('eq', '000');
                            } else {
                                return report => report.id('eq', '000');
                            }
                        }),
                        /* syncExpression(SubscriptionPlans, () => {
                            if(rootPath === CPA_START_ROUTE_PATH) {
                                return subscriptionPlans => subscriptionPlans.id('eq', '000');
                            } else if(rootPath === BUSINESS_START_ROUTE_PATH) {
                                return subscriptionPlans => subscriptionPlans.id('eq', '000');
                            } else if(rootPath === ADMIN_START_ROUTE_PATH) {
                                return subscriptionPlans => subscriptionPlans.id('eq', '000');
                            } else {
                                return subscriptionPlans => subscriptionPlans.id('eq', '000');
                            }
                        }),
                        syncExpression(Subscriptions, () => {
                            if(rootPath === CPA_START_ROUTE_PATH) {
                                return subscriptions => subscriptions.id('eq', '000');
                            } else if(rootPath === BUSINESS_START_ROUTE_PATH) {
                                return subscriptions => subscriptions.id('eq', '000');
                            } else if(rootPath === ADMIN_START_ROUTE_PATH) {
                                return subscriptions => subscriptions.id('eq', '000');
                            } else {
                                return subscriptions => subscriptions.id('eq', '000');
                            }
                        }), */
                        syncExpression(Messages, () => {
                            if(rootPath === CPA_START_ROUTE_PATH) {
                                return messages => messages.userId("eq", globalState["user_detail"]["sub"]);
                            } else if(rootPath === BUSINESS_START_ROUTE_PATH) {
                                return messages => messages.id('eq', '000');
                            } else if(rootPath === ADMIN_START_ROUTE_PATH) {
                                return messages => messages.id('eq', '000');
                            } else {
                                return messages => messages.id('eq', '000');
                            }
                        }),
                        syncExpression(ChatInfo, () => {
                            if(rootPath === CPA_START_ROUTE_PATH) {
                                const tempbusinessID = [...businessIDs];
                                console.log('tempe', tempbusinessID)
                                return chatInfo => chatInfo.or(
                                    ci => {
                                        tempbusinessID.forEach(bid => ci.id('eq', bid));
                                    }
                                )
                            } else if(rootPath === BUSINESS_START_ROUTE_PATH) {
                                return chatInfo => chatInfo.id('eq', '000');
                            } else if(rootPath === ADMIN_START_ROUTE_PATH) {
                                return chatInfo => chatInfo.id('eq', '000');
                            } else {
                                return chatInfo => chatInfo.id('eq', '000');
                            }
                        }),
                        syncExpression(Terms, () => {
                            if(rootPath === CPA_START_ROUTE_PATH) {
                                return messages => messages.id('eq', '000');
                            } else if(rootPath === BUSINESS_START_ROUTE_PATH) {
                                return messages => messages.id('eq', '000');
                            } else if(rootPath === ADMIN_START_ROUTE_PATH) {
                                return messages => messages.id('eq', '000');
                            } else {
                                return messages => messages.id('eq', '000');
                            }
                        })
                    ],
                });

                console.log("Comes inside the datastore listerner 123...");

                DataStore.start();

            }
        } catch(e) {
            console.log('Unrecoverable error', e);
            //await Auth.signOut();
            //dispatch(logoutUser());
            dispatch(setSessionValue(true));
        }
    }

    return (
        <Suspense fallback={<Loader />}>
            <Router>
                {
                    !globalState["isSessionNotExists"]
                    ?
                    <>
                        {
                            globalState["root_path"] === ADMIN_START_ROUTE_PATH
                            ?
                            <AdminHeader />
                            :
                            <Header />
                        }
                        <main className="layout">
                            {
                                globalState["root_path"] === CPA_START_ROUTE_PATH
                                &&
                                <Sidebar />
                            }
                            {
                                globalState["root_path"] === ADMIN_START_ROUTE_PATH
                                &&
                                globalState["user_detail"]["sub"] !== undefined
                                &&
                                globalState["user_detail"]["sub"] !== ''
                                &&
                                <AdminSidebar />
                            }
                            <AllRoutes globalState={globalState} />
                        </main>
                        <Footer />
                    </>
                    :
                    <LogoutUser />
                }
            </Router>
        </Suspense>
    );
}

export default RouterOutlet;