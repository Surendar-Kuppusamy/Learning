import React, { Suspense, lazy, useEffect, useCallback, useMemo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { BrowserRouter as Router, Navigate, useLocation, useNavigate, Routes, Route, useRoutes } from "react-router-dom";
import { GET_ROOT_PATH } from '../slices/Functions/CommonFunctions';
import ConfiguredRoutes from './ConfiguredRoutes';


function stringToBoolean(value){
    return (String(value).toLowerCase() === 'true');
}

const Container                 =   React.lazy(() => import('../components/Container'));

function AllRoutes(props) {
    const dispatch              =   useDispatch();
    const navigate              =   useNavigate();
    const location              =   useLocation();
    //const globalState           =   useSelector(state => state.global);
    const globalState           =   props.globalState;
    

    /* const isCpaAuthenticated        =   globalState.is_cpa_authenticated;
    const isBusinessAuthenticated   =   globalState.is_business_authenticated; */

    const isCpaAuthenticated        =   localStorage.getItem('is_cpa_authenticated')
                                                ? stringToBoolean(localStorage.getItem('is_cpa_authenticated'))
                                                : false;
    const isBusinessAuthenticated   =   localStorage.getItem('is_business_authenticated')
                                                ? stringToBoolean(localStorage.getItem('is_business_authenticated'))
                                                : false;

    const isAdminAuthenticated      =   localStorage.getItem('is_admin_authenticated')
                                                ? stringToBoolean(localStorage.getItem('is_admin_authenticated'))
                                                : false;

    //const rootPath                  =   GET_ROOT_PATH(location.pathname, globalState);
    const rootPath                  =   globalState["root_path"];

    console.log('rootPathrootPathrootPath', rootPath);

    console.log('Redirecting here', isCpaAuthenticated);

    const isVerificaionDone             =   (
                                                globalState['user_detail']['email_verified'] !== undefined
                                                &&
                                                globalState['user_detail']['phone_number_verified'] !== undefined
                                                &&
                                                !globalState['user_detail']['email_verified']
                                                &&
                                                !globalState['user_detail']['phone_number_verified']
                                            )
                                            ?   false
                                            :   true;

    const cpaInfoUpdated                =   (
                                                globalState['user_detail']['custom:role'] !== undefined
                                                &&
                                                globalState['user_detail']['custom:step'] !== undefined
                                                &&
                                                globalState['user_detail']['custom:role'] === '3'
                                                &&
                                                globalState['user_detail']['custom:step'] === '2'
                                            )
                                            ?   false
                                            :   true;


    const businessSelectPlanUpdated     =   (
                                                globalState['user_detail']['custom:role'] !== undefined
                                                &&
                                                globalState['user_detail']['custom:step'] !== undefined
                                                &&
                                                globalState['user_detail']['custom:role'] === '1'
                                                &&
                                                globalState['user_detail']['custom:step'] === '2'
                                            )
                                            ?   false
                                            :   true;


    const businessSetupPaymentUpdated   =   (
                                                globalState['user_detail']['custom:role'] !== undefined
                                                &&
                                                globalState['user_detail']['custom:step'] !== undefined
                                                &&
                                                globalState['user_detail']['custom:role'] === '1'
                                                &&
                                                globalState['user_detail']['custom:step'] === '3'
                                            )
                                            ?   false
                                            :   true;

    const allRouting = useRoutes(ConfiguredRoutes(rootPath, globalState, isCpaAuthenticated, isBusinessAuthenticated, isAdminAuthenticated));

    return (
        <Container>
            {allRouting}
        </Container>
    );
}


export default AllRoutes;
