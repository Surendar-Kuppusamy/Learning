import React, { Suspense, lazy, useEffect, useCallback, useMemo } from 'react';
import { Navigate } from "react-router-dom";
import { ADMIN_START_ROUTE_PATH, BUSINESS_START_ROUTE_PATH, CPA_START_ROUTE_PATH } from '../constants/GlobalConstants';


//Ladning Pages
const Container                 =   React.lazy(() => import('../components/Container'));

const Signup                    =   React.lazy(() => import('../pages/auth/Signup'));
const TermsAndConditions        =   React.lazy(() => import('../pages/auth/TermsAndConditions'));
const PrivacyPolicy             =   React.lazy(() => import('../pages/auth/PrivacyPolicy'));
const Login                     =   React.lazy(() => import('../pages/auth/Login'));
const VerificationCode          =   React.lazy(() => import('../pages/auth/VerificationCode'));
const ChooseVerificationType    =   React.lazy(() => import('../pages/auth/ChooseVerificationType'));
const ForgotPassword            =   React.lazy(() => import('../pages/auth/ForgotPassword'));
const ResetPassword             =   React.lazy(() => import('../pages/auth/ResetPassword'));
const ChangePassword            =   React.lazy(() => import('../pages/auth/ChangePassword'));
const LogoutUser                =   React.lazy(() => import('../pages/auth/LogoutUser'));


//const Modals                    =   React.lazy(() => import('../components/Modals'));


const Profile                   =   React.lazy(() => import('../pages/user/Profile'));
const UserInfo                  =   React.lazy(() => import('../pages/user/UserInfo'));
const RedirectPage              =   React.lazy(() => import('../pages/user/RedirectPage'));


//CPA
const Dashboard                 =   React.lazy(() => import('../pages/cpa/Dashboard'));
const CPAInfo                   =   React.lazy(() => import('../pages/cpa/CPAInfo'));
const BusinessList              =   React.lazy(() => import('../pages/cpa/BusinessList'));

const CompanyDashboard          =   React.lazy(() => import('../pages/cpa/CompanyDashboard'));
const CreateReport              =   React.lazy(() => import('../pages/cpa/CreateReport'));
const Reports                   =   React.lazy(() => import('../pages/cpa/Reports'));
const ChatBox                   =   React.lazy(() => import('../pages/cpa/ChatBox'));


//Receipts
const Receipts                  =   React.lazy(() => import('../pages/cpa/Receipts'));
const ReceiptsList              =   React.lazy(() => import('../pages/cpa/ReceiptsList'));
const InviteBusiness            =   React.lazy(() => import('../pages/cpa/InviteBusiness'));

//Business
const SelectPlan                =   React.lazy(() => import('../pages/business/SelectPlan'));
const SelectPlans               =   React.lazy(() => import('../pages/business/SelectPlans'));
const SetupPayment              =   React.lazy(() => import('../pages/business/SetupPayment'));
const BusinessDashboard         =   React.lazy(() => import('../pages/business/BusinessDashboard'));
const ReceiptsFrequencyChart    =   React.lazy(() => import('../graphs/cpa/ReceiptsFrequencyChart'));
const AddCard                   =   React.lazy(() => import('../pages/business/AddCard'));
const PaymentList               =   React.lazy(() => import('../pages/business/PaymentList'))


//Admin
const AdminDashboard            =   React.lazy(() => import('../pages/admin/AdminDashboard'));
const AddBlog                   =   React.lazy(() => import('../pages/admin/AddBlog'));
const AddFAQ                    =   React.lazy(() => import('../pages/admin/AddFAQ'));
const BusinessUserList          =   React.lazy(() => import('../pages/admin/BusinessUserList'));
const BusinessUserDetail        =   React.lazy(() => import('../pages/admin/BusinessUserDetail'));
const CpaUserList               =   React.lazy(() => import('../pages/admin/CpaUserList'));
const CpaUserDetail             =   React.lazy(() => import('../pages/admin/CpaUserDetail'));
const Category                  =   React.lazy(() => import('../pages/admin/Category'));
const AddCategory               =   React.lazy(() => import('../pages/admin/AddCategory'));
const Account                   =   React.lazy(() => import('../pages/admin/Account'))
const Subscriptions             =   React.lazy(() => import('../pages/admin/Subscriptions'));
const BlogList                  =   React.lazy(() => import('../pages/admin/BlogList'));
const FaqList                   =   React.lazy(() => import('../pages/admin/FaqList'));
const PaymentMode               =   React.lazy(() => import('../pages/admin/PaymentMode'));
const AddPayment                =   React.lazy(() => import('../pages/admin/AddPayment'));
const AddAccount                =   React.lazy(() => import('../pages/admin/AddAccount'));
const Terms                     =   React.lazy(() => import('../pages/admin/Terms'));
const AddTerms                  =   React.lazy(() => import('../pages/admin/AddTerms'));
const EmailTemplate             =   React.lazy(() => import('../pages/admin/EmailTemplate'));
const EmailTemplateList         =   React.lazy(() => import('../pages/admin/EmailTemplateList'));
const AddEditCoupon             =   React.lazy(() => import('../pages/admin/AddEditCoupon'));
//const AddEditPlan               =   React.lazy(() => import('../pages/admin/AddEditPlan'));


function stringToBoolean(value){
    return (String(value).toLowerCase() === 'true');
}


const ConfiguredRoutes = (rootPath, globalState, isCpaAuthenticated, isBusinessAuthenticated, isAdminAuthenticated) => {

    
    const userRole  =   (globalState['user_detail']['custom:role'] !== undefined) ? globalState['user_detail']['custom:role'] : null;
    const userStep  =   (globalState['user_detail']['custom:step'] !== undefined) ? globalState['user_detail']['custom:step'] : null;

    const subscriptionStatus    =   (globalState['user_detail']['custom:isSubscribed'] !== undefined)
                                        ? stringToBoolean(globalState['user_detail']['custom:isSubscribed'])
                                        : false;

    console.log("subscriptionStatus", subscriptionStatus);

    let authNavigatePath            =   '';
    let unAuthNavigatePath          =   '';
    let cpaInfoNavigatePath         =   '';
    let businessInfoNavigatePath    =   '';
    let businessSelectPlan          =   '';
    let cardPageNavigatePath        =   '';
    let emailVerifyNavigatePath     =   '';

    if(isCpaAuthenticated === true) {
        rootPath    =   CPA_START_ROUTE_PATH;
    } else if(isBusinessAuthenticated === true) {
        rootPath    =   BUSINESS_START_ROUTE_PATH;
    } else if(isAdminAuthenticated === true) {
        rootPath    =   ADMIN_START_ROUTE_PATH;
    }

    switch (rootPath) {
        case CPA_START_ROUTE_PATH:

            if(userRole === null || userStep === null) {
                authNavigatePath    =   rootPath+'/login';
                cpaInfoNavigatePath =   rootPath+'/login';
            } else if(!isCpaAuthenticated) {
                authNavigatePath    =   rootPath+'/login';
                cpaInfoNavigatePath =   rootPath+'/login';
            }

            if(isCpaAuthenticated && parseInt(userRole) === 3 && parseInt(userStep) === 1) {
                unAuthNavigatePath  =   rootPath+'/info';
                authNavigatePath    =   rootPath+'/info';
            } else if(isCpaAuthenticated && parseInt(userRole) === 3 && parseInt(userStep) === 2) {
                unAuthNavigatePath  =   rootPath+'/dashboard';
                //cpaInfoNavigatePath =   rootPath+'/dashboard';
            }

            //console.log(userRole, userStep, isCpaAuthenticated, 'Checinging', unAuthNavigatePath, cpaInfoNavigatePath);

            return [
                {
                    path: rootPath+'/logout',
                    element: <LogoutUser />
                },
                {
                    path: '/logout',
                    element: <LogoutUser />
                },
                {
                    path: rootPath+'/login',
                    element: (unAuthNavigatePath === '') ? <Login /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'/redirect/:redirect_details',
                    element: <RedirectPage />
                },
                {
                    path: rootPath+'/signup',
                    element:  (unAuthNavigatePath === '') ? <Signup /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'/termsandcondition',
                    element:  (unAuthNavigatePath === '') ? <TermsAndConditions /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'/privacypolicy',
                    element:  (unAuthNavigatePath === '') ? <PrivacyPolicy /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'/signup/:cpa_details',
                    element:  (unAuthNavigatePath === '') ? <Signup /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'/verify/code/:verification_type',
                    element:  (unAuthNavigatePath === '') ? <VerificationCode /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'/verify/:verification_type',
                    element:  (authNavigatePath === '') ? <VerificationCode /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/verify/profile/:verification_type',
                    element:  (authNavigatePath === '') ? <VerificationCode /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/choose/verification/type',
                    element:  (unAuthNavigatePath === '') ? <ChooseVerificationType /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'/forgot/password',
                    element:  (unAuthNavigatePath === '') ? <ForgotPassword /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'/reset/password',
                    element:  (unAuthNavigatePath === '') ? <ResetPassword /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'/info',
                    //element: <UserInfo />
                    element: (cpaInfoNavigatePath === '') ? <UserInfo /> : <Navigate to={cpaInfoNavigatePath} />
                },
                /* {
                    path: rootPath+'/user/info',
                    element: <UserInfo />
                }, */
                {
                    path: rootPath+'/dashboard',
                    element:  (authNavigatePath === '') ? <Dashboard /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/company/:company_id/dashboard',
                    element:  (authNavigatePath === '') ? <CompanyDashboard /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/change/password',
                    element:  (authNavigatePath === '') ? <ChangePassword /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/profile',
                    element:  (authNavigatePath === '') ? <Profile /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/invite/business',
                    element:  (authNavigatePath === '') ? <InviteBusiness /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/business/list',
                    element:  (authNavigatePath === '') ? <BusinessList /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/business/:type/list',
                    element:  (authNavigatePath === '') ? <BusinessList /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/company/receipts',
                    element:  (authNavigatePath === '') ? <Receipts /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/company/:company_id/receipts',
                    element:  (authNavigatePath === '') ? <Receipts /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/chatbox',
                    element:  (authNavigatePath === '') ? <ChatBox /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/company/:company_id/chatbox',
                    element:  (authNavigatePath === '') ? <ChatBox /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/company/:company_id/create/report',
                    element:  (authNavigatePath === '') ? <CreateReport /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/company/:company_id/report',
                    element:  (authNavigatePath === '') ? <Reports /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: '*',
                    element: <Navigate to={rootPath+'/login'} />
                }
            ]
        break;
        case BUSINESS_START_ROUTE_PATH:
            if(userRole === null || userStep === null) {
                authNavigatePath            =   rootPath+'/login';
                businessInfoNavigatePath    =   rootPath+'/login';
                businessSelectPlan          =   rootPath+'/login';
                cardPageNavigatePath        =   rootPath+'/login';
                emailVerifyNavigatePath     =   rootPath+'/login';
            } else if(!isBusinessAuthenticated) {
                authNavigatePath            =   rootPath+'/login';
                businessInfoNavigatePath    =   rootPath+'/login';
                businessSelectPlan          =   rootPath+'/login';
                cardPageNavigatePath        =   rootPath+'/login';
                emailVerifyNavigatePath     =   rootPath+'/login';
            }

            if(isBusinessAuthenticated && parseInt(userRole) === 1 && parseInt(userStep) === 1) {
                unAuthNavigatePath  =   rootPath+'/info';
                authNavigatePath    =   rootPath+'/info';
                businessSelectPlan  =   rootPath+'/info';
                cardPageNavigatePath=   rootPath+'/info';
                emailVerifyNavigatePath =   rootPath+'/info';
            } else if(isBusinessAuthenticated && parseInt(userRole) === 1 && parseInt(userStep) >= 2 && !subscriptionStatus) {
                unAuthNavigatePath          =   rootPath+'/select/plan';
                businessInfoNavigatePath    =   rootPath+'/select/plan';
                authNavigatePath            =   rootPath+'/select/plan';
            } else if(isBusinessAuthenticated && parseInt(userRole) === 1 && parseInt(userStep) === 2 && subscriptionStatus) {
                unAuthNavigatePath          =   rootPath+'/dashboard';
                businessInfoNavigatePath    =   rootPath+'/dashboard';
                businessSelectPlan          =   rootPath+'/dashboard';
                cardPageNavigatePath        =   rootPath+'/dashboard';
            } else if(isBusinessAuthenticated && parseInt(userRole) === 1 && parseInt(userStep) >= 1) {
                unAuthNavigatePath          =   rootPath+'/dashboard';
                businessInfoNavigatePath    =   rootPath+'/dashboard';
                businessSelectPlan          =   rootPath+'/dashboard';
                cardPageNavigatePath        =   rootPath+'/dashboard';
            }

            //console.log('unAuthNavigatePath', unAuthNavigatePath);
            

            return [
                {
                    path: rootPath+'/logout',
                    element: <LogoutUser />
                },
                {
                    path: '/logout',
                    element: <LogoutUser />
                },
                {
                    path: rootPath+'/login',
                    element: (unAuthNavigatePath === '') ? <Login /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'/signup',
                    element:  (unAuthNavigatePath === '') ? <Signup /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'/termsandcondition',
                    element:  (unAuthNavigatePath === '') ? <TermsAndConditions /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'/privacypolicy',
                    element:  (unAuthNavigatePath === '') ? <PrivacyPolicy /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'/signup/:cpa_details',
                    element:  (unAuthNavigatePath === '') ? <Signup /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'/verify/code/:verification_type',
                    element:  (unAuthNavigatePath === '') ? <VerificationCode /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'/verify/:verification_type',
                    element:  (emailVerifyNavigatePath === '') ? <VerificationCode /> : <Navigate to={emailVerifyNavigatePath} />
                },
                {
                    path: rootPath+'/verify/profile/:verification_type',
                    element:  (authNavigatePath === '') ? <VerificationCode /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/choose/verification/type',
                    element:  (unAuthNavigatePath === '') ? <ChooseVerificationType /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'/forgot/password',
                    element:  (unAuthNavigatePath === '') ? <ForgotPassword /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'/reset/password',
                    element:  (unAuthNavigatePath === '') ? <ResetPassword /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'/info',
                    element:  (businessInfoNavigatePath === '') ? <UserInfo /> : <Navigate to={businessInfoNavigatePath} />
                    //element:  <UserInfo />
                },
                /* {
                    path: rootPath+'/user/info',
                    element: <UserInfo />
                }, */
                {
                    path: rootPath+'/change/password',
                    element:  (authNavigatePath === '') ? <ChangePassword /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/profile',
                    element:  (authNavigatePath === '') ? <Profile /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/select/plan',
                    //element:  <SelectPlans />
                    element:  (businessSelectPlan === '') ? <SelectPlans /> : <Navigate to={businessSelectPlan} />                    
                },
                {
                    path: rootPath+'/update/plan/:subscriptionID',
                    element:  (authNavigatePath === '') ? <SelectPlans /> : <Navigate to={authNavigatePath} />                    
                },
                {
                    path: rootPath+'/subscribe/plan',
                    element:  (authNavigatePath === '') ? <SelectPlans /> : <Navigate to={authNavigatePath} />                    
                },
                {
                    path: rootPath+'/setup/payment/:plan_id',
                    element:  (cardPageNavigatePath === '') ? <SetupPayment /> : <Navigate to={cardPageNavigatePath} />
                },
                {
                    path: rootPath+'/add/subscription/:plan_id',
                    element:  (authNavigatePath === '') ? <SetupPayment /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/upgrade/subscription/:plan_id',
                    element:  (authNavigatePath === '') ? <SetupPayment /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/dashboard',
                    element:  (authNavigatePath === '') ? <BusinessDashboard /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/checkout/session/:status/:session_id',
                    element:  (authNavigatePath === '') ? <AddCard /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/checkout/session/:status',
                    element:  (authNavigatePath === '') ? <AddCard /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'/payment/list',
                    element:  (authNavigatePath === '') ? <PaymentList /> : <Navigate to={authNavigatePath} />
                },
                

                {
                    path: rootPath+'/graph',
                    element:  <ReceiptsFrequencyChart />
                },
                {
                    path: '*',
                    element: <Navigate to={rootPath+'/login'} />
                }
            ]
        break;
        case ADMIN_START_ROUTE_PATH:
            rootPath    =   ADMIN_START_ROUTE_PATH;
            return [
                {
                    path: rootPath+'/logout',
                    element: <LogoutUser />
                },
                {
                    path: '/logout',
                    element: <LogoutUser />
                },
                {
                    path: rootPath+'/login',
                    element: (!isAdminAuthenticated) ? <Login /> : <Navigate to={rootPath+'/dashboard'} />
                },
                {
                    path: rootPath+'/dashboard',
                    element: (isAdminAuthenticated) ? <AdminDashboard /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+'/add/blog',
                    element: (isAdminAuthenticated) ? <AddBlog /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+'/add/blog/:user_id',
                    element: (isAdminAuthenticated) ? <AddBlog /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+'/add/faq',
                    element: (isAdminAuthenticated) ? <AddFAQ /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+'/add/faq/:user_id',
                    element: (isAdminAuthenticated) ? <AddFAQ /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+'/user/business/list',
                    element: (isAdminAuthenticated) ? <BusinessUserList /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+'/user/business/detail/:user_id',
                    element: (isAdminAuthenticated) ? <BusinessUserDetail /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+'/users/cpa/list',
                    element: (isAdminAuthenticated) ? <CpaUserList /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+'/users/cpa/detail/:user_id',
                    element:(isAdminAuthenticated) ? <CpaUserDetail /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+'/setting/category',
                    element: (isAdminAuthenticated) ? <Category /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+'/setting/add/category',
                    element: (isAdminAuthenticated) ? <AddCategory /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+'/setting/add/paymentmode',
                    element: (isAdminAuthenticated) ? <AddPayment /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+'/setting/add/paymentmode/:user_id',
                    element: (isAdminAuthenticated) ? <AddPayment /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+'/setting/add/category/:user_id',
                    element: (isAdminAuthenticated) ? <AddCategory /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+'/subscriptions',
                    element: (isAdminAuthenticated) ? <Subscriptions /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+'/setting/account',
                    element: (isAdminAuthenticated) ? <Account /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+ '/bloglist',
                    element: (isAdminAuthenticated) ? <BlogList /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+ '/faqlist',
                    element: (isAdminAuthenticated) ? <FaqList /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+ '/setting/paymentmode',
                    element: (isAdminAuthenticated) ? <PaymentMode /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+ '/setting/terms',
                    element: (isAdminAuthenticated) ? <Terms /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+ '/setting/add/terms',
                    element: (isAdminAuthenticated) ? <AddTerms /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+ '/setting/add/terms/:user_id',
                    element: (isAdminAuthenticated) ? <AddTerms /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+ '/setting/add/account',
                    element: (isAdminAuthenticated) ? <AddAccount /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+ '/setting/add/account/:user_id',
                    element: (isAdminAuthenticated) ? <AddAccount /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+ '/add/emailtemplate',
                    element: (isAdminAuthenticated) ? <EmailTemplate /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+ '/add/emailtemplate/:user_id',
                    element: (isAdminAuthenticated) ? <EmailTemplate /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+ '/emailtemplateList',
                    element: (isAdminAuthenticated) ? <EmailTemplateList /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+ '/setting/add/coupon',
                    element: (isAdminAuthenticated) ? <AddEditCoupon /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+ '/setting/edit/coupon/:coupon_id',
                    element: (isAdminAuthenticated) ? <AddEditCoupon /> : <Navigate to={rootPath+'/login'} />
                },
                /* {
                    path: rootPath+ '/add/plan',
                    element: (isAdminAuthenticated) ? <AddEditPlan /> : <Navigate to={rootPath+'/login'} />
                },
                {
                    path: rootPath+ '/edit/plan/:plan_id',
                    element: (isAdminAuthenticated) ? <AddEditPlan /> : <Navigate to={rootPath+'/login'} />
                }, */
                {
                    path: '*',
                    element: <Navigate to={rootPath+'/login'} />
                }
            ]
        break;
        default:
            rootPath    =   CPA_START_ROUTE_PATH;
            return [
                {
                    path: rootPath+'/login',
                    element: (!isAdminAuthenticated) ? <Login /> : <Navigate to={rootPath+'/add/blog'} />
                },
                {
                    path: '*',
                    element: <Navigate to={rootPath+'/login'} />
                }
            ]
    }
};

export default ConfiguredRoutes;