Number.prototype.stripePrice    =   function() {
    return this / 100;
};

String.prototype.dateFormat    =   function() {
    const options = { year: "numeric", month: "short", day: "numeric" };
    return new Date(this).toLocaleDateString(undefined, options);
};

String.prototype.dateTimeFormat    =   function() {
    const options = { year: "numeric", month: "short", day: "numeric" };
    const showTime  =   new Date(this).toLocaleTimeString('en-US');
    return new Date(this).toLocaleDateString(undefined, options)+' '+showTime;
};

String.prototype.toBoolean    =   function() {
    return (String(this).toLowerCase() === 'true');
};

Number.prototype.currency    =   function() {
    return "$"+this;
};