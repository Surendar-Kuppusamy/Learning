import i18next from 'i18next';
import moment from 'moment';


export let LANGUAGE = 'en';

export const ENBALE_UPGRADE_BTN         =   2;

export const MAXIMUM_FILE_SIZE          =   9000000;

export const DEFAULT_PER_PAGE           =   10;

export const CPA_START_ROUTE_PATH       =   '/cpa';
export const BUSINESS_START_ROUTE_PATH  =   '/business';
export const ADMIN_START_ROUTE_PATH     =   '/admin';

const IMAGE_TYPES                   =   [ "image/jpeg", "image/jpg", "image/svg", "image/png" ];
export const VALID_IMAGE_TYPES      =   IMAGE_TYPES.join(",");

export const ALL_VALID_IMAGE_TYPES  =   { 'image/*': ['.jpeg', '.jpg', '.png', '.heic'] };

export const AZ_PAYMENT_TYPES       =   [
    {
        "value":    1,
        "label":    "Subscriptions"
    },
    {
        "value":    2,
        "label":    "Add on"
    }
];


//1 - Income, 2 - Manual Expense, 3 - Scanned Expense
export const AZ_APP_VERSION = '1.9.0';


export const CATEGORY_TYPES       =   [
    {
        "value":    1,
        "label":    "Income"
    },
    {
        "value":    2,
        "label":    "Expense"
    }
];

export const LANGUAGE_SUPPORTED_OPTIONS =   [
    {
        "value":    "en",
        "label":    "En"
    },
    {
        "value":    "fr",
        "label":    "Fr"
    }
];

export const DEFAULT_PAYMENT_LAMBDA_PLAN_DATA_PARAMETERS  =   {
    "id": "",
    "name": "",
    "notes": "",
    "type": 0,
    "period": 0,
    "price": 0,
    "expenseReceiptsQty": 0,
    "invoiceQty": 0,
    "teamMemberQty": 0,
    "productKey": "",
    "priceKey": "",
    "status": 0,
    "extraDetail": "",
    "extraNumber": 0,
}


export const DEFAULT_PAYMENT_LAMBDA_COUPON_DATA_PARAMETERS  =   {
    "stripeCouponID": "",
    "id": "",
    "Code": "",
    "percentage": 0,
    "amount": 0,
    "name": "",
    "notes": "",
    "period": false,
    "validFrom": new Date().getTime(),
    "validTo": new Date().getTime(),
    "status": 0,
    "deleteStatus": false,
    "details": "",
    "type": 0,
    "maxUseLimit": 0,
    "usedCount": 0,
    "extraDetail": "",
    "extraNumber": 0
}

export const DEFAULT_PAYMENT_LAMBDA_PARAMETERS  =   {
    "language"              :   "",
    "name"                  :   "",
    "userID"                :   "",
    "userRole"              :   "",
    "description"           :   '',
    "collectionName"        :   "",
    "planID"                :   "",
    "paymentType"           :   0,
    "paymentID"             :   "",
    "status"                :   1,
    
    "paymentMethodID"       :   "",

    "cardName"              :   "",
    "cardExpMonth"          :   0,
    "cardExpYear"           :   0,
    "cardCountry"           :   "",
    "cardBrandName"         :   "",
    "cardNo"                :   "",
    "subscriptionID"        :   "",
    "subscriptionTableID"   :   "",
    "cpaUserId"             :   "",
    "refundAmount"          :   "",
    "discountAmount"        :   "",
    "discountId"            :   "",
    "customerStripeId"      :   "",
    "subscriptionType"      :   "",
    "taxAmount"             :   "",
    "email"                 :   "",
    "extraDetails"          :   "",
    "couponsData"           :   DEFAULT_PAYMENT_LAMBDA_COUPON_DATA_PARAMETERS,
    "planData"              :   DEFAULT_PAYMENT_LAMBDA_PLAN_DATA_PARAMETERS
};

export const DEFAULT_PAYMENT_LAMBDA_PARAMS = {
    "parameters"    :   DEFAULT_PAYMENT_LAMBDA_PARAMETERS,
    "type"          :   ""
};

export const DEFAULT_FETCH_DATA_LAMBDA_RECEIPTS_SUB_PARAMETERS   =   {
    "tableName"         :   "",
    "cpaUserID"         :   "",
    "businessUserID"    :   "",
    "businessUserIDs"   :   [],
    "businessPurpose"   :   0,
    "filterBy"          :   0,
    "startDate"         :   "",
    "endDate"           :   "",
    "categoryID"        :   "",
    "cpaStatus"         :   0,
    "searchText"        :   "",
    "deleteStatus"      :   false,
    "nextToken"         :   "",
    "sortBy"            :   "",
    "sortOn"            :   "",
    "limit"             :   0,
    "extraDetail"       :   ""
};

export const DEFAULT_FETCH_DATA_LAMBDA_CPACOMPANY_SUB_PARAMETERS   =   {
    "tableName"         :   "",
    "email"             :   "",
    "searchText"        :   "",
    "cpaUserID"         :   "",
    "businessUserID"    :   "",
    "businessUserIDs"   :   [],
    "deleteStatus"      :   false,
    "nextToken"         :   "",
    "sortBy"            :   "",
    "sortOn"            :   "",
    "limit"             :   0,
    "extraDetail"       :   ""
};

export const DEFAULT_FETCH_DATA_LAMBDA_PARAMETERS  =   {
    "receiptsFilter"    :   DEFAULT_FETCH_DATA_LAMBDA_RECEIPTS_SUB_PARAMETERS,
    "cpaCompanyFilter"  :   DEFAULT_FETCH_DATA_LAMBDA_CPACOMPANY_SUB_PARAMETERS,
    "extraDetail"       :   ""
};

export const DEFAULT_FETCH_DATA_LAMBDA_PARAMS = {
    "parameters"    :   DEFAULT_FETCH_DATA_LAMBDA_PARAMETERS,
    "type"          :   ""
};

export const COOKIE_NAME    =   'ExpenseTracker';

export const WEEK_DAYS      =   [i18next.t("sunday"),i18next.t("monday"),i18next.t("tuesday"),i18next.t("wednesday"),i18next.t("thursday"),i18next.t("friday"),i18next.t("saturday")];
export const MONTH_NAMES    =   [i18next.t("january"), i18next.t("february"), i18next.t("march"), i18next.t("april"), i18next.t("may"), i18next.t("june"), i18next.t("july"), i18next.t("august"), i18next.t("september"), i18next.t("october"), i18next.t("november"), i18next.t("december")];


export const SUBSCRIPTION_MONTH_SELECTOR    =   { "1": "monthly", "2": "six_month", "3": "twelve_month" };
export const SUBSCRIPTION_MONTHS            =   { "1": i18next.t("monthly"), "2": i18next.t("six_months"), "3": i18next.t("one_year") };
export const SUBSCRIPTION_TYPES             =   ['', 'Basic', 'Advance', 'Pro'];

export const USER_VALIDATE_API_NAME = 'cpaexpansetracker';
export const USER_VALIDATE_API_PATH = '/admin/checkUserName';

export const COUNTRIES = [
    { value: 'Canada', label: i18next.t("canada") },
    { value: 'India', label: i18next.t("india") }
];

export const COUNTRY_CODES_FOR_PHONE = [
    'CA',
    'IN'
];

export const HIDE_SIDEBAR = [
    CPA_START_ROUTE_PATH+'/signup',
    CPA_START_ROUTE_PATH+'/login',

    CPA_START_ROUTE_PATH+'/info',
    CPA_START_ROUTE_PATH+'/dashboard',
    CPA_START_ROUTE_PATH+'/company/list',
    CPA_START_ROUTE_PATH+'/company/pending/list',
    CPA_START_ROUTE_PATH+'/profile',
    CPA_START_ROUTE_PATH+'/verify/code/email',
    CPA_START_ROUTE_PATH+'/choose/verification/type',
    CPA_START_ROUTE_PATH+'/verify/email',
    CPA_START_ROUTE_PATH+'/verify/phone_number',
    CPA_START_ROUTE_PATH+'/verify/code/phone_number',
    CPA_START_ROUTE_PATH+'/business/list',
    CPA_START_ROUTE_PATH+'/business/pending/list',
    CPA_START_ROUTE_PATH+'/company/receipts',


    //Business
    BUSINESS_START_ROUTE_PATH+'/signup',
    BUSINESS_START_ROUTE_PATH+'/login',

    BUSINESS_START_ROUTE_PATH+'/dashboard',
    BUSINESS_START_ROUTE_PATH+'/verify/code/email',
    BUSINESS_START_ROUTE_PATH+'/verify/email',
    BUSINESS_START_ROUTE_PATH+'/verify/phone_number',
    BUSINESS_START_ROUTE_PATH+'/company/list',
    BUSINESS_START_ROUTE_PATH+'/company/pending/list',
    BUSINESS_START_ROUTE_PATH+'/profile',
    BUSINESS_START_ROUTE_PATH+'/choose/verification/type',
    BUSINESS_START_ROUTE_PATH+'/select/plan',
    BUSINESS_START_ROUTE_PATH+'/setup/payment',

    //Admin
    ADMIN_START_ROUTE_PATH+'/login'
];


export const CPA_DASHBOARD_DATE_FILTER    =   [
    { value: 'thisWeek', label: i18next.t("this_week") },
    { value: 'thisMonth', label: i18next.t("this_month") },
    { value: 'thisYear', label: i18next.t("this_year") }
];

export const CPA_DASHBOARD_GRAPH_FILTER    =   [
    { value: 'week', label: i18next.t("week") },
    { value: 'month', label: i18next.t("month") },
    { value: 'year', label: i18next.t('year') }
];

export const CPA_DASHBOARD_BUSINESS_FILTER    =   [
    {
        label: i18next.t("all"),
        value: 1
    },
    {
        label: i18next.t("for_business"),
        value: 2
    },
    {
        label: i18next.t("for_personal"),
        value: 3
    }
];

export const MONTH_OPTIONS    =   [
    { value: '01', label: i18next.t("january") },
    { value: '02', label: i18next.t("february") },
    { value: '03', label: i18next.t("march") },
    { value: '04', label: i18next.t('april') },
    { value: '05', label: i18next.t('may') },
    { value: '06', label: i18next.t("june") },
    { value: '07', label: i18next.t('july') },
    { value: '08', label: i18next.t("august") },
    { value: '09', label: i18next.t("september") },
    { value: '10', label: i18next.t("october") },
    { value: '11', label: i18next.t('november') },
    { value: '12', label: i18next.t('december') }
];

export const SELECT_PLAN_OPTIONS    =   {
    'YEARLY': [
        { 'name': 'export_expense_report', 'label': 'Export expense report (pdf or excel)', 'value': '', 'status': true },
        { 'name': 'team_members', 'label': '2 team members', 'value': '', 'status': true },
        { 'name': 'receipts_month', 'label': '200 receipts/month', 'value': '', 'status': true },
        { 'name': 'scan_email_receipts', 'label': 'Scan email receipts', 'value': '', 'status': true },
        { 'name': 'upload_bank_transactions', 'label': 'Upload bank transactions', 'value': '', 'status': true },
        { 'name': 'manage_recurring_receipts', 'label': 'Manage recurring receipts', 'value': '', 'status': true },
        { 'name': 'custom_support_via_email', 'label': 'Customer support via email', 'value': '', 'status': true }
    ],
    'MONTHLY': [
        { 'name': 'export_expense_report', 'label': 'Export expense report (pdf or excel)', 'value': '', 'status': true },
        { 'name': 'team_members', 'label': '2 team members', 'value': '', 'status': true },
        { 'name': 'receipts_month', 'label': '200 receipts/month', 'value': '', 'status': true },
        { 'name': 'scan_email_receipts', 'label': 'Scan email receipts', 'value': '', 'status': true },
        { 'name': 'upload_bank_transactions', 'label': 'Upload bank transactions', 'value': '', 'status': true },
        { 'name': 'manage_recurring_receipts', 'label': 'Manage recurring receipts', 'value': '', 'status': true },
        { 'name': 'custom_support_via_email', 'label': 'Customer support via email', 'value': '', 'status': true }
    ]
}

export const INITIAL_DASHBOARD_DATA	=	{
    'subTotalIncome'		:   0.00,
    'subTotalExpenses'      :   0.00,
    'taxTotalIncome'        :   0.00,
    'taxTotalExpenses'      :   0.00,
    'recentTransactions'    :   []
};

export const TOP_HEADER_HEIGHT  =   80;

export const GRAPHQL_MAXIMUM_LIMIT      =   1000000000;
export const GRAPHQL_UNLIMITED_LIMIT    =   1000000000;


export const REPORT_FORMATS =   ['', i18next.t("excel"), i18next.t("pdf")];

export const RECEIPTS_TYPES =   ['', i18next.t("income"), i18next.t("expense"), i18next.t("expense")];

export const STATUS = ['', 'Active', 'Cancel', 'InActive'];

export const ROLE = ['', "Business", "Team Member", "Cpa"]

export const REPORT_FILTERS =   {
                                    format: [
                                        {
                                            label: i18next.t("excel"),
                                            value: 1
                                        },
                                        {
                                            label: i18next.t("pdf"),
                                            value: 2
                                        }
                                    ],
                                    type: [
                                        {
                                            label: i18next.t("income"),
                                            value: 1
                                        },
                                        {
                                            label: i18next.t("expense"),
                                            value: 2
                                        }
                                    ],
                                    purpose: [
                                        {
                                            label: i18next.t("all"),
                                            value: 1
                                        },
                                        {
                                            label: i18next.t("for_business"),
                                            value: 2
                                        },
                                        {
                                            label: i18next.t("for_personal"),
                                            value: 3
                                        }
                                    ]
                                }




export const PAGINATION_DEFAULT_OBJECT = { pageRange: 5, total: 0, allFetchedData: [], filteredData: [] };

export const PAGINATION_VALUES  =   { limit: 2, offset: 0 };

//export const RECEIPT_FILTER_OBJ =   { filterBy: 0, category: '', sortBy: '', cpaStatus: 0, startDate: new Date(moment().subtract(3, "months")), endDate: new Date(moment()) };
export const RECEIPT_FILTER_OBJ =   { filterBy: 0, category: '', sortBy: '', cpaStatus: 0, startDate: null, endDate: null };

export const RECEIPT_FILTER_OPTIONS =   {
                                            filterBy: [
                                                {
                                                    label: i18next.t("income"),
                                                    value: 1
                                                },
                                                {
                                                    label: i18next.t("expense"),
                                                    value: 2
                                                }
                                            ],
                                            sortBy: [
                                                {
                                                    label: i18next.t("highest"),
                                                    value: 'highest'
                                                },
                                                {
                                                    label: i18next.t("lowest"),
                                                    value: 'lowest'
                                                },
                                                {
                                                    label: i18next.t("newest"),
                                                    value: 'newest'
                                                },
                                                {
                                                    label: i18next.t("oldest"),
                                                    value: 'oldest'
                                                }
                                            ],
                                            cpaStatus: [
                                                {
                                                    label: i18next.t("verified"),
                                                    value: 1
                                                },
                                                {
                                                    label: i18next.t("rejected"),
                                                    value: 2
                                                },
                                            ]
                                        };

export const SUBSCRIPTION_PERIODS   =   ['', 'monthly', 'bi-annual', 'yearly'];

export const TIME_DATE = (moment().format('lll'))
