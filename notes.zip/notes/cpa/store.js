import { configureStore, createListenerMiddleware } from '@reduxjs/toolkit';
import globalReducer from '../slices/globalSlice';
import cpaReducer from '../slices/cpaSlice';
import businessReducer from '../slices/businessSlice';
import adminReducer from '../slices/adminSlice';


const reducer = {
	global		:	globalReducer,
	cpa			:	cpaReducer,
	business 	:	businessReducer,
	admin		:	adminReducer
};

const store = configureStore({
	reducer: reducer,
	middleware: (getDefaultMiddleware) => getDefaultMiddleware({ serializableCheck: false }),
	devTools: (process.env.REACT_APP_ENV === 'development'),
});

export default store;