import { isEmpty } from 'lodash';


export const modifyAuthStates = async(type, userDetail, currentState, {}) => {
    return new Promise(async(resolve, reject) => {
        try {

            let tempState = { ...currentState };

            if(type == 'signUpUser' || type == 'getNotConfirmUserDetails') {

                tempState['is_verification_pending']    =   true;
                tempState['verification_status']        =   false;
                tempState['verification_username']      =   userDetail?.username;
                tempState['verification_userdetail']    =   userDetail?.attributes;
                
                localStorage.setItem('is_verification_pending', true);
                localStorage.setItem('verification_status', false);
                localStorage.setItem('verification_username', userDetail?.username);
                localStorage.setItem('verification_userdetail', JSON.stringify(userDetail?.attributes));

                if(userDetail?.attributes && userDetail?.attributes['custom:role'] != undefined && userDetail?.attributes['custom:role'] == '1') {

                    tempState['root_path']          =   '/business';
                    tempState['verification_path']  =   '/business/verify/code';

                    localStorage.setItem('verification_path', '/business/verify/code');
                    localStorage.setItem('root_path', '/business');

                } else if(userDetail?.attributes && userDetail?.attributes['custom:role'] != undefined && userDetail?.attributes['custom:role'] == '3') {

                    tempState['root_path']          =   '/cpa';
                    tempState['verification_path']  =   '/cpa/verify/code';

                    localStorage.setItem('verification_path', '/cpa/verify/code');
                    localStorage.setItem('root_path', '/cpa');

                }

                //Other states
                tempState['is_business_authenticated']      =   false;
                tempState['business_user_detail']           =   {};
                tempState['current_session_type']           =   'cpa';
                tempState['current_session_role']           =   0;
                tempState['user_detail']                    =   {};

                tempState['is_cpa_authenticated']           =   false;
                tempState['cpa_user_detail']                =   {};
                tempState['current_session_type']           =   'cpa';
                tempState['current_session_role']           =   0;
                tempState['user_detail']                    =   {};

                localStorage.removeItem('is_cpa_authenticated');
                localStorage.removeItem('is_business_authenticated');
                localStorage.removeItem('cpa_user_detail');
                localStorage.removeItem('business_user_detail');
                localStorage.removeItem('user_detail');
                localStorage.removeItem('current_session_type');
                localStorage.removeItem('current_session_role');

                return resolve(tempState);
            }

            if(type == 'verifySignUpCode' || type == 'loginUser') {

                var userDetails = { ...tempState['verification_userdetail'], username: tempState['verification_username'] };


                if(tempState['verification_userdetail']['custom:role'] != undefined && tempState['verification_userdetail']['custom:role'] == '1') {

                    tempState['is_business_authenticated']  =   true;
                    tempState['business_user_detail']       =   userDetails;
                    tempState['current_session_type']       =   'business';
                    tempState['current_session_role']       =   1;
                    tempState['user_detail']                =   userDetails;
                    
                    tempState['root_path']                  =   '/business';
                    
                    localStorage.setItem('is_business_authenticated', true);
                    localStorage.setItem('user_detail', JSON.stringify(userDetails));
                    localStorage.setItem('business_user_detail', JSON.stringify(userDetails));
                    localStorage.setItem('current_session_type', 'business');
                    localStorage.setItem('current_session_role', 1);
                    localStorage.setItem('root_path', '/business');
    
                } else if(tempState['verification_userdetail']['custom:role'] != undefined && tempState['verification_userdetail']['custom:role'] == '3') {
    
                    tempState['is_cpa_authenticated']       =   true;
                    tempState['cpa_user_detail']            =   userDetails;
                    tempState['current_session_type']       =   'cpa';
                    tempState['current_session_role']       =   3;
                    tempState['user_detail']                =   userDetails;

                    tempState['root_path']                  =   '/cpa';
                    
                    localStorage.setItem('is_cpa_authenticated', true);
                    localStorage.setItem('user_detail', JSON.stringify(userDetails));
                    localStorage.setItem('cpa_user_detail', JSON.stringify(userDetails));
                    localStorage.setItem('current_session_type', 'cpa');
                    localStorage.setItem('current_session_role', 3);
                    localStorage.setItem('root_path', '/cpa');
    
                }

                localStorage.removeItem('is_verification_pending');
                localStorage.removeItem('verification_status');
                localStorage.removeItem('verification_username');
                localStorage.removeItem('verification_userdetail');
                localStorage.removeItem('verification_path');

                tempState['is_verification_pending']    =   false;
                tempState['verification_status']        =   true;
                tempState['verification_username']      =   '';
                tempState['verification_userdetail']    =   {};
                tempState['verification_path']          =   '';

                return resolve(tempState);

            }

            if(type == 'getCurrentUser') {

                if(userDetail?.attributes['custom:role'] != undefined && userDetail?.attributes['custom:role'] == '1') {

                    tempState['is_business_authenticated']  =   true;
                    tempState['business_user_detail']       =   userDetail;
                    tempState['current_session_type']       =   'business';
                    tempState['current_session_role']       =   1;
                    tempState['user_detail']                =   userDetail;
                    
                    tempState['root_path']                  =   '/business';
                    
                    localStorage.setItem('is_business_authenticated', true);
                    localStorage.setItem('user_detail', JSON.stringify(userDetail));
                    localStorage.setItem('business_user_detail', JSON.stringify(userDetail));
                    localStorage.setItem('current_session_type', 'business');
                    localStorage.setItem('current_session_role', 1);
                    localStorage.setItem('root_path', '/business');
    
                } else if(userDetail?.attributes['custom:role'] != undefined && userDetail?.attributes['custom:role'] == '3') {
    
                    tempState['is_cpa_authenticated']       =   true;
                    tempState['cpa_user_detail']            =   userDetail;
                    tempState['current_session_type']       =   'cpa';
                    tempState['current_session_role']       =   3;
                    tempState['user_detail']                =   userDetail;

                    tempState['root_path']                  =   '/cpa';
                    
                    localStorage.setItem('is_cpa_authenticated', true);
                    localStorage.setItem('user_detail', JSON.stringify(userDetail));
                    localStorage.setItem('cpa_user_detail', JSON.stringify(userDetail));
                    localStorage.setItem('current_session_type', 'cpa');
                    localStorage.setItem('current_session_role', 3);
                    localStorage.setItem('root_path', '/cpa');
    
                }

                localStorage.removeItem('is_verification_pending');
                localStorage.removeItem('verification_status');
                localStorage.removeItem('verification_username');
                localStorage.removeItem('verification_userdetail');
                localStorage.removeItem('verification_path');

                tempState['is_verification_pending']    =   false;
                tempState['verification_status']        =   true;
                tempState['verification_username']      =   '';
                tempState['verification_userdetail']    =   {};
                tempState['verification_path']          =   '';

                return resolve(tempState);
            }

            if(type == 'logoutUser') {

                tempState['is_cpa_authenticated']       =   false;
                tempState['cpa_user_detail']            =   {};
                tempState['is_business_authenticated']  =   false;
                tempState['business_user_detail']       =   {};
                tempState['user_detail']                =   {};
                tempState['current_session_type']       =   '';
                tempState['current_session_role']       =   0;
                tempState['user_detail']                =   {};

                tempState['is_verification_pending']    =   false;
                tempState['verification_status']        =   false;
                tempState['verification_username']      =   '';
                tempState['verification_userdetail']    =   {};
                tempState['verification_path']          =   '';


                localStorage.removeItem('is_cpa_authenticated');
                localStorage.removeItem('cpa_user_detail');
                localStorage.removeItem('user_detail');
                localStorage.removeItem('is_business_authenticated');
                localStorage.removeItem('business_user_detail');
                localStorage.removeItem('current_session_type');
                localStorage.removeItem('current_session_role');
                localStorage.removeItem('root_path');

                localStorage.removeItem('is_verification_pending');
                localStorage.removeItem('verification_status');
                localStorage.removeItem('verification_username');
                localStorage.removeItem('verification_userdetail');
                localStorage.removeItem('verification_path');

                return resolve(tempState);
            }

        } catch(err) {
            reject(err);
        }
    });
}