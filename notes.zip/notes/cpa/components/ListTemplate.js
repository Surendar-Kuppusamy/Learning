import React,  { useEffect, useState, useMemo }  from 'react';
import { useTable, usePagination, useSortBy, useFilters, useGlobalFilter, useAsyncDebounce  } from 'react-table';
import ReactPaginate from 'react-paginate';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch } from '@fortawesome/free-solid-svg-icons';
import { Scrollbars } from 'react-custom-scrollbars-2';
import { matchSorter } from 'match-sorter';


function ListTemplate({columns, data, hiddenColumns=[], searchClass, parentTableClass, tableClass, rowClass, rowClickEvent, noDataMsg, noDataColSpan, activeRowID, callBackFunc, customFunction, customValues, detailValue, perPage, searchText, tableHeight, ...rest }) {

    const {
            setHiddenColumns,
            visibleColumns,
            preGlobalFilteredRows,
            getTableProps,
            getTableBodyProps,
            headerGroups,
            prepareRow,
            setGlobalFilter,
            rows,
            page,
            canPreviousPage,
            canNextPage,
            pageOptions,
            pageCount,
            gotoPage,
            nextPage,
            previousPage,
            setPageSize,
            state: { pageIndex, pageSize, globalFilter },
        }   =   useTable(
                    {
                        columns,
                        data,
                        initialState: { pageIndex: 0, hiddenColumns: hiddenColumns },
                        customFunction,
                        customValues,
                        detailValue
                    },
                    useGlobalFilter, // useGlobalFilter!
                    useSortBy,
                    usePagination,
                    
                );

        useEffect(() => {
            if(callBackFunc !== undefined) {
                callBackFunc();
            }
            if(rest?.customCallback !== undefined) {
                rest?.customCallback(globalFilter, pageIndex, pageSize);
            }
        }, [globalFilter, pageIndex, pageSize]);

        useEffect(() => {
            setGlobalFilter(searchText)
        }, [searchText]);
    

    return (
        <>
            
            <div className={'row search-sec mb-3 d-none ' +(searchClass !== undefined ? searchClass: '')+ ' '}>
                <div className="col-auto search-box">
                    <input
                        className="form-control filter-search"
                        placeholder="Search Text"
                        type="text"
                        value={globalFilter || ""}
                        onChange={e => setGlobalFilter(e.target.value)}
                    />
                    {/*<FontAwesomeIcon className="icon-class" icon={faSearch} />*/}
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M19.7177 18.0812L16.0909 14.5357C17.5395 12.7531 18.242 10.4896 18.0537 8.21062C17.8654 5.93169 16.8008 3.81074 15.0789 2.28409C13.3569 0.757445 11.1085 -0.0587926 8.79631 0.00329959C6.4841 0.0653918 4.28388 1.00109 2.6483 2.6179C1.01271 4.23471 0.0661511 6.40967 0.0033379 8.69535C-0.0594753 10.981 0.766239 13.2036 2.31061 14.9058C3.85499 16.608 6.00057 17.6604 8.30596 17.8465C10.6113 18.0326 12.9012 17.3382 14.7045 15.9062L18.2911 19.4616C18.3845 19.5547 18.4956 19.6286 18.618 19.679C18.7405 19.7294 18.8718 19.7554 19.0044 19.7554C19.137 19.7554 19.2683 19.7294 19.3908 19.679C19.5132 19.6286 19.6243 19.5547 19.7177 19.4616C19.8988 19.2764 20 19.0289 20 18.7714C20 18.5138 19.8988 18.2663 19.7177 18.0812ZM4.08536 13.92C3.10903 12.945 2.44639 11.7062 2.18086 10.3596C1.91532 9.01301 2.05878 7.61888 2.59316 6.35275C3.12755 5.08661 4.02896 4.00508 5.18389 3.24435C6.33883 2.48361 7.69564 2.07769 9.08349 2.07769C10.4713 2.07769 11.8281 2.48361 12.9831 3.24435C14.138 4.00508 15.0394 5.08661 15.5738 6.35275C16.1082 7.61888 16.2517 9.01301 15.9861 10.3596C15.7206 11.7062 15.0579 12.945 14.0816 13.92C13.4277 14.5731 12.6492 15.0915 11.7913 15.4453C10.9334 15.7992 10.0131 15.9813 9.08349 15.9813C8.15391 15.9813 7.23355 15.7992 6.37564 15.4453C5.51773 15.0915 4.7393 14.5731 4.08536 13.92Z" fill="#8F9BB3"/>
                    </svg>
                </div>
            </div>
            
            {
                rows.length !== 0
                &&
                <div className={'table-list table-responsive '+((parentTableClass !== undefined) ? parentTableClass : '') + ''}>
                    {/* <Scrollbars  autoHeight autoHeightMin={`calc(100vh - 120px)`}> */}
                    <Scrollbars  autoHeight autoHeightMax={tableHeight}>
                        <table {...getTableProps()} className={" "+(tableClass !== undefined ? tableClass: '')+" "}>
                            <thead>
                                {
                                    headerGroups.map(headerGroup => (
                                        <tr {...headerGroup.getHeaderGroupProps()}>
                                            {
                                                headerGroup.headers.map(column => 
                                                    {
                                                        //console.log(column, 'column');
                                                        return (
                                                            <th
                                                                className={(column?.thClassNames !== undefined ? column?.thClassNames : '' )}
                                                                {...column.getHeaderProps(column.getSortByToggleProps())}
                                                            >
                                                                {
                                                                    column.render('Header')
                                                                }
                                                                <span>
                                                                    {
                                                                        column.isSorted
                                                                            ? column.isSortedDesc
                                                                                ? ' 🔽'
                                                                                : ' 🔼'
                                                                            : ''
                                                                    }
                                                                </span>
                                                            </th>
                                                        )
                                                    }
                                                )
                                            }
                                        </tr>
                                    ))
                                }
                            </thead>
                            <tbody {...getTableBodyProps()}>
                                {
                                    page.map((row, i) => {
                                        prepareRow(row);
                                        //console.log('Check value', row);
                                        return (
                                            <tr 
                                                className = {" "+ ((activeRowID !== undefined && row?.original?.id !== undefined && row?.original?.id === activeRowID) ? ' active ' : ' ' ) + (rowClass !== undefined ? rowClass: '') + (i%2 === 0 ? " even-row ": " odd-row  ") + " pointer " }
                                                {...row.getRowProps()}
                                                onClick={(e) => { if(rowClickEvent !== undefined) rowClickEvent(e, row?.original);}}
                                                id={(row?.original?.id !== undefined) ? row?.original?.id : Math.random().toString()}
                                            >
                                                {
                                                    row.cells.map((cell, j) => {
                                                        //console.log('cell', cell);
                                                        return (
                                                            <td
                                                                className = {" "+ ((cell?.column?.tdClassNames !== undefined) ? cell?.column?.tdClassNames : '' ) +" "}
                                                                {...cell.getCellProps()}
                                                            >
                                                                {
                                                                    cell.render('Cell')
                                                                }
                                                            </td>
                                                        );
                                                    })
                                                }
                                            </tr>
                                        );
                                    })
                                }

                                {
                                    rows.length === 0 && (
                                        <tr className={(rowClass !== undefined ? rowClass : '')}>
                                            <td className="text-center" colSpan={(noDataColSpan !== undefined ? noDataColSpan: '')}>
                                                <div className="no-data">
                                                    {
                                                        (noDataMsg !== undefined ? noDataMsg: '')
                                                    }
                                                </div>
                                            </td>
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>
                        
                    </Scrollbars>
                </div>
            }
            {
                rows.length === 0
                &&
                <div className="container-fluid no-data-sec px-4">
                    <div className="no-data">
                        <div className="content">
                            <div className="icon">
                                <img src={`${process.env.PUBLIC_URL}/images/no-data.svg`} />
                            </div>
                            <div className="text">
                                {
                                    noDataMsg !== undefined
                                    &&
                                    noDataMsg !== ''
                                    &&
                                    noDataMsg
                                }
                            </div>
                        </div>
                    </div>
                </div>
            }
            
            <div className="react-table-pagination row">
                {/* <pre>
                    <code>
                    {JSON.stringify(
                        {
                        pageIndex,
                        pageSize,
                        pageCount,
                        canNextPage,
                        canPreviousPage,
                        },
                        null,
                        2
                    )}
                    </code>
                </pre> */}
                <div className="col-md-9">
                    <ul className="pagination justify-content-start my-4 mt-4">
                        {
                            pageCount > 1
                            &&
                            <>
                                <li className={' page-item '+((!canPreviousPage) ? ' disabled ' : '')+' '}>
                                    <button className="page-link" onClick={() => gotoPage(0)} disabled={!canPreviousPage}>
                                        {'<<'}
                                    </button>
                                </li>
                                <li className={' page-item '+((!canPreviousPage) ? ' disabled ' : '')+' '}>
                                    <button className="page-link" onClick={() => previousPage()} disabled={!canPreviousPage}>
                                        {'<'}
                                    </button>
                                </li>
                            </>
                        }
                        {
                            pageCount > 1
                            &&
                            <ReactPaginate
                                renderOnZeroPageCount={null}
                                previousLabel={'previous'}
                                nextLabel={'next'}
                                breakLabel={'...'}
                                breakClassName={'break-me'}
                                pageCount={pageCount}
                                marginPagesDisplayed={2}
                                pageRangeDisplayed={pageSize}
                                onPageChange={(data) => gotoPage(parseInt(data.selected))}
                                forcePage={pageIndex}
                                initialPage={pageIndex}
                                containerClassName={'pagination justify-content-start my-4 mt-0 '}
                                activeClassName={'active'}
                                pageClassName={'page-item'}
                                pageLinkClassName={'page-link'}
                                previousClassName={' d-none page-item'}
                                nextClassName={'page-item'}
                                previousLinkClassName={' d-none page-link'}
                                nextLinkClassName={' d-none page-link'}
                            />
                        }
                        {
                            pageCount > 1
                            &&
                            <>
                                <li className={' page-item '+((!canNextPage) ? ' disabled ' : '')+' '}>
                                    <button className="page-link" onClick={() => nextPage()} disabled={!canNextPage}>
                                        {'>'}
                                    </button>
                                </li>
                                <li className={' page-item '+((!canNextPage) ? ' disabled ' : '')+' '}>
                                    <button className="page-link" onClick={() => gotoPage(pageCount - 1)} disabled={!canNextPage}>
                                        {'>>'}
                                    </button>
                                </li>
                            </>
                        }
                    </ul>
                </div>
                <div className={perPage ? 'col-md-3' : 'd-none' }>
                    <div className="form-group">
                        <label htmlFor="perPage">Per Page</label>
                        <select
                            className="form-control"
                            id="perPage"
                            value={pageSize}
                            onChange={e => {
                                setPageSize(Number(e.target.value))
                            }}
                            >
                            {[10, 20, 30, 40, 50].map(pageSize => (
                                <option key={pageSize} value={pageSize}>
                                Show {pageSize}
                                </option>
                            ))}
                        </select>
                    </div>
                </div>
            </div>
            
        </>
    );
}


export default ListTemplate;