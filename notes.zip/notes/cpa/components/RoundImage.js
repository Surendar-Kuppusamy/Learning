import React, { useMemo } from 'react';

function RoundImage(props) {

    const username  =   useMemo(() => {
        if(
            props?.username !== undefined
            &&
            props?.username !== null
            &&
            props?.username !== ''
        ) {
            return props?.username.toUpperCase().substring(0, 2);
        }  
    });

    return (
        <>
            {
                (
                    props?.src !== undefined
                    &&
                    props?.src !== null
                    &&
                    props?.src !== ''
                )
                ? <img src={props?.src} alt={username} />
                : <span className="">
                    {
                       username
                    }
                </span>
            }
        </>
        
    );
}

export default RoundImage;