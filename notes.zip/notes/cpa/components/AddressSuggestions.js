import React,  { useEffect, useState, useRef }  from 'react';
import { findIndex } from 'lodash';
import { Geo } from "aws-amplify";
import { COUNTRY_WITH_CODE, ALPHA_TWO_TO_THREE_COUNTRY_CODE } from '../constants/CountryWithCode.js';

var TIMEOUT;

function AddressSuggestions(props) {

    const sleep     =   (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    const [geoLocations, setGeoLocations]           =   useState([]);

    useEffect(() => {
        searchLocation(props?.address);
    },[props?.address]);

    const searchLocation = (text) => {
        setGeoLocations([]);
        if(TIMEOUT) {
            clearTimeout(TIMEOUT);
        }

        TIMEOUT =   setTimeout(() => {

            if(text.length > 3) {
                var savedCountryCode    =   (props?.globalState['user_detail']['custom:countryCode'] !== undefined)
                                                ? props?.globalState['user_detail']['custom:countryCode']
                                                : '';
                props?.setLoader(true);

                console.log('savedCountryCode', props?.globalState["user_detail"]);

                var filter;
                if(savedCountryCode === '') {
                    filter = {
                        "maxResults": 6,
                    }
                } else {
                    filter = {
                        "countries": [savedCountryCode.slice(0, 3).toUpperCase().toString()],
                        "maxResults": 6,
                    }
                }
                //console.log(filter)
                Geo.searchByText(text, filter).then(res => {
                    console.log(res, 'Get Response');
                    setGeoLocations(res.filter(loc => loc["region"] !== undefined && loc["geometry"] !== undefined));
                    props?.setLoader(false);
                }).catch(err => {
                    console.log("Error", err)
                    setGeoLocations([]);
                    props?.setLoader(false);
                });
            }
        },300);
    }

    return(
        <>
            {
                props?.address !== undefined
                &&
                props?.address.length > 2
                &&
                props?.isAddressFocued
                &&
                <ul>
                    {
                        geoLocations.map((location, index) => {
                            return(
                                <li
                                    className="pointer"
                                    key={index}
                                    onClick={e => { setGeoLocations([]); props?.selectGeoLocation(e, location); }}
                                >
                                    {location.label}
                                </li>
                            )
                        })
                    }
                    {
                        props?.address.length > 2
                        &&
                        geoLocations.length === 0
                        &&
                        <li
                            className="pointer"
                        >
                            No suggestions for this text
                        </li>
                    }
                </ul>
            }
        </>
    )
}

export default AddressSuggestions;