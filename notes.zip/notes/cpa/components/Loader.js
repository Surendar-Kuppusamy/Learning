import React from 'react';

function Loader() {
    return (
        <div id="semiTransparenDiv"></div>
    );
}

export default Loader;