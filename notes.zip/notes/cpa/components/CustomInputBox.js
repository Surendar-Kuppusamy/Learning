import React, { useEffect, useState, useMemo } from 'react';
import { useSelector } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { useFormContext } from "react-hook-form";


function CustomInputBox(props) {

    const showHint = () => {
        if(props?.hint && props?.hint != '') {
            props?.trigger(props?.name);
        }
    }

    if(props?.hint && props?.hint != '') {
        return (
            <>
                <div className={' formfield '+ props?.parentClass}>
                    <input
                        {...props?.register(props.name)}
                        maxLength={((props?.validation?.maxLength !== undefined) ? props?.validation?.maxLength : '')}
                        defaultValue={props?.defaultValue}
                        type={props?.type}
                        className={(props?.errors[props?.name]) ? 'form-control is-invalid '+props?.class : 'form-control '+props?.class}
                        id={props?.id}
                        placeholder={props?.placeholder}
                        style={props?.style}
                        onKeyUp={showHint}
                        onFocus={props?.focusFunc}
                        onBlur={(e) => props?.trigger(props?.name)}
                        onBlurCapture={props?.blurFunc}
                        disabled={(props?.disabled !== undefined && props?.disabled === true)}
                    />
                    <label htmlFor={props?.id}>{props?.label}</label>
                    {
                        props?.iconName
                        &&
                        <span className={props?.iconClass} onClick={props?.iconClickHandler}>
                            <FontAwesomeIcon icon={props?.iconName}/>
                        </span>
                    }
                </div>
                <p className={'text-danger err-msg '+props?.errorClass}>
                    {
                        props?.errors[props?.name]
                        &&
                        props?.errors[props?.name].message
                    }
                </p>
            </>
        );
    } else {
        return (
            <>
                <div className={' formfield '+ props?.parentClass}>
                    <input
                        {...props?.register(props.name)}
                        maxLength={((props?.validation?.maxLength !== undefined) ? props?.validation?.maxLength : '')}
                        defaultValue={props?.defaultValue}
                        type={props?.type}
                        className={(props?.errors[props?.name]) ? 'form-control is-invalid '+props?.class : 'form-control '+props?.class}
                        id={props?.id}
                        placeholder={props?.placeholder}
                        style={props?.style}
                        onFocus={props?.focusFunc}
                        onBlur={(e) => props?.trigger(props?.name)}
                        onBlurCapture={props?.blurFunc}
                        disabled={(props?.disabled !== undefined && props?.disabled === true)}
                    />
                    <label htmlFor={props?.id}>{props?.label}</label>
                    {
                        props?.iconName
                        &&
                        <span className={props?.iconClass} onClick={props?.iconClickHandler}>
                            <FontAwesomeIcon icon={props?.iconName}/>
                        </span>
                    }
                </div>
                <p className={'text-danger err-msg '+props?.errorClass}>
                    {
                        props?.errors[props?.name]
                        &&
                        props?.errors[props?.name].message
                    }
                </p>
            </>
        );
    }
}

export default CustomInputBox;