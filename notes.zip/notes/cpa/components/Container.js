import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useLocation } from "react-router-dom";
import Loader from '../components/Loader';
import PageLoader from '../components/PageLoader';
import { ADMIN_START_ROUTE_PATH, BUSINESS_START_ROUTE_PATH, CPA_START_ROUTE_PATH, HIDE_SIDEBAR } from '../constants/GlobalConstants';

function Container(props) {

    const globalState   =   useSelector(state => state.global);
    const cpaState      =   useSelector(state => state.cpa);
    const businessState =   useSelector(state => state.business);
    const adminState    =   useSelector(state => state.admin);

    const location          =   useLocation();

    const [activeNav, setActiveNav]         =   useState('');
    const [paddingClass, setPaddingClass]   =   useState('');

    useEffect(() => {
        setActiveNav(location.pathname);

        if(globalState["root_path"] === BUSINESS_START_ROUTE_PATH) {
            setPaddingClass('ps-0');
        }
        if(globalState["root_path"] !== BUSINESS_START_ROUTE_PATH) {
            setPaddingClass('');
        }

        if((HIDE_SIDEBAR.includes(location.pathname)) || globalState.user_detail.sub === undefined) {
            setPaddingClass('ps-0');
        }
        

        console.log(location, activeNav, 'activeNav', paddingClass);

    },[location, activeNav]);



    return (
        <div className={'layout-content ' + paddingClass + ' '}>
            <div className={paddingClass === 'ps-0' ? "container" : "container-fluid" }>
                {
                    (
                        (globalState.page_loader || cpaState.page_loader)
                        &&
                        (!globalState.site_loader && !cpaState.site_loader)
                    )
                    ? <PageLoader />
                    : props.children
                }
                {
                    (
                        globalState?.site_loader
                        ||
                        cpaState?.site_loader
                        ||
                        businessState?.site_loader
                        ||
                        adminState?.site_loader
                        ||
                        globalState?.manual_site_loader
                        ||
                        cpaState?.manual_site_loader
                        ||
                        businessState?.manual_site_loader
                        ||
                        adminState?.manual_site_loader
                    )
                    &&
                    <Loader />
                }
            </div>
        </div>
    );
}

export default Container;