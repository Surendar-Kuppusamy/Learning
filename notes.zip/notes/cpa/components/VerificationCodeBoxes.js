import React,  { useEffect, useState, useRef }  from 'react';


function VerificationCodeBoxes(props) {

    const sleep     =   (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    const inputRefs =   useRef([]);
    const [allCodes, setAllCodes]   =   useState([]);

    useEffect(() => {
        if(props?.clearCodes) {
            clearVerificationCode();
        }
    }, [props?.clearCodes]);

    const changeVerificationCode    =   (event) => {
        //console.log(event, 'changeVerificationCode', event.target.id);
        const verifyCode    =   inputRefs.current.map((cur, i) => cur.value);
        setAllCodes(verifyCode);
        props?.setVerificationCode(verifyCode.join(""));
        //console.log('verifyCode', verifyCode.join(""));
        if(event.target.value !== '') {
            const id    =   parseInt(event.target.id.replace("verification_input_", "")) + 1;
            if(inputRefs.current[id] !== undefined) {
                inputRefs.current[id].focus();
                inputRefs.current[id].setSelectionRange(0,0);
            }
        }
    }

    const keyDownVerificationCode   =   (event) => {
        //console.log(event.key, 'Key pressed', event.target.value);       
        if(event.target.value === '' && event.key === 'Backspace') {
            const id    =   parseInt(event.target.id.replace("verification_input_", "")) - 1;
            if(inputRefs.current[id] !== undefined) {
                inputRefs.current[id].focus();
                //inputRefs.current[id].setSelectionRange(0,0);
            }
        } else if(event.target.value === '' && event.key === "Delete") {
            const id    =   parseInt(event.target.id.replace("verification_input_", "")) + 1;
            if(inputRefs.current[id] !== undefined) {
                
                inputRefs.current[id].focus();
                inputRefs.current[id].setSelectionRange(0,0);
            }
        }
    }

    const clearVerificationCode     =   () => {
        inputRefs.current.map((cur, i) => { cur.value = ''; });
        props?.setVerificationCode('');
        props?.setClearCodes(false);
    }

    const focusVerificationCode =   (event) => {
        const id    =   parseInt(event.target.id.replace("verification_input_", ""));
        inputRefs.current[id].setSelectionRange(0,0);
    }

    return (
        <div className="verification-container">
            {
                [...Array(props?.verificationCodeCount)].map(
                    (el, index) => ( 
                        <input
                            key={index}
                            type="text"
                            ref={(element) => inputRefs.current[index] = element}
                            maxLength={1}
                            placeholder="0"
                            /* onFocus={focusVerificationCode} */
                            onKeyDown={keyDownVerificationCode}
                            onChange={changeVerificationCode}
                            name={'verification_input_'+index}
                            id={'verification_input_'+index}
                            className={'code-box character'}
                        />
                    )
                )
            }
        </div>
    )
}

export default VerificationCodeBoxes;
