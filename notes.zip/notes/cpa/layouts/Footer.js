import React from 'react';

function Footer() {
    return (
        <footer>
            <div className="footer">
                
            </div>
        </footer>
    );
}

export default Footer;