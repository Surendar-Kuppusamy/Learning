import React, { useEffect, useState, useMemo, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Outlet, Link, useLocation, useNavigate } from "react-router-dom";
import Select, { components } from 'react-select';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrashAlt, faPencilAlt, faTimes,faVideo, faCheck, faBriefcase, faChartPie, faShoppingCart, faFile, faUsers, faList, faFolderPlus, faChartLine, faMusic, faBookReader, faFileAlt, faHandsHelping, faUserFriends, faPeopleArrows,faGuitar, faMicrophoneAlt, faBook, faBookMedical, faImages, faImage, faFileMedical, faShieldAlt, faFileContract} from '@fortawesome/free-solid-svg-icons';
import { toast } from 'react-toastify';
import { confirmAlert } from 'react-confirm-alert';

import { logoutUser } from '../slices/globalSlice';
import { setCompanySelected } from '../slices/cpaSlice';

function AdminHeader(props) {

    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    const dispatch          =   useDispatch();
    const navigate          =   useNavigate();
    const globalState       =   useSelector(app => app.global);
    const cpaState          =   useSelector(app => app.cpa);
    const location          =   useLocation();

    const [selectedBusiness, setSelectedBusiness]   =   useState('');

    const logoutConfirmed = async() => {
        dispatch(logoutUser())
        .unwrap()
        .then(data => {
            console.log('CAP Logout Response', data);
            navigate(globalState.root_path+'/login');
            //window.location.reload();
        })
        .catch(e => {
            console.log('error find', e.message);
            toast.error(e.message, {theme: "colored"});
        });
    }

    const logout = async(event) => {
        event.preventDefault();
        /* confirmAlert({
            title: 'Confirm',
            message: msg,
            buttons: [
              {
                label: 'Yes',
                onClick: () => cpalogoutConfirmed()
              },
              {
                label: 'No',
                onClick: () => console.log('Cancelled')
              }
            ]
        }); */
        logoutConfirmed()
    }

    const headerMenuClass   =   (menuPath) => {
        if(location.pathname.endsWith(menuPath)) {
            return 'nav-link active';
        } else {
            return 'nav-link';
        }
    }
   
    return (
        <header>
            <nav className="main-menu navbar navbar-expand-lg navbar-light sticky-top">
                <div className="container-fluid">
                    <a className="navbar-brand" href="#">
                        <img src={`${process.env.PUBLIC_URL}/images/logo.svg`} alt="Expense Tracker" />
                    </a>                    
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" >
                        <span className="icon-bar bar1"></span>
                        <span className="icon-bar bar2"></span>
                        <span className="icon-bar bar3"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarNav">
                        <span className="navbar-text" title='Admin Portal'>Admin Portal</span>
                        {
                            globalState["is_admin_authenticated"] === true
                            &&
                            <div className="nav-right ms-auto">
                                <div className="dropdown">
                                    <a className="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" title="Login"><span style={{ color:'#000' }}>Welcome</span> {globalState?.user_detail?.username}</a>
                                    <div className="dropdown-menu">                                        
                                        <a className="dropdown-item" title="Logout" onClick={logout} href=" ">Logout</a>
                                    </div>
                                </div>
                            </div>
                        }                        
                    </div>
                </div>
            </nav>
        </header>
    );
}

export default AdminHeader;