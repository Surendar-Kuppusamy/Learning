import React, { useEffect, useState, useMemo, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Outlet, Link, useLocation, useNavigate } from "react-router-dom";
import Select, { components } from 'react-select';
import { toast } from 'react-toastify';
import { confirmAlert } from 'react-confirm-alert';
import { useTranslation } from 'react-i18next';
import { logoutUser } from '../slices/globalSlice';
import { setCompanySelected } from '../slices/cpaSlice';
import { useCookies } from 'react-cookie';
import { CPA_DASHBOARD_GRAPH_FILTER, BUSINESS_START_ROUTE_PATH, ADMIN_START_ROUTE_PATH, LANGUAGE_SUPPORTED_OPTIONS, CPA_START_ROUTE_PATH, COOKIE_NAME } from '../constants/GlobalConstants.js';



function Header(props) {

    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    const dispatch          =   useDispatch();
    const navigate          =   useNavigate();
    const { t, i18n }       =   useTranslation();
    const globalState       =   useSelector(app => app.global);
    const cpaState          =   useSelector(app => app.cpa);
    const location          =   useLocation();

    const [cookies, setCookie, removeCookie]  =   useCookies([COOKIE_NAME]);

    const [selectedBusiness, setSelectedBusiness]   =   useState('');
    const [activeNav, setActiveNav]                 =   useState(CPA_DASHBOARD_GRAPH_FILTER+'/dashboard');

    let activeLanguage    =   localStorage.getItem('expense_tracker_language') ? localStorage.getItem('expense_tracker_language') : 'en';
    if(cookies["expense_tracker_language"] !== undefined && cookies["expense_tracker_language"] !== null) {
        activeLanguage  =   cookies["expense_tracker_language"];
    }
    const [language, setLanguage]   =   useState(activeLanguage);

    function changeLanguage(e) {
        console.log(e, 'changeLanguage');
        setCookie('expense_tracker_language', e.value, { path: globalState['root_path'] });
        i18n.changeLanguage(e.value);
        setLanguage(e.value);
        window.location.reload();
    }
    

    useEffect(() => {
        setActiveNav(location.pathname);
    },[location, activeNav]);

    useEffect(() => {
        if(location.pathname.startsWith(CPA_START_ROUTE_PATH+'/company/'+cpaState.selected_business)) {
            setSelectedBusiness(cpaState.selected_business);
        } else {
            setSelectedBusiness('');
        }
    },[location, cpaState.selected_business, cpaState.business_list]);

    const onChangeCompany = async(val) => {
        console.log('onChangeCompany', val);
        if(val !== null) {
            dispatch(setCompanySelected(val));
            navigate(globalState.root_path+'/company/'+val.value+'/receipts');    
        }
    };

    const logout = async(event) => {
        event.preventDefault();
        /* confirmAlert({
            title: 'Confirm',
            message: msg,
            buttons: [
              {
                label: 'Yes',
                onClick: () => cpalogoutConfirmed()
              },
              {
                label: 'No',
                onClick: () => console.log('Cancelled')
              }
            ]
        }); */
        navigate('/logout');
    }

    const headerMenuClass   =   (menuPath) => {
        if(location.pathname.endsWith(menuPath)) {
            return 'nav-link active pointer';
        } else {
            return 'nav-link pointer';
        }
    }
    

    
    return (
        <header>
            <nav className="main-menu navbar navbar-expand-lg navbar-light sticky-top">
                <div className="container-fluid">
                    <a className="navbar-brand" href="#">
                        <img src={`${process.env.PUBLIC_URL}/images/logo.svg`} alt="Expense Tracker" />
                    </a>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" >
                        <span className="icon-bar bar1"></span>
                        <span className="icon-bar bar2"></span>
                        <span className="icon-bar bar3"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarNav">

                        {
                            location.pathname.startsWith(BUSINESS_START_ROUTE_PATH)
                            &&
                            <span className="navbar-text" title={t("business_portal")}>
                                {t("business_portal")}
                            </span>
                        }
                        {
                            !(
                                globalState?.is_cpa_authenticated
                                &&
                                !location.pathname.startsWith(CPA_START_ROUTE_PATH+'/info')
                            )
                            &&
                            location.pathname.startsWith(CPA_START_ROUTE_PATH)
                            &&
                            <span className="navbar-text" title={t("cpa_portal")}>
                                {t("cpa_portal")}
                            </span>
                        }
                        {
                            globalState?.is_cpa_authenticated
                            &&
                            !location.pathname.startsWith(CPA_START_ROUTE_PATH+'/info')
                            && 
                            <ul className="mx-auto navbar-nav">
                                <li className="nav-item">
                                    <span className="navbar-text cpa-portal" title={t("cpa_portal")}>
                                        {t("cpa_portal")}
                                    </span>
                                </li>
                                <li className="nav-item">
                                    <Link to={globalState.root_path+'/dashboard'} className={headerMenuClass(CPA_START_ROUTE_PATH+'/dashboard')} title={t("cpa_dashboard")}>
                                        {t("cpa_dashboard")}
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <Link to={globalState.root_path+BUSINESS_START_ROUTE_PATH+'/list'} className={headerMenuClass(CPA_START_ROUTE_PATH+'/business/list')} title={t("business")}>
                                        {t("business")}
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <Link to={globalState.root_path+BUSINESS_START_ROUTE_PATH+'/pending/list'} className={headerMenuClass(CPA_START_ROUTE_PATH+BUSINESS_START_ROUTE_PATH+'/pending/list')} title= {t("pending_invites")}>
                                        {t("pending_invites")}
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#features" title={t("add_team")}>{t("add_team")}</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#pricing" title={t("settings")}>{t("settings")}</a>
                                </li>
                            </ul>
                        }
                        <div className="nav-right ms-auto">
                            {/* <a href="#" className="notify" title="notification"> 
                                <i className="fa-solid fa-bell"></i>
                            </a>*/}
                             <Select
                                className="cpa-select-container lang"
                                classNamePrefix="cpa-select"
                                noOptionsMessage={() => 'NA'}
                                placeholder={t("choose_language")}
                                options={LANGUAGE_SUPPORTED_OPTIONS}
                                value={LANGUAGE_SUPPORTED_OPTIONS.filter(({ value }) => value === language)}
                                onChange={changeLanguage}
                            /> 
                            {
                                globalState?.is_cpa_authenticated
                                &&
                                !location.pathname.startsWith(CPA_START_ROUTE_PATH+'/info')
                                && 
                                <Select
                                    className="cpa-select-container"
                                    classNamePrefix="cpa-select"
                                    /* menuIsOpen */
                                    noOptionsMessage={() => t("no_business")}
                                    placeholder={t("choose_business")}
                                    options={cpaState.business_list}
                                    /* value={cpaState.business_list.find(c => c.value === cpaState.selected_dashboard_company)} */
                                    /* defaultValue={cpaState.selected_business_detail} */
                                    value={cpaState.business_list.filter(({ value }) => value === selectedBusiness)}
                                    onChange={(val) => onChangeCompany(val) }
                                    formatOptionLabel={(business, { context }) => {
                                        return (
                                            <ul className="user-list">
                                                <li className="user-list-item">
                                                    {
                                                        business.image !== ''
                                                        ?   <img width="30" height="24" className="d-inline-block align-text-top" src={business.image} alt={business.label} />
                                                        :   <div className="prof-icon">
                                                                <span className="">{ business.label.toUpperCase().substring(0, 2) }</span>
                                                            </div>
                                                    }
                                                    <span>{business.label}</span>
                                                </li>
                                            </ul>
                                        )
                                    }}
                                    
                                />
                            }

                            {
                                (
                                    (
                                        (globalState['is_cpa_authenticated'] && location.pathname.startsWith(CPA_START_ROUTE_PATH))
                                        ||
                                        (globalState['is_business_authenticated'] && location.pathname.startsWith(BUSINESS_START_ROUTE_PATH))
                                    )
                                    &&
                                    globalState?.user_detail?.username != ''
                                )
                                    ?
                                        <div className="dropdown">
                                            <a className="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" title={t("login")}><span style={{ color:'#000' }}>{t("welcome")}</span> {globalState?.user_detail?.username}</a>
                                            <div className="dropdown-menu">
                                                {
                                                    !location.pathname.startsWith(CPA_START_ROUTE_PATH+'/info')
                                                    &&
                                                    !location.pathname.startsWith(BUSINESS_START_ROUTE_PATH)
                                                    &&
                                                    <Link to={globalState.root_path+'/profile'} className={'dropdown-item '+ (location.pathname.endsWith(CPA_START_ROUTE_PATH+'/profile') ? ' active ' : '') +' pointer'} title={t("profile")}>
                                                        {t("profile")}
                                                    </Link>
                                                }
                                                {
                                                    location.pathname.startsWith(BUSINESS_START_ROUTE_PATH)
                                                    &&
                                                    <Link to={globalState.root_path+'/dashboard'} className={'dropdown-item '+ (location.pathname.startsWith(BUSINESS_START_ROUTE_PATH+'/dashboard') ? ' active ' : '') +' pointer'} title={t("subscription")}>
                                                        {t("subscription")}
                                                    </Link>
                                                }

                                                <Link to={'/logout'} className={'dropdown-item '+ (location.pathname.startsWith('/logout') ? ' active ' : '') +' pointer'} title={t("logout")}>
                                                        {t("logout")}
                                                </Link>
                                            </div>
                                        </div>
                                    :
                                        <div className="dropdown">
                                            <a className="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" title={t("login")}>{t("login")}</a>
                                            <div className="dropdown-menu">
                                                <a className="dropdown-item" href={BUSINESS_START_ROUTE_PATH+'/login'} title={t("business_login")}>
                                                    {t("business_login")}
                                                </a>
                                                <a className="dropdown-item" href={CPA_START_ROUTE_PATH+'/login'} title={t("cpa_login")}>
                                                    {t("cpa_login")}
                                                </a>
                                            </div>
                                        </div>
                            }
                        </div>
                    </div>
                </div>
            </nav>
        </header>
    );

    
}

export default Header;