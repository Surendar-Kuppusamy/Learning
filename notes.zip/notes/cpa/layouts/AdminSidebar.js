import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Outlet, Link, useLocation, useNavigate } from "react-router-dom";
import Select from 'react-select';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faComments, faFileContract, faFileInvoice, faFileLines, faGauge, faPeopleGroup, faReceipt, faUserTie } from '@fortawesome/free-solid-svg-icons';
import { HIDE_SIDEBAR, CPA_START_ROUTE_PATH, ADMIN_START_ROUTE_PATH, RETURN_className_NAMES } from '../constants/GlobalConstants';
import { toast } from 'react-toastify';
import { setCompanySelected } from '../slices/cpaSlice';
import { SbDashboard, SbReceipt, SbReport, SbInvoice, SbClient, SbTeam, SbChat, UserIcon, SbSettings, SbSubscribe, SbBlog, SbFAQ, SbEmail} from '../components/Icons';

function AdminSidebar(props) {

    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    const dispatch      =   useDispatch();
    const navigate      =   useNavigate();
    const location      =   useLocation();
    const globalState   =   useSelector(app => app.global);
    const adminState    =   useSelector(app => app.admin);

    const activeMenuClass   =   (startPath, endPath, condType, defaultClass, expClass)  => {
        if(condType === 'both' && location.pathname.startsWith(startPath) && location.pathname.endsWith(endPath)) {
            return defaultClass+' '+expClass;
        } else if(condType === 'start' && location.pathname.startsWith(startPath)) {
            return defaultClass+' '+expClass;
        } else if(condType === 'end' && location.pathname.endsWith(endPath)) {
            return defaultClass+' '+expClass;
        } else if(condType === 'or' && (location.pathname.startsWith(startPath) || location.pathname.endsWith(endPath))) {
            return defaultClass+' '+expClass;
        } else {
            return defaultClass;
        }
    }

    const navigationPath    =   (path)  => {
        if(adminState?.selected_business !== '') {
            return path;
        } else {
            return '';
        }
    }

    const settingsLinks =   [ADMIN_START_ROUTE_PATH+'/user/category', ADMIN_START_ROUTE_PATH+'/account', ADMIN_START_ROUTE_PATH+'/paymentmode', ADMIN_START_ROUTE_PATH+'/terms', ADMIN_START_ROUTE_PATH+'/add/coupon'];

    return (
        <div className="layout-sidenav">		
            <div className="sidebar">
                <ul className="sb-menu" id="accordion">
                    <li className={activeMenuClass(ADMIN_START_ROUTE_PATH+'/dashboard', '', 'start', "sb-item", 'active')}>
                        <Link to={navigationPath(ADMIN_START_ROUTE_PATH+'/dashboard')} className="sb-link" title="Dashboard">
                            <div className="sb-icon"><SbDashboard/></div>
                            <span className="sb-text">Dashboard</span>
                        </Link>
                    </li>

                    <li className="sb-item">
                        <a href="#users" className="sb-link" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="users" title="Users">
                            <div className="sb-icon"><SbClient/></div>
                            <span className="sb-text">Users</span>
                        </a>                    
                        <div className="collapse" id="users" data-bs-parent="#accordion">
                            <ul className="sub-menu">
                            <li className="sb-item">
                                    <Link to={navigationPath(ADMIN_START_ROUTE_PATH+'/user/business/list')} className={activeMenuClass(ADMIN_START_ROUTE_PATH+'/user/business/list', '', 'start', 'sb-link', 'active')} title="Business users">
                                        <span className="sb-text">Business users</span>
                                    </Link>
                                    <Link to={navigationPath(ADMIN_START_ROUTE_PATH+'/users/cpa/list')} className={activeMenuClass(ADMIN_START_ROUTE_PATH+'/users/cpa/list', '', 'start', 'sb-link', 'active')} title="CPA">
                                        <span className="sb-text">CPA</span>
                                    </Link>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li className="sb-item">
                        <a href="#settings" className="sb-link"  data-bs-toggle="collapse" role="button" aria-expanded={settingsLinks.includes(location.pathname) ? true : false} aria-controls="settings" title="Settings">
                            <div className="sb-icon"><SbSettings/></div>
                            <span className="sb-text">Settings</span>
                        </a>
                        <div className="collapse" id="settings" data-bs-parent="#accordion">
                            <ul className="sub-menu">
                                <li className="sb-item" >
                                    <Link to={navigationPath(ADMIN_START_ROUTE_PATH+'/setting/category')} className={activeMenuClass(ADMIN_START_ROUTE_PATH+'/setting/category', '', 'start', 'sb-link', 'active')} title="Category">
                                        <span className="sb-text">Category</span>
                                    </Link>
                                    <Link to={navigationPath(ADMIN_START_ROUTE_PATH+'/setting/account')} className={activeMenuClass(ADMIN_START_ROUTE_PATH+'/setting/account', '', 'start', 'sb-link', 'active')} title="Account">
                                        <span className="sb-text">Account</span>
                                    </Link>
                                    <Link to={navigationPath(ADMIN_START_ROUTE_PATH+'/setting/paymentmode')} className={activeMenuClass(ADMIN_START_ROUTE_PATH+'/setting/paymentmode', '', 'start', 'sb-link', 'active')} title="Payment mode">
                                        <span className="sb-text">Payment mode</span>
                                    </Link>
                                    <Link to={navigationPath(ADMIN_START_ROUTE_PATH+'/setting/terms')} className={activeMenuClass(ADMIN_START_ROUTE_PATH+'/setting/terms', '', 'start', 'sb-link', 'active')} title="Terms">
                                        <span className="sb-text">Terms</span>
                                    </Link>
                                    <Link to={navigationPath(ADMIN_START_ROUTE_PATH+'/setting/add/coupon')} className={activeMenuClass(ADMIN_START_ROUTE_PATH+'/setting/add/coupon', '', 'start', 'sb-link', 'active')} title="Terms">
                                        <span className="sb-text">Coupons</span>
                                    </Link>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li className={activeMenuClass(ADMIN_START_ROUTE_PATH+'/subscriptions', '', 'start', 'sb-item', 'active')}>
                        <Link to={navigationPath(ADMIN_START_ROUTE_PATH+'/subscriptions')} className="sb-link" title="Subscription">
                            <div className="sb-icon"><SbSubscribe/></div>
                            <span className="sb-text">Subscription</span>
                        </Link>
                    </li>
                    <li className={activeMenuClass(ADMIN_START_ROUTE_PATH+'/bloglist', '', 'start', 'sb-item', 'active')}>
                        <Link to={navigationPath(ADMIN_START_ROUTE_PATH+'/bloglist')} className="sb-link" title="Blog">
                            <div className="sb-icon"><SbBlog/></div>
                            <span className="sb-text">Blog</span>
                        </Link>

                    </li>
                    <li className={activeMenuClass(ADMIN_START_ROUTE_PATH+'/faqlist', '', 'start', 'sb-item', 'active')}>
                    <Link to={navigationPath(ADMIN_START_ROUTE_PATH+'/faqlist')} className="sb-link" title="FAQ">
                            <div className="sb-icon"><SbFAQ/></div>
                            <span className="sb-text">FAQ</span>
                        </Link>
                    </li>
                    <li className={activeMenuClass(ADMIN_START_ROUTE_PATH+'/emailtemplatelist', '', 'start', 'sb-item', 'active')}>
                    <Link to={navigationPath(ADMIN_START_ROUTE_PATH+'/emailtemplatelist')} className="sb-link" title="Email Template">
                            <div className="sb-icon"><SbEmail/></div>
                            <span className="sb-text">Email Template</span>
                        </Link>
                    </li>			
                </ul>
            </div>	
        </div>  
    ) 
}


export default AdminSidebar;