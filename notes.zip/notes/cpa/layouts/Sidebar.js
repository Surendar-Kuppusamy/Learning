import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Outlet, Link, useLocation, useNavigate } from "react-router-dom";
import Select from 'react-select';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { useTranslation } from 'react-i18next';
import { faComments, faFileContract, faFileInvoice, faFileLines, faGauge, faPeopleGroup, faReceipt, faUserTie } from '@fortawesome/free-solid-svg-icons';
import { HIDE_SIDEBAR, CPA_START_ROUTE_PATH, RETURN_CLASS_NAMES } from '../constants/GlobalConstants';
import { toast } from 'react-toastify';
import { setCompanySelected } from '../slices/cpaSlice';
import { SbDashboard, SbReceipt, SbReport, SbInvoice, SbClient, SbTeam, SbChat} from '../components/Icons';

function Sidebar(props) {

    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    const dispatch      =   useDispatch();
    const navigate      =   useNavigate();
    const { t, i18n }   =   useTranslation();
    const location      =   useLocation();
    const globalState   =   useSelector(app => app.global);
    const cpaState      =   useSelector(app => app.cpa);
    

    const activeMenuClass   =   (startPath, endPath, condType, defaultClass, expClass)  => {
        if(condType === 'both' && location.pathname.startsWith(startPath) && location.pathname.endsWith(endPath)) {
            return defaultClass+' '+expClass;
        } else if(condType === 'start' && location.pathname.startsWith(startPath)) {
            return defaultClass+' '+expClass;
        } else if(condType === 'end' && location.pathname.endsWith(endPath)) {
            return defaultClass+' '+expClass;
        } else if(condType === 'or' && (location.pathname.startsWith(startPath) || location.pathname.endsWith(endPath))) {
            return defaultClass+' '+expClass;
        } else {
            return defaultClass;
        }
    }

    const navigationPath    =   (path)  => {
        if(cpaState?.selected_business !== '') {
            return path;
        } else {
            return '';
        }
    }
    

    if(!HIDE_SIDEBAR.includes(location.pathname) && location.pathname.startsWith(CPA_START_ROUTE_PATH) && globalState.user_detail.sub !== undefined && globalState.is_cpa_authenticated) {
        return (
            /* <div className={'layout-sidenav '+ (HIDE_SIDEBAR.includes(activeNav) && ' d-none')+ ' '+ (globalState.user_detail.sub === undefined && ' d-none')+' '}></div> */
            <div className="layout-sidenav">
                <div className="sidebar">
                    <ul className="sb-menu">
                        <li className={activeMenuClass(CPA_START_ROUTE_PATH+'/company', '/dashboard', 'both', 'sb-item pointer ', 'active')}>
                            
                            <Link to={navigationPath(CPA_START_ROUTE_PATH+'/company/'+cpaState?.selected_business+'/dashboard')} className="sb-link" title={t("dashboard")}>
                                <div className="sb-icon">
                                    <SbDashboard/>
                                </div>
                                <span className="sb-text">{t("dashboard")}</span>
                            </Link>
                        </li>
                        
                        <li className={activeMenuClass(CPA_START_ROUTE_PATH+'/company', '/receipts', 'both', 'sb-item pointer ', 'active')}>
                            <Link to={navigationPath(CPA_START_ROUTE_PATH+'/company/'+cpaState?.selected_business+'/receipts')} className="sb-link" title={t("receipts")}>
                                <div className="sb-icon">
                                    <SbReceipt/>
                                </div>
                                <span className="sb-text">{t("receipts")}</span>
                            </Link>
                        </li>

                        <li className={activeMenuClass(CPA_START_ROUTE_PATH+'/company', '/report', 'both', 'sb-item pointer ', 'active')}>
                            <Link to={navigationPath(CPA_START_ROUTE_PATH+'/company/'+cpaState?.selected_business+'/report')} className="sb-link" title={t("reports")}>
                                <div className="sb-icon">
                                    <SbReport/>
                                </div>
                                <span className="sb-text">{t("reports")}</span>
                            </Link>
                        </li>
                        <li className={activeMenuClass(CPA_START_ROUTE_PATH+'/company', '/chatbox', 'both', 'sb-item pointer ', 'active')}>
                            <Link to={navigationPath(CPA_START_ROUTE_PATH+'/company/'+cpaState?.selected_business+'/chatbox')} className="sb-link" title={t("reports")}>
                                <div className="sb-icon">
                                    <SbChat/>
                                </div>
                                <span className="sb-text">{t("chat")}</span>
                                <div className='msg-count'>1</div> 
                            </Link>
                        </li>
                        {/* <li className="sb-item">
                            <a href="#" className="sb-link" title="invoices">
                                <div className="sb-icon">
                                    <SbInvoice/>
                                </div>
                                <span className="sb-text">{t("invoices")}</span>
                            </a>
                        </li>
                        <li className="sb-item">
                            <a href="#" className="sb-link" title="clients">
                                <div className="sb-icon">
                                    <SbClient/>
                                </div>
                                <span className="sb-text">{t("clients")}</span>
                            </a>
                        </li> */}
                        <li className="sb-item">
                            <a href="#" className="sb-link" title={t("team_members")}>
                                <div className="sb-icon">
                                    <SbTeam/>
                                </div>
                                <span className="sb-text">{t("team_members")}</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        );
    } else {
        return (
            <div className="d-none"></div>
        )
    }   
}

export default Sidebar;