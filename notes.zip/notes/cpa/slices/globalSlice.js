import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { isEmpty, findIndex } from 'lodash';
import { Amplify, DataStore, Auth, Predicates, Hub, Logger, API, Storage, SortDirection, graphqlOperation } from "aws-amplify";
import * as AWS from 'aws-sdk';
import awsmobile from '../aws-exports';
import { updatePaymentStatus, updateSubscriptionStatus } from './businessSlice';
import { ALERT_MESSAGES } from "../constants/AlertMessages";
import { CPACompany, TeamMemberUser, CPAUser, CompanyUser } from "../models";
import { listCategories, listReceiptByUserIdTotalSort, listReceiptByUserIdDateSort, subscriptionProcess, listCompanyUsers, listCPACompanies, getCompanyUser, fetchData, getCPAUser, getCPACompany } from "../graphql/queries";
import { ADMIN_START_ROUTE_PATH, BUSINESS_START_ROUTE_PATH, CPA_START_ROUTE_PATH, DEFAULT_FETCH_DATA_LAMBDA_PARAMETERS, GRAPHQL_MAXIMUM_LIMIT, GRAPHQL_UNLIMITED_LIMIT } from "../constants/GlobalConstants";
import { updateCPACompany, updateCPADetails, updateCompanyUser, updateCPAUser } from "../graphql/mutations";
import { getRecordByID, getDataViaGraphql, updateRecordByID } from './Functions/CommonFunctions';


const logger = new Logger('My-Logger');

function stringToBoolean(value){
    return (String(value).toLowerCase() === 'true');
}

function getRootPath() {
    const isRootPathExists  =   localStorage.getItem('root_path');
    //console.log(window.location.pathname, 'window.location.pathname');
    const pathName          =   window.location.pathname;
    if(pathName.startsWith(CPA_START_ROUTE_PATH)) {
        return CPA_START_ROUTE_PATH;
    } else if(pathName.startsWith(BUSINESS_START_ROUTE_PATH)) {
        return BUSINESS_START_ROUTE_PATH;
    } else if(pathName.startsWith(ADMIN_START_ROUTE_PATH)) {
        return ADMIN_START_ROUTE_PATH;
    } else if(isRootPathExists) {
        return localStorage.getItem('root_path');
    } else {
        return CPA_START_ROUTE_PATH;
    }
}

/* async function logWrite() {
    const loggerName        =   'ExpenseTrackerLogger/errorLogs.log';
    const currentLogs       =   await Storage.get(loggerName);
    const uploadStatus      =   await Storage.put(profileImage, data["userLogo"][0], { contentType: data["userLogo"][0]["type"] });
} */

function clearLocalStorage() {
    localStorage.removeItem('is_user_authenticated');
    localStorage.removeItem('is_cpa_authenticated');
    localStorage.removeItem('is_business_authenticated');
    localStorage.removeItem('is_admin_authenticated');
    localStorage.removeItem('user_detail');
    localStorage.removeItem('is_datastore_ready');
    localStorage.removeItem('sync_datastore');
    localStorage.removeItem('cpa_company_error');
    localStorage.removeItem('az_redirect_url');
    localStorage.removeItem('az_redirect_for');
    localStorage.removeItem('root_path');
    localStorage.removeItem('notificarion_alert');
}

const resetValues     =   {
    'site_loader'                   :   false,
    'page_loader'                   :   false,
    'first_load'                    :   true,
    'manual_site_loader'            :   false,
    'is_logout'                     :   false,
    'pending_actions'               :   [],
    'cpa_company_error'             :   '',
    'update_business_list'          :   false,
    'business_list'                 :   [],
    'az_redirect_url'               :   '',
    'az_redirect_for'               :   '',
    'root_path'                     :   '',
    'user_detail'                   :   {},
    'is_user_authenticated'         :   false,
    'is_cpa_authenticated'          :   false,
    'is_business_authenticated'     :   false,
    'is_admin_authenticated'        :   false,
    'sync_datastore'                :   false,
    'is_datastore_ready'            :   false,
    'isSessionNotExists'            :   false,
    'notificarion_alert'            :   ''
}


const initialState = {
    'site_loader'                   :   false,
    'page_loader'                   :   false,
    'first_load'                    :   true,
    'manual_site_loader'            :   false,
    'is_logout'                     :   false,
    'pending_actions'               :   [],
    'cpa_company_error'             :   '',
    'update_business_list'          :   false,
    'business_list'                 :   [],
    'az_redirect_url'               :   localStorage.getItem('az_redirect_url')
                                            ? localStorage.getItem('az_redirect_url')
                                            : '',
    'az_redirect_for'               :   localStorage.getItem('az_redirect_for')
                                            ? localStorage.getItem('az_redirect_for')
                                            : '',
    'root_path'                     :   getRootPath(),
    'user_detail'                   :   localStorage.getItem('user_detail')
                                            ? JSON.parse(localStorage.getItem('user_detail'))
                                            : {},
    'is_user_authenticated'         :   localStorage.getItem('is_user_authenticated')
                                            ? stringToBoolean(localStorage.getItem('is_user_authenticated'))
                                            : false,
    'is_cpa_authenticated'          :   localStorage.getItem('is_cpa_authenticated')
                                            ? stringToBoolean(localStorage.getItem('is_cpa_authenticated'))
                                            : false,
    'is_business_authenticated'     :   localStorage.getItem('is_business_authenticated')
                                            ? stringToBoolean(localStorage.getItem('is_business_authenticated'))
                                            : false,
    'is_admin_authenticated'        :   localStorage.getItem('is_admin_authenticated')
                                            ? stringToBoolean(localStorage.getItem('is_admin_authenticated'))
                                            : false,
    'sync_datastore'                :   localStorage.getItem('sync_datastore')
                                            ? stringToBoolean(localStorage.getItem('sync_datastore'))
                                            : false,
    'is_datastore_ready'            :   localStorage.getItem('is_datastore_ready')
                                            ? stringToBoolean(localStorage.getItem('is_datastore_ready'))
                                            : false,
    'isSessionNotExists'            :   false,
    'notificarion_alert'            :   localStorage.getItem('notificarion_alert')
                                            ?   localStorage.getItem('notificarion_alert')
                                            :   ''
};

export const getCurrentUser = createAsyncThunk(
    "get/current/user",
    (data, { getState, rejectWithValue }) => {
        return new Promise((resolve, reject) => {
            const tempState =   getState();
            try {
                Auth.currentAuthenticatedUser(/* { bypassCache: true } */)
                //Auth.currentAuthenticatedUser()
                    .then(currentUser => { 
                        return resolve({ status: true, currentUser: currentUser, "root_path": tempState["global"]["root_path"]  })
                    })
                    .catch((e) => {
                        console.log(e, 'getCurrentUser');
                        return resolve({ status: false, currentUser: {}, "root_path": tempState["global"]["root_path"]  })
                    });
            } catch(e) {
                console.log(e, 'getCurrentUser');
            }
            
        });
    }
);


export const signUpUser = createAsyncThunk(
    "user/sigup",
    async (data, { getState, rejectWithValue }) => {
        //console.log('Post Data', data);
        return new Promise((resolve, reject) => {
            var signUpData = {
                username: data.username,
                password: data.password,
                attributes: {
                    name                    :   data?.fullname,
                    email                   :   data?.email,
                    phone_number            :   data?.phone_number,
                    'birthdate'             :   '',
                    'custom:role'           :   data?.customer_role,
                    'custom:country'        :   data?.country,
                    'custom:countryCode'    :   data?.country_code,
                    'custom:step'           :   '0',
                    'custom:company_id'     :   data?.company_id,
                    'custom:isSubscribed'   :   'false'
                },
                autoSignIn: { // optional - enables auto sign in after user is confirmed
                    enabled: true,
                }
            }
            Auth.signUp({ ...signUpData }).then(userDetails => {
                return resolve({ status: 'success', data: userDetails });
            }).catch(err => {
                console.log('signUpUser', err);
                return resolve({ status: 'error', data: err });
            });
        });
    }
);

export const autoSignInUser = createAsyncThunk(
    "user/auto/signin",
    async (data, { getState, rejectWithValue }) => {
        return data;
    }
);

export const loginUser = createAsyncThunk(
    "user/login",
    async (data, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {
            console.log('Login Details', data);
            Auth.signIn(data.username, data.password, { 'role': data.role }).then(user => {
                return resolve({ status: 'success', data: user });
            }).catch(err => {
                return resolve({ status: 'error', data: err });
            });
        });        
    }
);

export const logoutUser = createAsyncThunk(
    "user/logout",
    async(data, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {
            try {
                console.log("Session logout Start");
                Auth.signOut().then(res => {
                    console.log("Session logout Completed");
                    resolve(true);
                }).catch(err => {
                    console.log("Session logout failed", err);
                    resolve(false);
                });
            } catch(e) {
                console.log("Session logout failed with error");
                console.log('logoutUser', e)
                rejectWithValue(e);
            }
        });
    }
);

export const autoLogoutUser = createAsyncThunk(
    "user/auto/logout",
    async(data, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {
            try {
                console.log("Datastore clear");
                DataStore.clear().then((res) => {
                    console.log('DataStore.cleared successfully ====>', res);
                    DataStore.stop().then(res => {
                        console.log('DataStore.stopped successfully ====>', res);
                        return resolve(true);
                    }).catch(err => {
                        return resolve(false);
                    });
                }).catch((err) => {
                    console.log('DataStore.failed ====>', err);
                    return resolve(false);
                });
                console.log('Successfully Logged out');

                /* setTimeout(() => {
                    return resolve(false);
                }, 120000); */

            } catch(e) {
                console.log('autoLogoutUser', e);
                resolve(false);
                rejectWithValue(e);
            }
        });
    }
);


export const reSendVerificationCode = createAsyncThunk(
    "user/resend/verification",
    async (postData, { getState, rejectWithValue }) => {
        return new Promise((resolve, reject) => {
            try {
                Auth.currentAuthenticatedUser()
                    .then(user => Auth.verifyUserAttribute(user, postData.verification_type))
                    .then(data => {
                        console.log('Verification send data', data);
                        resolve({ status: 200, message: ALERT_MESSAGES['verification_code_resend'] });
                    })
                    .catch(err => {
                        console.log('Error on verification send', err);
                        reject(err);
                    });
            } catch (error) {
                console.log('error confirming sign up', error);
                return reject(error);
            }
        });
    }
);


export const sendVerificationCode = createAsyncThunk(
    "user/verify/code/send",
    async (postData, { getState, rejectWithValue }) => {
        return new Promise((resolve, reject) => {
            try {
                Auth.currentAuthenticatedUser()
                    .then(user => Auth.verifyUserAttribute(user, postData.verification_type))
                    .then(data => {
                        console.log('Verification send data', data);
                        resolve(true);
                    })
                    .catch(err => {
                        console.log('Error on verification send', err);
                        resolve(false);
                    });
            } catch (error) {
                console.log('error confirming sign up', error);
                return reject(error);
            }
        });
    }
);


export const updateUserAttribue = createAsyncThunk(
    "update/user/attribute",
    async (postData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {
            try {
                const tempState   =   getState();

                console.log("Testing", postData);

                if(postData["verification_type"] === undefined) {
                    return resolve({ status: 400, message: postData  });
                } else if(postData["verification_type"] !== 'email' && postData["verification_type"] !== 'phone_number') {
                    return resolve({ status: 400, message: postData  });
                } else {
                    const updateValue   =   (postData["verification_type"] === 'email')
                                                ? tempState['global']['user_detail']['email']
                                                : tempState['global']['user_detail']['phone_number'];
                    const updateType    =   postData["verification_type"];


                    const user = await Auth.currentAuthenticatedUser();
                    await Auth.updateUserAttributes(user, {
                        [updateType]: updateValue
                    })
                    .then(() => {
                        return resolve({ status: 200, message: user  });
                    })
                    .catch((e) => {
                        console.log('failed with error', e);
                        return resolve({ status: 400, message: e  });
                    });
                }
            } catch(error) {
                console.log("Something went wrong.", error);
                return resolve({ status: 400, name: error.name, message: error.message });
            }
        });
    }
)


export const verifyUserCode = createAsyncThunk(
    "verify/user/emailorphone/code",
    async (postData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {

            try {
                Auth.verifyCurrentUserAttributeSubmit(postData.verification_type, postData.code).then(response => {
                    console.log("Response", response);
                    return resolve({ status: 200, message: ALERT_MESSAGES['code_verification_success'], response: response, data: postData });
                }).catch(e => {
                    console.log('Caught error', e.name);
                    return resolve({ status: 400, name: e.name, message: e.message });
                });

            } catch(error) {
                console.log("Something went wrong.", error);
                return resolve({ status: 400, name: error.name, message: error.message });
            }
        });
    }
)

export const verifySignUpCode = createAsyncThunk(
    "user/verify/code",
    async (postData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {
            try {
                const tempState   =   getState();
                console.log('Verify Code', postData.verification_type, postData.code, tempState);

                if(tempState['global']['user_detail'] !== undefined && tempState['global']['user_detail']['custom:step'] !== undefined && parseInt(tempState['global']['user_detail']['custom:step']) >= 1) {

                    Auth.currentAuthenticatedUser()
                        .then(user => {
                            Auth.verifyUserAttributeSubmit(user, postData.verification_type, postData.code)
                                .then(data =>
                                    Auth.currentAuthenticatedUser()
                                        .then(currentUser => {
                                            console.log('Verification', currentUser);
                                            return resolve({ status: 200, message: ALERT_MESSAGES['code_verification_success'], currentUser: currentUser, 'reverify': true })
                                        })
                                )
                                .catch(e => {
                                    console.log('Caught error', e.name);
                                    return resolve({ status: 400, name: e.name, message: e.message })
                                });
                        });

                } else {
                    Auth.currentAuthenticatedUser()
                    .then(user => {
                        Auth.verifyUserAttributeSubmit(user, postData.verification_type, postData.code)
                            .then(data =>
                                Auth.updateUserAttributes(user, {
                                    'custom:step': "1",
                                }),
                            )
                            .then(data => 
                                Auth.currentAuthenticatedUser()
                                .then(currentUser => {
                                    console.log('Verification', currentUser);
                                    return resolve({ status: 200, message: ALERT_MESSAGES['code_verification_success'], currentUser: currentUser, 'reverify': false })
                                })
                            ).catch(e => {
                                console.log('Caught error', e.name);
                                return resolve({ status: 400, name: e.name, message: e.message })
                            });
                    });
                }
            } catch (error) {
                console.log('error confirming sign up', error);
                return reject(error);
            }
        });
    }
);

export const updateUserStep = createAsyncThunk(
    "update/user/step",
    async (postData, { getState, rejectWithValue }) => {
        return new Promise((resolve, reject) => {
            try {
                Auth.currentAuthenticatedUser().then(user => {
                    Auth.updateUserAttributes(user, {
                        'custom:step': postData?.step
                    }).then(result => {
                        resolve(postData?.step);
                    })
                });
            } catch (error) {
                console.log('error confirming sign up', error);
                return reject(error);
            }
        });
    }
);


export const changeUserPassord = createAsyncThunk(
    "change/user/password",
    async (formData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {
            Auth.currentAuthenticatedUser()
                .then(async user => {
                    try {
                        await Auth.changePassword(user, formData['old_password'], formData['new_password']);
                        resolve({ status: true, message: ALERT_MESSAGES['change_password_success']})
                    } catch(e) {
                        resolve({ status: false, message: e.message, error: e})
                    }
                })
                .then(data => console.log(data))
                .catch(err => resolve({ status: false, message: err, error: err}));
        });
        
    }
);


export const forgotUserPassord = createAsyncThunk(
    "forgot/user/password",
    async (formData, { getState, rejectWithValue }) => {
        return new Promise((resolve, reject) => {
            Auth.forgotPassword(formData['username'])
                .then(data => resolve({ status: true, message: ALERT_MESSAGES['forgot_password_code_send'], data: data }))
                .catch(err => resolve({ status: false, message: err.message, error: err}));
        });
    }
);

export const forgotUserPasswordSubmit = createAsyncThunk(
    "forgot/user/password/submit",
    async (formData, { getState, rejectWithValue }) => {
        return new Promise((resolve, reject) => {
            Auth.forgotPasswordSubmit(formData['username'], formData['code'], formData['new_password'])
                .then(data => resolve({ status: true, message: ALERT_MESSAGES['reset_password_success'], data: data }))
                .catch(err => resolve({ status: false, message: err.message, error: err}));
        });
    }
);


export const saveBusinessUserInfo = createAsyncThunk(
    "save/business/info",
    async (data, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {
            try {

                console.log(data, "Form Data");
                let businessPicture = '';

                if(data["userLogo"] !== undefined && data["userLogo"] !== null) {
                    const profileImageName  =   'businessProfile/'+data["id"];
                    const extension         =   data["userLogo"][0]["name"].substring(data["userLogo"][0]["name"].lastIndexOf('.') + 1);
                    const profileImage      =   profileImageName;
                    const uploadStatus      =   await Storage.put(profileImage, data["userLogo"][0], { contentType: data["userLogo"][0]["type"] });
                    businessPicture         =   await Storage.get(profileImage);
                }

                let companyUserDetails    =   {
                    businessName        :   data.name,
                    businessNumber      :   data.businessNumber,
                    businessAddress     :   data.officeAddress,
                    geoLocation         :   data.geoLocation,
                    region              :   data.region,
                    gst_hst             :   data.gst_hst
                }

                if(data["userLogo"] !== undefined && data["userLogo"] !== null) {
                    companyUserDetails["businessPicture"]   =   "businessProfile/"+data["id"];
                }

                const res       =  updateRecordByID(getCompanyUser, "getCompanyUser", updateCompanyUser, "updateCompanyUser",  data["id"], companyUserDetails);

                /* const original  =   await DataStore.query(CompanyUser, data.id);
                const res       =   await DataStore.save(
                    CompanyUser.copyOf(original, updated => {
                        updated.businessName        =   data.name;
                        updated.businessNumber      =   data.businessNumber;
                        updated.businessAddress     =   data.officeAddress;
                        updated.geoLocation         =   data.geoLocation;
                        updated.region              =   data.region;
                        updated.gst_hst             =   data.gst_hst;
                        if(data["userLogo"] !== undefined && data["userLogo"] !== null) {
                            updated.businessPicture =   "businessProfile/"+data["id"];
                        }
                    })
                ); */

                await Auth.currentAuthenticatedUser().then(async(user) => {
                    await Auth.updateUserAttributes(user, {
                        'custom:step': "2"
                    });
                });

                return resolve(res);

            } catch(e) {
                console.log('saveBusinessUserInfo', e);
                rejectWithValue(e.message);
            }
        });
    }
);


export const saveCPAUserInfo = createAsyncThunk(
    "save/cpa/info",
    async (data, { getState, rejectWithValue }) => {
        
        return new Promise(async(resolve, reject) => {

            try {
                
                //Update CPA user business details
                /* const original  =   await DataStore.query(CPAUser, data.id);
                const res       =   await DataStore.save(
                    CPAUser.copyOf(original, updated => {
                        updated.businessName        =   data.name;
                        updated.businessNumber      =   data.businessNumber;
                        updated.officeAddress       =   data.officeAddress;
                        updated.geoLocation         =   data.geoLocation;
                        updated.region              =   data.region;
                    })
                ); */

                const updateUserData    =   {
                    "businessName"      :   data.name,
                    "businessNumber"    :   data.businessNumber,
                    "officeAddress"     :   data.officeAddress,
                    "geoLocation"       :   data.geoLocation,
                    "region"            :   data.region
                }
                const res       =  updateRecordByID(getCPAUser, "getCPAUser", updateCPAUser, "updateCPAUser",  data.id, updateUserData);

                console.log('Data updated successfully');

                //Update 'custom:step' and join Comapny with this CPA process
                await Auth.currentAuthenticatedUser().then(async(user) => {

                    //Check is the signup with Comapny ID or not
                    if(user.attributes['sub'] !== undefined && user.attributes['sub'] !== '' && user.attributes['custom:company_id'] !== undefined && user.attributes['custom:company_id'] !== '') {

                        const companyID     =   user.attributes['custom:company_id'];
                        const CPAID         =   user.attributes['sub'];
                        const CPAEmail      =   user.attributes['email'];

                        console.log('companyID', companyID, 'CPAID', CPAID, 'CPAEmail', CPAEmail);

                        //const company       =   await DataStore.query(CompanyUser, companyID);

                        const currentCompanyStatus  =   await new Promise(async(resolve, reject) => {

                            const filter    =   {
                                "cpaID": {
                                    "eq": CPAID
                                },
                                "joined": {
                                    "eq": 0
                                },
                                "isDeleted": {
                                    "eq": false
                                },
                                "refCID": {
                                    "eq": companyID
                                }
                            };

                            const cpaCompanies  =   await getDataViaGraphql(listCPACompanies, "listCPACompanies", { filter: filter, limit: GRAPHQL_UNLIMITED_LIMIT });

                            /* const cpaCompanies  =   await DataStore.query(CPACompany, cc => cc.cpaID("eq", CPAID).joined("eq", 0).isDeleted("eq", false).refCID("eq", companyID)); */

                            return resolve(cpaCompanies);

                        });

                        const checkEmailMatchedRequest  =   await new Promise(async(resolve, reject) => {

                            const filter    =   {
                                "email": {
                                    "eq": CPAEmail
                                },
                                "joined": {
                                    "eq": 0
                                },
                                "isDeleted": {
                                    "eq": false
                                },
                                "refCID": {
                                    "eq": companyID
                                }
                            };

                            const cpaCompanies  =   await getDataViaGraphql(listCPACompanies, "listCPACompanies", { filter: filter, limit: GRAPHQL_UNLIMITED_LIMIT });

                            /* const cpaCompanies  =   await DataStore.query(CPACompany, cc => cc.email("eq", CPAEmail).joined("eq", 0).isDeleted("eq", false).refCID("eq", companyID)); */

                            resolve(cpaCompanies);
                            
                        });

                        console.log('currentCompanyStatus', currentCompanyStatus, 'checkEmailMatchedRequest', checkEmailMatchedRequest);

                        if(currentCompanyStatus.length === 0 && checkEmailMatchedRequest.length > 0) {

                            /* const originalCPACompany    =   await DataStore.query(CPACompany, checkEmailMatchedRequest[0]["id"]);
                            await DataStore.save(
                                    CPACompany.copyOf(originalCPACompany, updated => {
                                    updated.joined      =   1;
                                    updated.cpaID       =   CPAID;
                                    updated.joinedDate  =   new Date().toISOString()
                                })
                            ); */

                            const updatCPACompanyData    =   {
                                "joined"    : 1,
                                "cpaID"     : CPAID,
                                "joinedDate": new Date().toISOString()
                            }
                            const res       =  updateRecordByID(getCPACompany, "getCPACompany", updateCPACompany, "updateCPACompany",  checkEmailMatchedRequest[0]["id"], updatCPACompanyData);

                            const stopDataStore     =   await DataStore.stop();
                            const startDataStore    =   await DataStore.start();

                        } else if(currentCompanyStatus.length > 0) {

                            console.log(ALERT_MESSAGES['company_already_joined']);
                            localStorage.setItem('cpa_company_error', ALERT_MESSAGES['company_already_joined']);

                        } else if(checkEmailMatchedRequest.length === 0) {

                            console.log(ALERT_MESSAGES['cpa_company_request_email_invalid']);
                            localStorage.setItem('cpa_company_error', ALERT_MESSAGES['cpa_company_request_email_invalid']);

                        }
                    }

                    await Auth.updateUserAttributes(user, {
                        'custom:step': "2"
                    });
                });

                resolve(res);
            } catch(e) {
                console.log('saveCPAUserInfo', e);
                rejectWithValue(e.message);
            }
        });
    }
);

export const getCPABusinessIDs = createAsyncThunk(
    "get/business/ids",
    async (postData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {

            try {

                let subscripeGraphql;

                const tempState =   getState();

                DEFAULT_FETCH_DATA_LAMBDA_PARAMETERS["extraDetail"]    =   "getCPABusinessIDs";

                DEFAULT_FETCH_DATA_LAMBDA_PARAMETERS["cpaCompanyFilter"]["cpaUserID"]   =   tempState['global']['user_detail']['sub'];
                DEFAULT_FETCH_DATA_LAMBDA_PARAMETERS["cpaCompanyFilter"]["email"]       =   tempState['global']['user_detail']['email'];

                subscripeGraphql = API.graphql(
                    graphqlOperation(fetchData, {
                        args :  DEFAULT_FETCH_DATA_LAMBDA_PARAMETERS
                    }),
                ).then(result => {
                    try {
                        const businessIDs   =   JSON.parse(result.data.fetchData);
                        if(businessIDs["status"] === 'success' && businessIDs["data"] !== undefined) {
                            console.log('Get business IDs ', businessIDs["data"]);
                            resolve(businessIDs["data"]);
                        } else {
                            resolve([]);
                        }
                    } catch(error) {
                        console.log('Something went wrong on getCPABusinessIDs', error);
                        resolve([]);
                    }
                }).catch(error => {
                    console.log('Something went wrong on getCPABusinessIDs', error);
                    resolve([]);
                });
            } catch(error) {
                console.log('Something went wrong on getCPABusinessIDs', error);
                resolve([]);
            }
        });
    }
);

export const updateProfile = createAsyncThunk(
    "update/profile",
    async (postData, { getState, rejectWithValue }) => {

        return new Promise(async(resolve, reject) => {

            const tempState =   getState();

            const isPhoneVerified   =   tempState['global']['user_detail']['phone_number_verified'];
            const currentPhoneNum   =   tempState['global']['user_detail']['phone_number'];
            const currentEmail      =   tempState['global']['user_detail']['email'];
            const isEmailVerified   =   tempState['global']['user_detail']['email_verified'];

            const MODEL             =   (postData["location"].startsWith(CPA_START_ROUTE_PATH)) ? CPAUser : CompanyUser;

            let userProfileInfo   =   {
                "businessName"      :   postData.businessName,
                "businessNumber"    :   postData.businessNumber,
                "geoLocation"       :   postData.geoLocation,
                "region"            :   postData.region,
                /* "phoneNumber"       :   postData.phoneNumber,
                "email"             :   postData.email */
            }

            if(postData["location"].startsWith(CPA_START_ROUTE_PATH)) {
                userProfileInfo["officeAddress"]        =   postData.officeAddress;
            } else {
                userProfileInfo["businessAddress"]      =   postData.officeAddress;
            }

            if(postData["location"].startsWith(CPA_START_ROUTE_PATH)) {
                const res       =  updateRecordByID(getCPAUser, "getCPAUser", updateCPAUser, "updateCPAUser", postData["id"], userProfileInfo);
            } else {
                const res       =  updateRecordByID(getCompanyUser, "getCompanyUser", updateCompanyUser, "updateCompanyUser",  postData["id"], userProfileInfo);
            }

            /* const original  =   await DataStore.query(MODEL, postData.id);
            const res       =   await DataStore.save(
                MODEL.copyOf(original, updated => {
                    if(postData["location"].startsWith(CPA_START_ROUTE_PATH)) {
                        updated.officeAddress       =   postData.officeAddress;
                    } else {
                        updated.businessAddress     =   postData.officeAddress;
                    }
                    updated.businessName        =   postData.businessName;
                    updated.businessNumber      =   postData.businessNumber;
                    updated.geoLocation         =   postData.geoLocation;
                    updated.region              =   postData.region;
                    //updated.phoneNumber         =   postData.phoneNumber;
                    //updated.email               =   postData.email;
                })
            ); */

            console.log("isEmailVerified", isEmailVerified, currentEmail, postData["email"]);

            if(!isPhoneVerified && (currentPhoneNum !== postData.phoneNumber)) {
                await Auth.currentAuthenticatedUser().then(user => {
                    Auth.updateUserAttributes(user, {
                        'phone_number': postData.phoneNumber
                    });
                });

                const updatePhoneNumber     =   {
                    "phoneNumber": postData.phoneNumber
                }

                if(postData["location"].startsWith(CPA_START_ROUTE_PATH)) {
                    const res       =  updateRecordByID(getCPAUser, "getCPAUser", updateCPAUser, "updateCPAUser", postData["id"], updatePhoneNumber);
                } else {
                    const res       =  updateRecordByID(getCompanyUser, "getCompanyUser", updateCompanyUser, "updateCompanyUser",  postData["id"], updatePhoneNumber);
                }

                /* const resPhone   =   await DataStore.save(
                    MODEL.copyOf(original, updated => {
                        updated.phoneNumber         =   postData.phoneNumber;
                    })
                ); */

                return resolve({ 'isEmailChanged': false  });
            } else if(!isEmailVerified &&  (currentEmail !== postData.email)) {

                const user = await Auth.currentAuthenticatedUser();

                await Auth.updateUserAttributes(user, {
                    'email': postData["email"],
                }).then(() => {
                    resolve({ 'isEmailChanged': true  });
                }).catch((e) => {
                    resolve({ 'isEmailChanged': false  });
                    console.log('failed with error', e);
                });
            } else {
                resolve({ 'isEmailChanged': false  });
            }
        });
    }
);

export const verifyCode = createAsyncThunk(
    "verify/email/code",
    async (postData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {

            const tempState =   getState();
            await Auth.verifyCurrentUserAttributeSubmit('email', postData.code)
                .then(async() => {
                    console.log('email verified');

                    const updateData    =   {
                        "email": postData.email
                    };

                    if(postData["location"].startsWith(CPA_START_ROUTE_PATH)) {

                        const res   =   await updateRecordByID(getCPAUser, "getCPAUser", updateCPAUser, "updateCPAUser", postData.id, updateData);

                    } else if(postData["location"].startsWith(BUSINESS_START_ROUTE_PATH)) {

                        const res   =   await updateRecordByID(getCompanyUser, "getCompanyUser", updateCompanyUser, "updateCompanyUser", postData.id, updateData);

                    }

                    /* const original  =   await DataStore.query(CPAUser, postData.id);
                    const res       =   await DataStore.save(
                        CPAUser.copyOf(original, updated => {
                            updated.email   =   postData.email;
                        })
                    ); */

                    return resolve({ status: 200, name: '', message: '' })
                }).catch((e) => {
                    return resolve({ status: 400, name: e.name, message: e.message })
                    console.log('failed with error', e);
                });
        });
    }
);

export const getProfileData = createAsyncThunk(
    "get/profile/data",
    async (params, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {
            if(params.location.startsWith(CPA_START_ROUTE_PATH)) {
                const profileData   =   await DataStore.query(CPAUser, params["id"]);
                resolve(profileData);
            } else {
                const profileData   =   await DataStore.query(CompanyUser, params["id"]);
                console.log('profileData', profileData);
                resolve(profileData);
            }
        });
    }
);


export const updateUserAttributes = createAsyncThunk(
    "update/user/attributes",
    async (postData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {
            var cognitoidentityserviceprovider = new AWS.CognitoIdentityServiceProvider();

            var params = {
                UserAttributes: [{ Name: 'custom:step', Value: postData.step.toString() }],
                UserPoolId: awsmobile.aws_user_pools_id,
                Username: postData.username
            };

            cognitoidentityserviceprovider.adminUpdateUserAttributes(params, function(err, data) {
                if(err) {
                    console.log(err, err.stack); // an error occurred
                    rejectWithValue(err.message);
                } else {
                    console.log('Step update successfully', data);
                    resolve(data);
                }
            });
        })    
    }
);

/* export const deleteUser = createAsyncThunk(
    "delete/user",
    async (postData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {
            var cognitoidentityserviceprovider = new AWS.CognitoIdentityServiceProvider();

            var params = {
                UserPoolId: awsmobile.aws_user_pools_id,
                Username: postData.username
            };

            cognitoidentityserviceprovider.adminDeleteUser(params, function(err, data) {
                if(err) {
                    console.log(err, err.stack); // an error occurred
                    resolve({status: false, message: err.message });
                } else {
                    console.log('User deleted successfully', data);
                    resolve({status: true, message: 'User deleted successfully'});
                }
            });
        })    
    }
); */

export const deleteUser = createAsyncThunk(
    "delete/user",
    async (postData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {
            try {
                const result = await Auth.deleteUser();
                resolve({ status: true, message: ALERT_MESSAGES['delete_user'] })
            } catch (error) {
                console.log('Error deleting user', error);
                resolve({ status: true, message: error.message, error:error });
            }
        });
    }
);

//Don't use it
export const addCustomAttributes = createAsyncThunk(
    "add/user/custom/attribute",
    async (postData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {
            var cognitoidentityserviceprovider = new AWS.CognitoIdentityServiceProvider();

            var params = {
                CustomAttributes: [
                  {
                    AttributeDataType: 'String',
                    DeveloperOnlyAttribute: false,
                    Mutable: true,
                    Name: 'custom:step',
                    Required: false,
                  },
                ],
                UserPoolId: awsmobile.aws_user_pools_id,
              };

            cognitoidentityserviceprovider.addCustomAttributes(params, function(err, data) {
                if(err) {
                    console.log(err, err.stack); // an error occurred
                    /* rejectWithValue(err.message); */
                    resolve({status: false, message: err.message });
                } else {
                    console.log('User deleted successfully', data);
                    resolve({status: true, message: 'Attribute added successfully.'});
                }
            });
        })    
    }
);


const globalSlice = createSlice({
    name: "global",
    initialState,
    reducers: {
        siteLoader: (state, action) => {
            state['site_loader'] = action.payload;
        },
        setSessionValue: (state, action) => {
            state['isSessionNotExists'] = action.payload;
        },
        setUserDetails: (state, action) => {
            state["user_detail"]    =   action.payload;
        },
        setRedirectDetails: (state, action) => {
            state["az_redirect_url"]    =   action.payload["az_redirect_url"];
            state["az_redirect_for"]    =   action.payload["az_redirect_for"];

            localStorage.setItem("az_redirect_url", action.payload["az_redirect_url"]);
            localStorage.setItem("az_redirect_for", action.payload["az_redirect_for"]);
        },
        resetRedirectDetails: (state, action) => {
            state["az_redirect_url"]    =   "";
            state["az_redirect_for"]    =   "";

            localStorage.removeItem('az_redirect_url');
            localStorage.removeItem('az_redirect_for');
        },
        resetState: (state, action) => {

            clearLocalStorage();

            state['cpa_company_error']             =   '';
            state['update_business_list']          =   false;
            state['business_list']                 =   [];
            state['az_redirect_url']               =   '';
            state['az_redirect_for']               =   '';
            state['user_detail']                   =   {};
            state['is_user_authenticated']         =   false;
            state['is_cpa_authenticated']          =   false;
            state['is_business_authenticated']     =   false;
            state['is_admin_authenticated']        =   false;
            state['sync_datastore']                =   false;
            state['is_datastore_ready']            =   false;
            state['isSessionNotExists']            =   false;
            state['notificarion_alert']            =   '';
        },
        setRootPath: (state, action) => {
            state['root_path'] = action.payload;
            localStorage.setItem('root_path', action.payload);
        },
        pageLoader: (state, action) => {
            state['page_loader'] = action.payload;
        },
        setFirstTimeLoad: (state, action) => {
            state['first_load'] = action.payload;
        },
        setUserAuthenticated: (state, action) => {
            state['is_user_authenticated'] = true;
            state['site_loader'] = true;
        },
        reloadBusinessList: (state, action) => {
            state['update_business_list']   =   !state['update_business_list'];
        },
        setDatastore: (state, action) => {

            state['is_datastore_ready'] =   action.payload;
            localStorage.setItem('is_datastore_ready', action.payload);
            
            state['sync_datastore'] =   !action.payload;
            localStorage.setItem('sync_datastore', !action.payload);

            state['site_loader']            =   false;
            state['manual_site_loader']     =   false;
        },
        setCPACompanyError: (state, action) => {
            state['cpa_company_error']  =   localStorage.getItem('cpa_company_error')
                                            ? localStorage.getItem('cpa_company_error')
                                            : '';
        },
        clearCPACompanyError: (state, action) => {
            state['cpa_company_error']  =   '';
            localStorage.removeItem('cpa_company_error');
        },
        setManualSiteLoader: (state, action) => {
            state['manual_site_loader'] =   action.payload;
        },
        setCPAAuthenticated: (state, action) => {
            state['is_cpa_authenticated']       =   action.payload;
            state['is_user_authenticated']      =   action.payload;

            localStorage.setItem('is_user_authenticated', action.payload);
            localStorage.setItem('is_cpa_authenticated', action.payload);
        },
        setBusinessAuthenticated: (state, action) => {
            state['is_business_authenticated']  =   action.payload;
            state['is_user_authenticated']      =   action.payload;

            localStorage.setItem('is_user_authenticated', action.payload);
            localStorage.setItem('is_business_authenticated', action.payload);
        },
        setNotifcationAlert: (state, action) => {
            if(action.payload === true) {
                state['notificarion_alert']  =   ALERT_MESSAGES["notification_alert"];
                localStorage.setItem('notificarion_alert', ALERT_MESSAGES["notification_alert"]);
            } else {
                state['notificarion_alert']  =   '';
                localStorage.removeItem('notificarion_alert');
            }
        }
    },
    extraReducers: (builder) => {
        builder
            .addCase(signUpUser.fulfilled, (state, action) => {

                console.log('User signup response', action.payload);

                if(action.payload.status === 'success') {

                    var tempResponse    =    (action['payload']['data']['user']['storage']['user_detail'] !== undefined)
                                                ? JSON.parse(action['payload']['data']['user']['storage']['user_detail'])
                                                : {};
                    var tempUsername    =   (action['payload']['data']['user']['username'] !== undefined)
                                                ? { 'username': action['payload']['data']['user']['username']}
                                                : {};

                    var tempUserDetails =   { ...tempResponse, ...tempUsername };

                    state['user_detail']                =   tempUserDetails;
                    localStorage.setItem('user_detail', JSON.stringify(tempUserDetails));
                    
                }
                
            })
            .addCase(autoSignInUser.fulfilled, (state, action) => {

                /* state['is_user_authenticated']  =   true;
                localStorage.setItem('is_user_authenticated', true); */

                console.log('Auto Signin payload', action?.payload?.user_detail);
        
                var tempUserDetails =   { ...action?.payload?.user_detail };
                tempUserDetails['username'] =   action?.payload?.username;

                state['user_detail']                =   tempUserDetails;
                localStorage.setItem('user_detail', JSON.stringify(tempUserDetails));

                state['manual_site_loader'] =   false;

            })
            .addCase(loginUser.fulfilled, (state, action) => {

                if(action?.payload?.status === 'success') {
        
                    var tempUserDetails =   { ...action?.payload?.data?.attributes, username: action?.payload?.data?.username };

                    console.log('tempUserDetails', tempUserDetails);

                    if(tempUserDetails['custom:role'] != undefined && parseInt(tempUserDetails['custom:role']) === 1) {

                        if(parseInt(tempUserDetails['custom:step']) >= 1) {

                            state['is_business_authenticated']  =   true;
                            state['is_user_authenticated']      =   true;
                            state['sync_datastore']             =   true;
                            state['manual_site_loader']         =   true;

                            localStorage.setItem('sync_datastore', true);
                            localStorage.setItem('is_business_authenticated', true);
                            localStorage.setItem('is_user_authenticated', true);
                            
                        }

                    } else if(tempUserDetails['custom:role'] !== undefined && parseInt(tempUserDetails['custom:role']) === 3) {

                        if(parseInt(tempUserDetails['custom:step']) >= 1) {

                            state['is_cpa_authenticated']   =   true;
                            state['is_user_authenticated']  =   true;
                            state['sync_datastore']         =   true;

                            state['manual_site_loader']     =   true;


                            localStorage.setItem('sync_datastore', true);
                            localStorage.setItem('is_cpa_authenticated', true);
                            localStorage.setItem('is_user_authenticated', true);

                        }

                    } else if(tempUserDetails['custom:role'] !== undefined && parseInt(tempUserDetails['custom:role']) === 4) {

                        state['is_user_authenticated'] =   true;
                        state['is_admin_authenticated'] =   true;
                        state['sync_datastore']         =   true;

                        localStorage.setItem('sync_datastore', true);
                        localStorage.setItem('is_admin_authenticated', true);
                        localStorage.setItem('is_user_authenticated', true);

                        state['manual_site_loader'] =   true;

                    }

                    state['user_detail']        =   tempUserDetails;
                    localStorage.setItem('user_detail', JSON.stringify(tempUserDetails));
                }

            })
            .addCase(updateUserStep.fulfilled, (state, action) => {

                var tempUserDetails     =   state['user_detail'];
        
                if(tempUserDetails['custom:step'] != undefined) {

                    tempUserDetails['custom:step']  =   action.payload;
                    state['user_detail']            =   tempUserDetails;

                    localStorage.setItem('user_detail', JSON.stringify(tempUserDetails));

                }

            })
            .addCase(verifySignUpCode.fulfilled, (state, action) => {

                var tempPayload         =   action.payload;

                console.log('tempPayload', tempPayload);

                if(tempPayload?.status !== undefined && tempPayload?.status === 200) {

                    var tempUserDetails     =   state['user_detail'];

                    var currentUserDetails  =   (action?.payload?.currentUser !== undefined)
                                                    ? { ...action?.payload?.currentUser }
                                                    : {};

                    
                    if(currentUserDetails['attributes'] !== undefined) {
                        tempUserDetails         =   { ...currentUserDetails['attributes'], username: currentUserDetails['username'] };

                        state['user_detail']    =   tempUserDetails;
                    }

                    if(tempUserDetails['custom:step'] !== undefined && !tempPayload?.reverify) {
                        tempUserDetails['custom:step']  =   "1";
                        state['manual_site_loader']     =   true;
                        state['sync_datastore']         =   true;
                    }

                    localStorage.setItem('user_detail', JSON.stringify(tempUserDetails));

                }

            })
            .addCase(verifyUserCode.fulfilled, (state, action) => {
                var tempPayload         =   action.payload;
                console.log("tempPayload", tempPayload);
                if(tempPayload?.status !== undefined && tempPayload?.status === 200 && tempPayload?.response === "SUCCESS") {
                    if(tempPayload["data"] !== undefined && tempPayload["data"]["verification_type"] !== undefined && tempPayload["data"]["verification_type"] === "email") {
                        state['user_detail']["email_verified"]  =   true;
                    } else if(tempPayload["data"] !== undefined && tempPayload["data"]["verification_type"] !== undefined && tempPayload["data"]["verification_type"] === "phone_number") {
                        state['user_detail']["phone_number_verified"]  =   true;
                    }
                }
            })
            .addCase(logoutUser.fulfilled, (state, action) => {

                if(action.payload === true) {
        
                    clearLocalStorage();

                    state['cpa_company_error']             =   '';
                    state['update_business_list']          =   false;
                    state['business_list']                 =   [];
                    state['az_redirect_url']               =   '';
                    state['az_redirect_for']               =   '';
                    state['user_detail']                   =   {};
                    state['is_user_authenticated']         =   false;
                    state['is_cpa_authenticated']          =   false;
                    state['is_business_authenticated']     =   false;
                    state['is_admin_authenticated']        =   false;
                    state['sync_datastore']                =   false;
                    state['is_datastore_ready']            =   false;
                    state['isSessionNotExists']            =   false;
                    state['notificarion_alert']            =   '';
        
                }
            })
            .addCase(autoLogoutUser.fulfilled, (state, action) => {

                if(action.payload === true) {
        
                    clearLocalStorage();
                    
                    state['cpa_company_error']             =   '';
                    state['update_business_list']          =   false;
                    state['business_list']                 =   [];
                    state['az_redirect_url']               =   '';
                    state['az_redirect_for']               =   '';
                    state['user_detail']                   =   {};
                    state['is_user_authenticated']         =   false;
                    state['is_cpa_authenticated']          =   false;
                    state['is_business_authenticated']     =   false;
                    state['is_admin_authenticated']        =   false;
                    state['sync_datastore']                =   false;
                    state['is_datastore_ready']            =   false;
                    state['isSessionNotExists']            =   false;
                    state['notificarion_alert']            =   '';
        
                    //localStorage.removeItem('root_path');
                }
            })
            //.addCase(autoLogoutUser.fulfilled, () => resetValues)
            .addCase(deleteUser.fulfilled, (state, action) => {
        
                if(action.payload?.status === true) {
        
                    clearLocalStorage();
                    state['cpa_company_error']             =   '';
                    state['update_business_list']          =   false;
                    state['business_list']                 =   [];
                    state['az_redirect_url']               =   '';
                    state['az_redirect_for']               =   '';
                    state['user_detail']                   =   {};
                    state['is_user_authenticated']         =   false;
                    state['is_cpa_authenticated']          =   false;
                    state['is_business_authenticated']     =   false;
                    state['is_admin_authenticated']        =   false;
                    state['sync_datastore']                =   false;
                    state['is_datastore_ready']            =   false;
                    state['isSessionNotExists']            =   false;
                    state['notificarion_alert']            =   '';
        
                    //localStorage.removeItem('root_path');
                }

            })
            .addCase(getCurrentUser.fulfilled, (state, action) => {

                console.log('Current user state', action.payload);

                var currentUserDetails  =   action.payload;
                state['first_load']     =   false;
        
                if(currentUserDetails['status'] && !isEmpty(currentUserDetails['currentUser'])) {
                    
                    state['site_loader']            =   true;

                    var tempUserDetails =   { ...currentUserDetails['currentUser']['attributes'], username: currentUserDetails['currentUser']['username'] };
        
                    state['user_detail']                =   tempUserDetails;
                    localStorage.setItem('user_detail', JSON.stringify(tempUserDetails));

                    if(tempUserDetails['custom:role'] !== undefined && parseInt(tempUserDetails['custom:role']) === 1) {

                        if(tempUserDetails['custom:step'] !== undefined && parseInt(tempUserDetails['custom:step']) >= 1) {

                            state['is_user_authenticated']      =   true;
                            state['is_business_authenticated']  =   true;
                            
                            localStorage.setItem('is_business_authenticated', true);
                            localStorage.setItem('is_user_authenticated', true);

                            if(!state['is_datastore_ready']) {

                                state['sync_datastore'] =   true;
                                localStorage.setItem('sync_datastore', true);
                                state['manual_site_loader']     =   true;

                            }
                        }

                    } else if(tempUserDetails['custom:role'] !== undefined && parseInt(tempUserDetails['custom:role']) === 3) {

                        if(tempUserDetails['custom:step'] !== undefined && parseInt(tempUserDetails['custom:step']) >= 1) {

                            state['is_user_authenticated']  =   true;
                            state['is_cpa_authenticated']   =   true;

                            localStorage.setItem('is_cpa_authenticated', true);
                            localStorage.setItem('is_user_authenticated', true);

                            if(!state['is_datastore_ready']) {

                                state['sync_datastore']         =   true;
                                localStorage.setItem('sync_datastore', true);
                                state['manual_site_loader']     =   true;

                            }

                        }

                    } else if(tempUserDetails['custom:role'] !== undefined && parseInt(tempUserDetails['custom:role']) === 4) {

                        state["is_admin_authenticated"] =   true;
                        state['is_user_authenticated']  =   true;

                        localStorage.setItem('is_admin_authenticated', true);
                        localStorage.setItem('is_user_authenticated', true);

                        if(!state['is_datastore_ready']) {

                            state['sync_datastore']         =   true;
                            localStorage.setItem('sync_datastore', true);
                            state['manual_site_loader']     =   true;

                        }

                    }
        
                } else {
        
                    clearLocalStorage();
                    state['cpa_company_error']             =   '';
                    state['update_business_list']          =   false;
                    state['business_list']                 =   [];
                    state['az_redirect_url']               =   '';
                    state['az_redirect_for']               =   '';
                    state['user_detail']                   =   {};
                    state['is_user_authenticated']         =   false;
                    state['is_cpa_authenticated']          =   false;
                    state['is_business_authenticated']     =   false;
                    state['is_admin_authenticated']        =   false;
                    state['sync_datastore']                =   false;
                    state['is_datastore_ready']            =   false;
                    state['isSessionNotExists']            =   false;
                    state['notificarion_alert']            =   '';
        
                }
            })
            .addCase(saveCPAUserInfo.fulfilled, (state, action) => {
        
                var tempUserDetails =   state['user_detail'];
        
                if(tempUserDetails['custom:step'] != undefined) {
                    tempUserDetails['custom:step']  =   2;
                    state['user_detail']            =   tempUserDetails;
                    localStorage.setItem('user_detail', JSON.stringify(tempUserDetails));
                }

            })
            .addCase(saveBusinessUserInfo.fulfilled, (state, action) => {
        
                var tempUserDetails =   state['user_detail'];
        
                if(tempUserDetails['custom:step'] != undefined) {
                    tempUserDetails['custom:step']  =   2;
                    state['user_detail']            =   tempUserDetails;
                    localStorage.setItem('user_detail', JSON.stringify(tempUserDetails));
                }

            })
            .addCase(verifyCode.fulfilled, (state, action) => {
                if(action.payload['status'] !== undefined && action.payload['status'] && state['user_detail'] !== undefined) {
                    state['user_detail']['email_verified']  =   true;
                }
            })
            .addCase(updatePaymentStatus.fulfilled, (state, action) => {
                const resposne = action.payload;
                if(resposne['isStepUpdated'] !== undefined && resposne['isStepUpdated'] !== null && resposne['isStepUpdated'] === true) {
                    state['user_detail']['custom:step'] =   3;
                }
            })
            .addCase(updateSubscriptionStatus.fulfilled, (state, action) => {
                const resposne = action.payload;
                console.log("updateSubscriptionStatus Fulfilled", action.payload);
                if(resposne['status'] !== undefined && resposne['status'] !== null && resposne['status'] === "success") {
                    state['user_detail']['custom:isSubscribed'] =   "true";
                }
            })
            .addMatcher(
                (action) => action.type.endsWith('/pending'),
                (state, action) => {

                    state['pending_actions'].push(action.type)

                    if(!state['site_loader']) {
                        state['site_loader'] = true;
                    }
                }
            )
            .addMatcher(
                (action) => action.type.endsWith('/rejected'),
                (state, action) => {
                    var actionType  =   action.type;
                    actionType = actionType.replace("rejected", "pending")

                    var index = state['pending_actions'].indexOf(actionType);
                    if(index !== -1) {
                        state['pending_actions'].splice(index, 1);

                        if(state['site_loader'] && state['pending_actions'].length === 0) {
                            state['site_loader']    =   false;
                        }
                    } else {
                        if(state['site_loader'] && state['pending_actions'].length === 0) {
                            state['site_loader'] = false;
                        }
                    }

                }
            )
            .addMatcher(
                (action) => action.type.endsWith('/fulfilled'),
                (state, action) => {
                    var actionType  =   action.type;
                    actionType = actionType.replace("fulfilled", "pending");

                    var index = state['pending_actions'].indexOf(actionType);
                    if(index !== -1) {
                        state['pending_actions'].splice(index, 1);

                        if(state['site_loader'] && state['pending_actions'].length === 0) {
                            state['site_loader']    =   false;
                        }
                    } else {
                        if(state['site_loader'] && state['pending_actions'].length === 0) {
                            state['site_loader'] = false;
                        }
                    }

                    if(actionType   ===  'user/auto/logout/pending') {
                        const tempActions   =   state['pending_actions'];
                        for(var i = 0; i < tempActions.length; i++) {
                            if(state['pending_actions'][i] === 'user/auto/logout/pending') {
                                state['pending_actions'].splice(i, 1);
                            }
                        }
                    }
                }
            )
    }
});


// Action creators are generated for each case reducer function
export const { siteLoader, setNotifcationAlert, setSessionValue, setRedirectDetails, resetRedirectDetails, resetState, setUserDetails, reloadBusinessList, pageLoader, setRootPath, setManualSiteLoader, setDatastore, setBusinessAuthenticated, setCPAAuthenticated, setUserAuthenticated, setCPACompanyError, clearCPACompanyError, signOut, signIn } = globalSlice.actions;

const { reducer } = globalSlice;
export default reducer;