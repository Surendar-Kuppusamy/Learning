import * as yup from "yup";
import { isValidPhoneNumber } from 'react-phone-number-input';
import { ALERT_MESSAGES } from './AlertMessages';
import moment from "moment";


const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;
const userNameExp = /^[A-Za-z][a-zA-Z0-9_]{0,}[a-zA-Z]+[0-9]*$/;
const passwordExp = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[\^$*.\[\]{}\(\)?\-\"!@#%&\/,><\':;|_~`])\S{8,99}$/;

export const EmailReg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w\w+)+$/;
export const PasswordReg = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[\^$*.\[\]{}\(\)?\-\"!@#%&\/,><\':;|_~`])\S{8,99}$/;
export const UpperCaseReg = /(?=.*[A-Z])/;
export const SpaceCaseReg = /\s/;
export const LowerCaseReg = /(?=.*[a-z])/;
export const NumberCaseReg = /(?=.*[0-9])/;
export const SpecialCaseReg = /(?=.*[\^$*.\[\]{}\(\)?\-"!@#%&\/,><\’:;|_~`])(?=.*[\^$*.\[\]{}\(\)?\-"!@#%&\/,><\’:;|_~`])/;
export const specialChars = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
export const usernameReg = /^[a-zA-Z][a-zA-Z0-9]+[0-9]*$/;
export const NoSpace = /^[^-\s]{8,30}$/;
export const userFullReg = /^[a-zA-Z][a-zA-Z\s]*$/;

export const UserLoginSchema   =    yup.object().shape({
    username: yup.string().trim()
                            .required(ALERT_MESSAGES['username_required'])
                            .test('validSpecialCharacters', ALERT_MESSAGES['username_special_character'], 
                                (value) => !specialChars.test(value)
                            )
                            .matches(usernameReg, ALERT_MESSAGES['username_start_letter'])
                            .matches(userNameExp, ALERT_MESSAGES['username_regex'])
                            .min(8, ALERT_MESSAGES['username_length'])
                            .max(128, ALERT_MESSAGES['username_max_length']),
    password: yup.string().trim()
                            .required(ALERT_MESSAGES['password_required'])
                            .matches(PasswordReg, ALERT_MESSAGES['password_strong'])
                            

});

export const UserSignupSchema   =    yup.object().shape({
    fullname                :   yup.string().trim()
                                    .required(ALERT_MESSAGES['fullname_required'])
                                    .matches(userFullReg, ALERT_MESSAGES['fullname_regex']),
    username                :   yup.string().trim()
                                    .required(ALERT_MESSAGES['username_required'])
                                    .test('validSpecialCharacters', ALERT_MESSAGES['username_special_character'], 
                                        (value) => !specialChars.test(value)
                                    )
                                    .matches(userNameExp, ALERT_MESSAGES['username_regex'])
                                    .matches(usernameReg, ALERT_MESSAGES['username_regex_custom'])
                                    .min(8, ALERT_MESSAGES['username_length'])
                                    .max(128, ALERT_MESSAGES['username_max_length']),
    email                   :   yup.string().trim()
                                            .required(ALERT_MESSAGES['email_required'])
                                            .email(ALERT_MESSAGES['invalid_email']),
    phone_number            :   yup.string().trim()
                                            .required(ALERT_MESSAGES['phone_number_required'])
                                            .test('validPhoneNumber', ALERT_MESSAGES['phone_number_is_invalid'], 
                                                function(value) {
                                                    if(value === undefined || value === null) {
                                                        return false;
                                                    }
                                                    return isValidPhoneNumber(value);
                                                }
                                            ),
    password                :   yup.string().trim()
                                            .required(ALERT_MESSAGES['password_required'])
                                            .matches(PasswordReg, ALERT_MESSAGES['password_strong']),
    /* country                 :   yup.string().trim().required(ALERT_MESSAGES['country_required']), */
    /* terms_and_conditions    :   yup.bool().oneOf([true], ALERT_MESSAGES['terms_and_conditions']) */

});


export const changePasswordSchema   =    yup.object().shape({
    old_password                :   yup.string().trim()
                                            .required(ALERT_MESSAGES['old_password_required'])
                                            .matches(passwordExp, ALERT_MESSAGES['old_password_strong']),
    new_password                :   yup.string().trim()
                                                .required(ALERT_MESSAGES['new_password_required'])
                                                .matches(passwordExp, ALERT_MESSAGES['new_password_strong']),
    confirm_password            :   yup.string().trim()
                                                .required(ALERT_MESSAGES['confirm_password_required'])
                                                .oneOf([yup.ref('new_password'), null], ALERT_MESSAGES['password_not_match'])
                                                .matches(passwordExp, ALERT_MESSAGES['confirm_password_strong']),
});

export const forgotPasswordSchema   =    yup.object().shape({
    username                :   yup.string().trim()
                                    .required(ALERT_MESSAGES['username_required'])
                                    .test('validSpecialCharacters', ALERT_MESSAGES['username_special_character'], 
                                        (value) => !specialChars.test(value)
                                    )
                                    .matches(userNameExp, ALERT_MESSAGES['username_regex'])
                                    .matches(usernameReg, ALERT_MESSAGES['username_regex_custom'])
                                    .min(8, ALERT_MESSAGES['username_length'])
                                    .max(128, ALERT_MESSAGES['username_max_length']),
});

export const resetPasswordSchema    =    yup.object().shape({
    username                :   yup.string().trim()
                                    .required(ALERT_MESSAGES['username_required'])
                                    .test('validSpecialCharacters', ALERT_MESSAGES['username_special_character'], 
                                        (value) => !specialChars.test(value)
                                    )
                                    .matches(userNameExp, ALERT_MESSAGES['username_regex'])
                                    .matches(usernameReg, ALERT_MESSAGES['username_regex_custom'])
                                    .min(8, ALERT_MESSAGES['username_length'])
                                    .max(128, ALERT_MESSAGES['username_max_length']),
    password                :   yup.string().trim()
                                    .required(ALERT_MESSAGES['password_required'])
                                    .matches(PasswordReg, ALERT_MESSAGES['password_strong'])
});


export const CPAInfoSchema      =    yup.object().shape({
    cpaName                     :   yup.string().trim()
                                        .required(ALERT_MESSAGES['cpaNameRequired'])
                                        .matches(userFullReg, ALERT_MESSAGES['fullname_regex']),
    businessNumber              :   yup.string().trim().max(10, ALERT_MESSAGES['businessNumberMaxLen']),
    officeAddress               :   yup.string().trim().required(ALERT_MESSAGES['officeAddressRequired']),
    geoLocation                 :   yup.string().trim().required(ALERT_MESSAGES['officeAddressGRRequired']),
    region                      :   yup.string().trim().required(ALERT_MESSAGES['officeAddressGRRequired'])
});

export const UserInfoSchema     =    yup.object().shape({
    name                        :   yup.string().trim()
                                        .required(ALERT_MESSAGES['cpaNameRequired'])
                                        .matches(userFullReg, ALERT_MESSAGES['fullname_regex']),
    businessNumber              :   yup.string().trim().max(10, ALERT_MESSAGES['businessNumberMaxLen']),
    officeAddress               :   yup.string().trim().required(ALERT_MESSAGES['officeAddressRequired']),
    geoLocation                 :   yup.string().trim().required(ALERT_MESSAGES['officeAddressGRRequired']),
    region                      :   yup.string().trim().required(ALERT_MESSAGES['officeAddressGRRequired']),
    gst_hst                     :   yup.string().trim().max(30, ALERT_MESSAGES['gst_hst_MaxLen']),
});


export const InviteBusinessSchema   =    yup.object().shape({
    name                        :   yup.string().trim().required(ALERT_MESSAGES['nameRequired']),
    businessName                :   yup.string().trim().required(ALERT_MESSAGES['businessNameRequired']),
    email                       :   yup.string().trim().required(ALERT_MESSAGES['email_required']).email(ALERT_MESSAGES['invalid_email'])
});

export const ProfileValidationSchema   =    yup.object().shape({
    businessName                :   yup.string().trim().required(ALERT_MESSAGES['businessNameRequired']),
    businessNumber              :   yup.string().trim().required(ALERT_MESSAGES['businessNumberRequired']),
    phoneNumber                 :   yup.string().trim().required(ALERT_MESSAGES['phone_number_required']),
    officeAddress               :   yup.string().trim().required(ALERT_MESSAGES['officeAddressRequired']),
    geoLocation                 :   yup.string().trim().required(ALERT_MESSAGES['officeAddressGRRequired']),
    region                      :   yup.string().trim().required(ALERT_MESSAGES['officeAddressGRRequired']),
    email                       :   yup.string().trim().required(ALERT_MESSAGES['email_required']).email(ALERT_MESSAGES['invalid_email']),
    phoneNumber                 :   yup.string().trim()
                                        .required(ALERT_MESSAGES['phone_number_required'])
                                        .test('validPhoneNumber', ALERT_MESSAGES['phone_number_is_invalid'], 
                                            function(value) {
                                                if(value === undefined || value === null) {
                                                    return false;
                                                }
                                                return isValidPhoneNumber(value);
                                            }
                                        )
});

export const ReportValidationSchema   =    yup.object().shape({
    name            :   yup.string()
                            .trim()
                            .required(ALERT_MESSAGES['report_name_required'])
                            .test('validSpecialCharacters', ALERT_MESSAGES['report_name_specail_character'], 
                                (value) => !specialChars.test(value)
                            ),
    textSearch      :   yup.string().trim(),
    format          :   yup.string().required(ALERT_MESSAGES['report_format_required']),
    startDate       :   yup.string().required(ALERT_MESSAGES['report_startDate_required']),
    endDate         :   yup.string().required(ALERT_MESSAGES['report_endDate_required']),
    type            :   yup.string().required(ALERT_MESSAGES['report_type_required']),
    category        :   yup.array().min(1, ALERT_MESSAGES['report_category_required']),
    account         :   yup.array().min(1, ALERT_MESSAGES['report_account_required']),
    business        :   yup.string().required(ALERT_MESSAGES['report_business_required']),
    userId          :   yup.string().required(ALERT_MESSAGES['report_userId_required']),
    addedBy         :   yup.string().required(ALERT_MESSAGES['report_userId_required'])
});

export const AddBlogValidationSchema = yup.object().shape({
     //bannerimage : yup.string().required(ALERT_MESSAGES['blog_image_required']),
     title : yup.string().required(ALERT_MESSAGES['blog_title_required']),
     description   : yup.string().required(ALERT_MESSAGES['blog_description_required']),
     status   : yup.string().required(ALERT_MESSAGES['blog_status_required']),
     startDate       :   yup.string().required(ALERT_MESSAGES['blog_startDate_required'])/*,
      image       :   yup.string().required(ALERT_MESSAGES['blog_image_required']) */

});

export const AddFaqValidationSchema = yup.object().shape({
    question : yup.string().required(ALERT_MESSAGES['faq_question_required']),
    description   : yup.string().required(ALERT_MESSAGES['faq_description_required']),
    role   : yup.string().required(ALERT_MESSAGES['faq_role_required']),
});


export const AddEmailTemplateValidationSchema = yup.object().shape({
    title       : yup.string().required(ALERT_MESSAGES['emailtemplate_title_required']),
    description   : yup.string().required(ALERT_MESSAGES['emailtemplate_description_required']),
});
export const AddPaymentValidationSchema = yup.object().shape({
    paymentmode : yup.string().required(ALERT_MESSAGES['payment_paymentmode_required'])
});
export const AddTermsValidationSchema = yup.object().shape({
    term : yup.string().required(ALERT_MESSAGES['term_term_required'])

});

export const AddAccountValidationSchema = yup.object().shape({
    account : yup.string().required(ALERT_MESSAGES['account_account_required']),
    status   : yup.string().required(ALERT_MESSAGES['account_status_required']),



});

export const AddCategorySchema = yup.object().shape({
    categoryname : yup.string().required(ALERT_MESSAGES['category_categoryname_required'])
});

export const SetupPaymentSchema = yup.object().shape({
    firstname       :   yup.string().required(ALERT_MESSAGES['first_name_required']),
    lastname        :   yup.string().required(ALERT_MESSAGES['last_name_required']),
    payment_terms   :   yup.bool().oneOf([true], ALERT_MESSAGES['payment_terms_required'])
});

export const AddEditCouponSchema = yup.object().shape({
    name            :   yup.string().required(ALERT_MESSAGES['coupon_name_required']),
    notes           :   yup.string(),
    type            :   yup.string().required(ALERT_MESSAGES['coupon_type_required']),
    discountType    :   yup.bool().oneOf([true, false], ALERT_MESSAGES['coupon_discount_type_required']),
    forLifeTime     :   yup.bool().oneOf([true, false], ALERT_MESSAGES['coupon_period_required']),
    status          :   yup.bool().oneOf([true, false], ALERT_MESSAGES['coupon_status_required']),
    code            :   yup.string().required(ALERT_MESSAGES['coupon_code_required']).min(4, ALERT_MESSAGES['coupon_code_minimum']).max(10, ALERT_MESSAGES['coupon_code_maximum']),
    maxUseLimit     :   yup.number().typeError(ALERT_MESSAGES['number_type_error']).when('forLifeTime', { is: false, then: yup.number().typeError(ALERT_MESSAGES['number_type_error']).required(ALERT_MESSAGES['coupon_max_use_limit_required']).test("maxDigitsAfterDecimal",
    ALERT_MESSAGES['coupon_max_use_limit_invalid'],
    (number) => (parseFloat(number) > 0 && parseFloat(number) < 100) ) }),
    percentage      :   yup.number().typeError(ALERT_MESSAGES['number_type_error'])
                            .when('discountType', { is: false, then: yup.number().typeError(ALERT_MESSAGES['number_type_error']).required(ALERT_MESSAGES['coupon_percentage_required']).test("maxDigitsAfterDecimal",
                            ALERT_MESSAGES['coupon_percentage_invalid'],
                            (number) => (parseFloat(number) > 0 && parseFloat(number) < 100)
                        ) }),
    amount          :   yup.number().typeError(ALERT_MESSAGES['number_type_error'])
                                .when('discountType', { is: true, then: yup.number().typeError(ALERT_MESSAGES['number_type_error']).required(ALERT_MESSAGES['coupon_amount_required']).test("maxDigitsAfterDecimal",
                                ALERT_MESSAGES['coupon_amount_invalid'],
                                (number) => /^\d+(\.\d{1,4})?$/).test("greaterThanZero", ALERT_MESSAGES['coupon_amount_required'], (number) => parseFloat(number) > 0)
                            })
                                ,
    validFrom       :   yup.date().when('forLifeTime', { is: true, then: yup.date().required(ALERT_MESSAGES['coupon_valid_from_date_required']) }),
    validTo         :   yup.date().when('forLifeTime', { is: true, then: yup.date().required(ALERT_MESSAGES['coupon_valid_to_date_required']) })
                            .when('validFrom', (validFrom, schema) => (moment(validFrom).isValid() ? schema.min(validFrom) : schema))
});