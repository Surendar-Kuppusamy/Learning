import React, { useEffect, useState, forwardRef, useMemo, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { toast } from 'react-toastify';
import { useTranslation } from 'react-i18next';
import Select, { components } from 'react-select';
import DatePicker from "react-datepicker";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faXmark  } from '@fortawesome/free-solid-svg-icons';
import { Scrollbars } from 'react-custom-scrollbars-2';
import { RECEIPT_FILTER_OBJ, RECEIPT_FILTER_OPTIONS, RETURN_CLASS_NAMES } from '../../constants/GlobalConstants';
import { faCalendar, faCalendarAlt, faCalendarCheck } from '@fortawesome/free-solid-svg-icons';
import {CalendarIcon, CloseIcon } from '../../components/Icons';
import CustomDateHeader from '../../components/CustomDateHeader';

const Modals        =   React.lazy(() => import('../../components/Modals'));
const FilterBadge   =   React.lazy(() => import('../../components/FilterBadge'));


function ReceiptsFilter(props) {

    const sleep     =   (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    const dispatch          =   useDispatch();
    const navigate          =   useNavigate();
    const { t, i18n }       =   useTranslation();


    let fromDateRef;
    let toDateRef;

    const categoryRef                               =   useRef();
    const [categoryList, setCategoryList]           =   useState([]);
    const [categoriesOption, setCategoriesOption]   =   useState([]);
    const [receiptFilter, setReceiptFilter]         =   useState(props?.receiptFilter);
    const [startMaxDate, setStartMaxDate]           =   useState(new Date());
    const [endMinDate, setEndMinDate]               =   useState(null);

    const onChangeFilters = (date, name) => {
        console.log("name checking", name);
        if(name === " startDate" && new Date(date).getTime() > new Date(receiptFilter['endDate']).getTime()) {
            setReceiptFilter((prevState) => { return {...prevState, [name]: date, ["endDate"]: date }; })
        } else if(name === " endDate" && receiptFilter['startDate'].getTime() > date.getTime()) {
            setReceiptFilter((prevState) => { return {...prevState, [name]: date, ["startDate"]: date }; });
        } else {
            setReceiptFilter((prevState) => { return {...prevState, [name]: date}; });
        }
        if(name === "endDate") {
            setStartMaxDate(date);
        } else if(name === "startDate") {
            setEndMinDate(date);
        }
    };

    const resetFilter   =   async(event) => {
        event.preventDefault();
        //props?.setShowHideFilterModal(false);
        setReceiptFilter(RECEIPT_FILTER_OBJ);
        setTimeout(() => {
            categoryRef.current.setValue('');
        }, 100);
        //props?.getAllReceipts(props?.searchReceipts);
    }

    const setBadgeValue  =   (type, value)  => {
        setReceiptFilter((prevState) => { return {...prevState, [type]: value }; });
        if(type === "filterBy") {
            //updateCategory(value);
            console.log(categoryRef, 'categoryRef');
            categoryRef.current.setValue('');
        }
    }

    useEffect(() => {
        console.log('props.categories', props.categories);
        if(props.categories !== undefined && props.categories !== null && props.categories.length > 0) {
            setCategoryList(props?.categories.map((ca, i) => { return {'value': ca.id, 'label': ca.name, 'type': ca.type  }  }));
        } else {
            setCategoryList([]);
        }
    }, [props?.categories]);

    useEffect(() => {
        updateCategory(receiptFilter['filterBy']);
    }, [categoryList, receiptFilter['filterBy']]);

    const updateCategory    =   async(typeValue)  => {
        let tempCategoryList    =   [];
        for await(const ca of categoryList) {
            //console.log(getValues("type"), "types", ca);
            //receiptFilter['filterBy']
            if(parseInt(typeValue) === 0 || typeValue === '') {
                tempCategoryList.push({ label: ca["label"], value: ca["value"] });
            } else if(parseInt(typeValue) === 1 && ca["type"] === 1) {
                tempCategoryList.push({ label: ca["label"], value: ca["value"] });
            } else if(parseInt(typeValue) !== 1 && ca["type"] !== 1) {
                tempCategoryList.push({ label: ca["label"], value: ca["value"] });
            }
        }
        setCategoriesOption(tempCategoryList);
        setBadgeValue('category', "");
    }

    /* useEffect(() => {

    }, [categoryList]); */


    return (
        <Modals
            show={props?.showHideFilterModal}
            callback={props?.setShowHideFilterModal}
            //backDropFunc={resetFilter}
            backDropFunc={() => console.log("Close modal")}
            autoScroll
            scrollHeight={700}
            maxWidth={550}
            scrollbarRight={'-35px'}
        >
            <section id="ReceiptsFilter">
                <div className="container d-flex justify-content-center">
                    <div className="filter-modal">
                        <div className="fmodal-header">
                            <div className="icon" onClick={e => props?.setShowHideFilterModal(false)} title={t("close")}>
                                <CloseIcon />
                            </div>
                            <h4>{t("filter_transaction")}</h4>
                            {/* <pre>
                                { JSON.stringify(receiptFilter) }
                            </pre> */}
                        </div>

                         <div className="fmodal-body">
                        <FilterBadge
                            title={ "Type" }
                            options={RECEIPT_FILTER_OPTIONS['filterBy']}
                            filterValue={receiptFilter['filterBy']}
                            filterkey="filterBy"
                            setBadgeValue={setBadgeValue}
                        />
                        <div className="filter-field filter-select">
                            <h5>{t("category")}</h5>
                            <Select
                                className="cpa-select-container"
                                classNamePrefix="cpa-select"
                                placeholder={t("choose_category")}
                                options={categoriesOption}
                                value={categoriesOption.find(c => c.value === receiptFilter['category'])}
                                onChange={(val) => setBadgeValue('category', val["value"]) }
                                ref={categoryRef}
                            />
                        </div>
                        <FilterBadge
                            title={t("sort_by")}
                            options={RECEIPT_FILTER_OPTIONS['sortBy']}
                            filterValue={receiptFilter['sortBy']}
                            filterkey="sortBy"
                            setBadgeValue={setBadgeValue}
                        />
                        <FilterBadge
                            title={t("cpa_status")}
                            options={RECEIPT_FILTER_OPTIONS['cpaStatus']}
                            filterValue={receiptFilter['cpaStatus']}
                            filterkey="cpaStatus"
                            setBadgeValue={setBadgeValue}
                        />
                        <div className="filter-field">
                            <h5>{t("custom_date")}</h5>
                            <div className="row">
                                <div className="col-auto">
                                    <div className="filter-date-picker">
                                        <DatePicker
                                            selected={receiptFilter['startDate']}
                                            onChange={(date) => onChangeFilters(date, 'startDate')}
                                            dateFormat="dd/MM/yyyy"
                                            /* maxDate={startMaxDate} */
                                            placeholderText="dd/mm/yyy"
                                            className="filter-date-range-picker"
                                            /* monthsShown={2} */
                                            ref={c => fromDateRef = c}
                                            renderCustomHeader={({
                                                date,
                                                changeYear,
                                                changeMonth,
                                                decreaseMonth,
                                                increaseMonth,
                                                prevMonthButtonDisabled,
                                                nextMonthButtonDisabled
                                            }) => 
                                                (<CustomDateHeader
                                                    decreaseMonth={decreaseMonth}
                                                    increaseMonth={increaseMonth}
                                                    prevMonthButtonDisabled={prevMonthButtonDisabled}
                                                    nextMonthButtonDisabled={nextMonthButtonDisabled}
                                                    date={date}
                                                    selectedRange={[receiptFilter['startDate'], receiptFilter['endDate']]}
                                                    updateDateRange={(dates) => { onChangeFilters(dates[0], 'startDate'); onChangeFilters(dates[1], 'endDate'); fromDateRef.setOpen(false); }}
                                                />)
                                            }
                                            onKeyDown={(e) => {
                                                e.preventDefault();
                                            }}
                                            fixedHeight
                                            popperPlacement="top"
                                        />
                                        <i className="calender-icon" onClick={() => fromDateRef.setOpen(true)}>
                                            <CalendarIcon />
                                        </i>
                                    </div>
                                </div>
                                <div className="col-auto">
                                    <div className="filter-date-picker">
                                        <DatePicker
                                            selected={receiptFilter['endDate']}
                                            onChange={(date) => onChangeFilters(date, 'endDate')}
                                            dateFormat="dd/MM/yyyy"
                                            /* minDate={endMinDate} */
                                            placeholderText="dd/mm/yyy"
                                            className="filter-date-range-picker"
                                            ref={c => toDateRef = c}
                                            /* monthsShown={2} */

                                            renderCustomHeader={({
                                                date,
                                                changeYear,
                                                changeMonth,
                                                decreaseMonth,
                                                increaseMonth,
                                                prevMonthButtonDisabled,
                                                nextMonthButtonDisabled
                                            }) => 
                                                (<CustomDateHeader
                                                    decreaseMonth={decreaseMonth}
                                                    increaseMonth={increaseMonth}
                                                    prevMonthButtonDisabled={prevMonthButtonDisabled}
                                                    nextMonthButtonDisabled={nextMonthButtonDisabled}
                                                    date={date}
                                                    selectedRange={[receiptFilter['startDate'], receiptFilter['endDate']]}
                                                    updateDateRange={(dates) => { onChangeFilters(dates[0], 'startDate'); onChangeFilters(dates[1], 'endDate'); toDateRef.setOpen(false); }}
                                                />)
                                            }
                                            onKeyDown={(e) => {
                                                e.preventDefault();
                                            }}
                                            fixedHeight
                                            popperPlacement="top"
                                        />
                                        <i className="calender-icon" onClick={() => toDateRef.setOpen(true)}>
                                            <CalendarIcon />
                                        </i>
                                    </div>
                                </div>
                                {/* <DatePicker
                                        selectsRange
                                        selected={receiptFilter['startDate']}
                                        onChange={onChangeFilters}
                                        startDate={receiptFilter['startDate']}
                                        endDate={receiptFilter['endDate']}
                                        dateFormat="yyyy-MM-dd"
                                        maxDate={new Date()}
                                        placeholderText="Select Date range"
                                        className="filter-date-range-picker"
                                    /> */}
                            </div>				
                        </div>

                        <div className="filter-btns">
                            <button type="button" className="btn btn-secondary" title={t("close")} onClick={e => { props?.setShowHideFilterModal(false); }}>{t("close")}</button>
                            <button type="button" className="btn btn-primary" title={t("apply")} onClick={e => { props.setReceiptFilter(receiptFilter); props?.getAllReceipts(props?.searchReceipts, receiptFilter); props?.setShowHideFilterModal(false);}}>{t("apply")}</button>
                        </div>

                        <div className="modal-reset">
                            <a href='' onClick={resetFilter} title= {t("reset")}> 
                                {t("reset")}
                            </a>
                        </div>
                        </div>
                    </div>
                </div>
            </section>
        </Modals>
    );
}

export default ReceiptsFilter;