import moment from 'moment';
import { isEmpty, slice, uniq, findIndex, remove, filter } from 'lodash';
import { Amplify, DataStore, Auth, Predicates, Hub, Logger, API, Storage, SortDirection, graphqlOperation } from "aws-amplify";
import { ADMIN_START_ROUTE_PATH, BUSINESS_START_ROUTE_PATH, CPA_START_ROUTE_PATH } from '../../constants/GlobalConstants';

const asyncFunction = (t) => new Promise(resolve => setTimeout(resolve, t));

export const getDataViaGraphql = async(Query, QueryName, Variables) => {
    let CollectDatas    =   [];
    let LoopCount       =   0;
    const fetchedData   =   await new Promise((resolve, reject) => getData(resolve, reject, Query, QueryName, Variables, CollectDatas, LoopCount));
    return fetchedData;
};

const getData = async(resolve, reject, Query, QueryName, Variables, CollectDatas, LoopCount) => {

    console.log('LoopCount', LoopCount, 'CollectDatas', CollectDatas);

    API.graphql({ query: Query, variables: Variables })
        .then(async(response) => {

            await CollectDatas.push(...response["data"][QueryName]["items"]);

            if(
                response["data"][QueryName]["nextToken"] === undefined
                ||
                response["data"][QueryName]["nextToken"] === null
                ||
                response["data"][QueryName]["nextToken"] === ''
                ||
                LoopCount > 1000
            ) {
                return resolve(CollectDatas);
            } else {
                LoopCount   =   LoopCount + 1;
                Variables["nextToken"]  =   response["data"][QueryName]["nextToken"];
                await asyncFunction(500);
                getData(resolve, reject, Query, QueryName, Variables, CollectDatas, LoopCount);
            }
        }).catch(err => {
            console.log('Common API Errors', err);
            return resolve(CollectDatas);
        });
}


export const getPaginatedDataViaGraphql = async(Query, QueryName, Variables, Limit) => {
    let CollectDatas    =   [];
    let LoopCount       =   0;
    const fetchedData   =   await new Promise((resolve, reject) => getPaginatedData(resolve, reject, Query, QueryName, Variables, Limit, CollectDatas, LoopCount));
    return fetchedData;
};

const getPaginatedData = async(resolve, reject, Query, QueryName, Variables, Limit, CollectDatas, LoopCount) => {

    console.log('LoopCount', LoopCount, 'CollectDatas', CollectDatas);

    API.graphql({ query: Query, variables: Variables })
        .then(async(response) => {

            await CollectDatas.push(...response["data"][QueryName]["items"]);

            console.log("Checking", CollectDatas, CollectDatas.length >= Limit);

            if(
                response["data"][QueryName]["nextToken"] === undefined
                ||
                response["data"][QueryName]["nextToken"] === null
                ||
                response["data"][QueryName]["nextToken"] === ''
                ||
                LoopCount > 10000
                ||
                CollectDatas.length >= Limit
            ) {
                return resolve({ [QueryName]: CollectDatas, nextToken: response["data"][QueryName]["nextToken"]  });
            } else {
                LoopCount   =   LoopCount + 1;
                Variables["nextToken"]  =   response["data"][QueryName]["nextToken"];
                Variables["limit"]      =   Limit - CollectDatas.length;
                await asyncFunction(500);
                console.log("Checking123", CollectDatas, CollectDatas.length >= Limit);
                getPaginatedData(resolve, reject, Query, QueryName, Variables, Limit, CollectDatas, LoopCount);
            }
        }).catch(err => {
            console.log('Common API Errors', err);
            return resolve({ [QueryName]: CollectDatas, nextToken: null });
        });
}


export const getRecordByID = (Query, QueryName, ID) => {
    return new Promise((resolve, reject) => {
        try {
            API.graphql({ query: Query, variables: { id: ID }}).then(recordDetail => {
                if(recordDetail["errors"] === undefined && recordDetail["data"] !== undefined && recordDetail["data"][QueryName]["_version"]) {
                    resolve(recordDetail["data"][QueryName]);
                } else {
                    resolve(null);
                }
            }).catch(err => {
                console.log("getRecordByID", err);
                resolve(null);
            });
        } catch(e) {
            console.log("getRecordByID Try Catch", e);
            resolve(null);
        }
    });
}

export const updateRecordByID = (GetQuery, GetQueryName, UpdateQuery, UpdateQueryName,  ID, recordsToUpdate) => {
    return new Promise((resolve, reject) => {
        try {
            getRecordByID(GetQuery, GetQueryName, ID).then(updateData => {

                if(updateData !== null) {

                    const tempUpdateRecord  =   { "id": updateData["id"], "_version": updateData["_version"], ...recordsToUpdate };

                    API.graphql({ query: UpdateQuery, variables: { input: tempUpdateRecord }}).then(updatedData => {

                        if(updatedData["errors"] === undefined && updatedData["data"] !== undefined && updatedData["data"][UpdateQueryName]["id"] !== undefined) {
                            resolve({ status: "success", data: updatedData["data"][UpdateQueryName] });
                        } else {
                            resolve({ status: "error", data: updateData });
                        }
                        
                    }).catch(err => {
                        resolve({ status: "error", data: err });
                    });

                } else {
                    resolve({ status: "error", data: updateData });
                }

            }).catch(err => {
                resolve({ status: "error", data: err });
            });

        } catch(e) {

            console.log("updateRecordByID Try Catch", e);
            resolve({ status: "error", data: e });

        }

    });
};

export const getComapnyOptions = (cpaCompanies) => {
    return new Promise((resolve, reject) => {
        console.log('cpaCompaniescpaCompanies', cpaCompanies);
        const tempCompanyDetails    =   cpaCompanies.map((business) => {
            var tempPromise = new Promise((resolve, reject) => {
                if(business?.company !== undefined && business.joined == 1) {
                    var image = '';
                    if(business?.company?.businessPicture != '') {
                        Storage.get(business?.company?.businessPicture).then(img => {
                            resolve({ 'value': business?.company.id, 'email': business?.company?.email, 'title': business?.company?.fullName, 'label': business?.company?.fullName, image: img });
                        }).catch(err => {
                            resolve({ 'value': business?.company.id, 'email': business?.company?.email, 'title': business?.company?.fullName, 'label': business?.company?.fullName, image: "" });
                        });
                    } else {
                        resolve({ 'value': business?.company.id, 'email': business?.company?.email, 'title': business?.company?.fullName, 'label': business?.company?.fullName, image: '' });
                    }
                } else {
                    resolve(null);
                }
            });

            return tempPromise.then(data => data);
        });

        Promise.all(tempCompanyDetails).then((data) => {
            console.log('Worked Result', data);
            resolve(data.filter(val => val !== null));
        });
    });
}


export const RETURN_CLASS_NAMES    =   (defaultClass, expResult, trueClass, falseClass) => {
    return expResult ? defaultClass +' '+ trueClass : defaultClass +' '+ falseClass;
};

export const GET_ROOT_PATH  =   (locationPath, globalState) => {

    let rootPath = '';

    if(globalState['user_detail']["custom:role"] !== undefined && parseInt(globalState['user_detail']["custom:role"]) === 3) {
        rootPath    =   CPA_START_ROUTE_PATH;
    } else if(globalState['user_detail']["custom:role"] !== undefined && parseInt(globalState['user_detail']["custom:role"]) === 1) {
        rootPath    =   BUSINESS_START_ROUTE_PATH;
    } else if(globalState['user_detail']["custom:role"] !== undefined && parseInt(globalState['user_detail']["custom:role"]) === 4) {
        rootPath    =   ADMIN_START_ROUTE_PATH;
    } else if(locationPath.startsWith(CPA_START_ROUTE_PATH)) {
        rootPath    =   CPA_START_ROUTE_PATH;
    } else if(locationPath.startsWith(BUSINESS_START_ROUTE_PATH)) {
        rootPath    =   BUSINESS_START_ROUTE_PATH;
    } else if(locationPath.startsWith(ADMIN_START_ROUTE_PATH)) {
        rootPath    =   ADMIN_START_ROUTE_PATH;
    } else if(globalState['root_path'] !== undefined && globalState['root_path'] !== '') {
        rootPath    =   globalState['root_path'];
    } else {
        rootPath    =   CPA_START_ROUTE_PATH;
    }

    return rootPath;
}

export const GET_DEFAULT_ACCESS_PATH    =   (globalState, userDetails, extraDetail={}) => {
    return new Promise((resolve, reject) => {
        //console.log(globalState, userDetails, 'GET_DEFAULT_ACCESS_PATH ');
        try {
            if(userDetails === undefined) {
                return resolve('');
            } else if(parseInt(userDetails['custom:role']) !== 4 && parseInt(userDetails['custom:role']) !== 3 && parseInt(userDetails['custom:role']) !== 1) {
                return resolve('');
            } if(globalState["root_path"] === ADMIN_START_ROUTE_PATH && parseInt(userDetails['custom:role']) == 4) {
                return resolve(ADMIN_START_ROUTE_PATH+'/dashboard');
            } else if(
                userDetails['email_verified'] != undefined
                &&
                userDetails['phone_number_verified'] !== undefined
                &&
                !userDetails['email_verified']
                &&
                !userDetails['phone_number_verified']
            ) {
                return resolve(globalState['root_path']+'/choose/verification/type');
            } else if(parseInt(userDetails['custom:step']) === 1) {
                return resolve(globalState["root_path"]+'/info');
            }/*  else if(globalState["root_path"] === BUSINESS_START_ROUTE_PATH && parseInt(userDetails['custom:role']) == 1 && parseInt(userDetails['custom:step']) === 2) {
                return resolve(BUSINESS_START_ROUTE_PATH+'/select/plan');
            }  */else if(globalState["root_path"] === BUSINESS_START_ROUTE_PATH && parseInt(userDetails['custom:role']) == 1 && parseInt(userDetails['custom:step']) === 2 && (userDetails["custom:isSubscribed"] === undefined || userDetails["custom:isSubscribed"] === false)) {
                return resolve(BUSINESS_START_ROUTE_PATH+'/select/plan');
            } else if(globalState["root_path"] === BUSINESS_START_ROUTE_PATH && parseInt(userDetails['custom:role']) == 1 && parseInt(userDetails['custom:step']) >= 2) {
                return resolve(BUSINESS_START_ROUTE_PATH+'/dashboard');
            } else if(globalState["root_path"] === CPA_START_ROUTE_PATH && parseInt(userDetails['custom:role']) == 3 && parseInt(userDetails['custom:step']) === 1) {
                return resolve(CPA_START_ROUTE_PATH+'/info');
            } else if(globalState["root_path"] === CPA_START_ROUTE_PATH && parseInt(userDetails['custom:role']) == 3 && parseInt(userDetails['custom:step']) === 2 && globalState["az_redirect_for"] === userDetails['sub'] && globalState["az_redirect_url"] !== '') {
                return resolve(globalState["az_redirect_url"]);
            } else if(globalState["root_path"] === CPA_START_ROUTE_PATH && parseInt(userDetails['custom:role']) == 3 && parseInt(userDetails['custom:step']) === 2) {
                return resolve(CPA_START_ROUTE_PATH+'/dashboard');
            } else {
                return resolve('');
            }
        } catch(e) {
            console.log('GET_DEFAULT_ACCESS_PATH', e);
            return resolve('');
        }
    });
}


export const FORMAT_DATE = (dateString) => {
    const options = { year: "numeric", month: "short", day: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
    //return new Date(dateString).toDateString().replace(/^\S+\s/,'');
};

export const REMOVE_CURRENCY =   (amount) => {
    amount      =   amount.toString();
    amount      =   amount.replace(/£/g, "");
    amount      =   amount.replace(/€/g, "");
    amount      =   amount.replace(/$/g, "");
    amount      =   amount.replace(/₹/g, "");
    return parseFloat(amount);
}


export function isNumber(evt) {
    var iKeyCode = (evt.which) ? evt.which : evt.keyCode;
    if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
        return false;
    return true;
}


export function CONVERT_TO_SHORT_NUMBER_FORMAT(amount) {
    // Nine Zeroes for Billions
    return Math.abs(Number(amount)) >= 1.0e+9
    ? (Math.abs(Number(amount)) / 1.0e+9).toFixed(2) + "B"
    // Six Zeroes for Millions 
    : Math.abs(Number(amount)) >= 1.0e+6
    ? (Math.abs(Number(amount)) / 1.0e+6).toFixed(2) + "M"
    // Three Zeroes for Thousands
    : Math.abs(Number(amount)) >= 1.0e+3
    ? (Math.abs(Number(amount)) / 1.0e+3).toFixed(2) + "K"
    : Math.abs(Number(amount)).toFixed(2);
}


export const DATE_TO_ISO_FORMAT = (date = new Date()) => {
    const inp = {
        year    :   date.getFullYear(),
        month   :   date.getMonth(),
        day     :   date.getDate(),
        hour    :   date.getHours(),
        minutes :   date.getMinutes(),
        seconds :   date.getSeconds()
    }
    return moment.utc(inp).toISOString()
}

export const DISPLAY_EXPIRE_DATE  =   (endDate) => {
    //return new Date(endDate * 1e3).toISOString();
    let date = moment.unix(endDate);
    //return date.format("YYYY-MM-DD");
    return date.format("MM/DD/YYYY");
}

export const STRING_TO_BOOLEAN    =   (value) => {
    return (String(value).toLowerCase() === 'true');
}

export const SHOW_PRICE_WITH_DISCOUNT   =   (price, couponDetails=[]) => {
    if(couponDetails.length > 0) {
        if(couponDetails[0]["percentage"] !== undefined && couponDetails[0]["percentage"] !== null && parseFloat(couponDetails[0]["percentage"]) !== 0 ) {
            const discountAmount    =   ((parseFloat(couponDetails[0]["percentage"])/ 100) * parseFloat(price));
            const priceAmount       =   parseFloat(price) - parseFloat(discountAmount);
            return parseFloat((priceAmount).toFixed(2));
        } else if(couponDetails[0]["amount"] !== undefined && couponDetails[0]["amount"] !== null && parseFloat(couponDetails[0]["amount"])  !== 0 ) {
            const discountAmount    =   parseFloat(price) - parseFloat(couponDetails[0]["amount"]);
            return parseFloat((discountAmount).toFixed(2));
        } else {
            return price;
        }
    } else {
        return price;
    }
}