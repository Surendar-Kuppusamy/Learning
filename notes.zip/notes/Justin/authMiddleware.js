import jwt from 'jsonwebtoken';
import expressAsyncHandler from 'express-async-handler';
import { getDBConnection } from '../config/db.js';
import { Users } from '../models/UsersModel.js';
import { Admin } from '../models/AdminModel.js';

let USERID = 0;

export const verifyToken = async(req, res, next) => {
    let token;
    let err;
    if(req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        try {
            token = req.headers.authorization.split(' ')[1];
            jwt.verify(token, process.env.JWT_SECRET, function(err, decoded) {
                if(err) {
                    if(err.hasOwnProperty('name') && err.name == 'TokenExpiredError') {
                        res.status(200).json({
                            status: 'error',
                            message: 'Token expired.'
                        });
                    } else {
                        res.status(200).json({
                            status: 'error',
                            message: 'Invalid token.'
                        });
                    }
                } else {
                    setTimeout(async() => {
                        USERID = decoded.user_id;
                        const db = await getDBConnection();
                        const isTokenExists = await db.collection(Users.collection.name).where(Users.fields.access_token.key, '==', token).get();
                        if(isTokenExists.empty) {
                            res.status(200).json({
                                status: 'error',
                                message: 'Token expired.'
                            });
                        } else {
                            const usersRef = await db.collection(Users.collection.name).doc(decoded.user_id.toString());
                            const doc = await usersRef.get();
                            if(!doc.exists) {
                                res.status(200).json({
                                    status: 'error',
                                    message: 'Invalid token.'
                                });
                            } else {
                                next();
                            }
                        }
                    })
                }
            });
        } catch (error) {
            throw new Error(error.message);
        }
    } else {
        res.status(200).json({
            status: 'error',
            message: 'Token Required.'
        });
    }
}
export const verifyAdminToken = async(req, res, next) => {
    let token;
    let err;
    if(req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        try {
            token = req.headers.authorization.split(' ')[1];
            jwt.verify(token, process.env.JWT_SECRET, function(err, decoded) {
                if(err) {
                    if(err.hasOwnProperty('name') && err.name == 'TokenExpiredError') {
                        res.status(200).json({
                            status: 'error',
                            message: 'Token expired.'
                        });
                    } else {
                        res.status(200).json({
                            status: 'error',
                            message: 'Invalid token.'
                        });
                    }
                } else {
                    setTimeout(async() => {
                        USERID = decoded.user_id;
                        const db = await getDBConnection();
                        const isTokenExists = await db.collection(Admin.collection.name).where(Admin.fields.access_token.key, '==', token).get();
                        if(isTokenExists.empty) {
                            res.status(200).json({
                                status: 'error',
                                message: 'Token expired.'
                            });
                        } else {
                            const usersRef = await db.collection(Admin.collection.name).doc(decoded.user_id.toString());
                            const doc = await usersRef.get();
                            if(!doc.exists) {
                                res.status(200).json({
                                    status: 'error',
                                    message: 'Invalid token.'
                                });
                            } else {
                                next();
                            }
                        }
                    })
                }
            });
        } catch (error) {
            throw new Error(error.message);
        }
    } else {
        res.status(200).json({
            status: 'error',
            message: 'Token Required.'
        });
    }
}
export const generateToken = (user_id) => {
    return jwt.sign({ user_id:  user_id}, process.env.JWT_SECRET, {  }, { algorithm: 'RS256'});
};

export const getUserId = async(req) => {
    let token;
    if(req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        try {
            token = req.headers.authorization.split(' ')[1];
            const decoded = await jwt.verify(token, process.env.JWT_SECRET);
            return parseInt(decoded.user_id);
        } catch (error) {
            throw new Error(error.message);
            return false;
        }
    }   
}