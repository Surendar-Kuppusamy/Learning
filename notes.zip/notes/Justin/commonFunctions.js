import admin from 'firebase-admin';
import expressAsyncHandler from 'express-async-handler';
import fs from 'fs';
import os from 'os';
import multer from 'multer';
import path, { resolve } from 'path';
import ffmpeg from 'fluent-ffmpeg';
import ffmpeg_static from 'ffmpeg-static';
import sharp from 'sharp';
import { getDBConnection, getStorageConnection } from '../config/db.js';
import { Users } from '../models/UsersModel.js';
import { Music } from '../models/MusicModel.js';
import { AllCollectionsDocumentID } from '../models/AllCollectionsDocumentID.js';
import { PopulatedImagesLikeDeteleDetails } from '../models/PopulatedImagesLikeDeteleDetailsModel.js';
import { PopulateImages } from '../models/PopulateImagesModel.js';
import { CompilationMedias } from '../models/CompilationMediasModel.js';
import { Activities } from '../models/ActivitiesModel.js';
import { MediaGroup } from '../models/MediasGroupModel.js';
import { CHECK_VIDEO_EXTENSION, CHECK_IMAGE_EXTENSION, COMPILATION_IMAGE_FILE_PATH, MUSIC_PATH, POPULATED_IMAGE_PATH, COMPILATION_VIDEO_FILE_PATH, POPULATED_VIDEO_PATH, POPULATED_VIDEO_THUMBNAIL_PATH, JUSTIN_COMPILATION_FILE_PATH, FILE_ROOT_PATH, MEDIA_PATH, MEDIA_TYPE, TYPE } from '../constants/globalConstants.js';


//Below function is used to get the last inserted ID of collection. It will return ID, which will be used to insert new record. Function Arguments(collection[String data type], field[String data type]) => [collection] = "Collection name" and [field] = "On which field is having auto increment ID in the collections."
export const getLastInsertedID = expressAsyncHandler(async(collection, field, next) => {
    return new Promise(async(resolve, reject) => {
        try {
            const db = await getDBConnection();
            const collectionRef = await db.collection(AllCollectionsDocumentID.collection.name).doc('1');
            let doc = await collectionRef.get();
            if(!doc.exists) {   //If there is empty record in collection then insert default value
                let docID = await collectionRef.set(AllCollectionsDocumentID.default, { merge: true });
            }
            let dataObj = {
                [AllCollectionsDocumentID.fields.modified_on.key]: await admin.firestore.FieldValue.serverTimestamp(),
                [field]: admin.firestore.FieldValue.increment(1)
            };
            let updated = await collectionRef.set(dataObj, {merge: true});
            let allIDs = await  collectionRef.get();
            //return allIDs.get(field);
            resolve(allIDs.get(field));
        } catch(e) {
            console.log('Catch error in common function getLastInsertedID()');
            var errorLog = await saveErrorLogFileWithpath('getLastInsertedID', e.stack);
            let error = new Error(e.message);
            next(error);
        }
    });
});
/* export const getLastInsertedID = expressAsyncHandler(async(collection, field) => {
    try {
        const db = await getDBConnection();
        const collectionRef = await db.collection(collection).orderBy(field, 'desc').limit(1).get();
        if(collectionRef.empty) {   //If there is empty record in collection then return 1
            return 1;
        } else {
            let lastID = await collectionRef.docs[0].data()[field];
            lastID = lastID + 1;
            return lastID;
        }
    } catch(e) {
        console.log('Catch error in common function');
        errorLogger.error('Error occured on common function method "getLastInsertedID()", for logging', e);
        throw new Error(e.message);
    }
}); */

//Below function is used to get the collection data with document ID[Note: It will not get reference link data]. It will return data. Function Arguments(collection[String data type], document[Integer data type]) => [collection] = "Collection name",  [docID] = "In which document ID"
export const getCollectionDataWithDocID = expressAsyncHandler(async(collection, docID, next) => {
    return new Promise(async(resolve, reject) => {
        try {
            const db = await getDBConnection();
            let snapshot = await db.collection(collection).doc(docID.toString());
            let doc = await snapshot.get();
            if(!doc.exists) {
                resolve([]);
                //return [];
            } else {
                let data = [{id: parseInt(doc.id), ...doc.data()}];
                resolve(data);
                //return data;
            }
        } catch(e) {
            console.log('Catch error in common function getCollectionDataWithDocID()');
            var errorLog = await saveErrorLogFileWithpath('getCollectionDataWithDocID', e.stack);
            let error = new Error(e.message);
            next(error);
        }
    });
});

//Below function is used to get the collection data with document ID along with select fields options[Note: It will not get reference link data]. It will return data. Function Arguments(collection[String data type], docID[Integer data type], selectFieldsArr[Array data type]) => [collection] = "Collection name",  [docID] = "In which document ID", [selectFieldsArr] => "Array of fields which you want to select"
export const getCollectionDataWithSelectAndDocID = expressAsyncHandler(async(collection, docID, selectFieldsArr, next) => {
    return new Promise(async(resolve, reject) => {
        try {
            const db = await getDBConnection();
            let snapshot = await db.collection(collection).doc(docID.toString());
            let doc = await snapshot.get();
            if(!doc.exists) {
                resolve([]);
                //return [];
            } else {
                //let tempData = [{id: parseInt(doc.id), ...doc.data()}];
                let data = [];
                data[0] = {};
                data[0]['id'] = parseInt(doc.id);
                for(var i = 0; i < selectFieldsArr.length; i++) {
                    data[0][selectFieldsArr[i]] = doc.data()[selectFieldsArr[i]];
                    //data[0][selectFieldsArr[i]] = doc.get([selectFieldsArr[i]]);  //It shows error
                }
                resolve(data);
                //return data;
            }
        } catch(e) {
            console.log('Catch error in common function getCollectionDataWithSelectAndDocID()');
            var errorLog = await saveErrorLogFileWithpath('getCollectionDataWithSelectAndDocID', e.stack);
            let error = new Error(e.message);
            next(error);
        }
    });
});

//Below function is used to get the collection data with custom condition along with offset and limit[Note: It will not get reference link data]. It will return data. Function Arguments(collection[String data type], allCondition[Object data type], offset[Integer data type], limit[Integer data type]) => [collection] = "Collection name",  [allCondition] = "On which add your required custom conditions. In which add orderby data at last.", [offset] = "Offset of the collection list for pagination", [limit] = "Limit of the collection list for pagination"
export const getCollectionData = expressAsyncHandler(async(collection, allCondition, offset, limit, next) => {
    try {
        const db = await getDBConnection();
        let query = await db.collection(collection);
        if(Object.keys(allCondition).length != 0) {
            let result = await Promise.all(Object.keys(allCondition).map(async(key, index) => {
                return new Promise(async function(resolve, reject){
                    if(allCondition[key].type == 'where') {
                        query = await query.where(allCondition[key].field, allCondition[key].operator, allCondition[key].value);
                    } else if(allCondition[key].type == 'orderby') {
                        query = await query.orderBy(allCondition[key].field, allCondition[key].order);
                    } else if(allCondition[key].type == 'select') {
                        query = await query.select(...allCondition[key].fields);//In which fields used instead of field, because select fields in an array
                    }
                    resolve(allCondition[key]);
                })
            }));
        }
        if(offset != 0) {
            query = query.offset(offset);
        }
        if(limit != 0) {
            query = query.limit(limit);
        }
        let snapshot = await query.get();
        if(snapshot.empty) {
            return [];
        } else {
            let data = snapshot.docs.map(doc => {return{id: parseInt(doc.id), ...doc.data()}});
            return data;
        }
    } catch(e) {
        console.log('Catch error in common function getCollectionData()');
        var errorLog = await saveErrorLogFileWithpath('getCollectionData', e.stack);
        let error = new Error(e.message);
        next(error);
    }
});


export const getCollectionDataTotalCount = expressAsyncHandler(async(collection, allCondition, offset, limit, next) => {
    try {
        const db = await getDBConnection();
        let query = await db.collection(collection);
        if(Object.keys(allCondition).length != 0) {
            let result = await Promise.all(Object.keys(allCondition).map(async(key, index) => {
                return new Promise(async function(resolve, reject){
                    if(allCondition[key].type == 'where') {
                        query = await query.where(allCondition[key].field, allCondition[key].operator, allCondition[key].value);
                    } else if(allCondition[key].type == 'orderby') {
                        query = await query.orderBy(allCondition[key].field, allCondition[key].order);
                    } else if(allCondition[key].type == 'select') {
                        query = await query.select(...allCondition[key].fields);//In which fields used instead of field, because select fields in an array
                    }
                    resolve(allCondition[key]);
                })
            }));
        }
        if(offset != 0) {
            query = query.offset(offset);
        }
        if(limit != 0) {
            query = query.limit(limit);
        }
        let snapshot = await query.get();
        if(snapshot.empty) {
            return 0;
        } else {
            return snapshot.size;
        }
    } catch(e) {
        console.log('Catch error in common function getCollectionData()');
        var errorLog = await saveErrorLogFileWithpath('getCollectionDataTotalCount', e.stack);
        throw new Error(e.message);
        //let error = new Error(e.message);
        //next(error);
    }
});

//Below function is used to check is document exists or not. Function Arguments(collection[String data type], docID[Integer data type]). [collection] => "Collection name", [docID] => "Document ID"
export const checkIsDocExists = expressAsyncHandler(async(collection, docID, next) => {
    return new Promise(async(resolve, reject) => {
        try {
            const db = await getDBConnection();
            let doc = await db.collection(collection).doc(docID.toString()).get();
            if(!doc.exists) {
                resolve(false);
                //return false;
            } else {
                resolve(true);
                //return true;
            }
        } catch(e) {
            console.log('Catch error in common function checkIsDocExists()');
            var errorLog = await saveErrorLogFileWithpath('checkIsDocExists', e.stack);
            let error = new Error(e.message);
            next(error);
        }
    });
});

//Below function is used to check is data exists or not and it will return true. Function Arguments(collection[String data type], allCondition[Object data type], offset[Integer data type], limit[Integer data type]) => [collection] = "Collection name",  [allCondition] = "On which add your required custom conditions. In which add orderby data at last.", [offset] = "Offset of the collection list for pagination", [limit] = "Limit of the collection list for pagination"
export const checkIsDataExists = expressAsyncHandler(async(collection, allCondition, offset, limit, next) => {
    try {
        const db = await getDBConnection();
        let query = await db.collection(collection);
        //Start: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        if(Object.keys(allCondition).length != 0) {
            let result = await Promise.all(Object.keys(allCondition).map(async(key, index) => {
                return new Promise(async function(resolve, reject){
                    if(allCondition[key].type == 'where') {
                        query = await query.where(allCondition[key].field, allCondition[key].operator, allCondition[key].value);
                    } else if(allCondition[key].type == 'orderby') {
                        query = await query.orderBy(allCondition[key].field, allCondition[key].order);
                    } else if(allCondition[key].type == 'select') {
                        query = await query.select(...allCondition[key].fields);//In which fields used instead of field, because select fields in an array
                    }
                    resolve(allCondition[key]);
                })
            }));
        }
        //End: This block is used instead of "for" loop, for the reason of "wait untill loop is going to finish and then execute next code"
        if(offset != 0) {
            query = query.offset(offset);
        }
        if(limit != 0) {
            query = query.limit(limit);
        }
        let snapshot = await query.get();
        if(snapshot.empty) {
            return false;
        } else {
            return true;
        }
    } catch(e) {
        console.log('Catch error in common function checkIsDataExists()');
        var errorLog = await saveErrorLogFileWithpath('checkIsDataExists', e.stack);
        let error = new Error(e.message);
        next(error);
    }
});

//[Child function]Below function is used to return, what are all the reference link is wanted its data[We should mention it and what name should use on get data and delete reference field from data. Function Arguments(data[Object data type], referenceFieldsArray[Array data type], referenceFieldsNameSetArray[Array data type]) => [data] = "It have data which is getted from collection which is from parent function",  [referenceFieldsArray] = "Which have the list of fields with reference data type.", [referenceFieldsNameSetArray] = "It list the what kind of name should be used on data get."
export const getAllReferenceFields = expressAsyncHandler(async(data, referenceFieldsArray, referenceFieldsNameSetArray, next) => {
    try {
        return new Promise(function(resolve, reject){
            let referenceFieldsWithLinkAndnames = {
                links: [],
                names: []
            };
            let referenceFieldsWithLink = [];
            let referenceFieldsNames = [];
            for(var i = 0; i < referenceFieldsArray.length; i++) {
                if(data.hasOwnProperty(referenceFieldsArray[i]) && data[referenceFieldsArray[i]] != null) {
                    referenceFieldsWithLink.push(data[referenceFieldsArray[i]]);
                    referenceFieldsNames.push(referenceFieldsNameSetArray[i]);
                    delete data[referenceFieldsArray[i]];
                }
            }
            referenceFieldsWithLinkAndnames['links'] = referenceFieldsWithLink;
            referenceFieldsWithLinkAndnames['names'] = referenceFieldsNames;
            referenceFieldsWithLinkAndnames['data'] = data; //It is been not used. But don't remove it.
            resolve(referenceFieldsWithLinkAndnames);
        });
    } catch(e) {
        console.log('Catch error in common function getAllReferenceFields()');
        var errorLog = await saveErrorLogFileWithpath('getAllReferenceFields', e.stack);
        let error = new Error(e.message);
        next(error);
    }
});

//Below function is used to get data from collection along with the reference link. Function Arguments(collection[String data type], allCondition[Object data type], offset[Integer data type], limit[Integer data type], referenceFieldsArray[Array data type], referenceFieldsNameSetArray[Array data type]) => [collection] = "Collection name",  [allCondition] = "On which add your required custom conditions. In which add orderby data at last.", [offset] = "Offset of the collection list for pagination", [limit] = "Limit of the collection list for pagination", [referenceFieldsArray] = "Which have the list of fields with reference data type.", [referenceFieldsNameSetArray] = "It list the what kind of name should be used on data get."
export const getCollectionDataWithReferenceLinkData = expressAsyncHandler(async(collection, allCondition, offset, limit, referenceFieldsArray, referenceFieldsNameSetArray, next) => {
    try {
        const db = await getDBConnection();
        let query = await db.collection(collection);
        //Start: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        if(Object.keys(allCondition).length != 0) {
            let result = await Promise.all(Object.keys(allCondition).map(expressAsyncHandler(async(key, index) => {
                return new Promise(async function(resolve, reject){
                    if(allCondition[key].type == 'where') {
                        query = await query.where(allCondition[key].field, allCondition[key].operator, allCondition[key].value);
                    } else if(allCondition[key].type == 'orderby') {
                        query = await query.orderBy(allCondition[key].field, allCondition[key].order);
                    } else if(allCondition[key].type == 'select') {
                        query = await query.select(...allCondition[key].fields);//In which fields used instead of field, because select fields in an array
                    }
                    resolve(allCondition[key]);
                })
            })));
        }
        //Start: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        if(offset != 0) {
            query = query.offset(offset);
        }
        if(limit != 0) {
            query = query.limit(limit);
        }
        let snapshot = await query.get();
        if(snapshot.empty) {
            return [];
        } else {
            let datas = await Promise.all(snapshot.docs.map(expressAsyncHandler(async(doc) => {
                let temp = {
                    id: parseInt(doc.id),
                    ...doc.data()
                };
                let allReferenceDetails = await getAllReferenceFields(temp, referenceFieldsArray, referenceFieldsNameSetArray, next);
                temp = allReferenceDetails['data'];
                let tempObj = await getAllReferenceData(allReferenceDetails['names'], allReferenceDetails['links'], next);
                temp = Object.assign(temp, tempObj); //Merge or override the reference link data on the main data.
                return temp;
                /* let temp = {};
                temp['id'] = parseInt(doc.id);
                temp['data'] = await doc.data();
                let allReferenceDetails = await getAllReferenceFields(temp['data'], referenceFieldsArray, referenceFieldsNameSetArray);
                temp['data'] = allReferenceDetails['data'];
                let tempObj = await getAllReferenceData(allReferenceDetails['names'], allReferenceDetails['links']);
                temp['data'] = Object.assign(temp['data'], tempObj); //Merge or override the reference link data on the main data.
                return temp; */
            })));
            return datas;
        }
    } catch(e) {
        console.log('Catch error in common function getCollectionDataWithReferenceLinkData()');
        var errorLog = await saveErrorLogFileWithpath('getCollectionDataWithReferenceLinkData', e.stack);
        let error = new Error(e.message);
        next(error);
    }
});

//[Child function]Below function is used to get reference link data from collection. Function Arguments(refArr[Array data type], references[Array data type]). [refArr] => It list the what kind of name should be used on data get., [references] => Array of reference links.
export const getAllReferenceData = expressAsyncHandler(async(refArr, references, next) => {
    try {
        const db = await getDBConnection();
        return new Promise(function(resolve, reject){
            db.getAll(...references).then(docs => {
                const data = docs.map(doc => doc.data());
                let tempData = {};
                for(var i=0; i < data.length; i++) {
                    tempData[refArr[i]] = {
                        id: parseInt(docs[i].id),
                        ...data[i]
                    }
                }
                resolve(tempData);
            }).catch(err => reject(err));
        });
    } catch(e) {
        console.log('Catch error in common function getAllReferenceData()');
        var errorLog = await saveErrorLogFileWithpath('getAllReferenceData', e.stack);
        let error = new Error(e.message);
        next(error);
    }
});


//[Child function]Below function is used to return, what are all the reference link is wanted its data[We should mention it and what name should use on get data and delete reference field from data. Function Arguments(data[Object data type], referenceFieldsArray[Array data type], referenceFieldsNameSetArray[Array data type], removeFieldsArr[Array data type], selectFieldsObj[Object data type]) => [data] = "It have data which is getted from collection which is from parent function",  [referenceFieldsArray] = "Which have the list of fields with reference data type.", [referenceFieldsNameSetArray] = "It list the what kind of name should be used on data get.", [removeFieldsArr] = "Array of fields should be removed", [selectFieldsObj] = "Get the fields you want to select in a array of object, First object key represents the parent and then next number keys represents reference link by order, so don't change order."
export const getAllReferenceSelectFields = expressAsyncHandler(async(data, referenceFieldsArray, referenceFieldsNameSetArray, selectFieldsObj, next) => {
    try {
        return new Promise(function(resolve, reject){
            let referenceFieldsWithLinkAndnames = {
                links: [],
                names: []
            };
            let referenceFieldsWithLink = [];
            let referenceFieldsNames = [];
            let referenceFieldsSelect = {};
            let count = 0;
            for(var i = 0; i < referenceFieldsArray.length; i++) {
                if(data.hasOwnProperty(referenceFieldsArray[i]) && data[referenceFieldsArray[i]] != null) {
                    referenceFieldsWithLink.push(data[referenceFieldsArray[i]]);
                    referenceFieldsNames.push(referenceFieldsNameSetArray[i]);
                    referenceFieldsSelect[count.toString()] = selectFieldsObj[(i+1).toString()];
                    if(selectFieldsObj.hasOwnProperty('process_name')) {
                        referenceFieldsSelect['process_name'] = selectFieldsObj['process_name'];
                    }
                    if(data.hasOwnProperty(referenceFieldsArray[i])) {
                        delete data[referenceFieldsArray[i]];
                    }
                    count = count + 1;
                } else {
                    data[referenceFieldsNameSetArray[i]] = data[referenceFieldsArray[i]];   //Over write the key name for reference link
                    delete data[referenceFieldsArray[i]];
                }
            }
            /* referenceFieldsWithLinkAndnames['data'] = {};
            for(var j = 0; j < selectFieldsObj["1"].length; j++) {
                referenceFieldsWithLinkAndnames['data']['id'] = parseInt(data.id);
                if(data.hasOwnProperty(selectFieldsObj["1"][j])) {
                    referenceFieldsWithLinkAndnames['data'][selectFieldsObj["1"][j]] = data[selectFieldsObj["1"][j]];
                }
            } */
            referenceFieldsWithLinkAndnames['data'] = data; //It is been not used. But don't remove it.
            referenceFieldsWithLinkAndnames['links'] = referenceFieldsWithLink;
            referenceFieldsWithLinkAndnames['names'] = referenceFieldsNames;
            referenceFieldsWithLinkAndnames['select'] = referenceFieldsSelect;
            resolve(referenceFieldsWithLinkAndnames);
        });
    } catch(e) {
        console.log('Catch error in common function getAllReferenceSelectFields()');
        var errorLog = await saveErrorLogFileWithpath('getAllReferenceSelectFields', e.stack);
        let error = new Error(e.message);
        next(error);
    }
});


//Below function is used to get data from collection along with the reference link. Function Arguments(collection[String data type], allCondition[Object data type], offset[Integer data type], limit[Integer data type], referenceFieldsArray[Array data type], referenceFieldsNameSetArray[Array data type], selectFieldsObj[Object data type]) => [collection] = "Collection name",  [allCondition] = "On which add your required custom conditions. In which add orderby data at last.", [offset] = "Offset of the collection list for pagination", [limit] = "Limit of the collection list for pagination", [referenceFieldsArray] = "Which have the list of fields with reference data type.", [referenceFieldsNameSetArray] = "It list the what kind of name should be used on data get.", [selectFieldsObj] => "Get the fields you want to select in a array of object, First object key represents the parent and then next number keys represents reference link by order, so don't change order."
export const getCollectionDataWithReferenceLinkSelectData = expressAsyncHandler(async(collection, allCondition, offset, limit, referenceFieldsArray, referenceFieldsNameSetArray, selectFieldsObj, next) => {
    try {
        const db = await getDBConnection();
        let query = await db.collection(collection);
        //Start: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        if(Object.keys(allCondition).length != 0) {
            let result = await Promise.all(Object.keys(allCondition).map(expressAsyncHandler(async(key, index) => {
                return new Promise(async function(resolve, reject){
                    if(allCondition[key].type == 'where') {
                        query = await query.where(allCondition[key].field, allCondition[key].operator, allCondition[key].value);
                    } else if(allCondition[key].type == 'orderby') {
                        query = await query.orderBy(allCondition[key].field, allCondition[key].order);
                    } else if(allCondition[key].type == 'select') {
                        query = await query.select(...allCondition[key].fields);//In which fields used instead of field, because select fields in an array
                    }
                    resolve(allCondition[key]);
                })
            })));
        }
        //Start: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        if(offset != 0) {
            query = query.offset(offset);
        }
        if(limit != 0) {
            query = query.limit(limit);
        }
        let snapshot = await query.get();
        if(snapshot.empty) {
            return [];
        } else {
            let datas = await Promise.all(snapshot.docs.map(expressAsyncHandler(async(doc) => {
                let temp = {
                    id: parseInt(doc.id),
                    ...doc.data()
                };
                let allReferenceDetails = await getAllReferenceSelectFields(temp, referenceFieldsArray, referenceFieldsNameSetArray, selectFieldsObj, next);
                temp = allReferenceDetails['data'];
                let tempObj = await getAllReferenceSelectData(allReferenceDetails['names'], allReferenceDetails['select'], allReferenceDetails['links'], next);
                temp = Object.assign(temp, tempObj); //Merge or override the reference link data on the main data.
                return temp;
                /* let temp = {};
                temp['id'] = parseInt(doc.id);
                temp['data'] = await doc.data();
                let allReferenceDetails = await getAllReferenceSelectFields(temp['data'], referenceFieldsArray, referenceFieldsNameSetArray, selectFieldsObj);
                temp['data'] = allReferenceDetails['data'];
                let tempObj = await getAllReferenceSelectData(allReferenceDetails['names'], allReferenceDetails['select'], allReferenceDetails['links']);
                temp['data'] = Object.assign(temp['data'], tempObj); //Merge or override the reference link data on the main data.
                return temp; */
            })));
            return datas;
        }
    } catch(e) {
        console.log('Catch error in common function getCollectionDataWithReferenceLinkSelectData()');
        var errorLog = await saveErrorLogFileWithpath('getCollectionDataWithReferenceLinkSelectData', e.stack);
        let error = new Error(e.message);
        next(error);
    }
});

//[Child function]Below function is used to get reference link data from collection with the fields selection option. Function Arguments(refArr[Array data type], selectFieldsObj[Object data type], references[Array data type]). [refArr] => It list the what kind of name should be used on data get., [references] => Array of reference links, [selectFieldsObj] => Get the fields you want to select in a array of object, First object key represents the parent and then next number keys represents reference link by order, so don't change order.
export const getAllReferenceSelectData = expressAsyncHandler(async(refArr, selectFieldsObj, references, next) => {
    try {
        const db = await getDBConnection();
        return new Promise(function(resolve, reject){
            db.getAll(...references).then(docs => {
                /* let tempData = {};
                const data = docs.map((doc, i) => {
                    console.log(selectFieldsObj);
                    tempData[refArr[i]] = {};
                    for(var j = 0; j < selectFieldsObj[i.toString()].length; j++) {
                        tempData[refArr[i]]['id'] = parseInt(doc.id);
                        tempData[refArr[i]][selectFieldsObj[i.toString()][j]] = doc.get(selectFieldsObj[i.toString()][j]);
                    }
                });
                resolve(tempData); */
                const data = docs.map(doc => doc.data());
                let tempData = {};
                for(var i=0; i < data.length; i++) {
                    tempData[refArr[i]] = {};
                    for(var j = 0; j < selectFieldsObj[i.toString()].length; j++) {
                        tempData[refArr[i]]['id'] = parseInt(docs[i].id);
                        if(data[i].hasOwnProperty(selectFieldsObj[i.toString()][j])) {
                            tempData[refArr[i]][selectFieldsObj[i.toString()][j]] = data[i][selectFieldsObj[i.toString()][j]];
                        }
                        if(selectFieldsObj.hasOwnProperty('process_name') && selectFieldsObj['process_name'] == 'helpinghand_list') {
                            if(data[i].hasOwnProperty('temporary_helpinghand_user_id')) {
                                tempData[refArr[i]]['flag'] = 2;
                            } else if(data[i].hasOwnProperty('users_id')) {
                                tempData[refArr[i]]['flag'] = 1;
                            }
                            if(data[i].hasOwnProperty('profile_image')) {
                                tempData[refArr[i]]['profile'] = '';
                                if(tempData[refArr[i]]['profile_image'] != undefined && tempData[refArr[i]]['profile_image'] != null && tempData[refArr[i]]['profile_image'] != '') {
                                    if(process.env.MODE == "development") {
                                        tempData[refArr[i]]['profile'] = 'http://172.21.4.120:3000/public/profile/'+tempData[refArr[i]]['id']+'/'+tempData[refArr[i]]['profile_image'];
                                    } else {
                                        tempData[refArr[i]]['profile'] = process.env.STORAGE_BASE_URL+'public%2Fprofile'+'%2F'+tempData[refArr[i]]['id']+'%2F'+tempData[refArr[i]]['profile_image']+'?alt=media';
                                    }
                                }
                            }
                        } else if(selectFieldsObj.hasOwnProperty('process_name') && selectFieldsObj['process_name'] == 'user_list') {
                            if(data[i].hasOwnProperty('profile_image')) {
                                tempData[refArr[i]]['profile'] = '';
                                if(tempData[refArr[i]]['profile_image'] != undefined && tempData[refArr[i]]['profile_image'] != null && tempData[refArr[i]]['profile_image'] != '') {
                                    if(process.env.MODE == "development") {
                                        tempData[refArr[i]]['profile'] = 'http://172.21.4.120:3000/public/profile/'+tempData[refArr[i]]['id']+'/'+tempData[refArr[i]]['profile_image'];
                                    } else {
                                        tempData[refArr[i]]['profile'] = process.env.STORAGE_BASE_URL+'public%2Fprofile'+'%2F'+tempData[refArr[i]]['id']+'%2F'+tempData[refArr[i]]['profile_image']+'?alt=media';
                                    }
                                }
                            }
                        } else {
                            console.log(selectFieldsObj);
                        }
                    }
                }
                resolve(tempData);
            }).catch(err => reject(err));
        });
    } catch(e) {
        console.log('Catch error in common function getAllReferenceSelectData()');
        var errorLog = await saveErrorLogFileWithpath('getAllReferenceSelectData', e.stack);
        let error = new Error(e.message);
        next(error);
    }
});



//Below function is used to insert data into collection. Function Arguments(collection[Object data type], dataObj[Object data type], idField[String data type]). [collection] => "Collection Object from models", [dataObj] => "Data is going to insert", [idField] => "On which field is auto increment ID is stored for this collection"
export const insertData = expressAsyncHandler(async(Collection, dataObj, idField, next) => {
    return new Promise(async (resolve, reject) => {
        try {
            const db = await getDBConnection();
            let docID = await getLastInsertedID(Collection.collection.name, idField, next);
            dataObj[idField] = docID;
            let insertDataObj = Object.assign(Collection.default, dataObj); //By default add all fields on this insert record from the collection model
            const insertedDetail = await db.collection(Collection.collection.name).doc(docID.toString()).set(insertDataObj, { merge: true });
            resolve(docID);
            //return docID;
        } catch(e) {
            console.log('Catch error in common function insertData()');
            var errorLog = await saveErrorLogFileWithpath('insertData', e.stack);
            let error = new Error(e.message);
            next(error);
        }
    });
});

//Below function is used to update data into collection. Function Arguments(collection[String data type], dataObj[Object data type], docID[Integer data type]). [collection] => "Collection name", [dataObj] => "Data is going to insert", [docID] => "On which document is going to updated on collections"
export const updateData = expressAsyncHandler(async(collection, dataObj, docID, next) => {
    return new Promise(async(resolve, reject) => {
        try {
            const db = await getDBConnection();
            const updatedDetail = await db.collection(collection).doc(docID.toString()).set(dataObj, { merge: true });
            resolve(docID);
            //return docID;
        } catch(e) {
            console.log('Catch error in common function updateData()');
            var errorLog = await saveErrorLogFileWithpath('updateData', e.stack);
            let error = new Error(e.message);
            next(error);
        }
    });
});

//Below function is used to delete documents from collection. Function Arguments(collection[String data type], docIDArr[Array data type]). [collection] => "Collection name", [docIDArr] => "All this doument ID's are going to deleted from the collection"
export const deleteDataWithDocumentID = expressAsyncHandler(async(collection, docIDArr, next) => {
    try {
        const db = await getDBConnection();
        const batch = await db.batch();
        //Start: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        let result = await Promise.all(docIDArr.map(async (docID) => {
            return new Promise(async function(resolve, reject){
                let docRef = await db.collection(collection).doc(docID.toString());
                let res = await batch.delete(docRef);
                resolve(res);
            });
        }));
        //End: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        await batch.commit();
        return result;
    } catch(e) {
        console.log('Catch error in common function deleteDataWithDocumentID()');
        var errorLog = await saveErrorLogFileWithpath('deleteDataWithDocumentID', e.stack);
        let error = new Error(e.message);
        next(error);
    }
});

//Below function is used to delete the fields on the document of collection. Function Arguments(collection[String data type], docIDArr[Array data type], fieldObj[Object data type]). [collection] => "Collection name", [docIDArr] => "All this doument ID's are going to used for delete field deletion", [fieldObj] => "In represents the field which is going to delete Ex: let fieldObj = {capital: admin.firestore.FieldValue.delete()};"
export const deleteFieldWithDocumentID = expressAsyncHandler(async(collection, docIDArr, fieldObj, next) => {
    try {
        const db = await getDBConnection();
        //Start: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        let result = await Promise.all(docIDArr.map(async (docID) => {
            return new Promise(async function(resolve, reject){
                let docRef = await db.collection(collection).doc(docID.toString());
                const res = await docRef.set(fieldObj, { merge: true });
                resolve(res);
            });
        }));
        //End: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        return result;
    } catch(e) {
        console.log('Catch error in common function deleteFieldWithDocumentID()');
        var errorLog = await saveErrorLogFileWithpath('deleteFieldWithDocumentID', e.stack);
        let error = new Error(e.message);
        next(error);
    }
});

//Below function is used to delete documents of collection with the conditions. Function Arguments(collection[String data type], allCondition[Object data type]). [collection] => "Collection name", [allCondition] => "On which add your required custom conditions. In which add orderby data at last."
export const deleteDataWithCondition = expressAsyncHandler(async(collection, allCondition, next) => {    //Mostly don't use it. It will delete the all records in the collection with matched condition, if no condition then it delete all records of collection. It will not delete collection.
    try {
        const db = await getDBConnection();
        let query = await db.collection(collection);
        //Start: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        if(Object.keys(allCondition).length != 0) {
            let result = await Promise.all(Object.keys(allCondition).map(async(key, index) => {
                return new Promise(async function(resolve, reject){
                    if(allCondition[key].type == 'where') {
                        query = await query.where(allCondition[key].field, allCondition[key].operator, allCondition[key].value);
                    } else if(allCondition[key].type == 'orderby') {
                        query = await query.orderBy(allCondition[key].field, allCondition[key].order);
                    } else if(allCondition[key].type == 'select') {
                        query = await query.select(...allCondition[key].fields);//In which fields used instead of field, because select fields in an array
                    }
                    resolve(allCondition[key]);
                })
            }));
        }
        //End: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        let snapshot = await query.get();
        if(snapshot.empty) {
            return false;
        } else {
            return new Promise((resolve, reject) => {
                deleteQueryBatch(db, query, resolve, next).catch(reject);
            });
        }
    } catch(e) {
        console.log('Catch error in common function deleteDataWithCondition()');
        var errorLog = await saveErrorLogFileWithpath('deleteDataWithCondition', e.stack);
        let error = new Error(e.message);
        next(error);
    }
});

//[Child Function]Below function is used to delete documents of collection. Function Arguments(db[object data type], query[query string], resolve[callback function from promise]). [db] => "Database connections", [query] => "Firestore query with all condition applied", [resolve] => "Call back function from promise"
async function deleteQueryBatch(db, query, resolve, next) {
    return new Promise(async(resolve, reject) => {
        try {
            let snapshot = await query.get();
            const batchSize = snapshot.size;
            if (batchSize === 0) {  //If no data then resolve and 
                // When there are no documents left, we are done
                resolve(true);
                return;
            }
            // Delete documents in a batch
            const batch = db.batch();
            snapshot.docs.forEach((doc) => {
                batch.delete(doc.ref);
            });
            await batch.commit();
            // Recurse on the next process tick, to avoid
            // exploding the stack.
            process.nextTick(() => {    //If data exists it recalls function.
                deleteQueryBatch(db, query, resolve, next);
            });
        } catch(e) {
            console.log('Catch error in common function deleteQueryBatch()');
            var errorLog = await saveErrorLogFileWithpath('deleteQueryBatch', e.stack);
            let error = new Error(e.message);
            next(error);
        }
    });
}

//Below function is used to insert bulk data into the collection. Function Arguments(collection[Object data type], dataArr[Array data type], idField[String data type]). [collection] => "Collection Object from models", [dataArr] => "Data going to insert", [idField] => "On which field has the auto increment ID"
export const insertBulkData = expressAsyncHandler(async(Collection, dataArr, idField, next) => {
    try {
        const db = await getDBConnection();
        const batch = db.batch();
        let docID = await getLastInsertedID(Collection.collection.name, idField, next);
        let result = await Promise.all(dataArr.map(async (doc, index) => {
            return new Promise(async function(resolve, reject){
                if(index != 0) {
                    docID = docID + 1;
                }
                doc[idField] = docID;
                let insertDataObj = {};
                insertDataObj = Object.assign(Collection.default, doc); //By default add all fields on this insert record from the collection model
                let updateIDTable = await batch.set(db.collection(AllCollectionsDocumentID.collection.name).doc('1'), {[AllCollectionsDocumentID.fields[idField].key]: docID}, { merge: true });    //It update the collection ID's table
                let res = await batch.update(db.collection(Collection.collection.name).doc(docID.toString()), insertDataObj, { merge: true });
                //resolve(res);
                resolve(doc);
            });
        }));
        await batch.commit();
        return result;
    } catch(e) {
        console.log('Catch error in common function insertBulkData()');
        var errorLog = await saveErrorLogFileWithpath('insertBulkData', e.stack);
        let error = new Error(e.message);
        next(error);
    }
});


//Below function is used to update bulk data into the collection. Function Arguments(collection[string data type], dataArr[Array data type], docID[Array data type]). [collection] => "Collection name", [dataArr] => "Data going to update", [docID] => "ID's which is used to update document on this collection"
export const updateBulkData = expressAsyncHandler(async(collection, dataObj, docID, next) => {
    try {
        const db = await getDBConnection();
        const batch = db.batch();
        let result = await Promise.all(docID.map(async (docID, index) => {
            return new Promise(async function(resolve, reject){
                let res = await batch.set(db.collection(collection).doc(docID.toString()), dataObj, { merge: true });
                resolve(res);
                //resolve(dataObj);
            });
        }));
        await batch.commit();
        return result;
    } catch(e) {
        console.log('Catch error in common function updateBulkData()');
        var errorLog = await saveErrorLogFileWithpath('updateBulkData', e.stack);
        let error = new Error(e.message);
        next(error);
    }
});

export const generateSMSVerificationCode = expressAsyncHandler(async(mobileNumber, next) => {
    return new Promise(async(resolve, reject) => {
        try {
            let smsCode = Math.floor(Math.random() * 899999 + 100000);
            smsCode = smsCode.toString().substring(0, 4);
            smsCode =  parseInt(smsCode);
            resolve(smsCode);
            //return smsCode;
        } catch(e) {
            console.log('Catch error in common function generateSMSVerificationCode()');
            var errorLog = await saveErrorLogFileWithpath('generateSMSVerificationCode', e.stack);
            let error = new Error(e.message);
            next(error);
        }
    });
});

//Below function used to send the response. Function Arguments(res[Express response object], statusCode[Integer data type], status[String data type], message[String data type], data[Object data type]). [res] => "Express response object", [statusCode] => "Here comes the status code of the response", [status] => "Here comes the status of the API nor 'success' or 'error'", [message] => "Here comes the response message of the API", [data] => "Here comes the extra data need to return to response API"
export const jsonResponse = expressAsyncHandler(async(res, statusCode, status, message, data) => {
    try {
        if(data) {
            res.status(statusCode).json({
                status: status,
                message: message,
                data: data
            });
        } else {
            res.status(statusCode).json({
                status: status,
                message: message
            });
        }
    } catch(e) {
        console.log(e);
        console.log('Catch error in common function jsonResponse()');
        var errorLog = await saveErrorLogFileWithpath('jsonResponse', e.stack);
        throw new Error('Something went wrong');
    }
});

export const fileUploadWithCompressorLocal = expressAsyncHandler(async(filePath, fileName, detail, next) => {
    try {
        return new Promise(async function(resolve, reject) {
            var resizedFilename = 	path.basename(fileName, path.extname(fileName));
            resizedFilename 	=	resizedFilename+'.jpeg';
            await sharp(filePath+'/'+fileName)
                .rotate()
                .toFormat("jpeg", { mozjpeg: true })
                .toFile(path.resolve(filePath,resizedFilename));

            fs.unlinkSync(filePath+'/'+fileName);
            resolve(resizedFilename);
        });
    } catch(e) {
        console.log('Catch error in common function fileUpload()', e);
        var errorLog = await saveErrorLogFileWithpath('fileUpload', e.stack);
        throw new Error(e.message);
    }
});

export const fileUploadWithCompressorLocals = expressAsyncHandler(async(file, filePath, fileName, detail, next) => {
    try {
        return new Promise(async function(resolve, reject) {
            filePath = path.resolve(FILE_ROOT_PATH+filePath);
            let createPath = await createDirectoryLocal(filePath);
            /* var resizedFilename = 	path.basename(fileName, path.extname(fileName));
            resizedFilename 	=	resizedFilename+'.jpeg'; */
            await sharp(file.buffer)
                .rotate()
                .toFormat("jpeg", { mozjpeg: true })
                .toFile(path.resolve(filePath,fileName));
            resolve(fileName);
        });
    } catch(e) {
        console.log('Catch error in common function fileUploadWithCompressorLocals()', e);
        var errorLog = await saveErrorLogFileWithpath('fileUploadWithCompressorLocals', e.stack);
        throw new Error(e.message);
    }
});

export const fileUploadWithCompressor = expressAsyncHandler(async(file, filePath, fileName, detail, next) => {
    try {
        const storage = await getStorageConnection();
        var bucket = await storage.bucket();

        let compressedData;

        await sharp(file.buffer)
        /* .resize(450, 450, {
            fit: sharp.fit.outside,
            withoutReduction: true
        }) */
        .rotate()
        .toFormat("jpeg", { mozjpeg: true })
        .toBuffer()
        .then(data => {
            compressedData = data;
        })
        .catch(async err => { 
            console.log('Catch error in common function fileUploadWithCompressor()', err);
            var errorLog = await saveErrorLogFileWithpath('fileUploadWithCompressor', err.toString());
            let error = new Error("Compress error");
            next(error);
        });

        return new Promise(function(myResolve, myReject) {
            const blob = bucket.file(filePath+fileName);
            const blobWriter = blob.createWriteStream({
                metadata: {
                    contentType: file.mimetype
                }
            })
            
            blobWriter.on('error', async(err) => {
                console.log('File upload error', err);
                let error = new Error('Something went wrong');
                next(error);
                myReject(err);  // when error
            })
            
            blobWriter.on('finish', () => {
                myResolve(fileName); // when successful
            });
            blobWriter.end(compressedData)
        });
    } catch(e) {
        console.log('Catch error in common function fileUploadWithCompressor()');
        var errorLog = await saveErrorLogFileWithpath('fileUploadWithCompressor', e.stack);
        let error = new Error(e.message);
        next(error);
    }
});

export const fileUploadLocal = expressAsyncHandler(async(file, filePath, fileName, next) => {
    try {
        filePath = path.resolve(FILE_ROOT_PATH+filePath)+'/';
        let createPath = await createDirectoryLocal(filePath);
        return new Promise(function(resolve, reject) {
            fs.writeFileSync(filePath+fileName, file.buffer);
            resolve(fileName);
        });
    } catch(e) {
        console.log('Catch error in common function fileUploadLocal()');
        var errorLog = await saveErrorLogFileWithpath('fileUploadLocal', e.stack);
        throw new Error(e.message);
    }
});

export const fileUpload = expressAsyncHandler(async(file, filePath, fileName, next) => {
    try {
        const storage = await getStorageConnection();
        var bucket = await storage.bucket();
        return new Promise(function(myResolve, myReject) {
            const blob = bucket.file(filePath+fileName);
            const blobWriter = blob.createWriteStream({
                metadata: {
                    contentType: file.mimetype
                }
            })
            
            blobWriter.on('error', async(err) => {
                console.log('File upload error', err);
                let error = new Error('Something went wrong');
                next(error);
                myReject(err);  // when error
            })
            
            blobWriter.on('finish', () => {
                myResolve(fileName); // when successful
            });
            blobWriter.end(file.buffer)
        });
    } catch(e) {
        console.log('Catch error in common function fileUpload()');
        var errorLog = await saveErrorLogFileWithpath('fileUpload', e.stack);
        let error = new Error(e.message);
        next(error);
    }
});

export const getMediaLink = expressAsyncHandler(async(fileName) => {
    if(process.env.MODE == "development") {
        let link = 'http://'+req.hostname+':3000/public/'+fileName;
        return link;
    } else {
        path = path.replace("/", "%2F");
        let link = 'http://'+req.hostname+':3000/public%2F'+fileName;
        return link;
    }
});

export const saveErrorLogFileWithpath = expressAsyncHandler(async(path, message) => {
    try {
        return new Promise(async function(resolve, reject) {
            const storage = await getStorageConnection();
            var bucket = await storage.bucket();
            var date = new Date();
            //var name = date.getDate()  + "-" + (date.getMonth()+1) + "-" + date.getFullYear()+'_'+date.getTime()+'.log';
            var name = date.getDate()  + "-" + (date.getMonth()+1) + "-" + date.getFullYear()+'.log';
            var time = date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
            var fileName = 'public/logs/'+path+'/'+name;
            const file = bucket.file(fileName);
            message = message +' =====> ['+time+']';
            let existingMessage = "";
            file.exists().then(async function(data) {
                if(data[0]) {
                    file.createReadStream()
                        .on('error', function(err) {
                            console.log(err);
                            resolve(true);
                        })
                        .on('data', function(datas) {
                            var buf             =   Buffer.from(datas);
                            existingMessage     =   existingMessage + buf.toString();
                        })
                        .on('end', function() {
                            message     =   existingMessage+"\n\n"+message;
                            file.save(message, { resumable: false }, function(err) {
                                if(err) {
                                    console.log('Catch error in common function saveFile()', err);
                                    //throw new Error('Catch error in common function saveFile()');
                                }
                                resolve(true);
                            });
                        });
                } else {
                    file.save(message, function(err) {
                        if(err) {
                            console.log('Catch error in common function saveFile()', err);
                            //throw new Error('Catch error in common function saveFile()');
                        }
                        resolve(true);
                    });
                }
            });
        });    
    } catch(e) {
        console.log('Catch error in common function saveFile()', e);
        /* let error = new Error(e.message);
        next(error); */
        //throw new Error(e.message);
    }
});

export const saveErrorLogFile = expressAsyncHandler(async(message) => {
    try {
        const storage = await getStorageConnection();
        var bucket = await storage.bucket();
        var date = new Date();
        var name = date.getDate()  + "-" + (date.getMonth()+1) + "-" + date.getFullYear()+'_'+date.getTime()+'.log';
        var fileName = 'public/logs/'+name;
        const file = bucket.file(fileName);
        file.save(message, function(err) {
            if(err) {
                console.log('Catch error in common function saveFile()');
                throw new Error('Catch error in common function saveFile()');
            }
        });
    } catch(e) {
        console.log('Catch error in common function saveFile()');
        /* let error = new Error(e.message);
        next(error); */
        throw new Error(e.message);
    }
});

export const copyFile = expressAsyncHandler(async(sourceFileName, destinationPath, next) => {
    return new Promise(async(resolve, reject) => {
        try {
            const storage = await getStorageConnection();
            var bucket = await storage.bucket();
            let fileDetail = await bucket.file(sourceFileName);
            fileDetail.exists().then(function(data) {
                const exists = data[0];
                if(data[0]) {
                    fileDetail.get().then(async function(data) {
                        const file = data[0];
                        const apiResponse = data[1];
                        await bucket.file(apiResponse.name).copy(destinationPath).then(function(data) {
                            if(data) {
                                console.log('File copy is success');
                                resolve(true);
                            } else {
                                console.log('File copy is failed');
                                let error = new Error('Something went wrong.');
                                next(error);
                                resolve(false);
                            }
                        });
                    });
                } else {
                    console.log('File copy is failed');
                    resolve(false);
                }
            });
        } catch(e) {
            reject(false);
            console.log('Catch error in common function', e);
            var errorLog = await saveErrorLogFileWithpath('copyFile', e.stack);
            let error = new Error(e.message);
            next(error);
        }
    });
});

export const deleteFile = expressAsyncHandler(async(fileName, next) => {
    return new Promise(async(resolve, reject) => {
        try {
            const storage   =   await getStorageConnection();
            var bucket      =   await storage.bucket();
            let fileDetail  =   await bucket.file(fileName);

            fileDetail.exists().then(function(data) {
                const exists = data[0];
                if(data[0]) {
                    fileDetail.get().then(async function(data) {
                        const file = data[0];
                        const apiResponse = data[1];
                        await bucket.file(apiResponse.name).delete();
                        console.log('Delete success');
                        resolve(true);
                    });
                } else {
                    console.log('Delete Failed');
                    resolve(false);
                }
            });
        } catch(e) {
            reject(false);
            console.log('Catch error in common function', e);
            var errorLog = await saveErrorLogFileWithpath('deleteFile', e.stack);
            let error = new Error(e.message);
            next(error);
        }
    });
});

export const generalDeleteFile = expressAsyncHandler(async(filePath, next) => {
    return new Promise(async(resolve, reject) => {
        if(process.env.MODE == "development") {
            try {
                const storage   =   await getStorageConnection();
                var bucket      =   await storage.bucket();
                let fileDetail  =   await bucket.file(filePath);
                fileDetail.exists().then(function(data) {
                    const exists = data[0];
                    if(data[0]) {
                        fileDetail.get().then(async function(data) {
                            const file = data[0];
                            const apiResponse = data[1];
                            await bucket.file(apiResponse.name).delete();
                            console.log('Delete success');
                            resolve(true);
                        });
                    } else {
                        console.log('Delete Failed');
                        resolve(false);
                    }
                });
            } catch(e) {
                reject(false);
                console.log('Catch error in common function', e);
                var errorLog = await saveErrorLogFileWithpath('deleteFile', e.stack);
                throw new Error(e.message);
                //let error = new Error(e.message);
                //next(error);
            }
        } else {
            try {
                await fs.unlink(filePath, (async(err) => {
                    if(err) {
                        resolve(false);
                    } else {
                        resolve(true);
                    }
                }));
            } catch(e) {
                reject(false);
                console.log('Catch error in common function', e);
                var errorLog = await saveErrorLogFileWithpath('deleteFileLocal', e.stack);
                throw new Error(e.message);
                //let error = new Error(e.message);
                //next(error);
            }
        }
    });
});

export const deleteFolder = expressAsyncHandler(async(prefix) => {
    return new Promise(async(resolve, reject) => {
        try {
            if(prefix != undefined && prefix != null && prefix != 0 && prefix != '') {
                const storage = await getStorageConnection();
                var bucket = await storage.bucket();
                bucket.deleteFiles({
                    prefix: prefix
                }, async function(err) {
                    if(!err) {
                        resolve(true);
                    } else {
                        var errorLog = await saveErrorLogFileWithpath('folder_delete', err);
                        console.log('Catch error in common function', err);
                        resolve(false);
                    }
                });
            } else {
                resolve(false);
            }
        } catch(e) {
            var errorLog = await saveErrorLogFileWithpath('folder_delete', e.message);
            console.log('Catch error in common function', e);
            resolve(false);
            throw new Error(e.message);
        }
    });
});

export const deleteFolderLocal = expressAsyncHandler(async(path) => {
    try {
        if(fs.existsSync(path)) {
            const files = fs.readdirSync(path);
            if(files.length > 0) {
                files.forEach(function(filename) {
                    if(fs.statSync(path + "/" + filename).isDirectory()) {
                        deleteFolderLocal(path + "/" + filename);
                    } else {
                        fs.unlinkSync(path + "/" + filename);
                    }
                });
                fs.rmdirSync(path);
            } else {
                fs.rmdirSync(path);
            }
        } else {
            var errorLog = await saveErrorLogFileWithpath('folder_delete', 'Invalid folder or directory path =>'+path);
            console.log('Invalid folder or directory path =>'+path);
        }
    } catch(e) {
        var errorLog = await saveErrorLogFileWithpath('folder_delete', e.message);
        console.log('Catch error in common function', e);
    }
});

export const createDirectoryLocal = expressAsyncHandler(async(createDirectory, next) => {
    return new Promise(async(resolve, reject) => {
        try {
            let isDirectoryExists = await fs.existsSync(createDirectory);
            if(!isDirectoryExists) {
                await fs.mkdirSync(createDirectory, { recursive: true });	//Create path, if directory not exists
            }
            resolve(true);
        } catch(e) {
            reject(false);
            console.log('Catch error in common function', e);
            let error = new Error(e.message);
            next(error);
        }
    });
});

export const copyFileLocal = expressAsyncHandler(async(sourceFile, destination, next) => {
    return new Promise(async (resolve, reject) => {
        try {
            await fs.copyFile(sourceFile, destination, (err) => {
                if(err) {
                    resolve(false);
                } else {
                    resolve(true);
                }
            });
        } catch(e) {
            reject(false);
            console.log('Catch error in common function', e);
            let error = new Error(e.message);
            next(error);
        }
    });
});

export const deleteFileLocal = expressAsyncHandler(async(file, next) => {
    return new Promise(async(resolve, reject) => {
        file = await path.resolve(FILE_ROOT_PATH+file);
        try {
            await fs.unlink(file, (async(err) => {
                if(err) {
                    console.log(err);
                    resolve(false);
                } else {
                    resolve(true);
                }
            }));
        } catch(e) {
            reject(false);
            console.log('Catch error in common function', e);
            let error = new Error(e.message);
            next(error);
        }
    });
});

export const getCurrentGMTTime = expressAsyncHandler(async(next) => {
    return new Promise(async(resolve, reject) => {
        let currentTime = await admin.firestore.Timestamp.now(Date.now());
        resolve(currentTime);
        //return currentTime;
    });
});

export const getMediaName = expressAsyncHandler(async(next) => {
    return new Promise(async(resolve, reject) => {
        let mediaName = Date.now();
        let randomNumber = Math.floor(Math.random() * 899999 + 100000);
        randomNumber = randomNumber.toString().substring(0, 2);
        randomNumber =  parseInt(randomNumber);
        mediaName = randomNumber+'_'+mediaName;
        resolve(mediaName);
        //return mediaName;
    });
});

export const getQueryLikeString = expressAsyncHandler(async(queryString, fields) => {
    let mergeWord = '';
    if(fields[0] != undefined) {
        mergeWord += fields[0] +" LIKE '"+queryString+"%' OR ";
    }
    if(fields[1] != undefined) {
        mergeWord += fields[0] +" LIKE '"+queryString+"%' OR ";
    }
    const items = queryString.split(' ');
    for(let i = 0; i < items.length; i++) {
        for(let j = 1; j <= items.length; j++) {
            const slice = items.slice(i,j);
            if (slice.length) {
                var keyWord = slice.join(' ');
                let keyWord1 = keyWord.replace(keyWord.charAt(0), keyWord.charAt(0).toLowerCase());
                let keyWord2 = keyWord.replace(keyWord.charAt(0), keyWord.charAt(0).toUpperCase());
                let keyWord3 = keyWord.toUpperCase();
                let keyWord4 = keyWord.toLowerCase();
                if(fields[0] != undefined) {
                    mergeWord += fields[0] +" LIKE '"+keyWord1+"%' OR ";
                    mergeWord += fields[0] +" LIKE '"+keyWord2+"%' OR ";
                    mergeWord += fields[0] +" LIKE '"+keyWord3+"%' OR ";
                    mergeWord += fields[0] +" LIKE '"+keyWord4+"%' OR ";
                }
                if(fields[1] != undefined) {
                    mergeWord += fields[1] +" LIKE '"+keyWord1+"%' OR "
                    mergeWord += fields[1] +" LIKE '"+keyWord2+"%' OR ";
                    mergeWord += fields[1] +" LIKE '"+keyWord3+"%' OR ";
                    mergeWord += fields[1] +" LIKE '"+keyWord4+"%' OR ";
                }
            }
        }
    }
    mergeWord = mergeWord.slice(0, -3);
    return mergeWord;
});

export const getQueryLikeStringWithoutKeyword = expressAsyncHandler(async(queryString, fields) => {
    let mergeWord = '';
    if(fields[0] != undefined) {
        mergeWord += fields[0] +" LIKE '"+queryString+"%' OR ";
    }
    if(fields[1] != undefined) {
        mergeWord += fields[0] +" LIKE '"+queryString+"%' OR ";
    }
    mergeWord = mergeWord.slice(0, -3);
    return mergeWord;
});


export const isValidURL = expressAsyncHandler(async(url) => {
    var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
    '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.?)+[a-z]{2,}|'+ // domain name
    '((\\d{1,3}\\.){3}\\d{1,3}))'+ // ip (v4) address
    '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ //port
    '(\\?[;&amp;a-z\\d%_.~+=-]*)?'+ // query string
    '(\\#[-a-z\\d_]*)?$','i');
    return pattern.test(url);
});

export const convertTimeToSeconds = expressAsyncHandler(async(time) => {
    return new Promise((resolve, reject) => {
        const arr = time.split(":");
        const seconds = arr[0]*60+(+arr[1]);
        resolve(seconds);
    });
});


export const generateVideoFromImages = expressAsyncHandler(async(bucket, mediaDetailsForCon) => {
    return new Promise(async(resolve, reject) => {
        try {

            console.log("Comes to the part of generateVideoFromImages");

            let complexFilter   = "";
            let xfadeFilter     = "";
            let files           = [];
            let allTempFiles    = [];
            let execCommand     = "";
            let copyStatus;
            let command;

            for await (const [index, ffmpegData] of mediaDetailsForCon.ffmpeg_build_data.entries()) {
                let tempMedia           =   ffmpegData.media_url;
                let tempMediaName       =   'media'+(index+1)+path.extname(tempMedia);
                let tempMediaFile       =   await path.join(os.tmpdir(), tempMediaName);

                allTempFiles.push(tempMediaFile);

                files.push({ original: tempMedia, destination: tempMediaFile });

                if(index == 0) {
                    command = await ffmpeg(tempMediaFile).setFfmpegPath(ffmpeg_static).inputOptions(ffmpegData.input_option);
                } else {
                    command = await command.input(tempMediaFile).inputOptions(ffmpegData.input_option);
                }

                complexFilter   += ffmpegData.complex_filter;
                xfadeFilter     += ffmpegData.xfade_filter;
            }

            /* let buildFiles = await mediaDetailsForCon.ffmpeg_build_data.map(async(data, index) => {
                let tempMedia           = data.media_url;
                let tempMediaName       = 'media'+(index+1)+path.extname(tempMedia);
                let tempMediaFile        = path.join(os.tmpdir(), tempMediaName);
                allTempFiles.push(tempMediaFile);
                files.push({ original: tempMedia, destination: tempMediaFile });
                if(index == 0) {
                    command = ffmpeg(tempMediaFile).setFfmpegPath(ffmpeg_static).inputOptions(data.input_option);
                } else {
                    command = command.input(tempMediaFile).inputOptions(data.input_option);
                }
                complexFilter   += data.complex_filter;
                xfadeFilter     += data.xfade_filter;
            }); */

            console.log("generateVideoFromImages One ....");

            const music                 = mediaDetailsForCon['output_music'];
            const outputFile            = mediaDetailsForCon['output_path'];
            const outputFileName        = path.basename(outputFile);
            let musicName               = 'music'+path.extname(music);
            const musicFile             = path.join(os.tmpdir(), musicName);
            const tempOutputFilePath    = path.join(os.tmpdir(), outputFileName);

            files.push({ original: music, destination: musicFile });
            allTempFiles.push(musicFile);

            console.log("generateVideoFromImages Two ....");

            if(process.env.MODE == "development") {
                copyStatus = await downloadMultipleFilesLocal(bucket, files);
            } else {
                copyStatus = await downloadMultipleFiles(bucket, files);
            }

            console.log("generateVideoFromImages Three ....");

            if(copyStatus.length == files.length) {

                console.log("generateVideoFromImages Four ....");

                command = await command.input(musicFile);
                command = await command.inputOptions(['-stream_loop -1']);
                command = await command.complexFilter(complexFilter+xfadeFilter);
                command = await command.outputOptions(mediaDetailsForCon['output_option']);
                command.on('start', function(commandLine) {
                    //console.log('Spawned Ffmpeg with command: ' + commandLine);

                    //console.log("generateVideoFromImages Five ....", commandLine);

                    execCommand = commandLine+"\t\n";
                })
                .on('error', async function(err) {

                    console.log("generateVideoFromImages Seven ....");

                    var errorLog = await saveErrorLogFileWithpath('justincompilation', err.message.toString()+'\n\n'+execCommand); 
                    //await saveErrorLogFileWithpath('justincompilation', execCommand);
                    //allTempFiles.push(tempOutputFilePath);
                    let deleteStatus = await deleteTempFiles(allTempFiles);
                    resolve({ 'status': false, 'message': err.message });
                })
                .on('end', async function() {

                    console.log("generateVideoFromImages Six ....");

                    let status;
                    let copyOutput = [
                        {
                            original: tempOutputFilePath,
                            destination: outputFile
                        }
                    ];
                    if(process.env.MODE == "development") {
                        status = await uploadMultipleFilesLocal(bucket, copyOutput);
                    } else {
                        status = await uploadMultipleFiles(bucket, copyOutput);
                    }
                    if(status[0]) {
                        let deleteStatus = await deleteTempFiles(allTempFiles);
                        resolve({ 'status': true, 'message': 'File converted successfully.' });
                    } else {
                        resolve({ 'status': false, 'message': 'Error on copy file.' });
                    }
                })
                .save(tempOutputFilePath);
            } else {
                resolve({ 'status': false, 'message': 'File Copy failed.' });
            }

        } catch(e) {
            console.log('Comes here', e);
            var errorLog = await saveErrorLogFileWithpath('justincompilation', e.message);
            reject({ 'status': false, 'message': 'Something went wrong.' });
        }
    });
});

export const __generateVideoFromImages = expressAsyncHandler(async(bucket, mediaDetailsForCon) => {
    return new Promise(async(resolve, reject) => {
        try {
            let copyStatus;

            const media1                = mediaDetailsForCon['output_media'][0];
            const media2                = mediaDetailsForCon['output_media'][1];
            const media3                = mediaDetailsForCon['output_media'][2];
            const media4                = mediaDetailsForCon['output_media'][3];
            const media5                = mediaDetailsForCon['output_media'][4];

            const music                 = mediaDetailsForCon['output_music'];

            const outputFile            = mediaDetailsForCon['output_path'];

            const outputFileName        = path.basename(outputFile);

            let mediaName1              = 'media1'+path.extname(media1);
            let mediaName2              = 'media2'+path.extname(media2);
            let mediaName3              = 'media3'+path.extname(media3);
            let mediaName4              = 'media4'+path.extname(media4);
            let mediaName5              = 'media5'+path.extname(media5);

            let musicName               = 'music'+path.extname(music);

            const mediaFile1            = path.join(os.tmpdir(), mediaName1);
            const mediaFile2            = path.join(os.tmpdir(), mediaName2);
            const mediaFile3            = path.join(os.tmpdir(), mediaName3);
            const mediaFile4            = path.join(os.tmpdir(), mediaName4);
            const mediaFile5            = path.join(os.tmpdir(), mediaName5);

            const musicFile             = path.join(os.tmpdir(), musicName);

            const tempOutputFilePath    = path.join(os.tmpdir(), outputFileName);

            let files = [
                {
                    original: media1,
                    destination: mediaFile1
                },
                {
                    original: media2,
                    destination: mediaFile2
                },
                {
                    original: media3,
                    destination: mediaFile3
                },
                {
                    original: media4,
                    destination: mediaFile4
                },
                {
                    original: media5,
                    destination: mediaFile5
                },
                {
                    original: music,
                    destination: musicFile
                }
            ]

            if(process.env.MODE == "development") {
                copyStatus = await downloadMultipleFilesLocal(bucket, files);
            } else {
                copyStatus = await downloadMultipleFiles(bucket, files);
            }

            if(copyStatus.length == files.length) {
                var command = ffmpeg(mediaFile1)
                            .setFfmpegPath(ffmpeg_static)
                            .inputOptions(mediaDetailsForCon['ffmpeg_details'][0]['input_option'])
                            .input(mediaFile2)
                            .inputOptions(mediaDetailsForCon['ffmpeg_details'][1]['input_option'])
                            .input(mediaFile3)
                            .inputOptions(mediaDetailsForCon['ffmpeg_details'][2]['input_option'])
                            .input(mediaFile4)
                            .inputOptions(mediaDetailsForCon['ffmpeg_details'][3]['input_option'])
                            .input(mediaFile5)
                            .inputOptions(mediaDetailsForCon['ffmpeg_details'][4]['input_option'])
                            .input(musicFile)
                            .complexFilter(mediaDetailsForCon['complex_filter'])
                            .outputOptions(mediaDetailsForCon['output_option'])
                            .on('start', function(commandLine) {
                                console.log('Spawned Ffmpeg with command: ' + commandLine);
                            })
                            .on('end', async function() {
                                let status;
                                let copyOutput = [
                                    {
                                        original: tempOutputFilePath,
                                        destination: outputFile
                                    }
                                ];
                                if(process.env.MODE == "development") {
                                    status = await uploadMultipleFilesLocal(bucket, copyOutput);
                                } else {
                                    status = await uploadMultipleFiles(bucket, copyOutput);
                                }
                                if(status[0]) {
                                    let allTempFiles = [mediaFile1, mediaFile2, mediaFile3, mediaFile4, mediaFile5, musicFile, tempOutputFilePath];
                                    let deleteStatus = await deleteTempFiles(allTempFiles);
                                    resolve({ 'status': true, 'message': 'File converted successfully.' });
                                } else {
                                    resolve({ 'status': false, 'message': 'Error on copy file.' });
                                }
                            })
                            .on('error', async function(err) {
                                var errorLog = await saveErrorLogFileWithpath('justincompilation', 'Error: ---->'+err.message);
                                let allTempFiles = [mediaFile1, mediaFile2, mediaFile3, mediaFile4, mediaFile5, musicFile, tempOutputFilePath];
                                let deleteStatus = await deleteTempFiles(allTempFiles);
                                resolve({ 'status': false, 'message': err.message });
                            })
                            .save(tempOutputFilePath);
            } else {
                resolve({ 'status': false, 'message': 'Issue on copying file.' });
            }
        } catch(e) {
            var errorLog = await saveErrorLogFileWithpath('justincompilation', 'Error: ---->'+e.stack);
            resolve({ 'status': false, 'message': 'Something went wrong.' });
        }
    });
});

/* export const generateCompilationVideoThumbnail = expressAsyncHandler(async(bucket, videoPath, outputFilePath) => {
    return new Promise((resolve, reject) => {
        setTimeout(expressAsyncHandler(async() => {
            try {
                let copyStatus;
                const media1                = videoPath;
                let mediaName1              = 'media1'+path.extname(media1);
                const mediaFile1            = path.join(os.tmpdir(), mediaName1);

                const outputFile            = outputFilePath;
                const outputFileName        = path.basename(outputFile);
                const tempOutputFilePath    = path.join(os.tmpdir(), outputFileName);

                let files = [
                    {
                        original: media1,
                        destination: mediaFile1
                    }
                ];

                if(process.env.MODE == "development") {
                    copyStatus = await downloadMultipleFilesLocal(bucket, files);
                } else {
                    copyStatus = await downloadMultipleFiles(bucket, files);
                }

                if(copyStatus.length == files.length) {
                    var command = ffmpeg(mediaFile1)
                                .setFfmpegPath(ffmpeg_static)
                                .inputOptions(['-ss 00:00:00.15'])
                                //.complexFilter(['-vf scale=320:320:force_original_aspect_ratio=decrease'])
                                .outputOptions(['-vf scale=320:320:force_original_aspect_ratio=decrease', '-vframes 1'])
                                .on('start', function(commandLine) {
                                    console.log('Spawned Ffmpeg with command: ' + commandLine);
                                })
                                .on('end', function() {
                                    setTimeout(expressAsyncHandler(async() => {
                                        let status;
                                        let copyOutput = [
                                            {
                                                original: tempOutputFilePath,
                                                destination: outputFile
                                            }
                                        ];
                                        if(process.env.MODE == "development") {
                                            status = await uploadMultipleFilesLocal(bucket, copyOutput);
                                        } else {
                                            status = await uploadMultipleFiles(bucket, copyOutput);
                                        }
                                        let allTempFiles = [mediaFile1, tempOutputFilePath];
                                        let deleteStatus = await deleteTempFiles(allTempFiles);
                                        resolve({ 'status': true, 'message': 'Thumbnail generated successfully.' });
                                    }));
                                })
                                .on('error', function(err) {
                                    setTimeout(expressAsyncHandler(async() => {
                                        console.log(err);
                                        await saveErrorLogFileWithpath('justincompilation', err.message);
                                        let allTempFiles = [mediaFile1, tempOutputFilePath];
                                        let deleteStatus = await deleteTempFiles(allTempFiles);
                                        resolve({ 'status': false, 'message': err.message });
                                    }));
                                })
                                .save(tempOutputFilePath);
                } else {
                    resolve({ 'status': false, 'message': 'Issue on copying file.' });
                }
            } catch(e) {
                await saveErrorLogFileWithpath('justincompilation', e.message);
                reject({ 'status': false, 'message': 'Something went wrong.' });
            }
        }));
    });
}); */

export const getMediasContent = expressAsyncHandler(async(db, collectionRef, usedIDs, action, extraData) => {
    return new Promise(async(resolve, reject) => {
        try {
            
            const mediasRef         =   await collectionRef.get();

            var usedMedias          =   [];
            var unUsedMedias        =   [];
            var likedMedias         =   [];

            if(!mediasRef.empty) {

                for await (const media of mediasRef.docs) {
                    
                    const mediaID       =   media.id;
                    const mediaData     =   await media.data();
                    const buildMedia    =   { ...mediaData, id: mediaID };

                    if(action == 'medias') {

                        if(!usedIDs.includes(parseInt(mediaID))) {

                            unUsedMedias.push({...buildMedia});

                        } else if(buildMedia['liked_user_ids'].includes(extraData['user_id'])) {

                            likedMedias.push({...buildMedia});

                        } else {

                            usedMedias.push({...buildMedia});

                        }

                    } else if(action == 'justin') {

                        if(!usedIDs.includes(parseInt(mediaID))) {
                            
                            if(extraData['deleted_populated_images_ids'] != undefined && extraData['deleted_populated_images_ids'].includes(parseInt(mediaID))) {
                            
                            } else {
                                unUsedMedias.push({...buildMedia});
                            }
                        } else if(extraData['deleted_populated_images_ids'] != undefined && extraData['deleted_populated_images_ids'].includes(parseInt(mediaID))) {
                            //likedMedias.push({...buildMedia});
                        } else if(extraData['liked_populated_images_ids'] != undefined && extraData['liked_populated_images_ids'].includes(parseInt(mediaID))) {

                            likedMedias.push({...buildMedia});

                        } else {

                            usedMedias.push({...buildMedia});

                        }

                    } else {

                        if(!usedIDs.includes(parseInt(mediaID))) {

                            unUsedMedias.push({...buildMedia});

                        } else {

                            usedMedias.push({...buildMedia});

                        }

                    }
                }

                await usedMedias.sort(()=> Math.random()-0.5);
                await likedMedias.sort(()=> Math.random()-0.5);

                resolve({ 'usedMedias': usedMedias, 'unUsedMedias': unUsedMedias, 'likedMedias': likedMedias });

            } else {
                resolve({ 'usedMedias': [], 'unUsedMedias': [], 'likedMedias': [] });
            }
        } catch(e) {

            await saveErrorLogFileWithpath('getMediasContent', e.stack);
            resolve({ 'usedMedias': [], 'unUsedMedias': [], 'likedMedias': [] });

        }
    });
});

export const getCompilationMedia = expressAsyncHandler(async(db, collectionRef, lastUsedID, extraData) => {
    return new Promise(async(resolve, reject) => {
        try {

            const nextCompiltaionID =   parseInt(lastUsedID) + 1;
            const mediasRef         =   await collectionRef.where('compilation_medias_id', '>=', nextCompiltaionID)
                                                            .orderBy('compilation_medias_id', 'asc')
                                                            .limit(1)
                                                            .get();
            let compilationMedias   =   [];

            if(mediasRef.empty) {
                const defaultMediaRef   =   await collectionRef.orderBy('compilation_medias_id', 'asc').limit(1).get();
                for await (const [index, compilationMedia] of defaultMediaRef.docs.entries()) {
                    var tempCompilationData     =   await compilationMedia.data();
                    var tempCompilationmedia    =   { "id": compilationMedia.id, ...tempCompilationData };
                    compilationMedias.push(tempCompilationmedia);
                }
                resolve(compilationMedias);
            } else {
                for await (const [index, compilationMedia] of mediasRef.docs.entries()) {
                    var tempCompilationData     =   await compilationMedia.data();
                    var tempCompilationmedia    =   { "id": compilationMedia.id, ...tempCompilationData };
                    compilationMedias.push(tempCompilationmedia);
                }
                resolve(compilationMedias);
            }

        } catch(e) {

            await saveErrorLogFileWithpath('getCompilationMedia', e.stack);
            resolve([]);

        }
        
    });
});


export const getContentById = expressAsyncHandler(async(db, ids, collection, whereKeyName, condOperator, processName, userID, detail) => {
    try {
        const collectionPath = db.collection(collection);
        const batches = [];
        const whereKey = (whereKeyName != '') ? whereKeyName : await admin.firestore.FieldPath.documentId();
        let typeKey = 'type';
        /* if(detail.user_role != undefined && detail.user_role == 1) {
            typeKey = 'type_for_user';
        } */
        while (ids.length) {
            // firestore limits batches to 10
            const batch = ids.splice(0, 10);
            // add the batch request to to a queue
            if(processName == 'mediagroup') {
                batches.push(
                    collectionPath
                    .where(
                        'reference_ids',
                        'array-contains',
                        db.doc(Users.collection.name+'/'+userID.toString())
                    )
                    .where(
                        typeKey,
                        '==',
                        3
                    )
                    .where(
                        'media_type',
                        '==',
                        detail.media_type
                    )
                    .where(
                        'is_temporary_media',
                        '==',
                        0
                    )
                    .where(
                        'async_media_upload_response_code',
                        '==',
                        200
                    )
                    .where(
                        whereKey,
                        condOperator,
                        [...batch]
                    )
                    .limit(10)
                    .get()
                    .then(results => results.docs.map(result => {
                        return { id: result.id, media_group_id: result.get('media_group_id'), type: result.get('type'), media_type: result.get('media_type'), caption: result.get('caption'), liked_user_ids: result.get('liked_user_ids'), created_by: result.get('created_by')._path.segments[1], medias_details: result.get('medias_details')  }
                    }))
                )
            } else if(processName == 'populated') {
                batches.push(
                    collectionPath
                    .where(
                        'user_role',
                        '==',
                        1
                    )
                    .where(
                        'status',
                        '==',
                        1
                    )
                    .where(
                        whereKey,
                        condOperator,
                        [...batch]
                    )
                    .limit(10)
                    .get()
                    .then(results => results.docs.map(result => {
                        return { id: result.id, populate_id: result.get('populate_id'), media_type: result.get('media_type'), populate_video_duration: result.get('populate_video_duration'), populate_video: result.get('populate_video'), populate_thumbnail: result.get('populate_thumbnail'), populate_image: result.get('populate_image'), caption: result.get('caption') }
                    }))
                )
            } else if(processName == 'music') {
                batches.push(
                    collectionPath
                    .where(
                        whereKey,
                        condOperator,
                        [...batch]
                    )
                    .limit(1)
                    .get()
                    .then(results => results.docs.map(result => {
                        return { id: result.id, music_id: result.get('music_id'), audio_file: result.get('audio_file'), title: result.get('title'), album_name: result.get('album_name') }
                    }))
                )
            } else {
                batches.push(
                    collectionPath
                    .where(
                        whereKey,
                        condOperator,
                        [...batch]
                    )
                    .get()
                    .then(results => results.docs.map(result => {
                        return { id: result.id, ...result.data() }
                    }))
                )
            }
        }
        return Promise.all(batches).then(content => content.flat());
    } catch(e) {
        var errorLog = await saveErrorLogFileWithpath('justincompilation', 'Error: ---->'+e.stack);
        return false;
    }
});

export const checkUserCompilationStatus = expressAsyncHandler(async(db, user, next) => {
    return new Promise(async(resolve, reject) => {
        try {
            let usedCounts          =   { 'medias': 0, 'populated': 0 };
            let unUsedMediasCounts  =   { 'medias': 0, 'populated': 0 };
            let deletePopulatedIDs  =   [];
            let assetCount          =   0;
            let musics;

            let userJustinDeletedLikedIDs = await getCollectionDataWithDocID('populated_images_like_detele_details', parseInt(user.id));

            /* const lastUsedCompilationID   =   await new Promise((resolve, reject) => {
                if(user.last_compilation_media_used_id != undefined) {
                    resolve(user.last_compilation_media_used_id);
                } else {
                    resolve(0);
                }
            }); */

            let usedMediaIDs = await new Promise((resolve, reject) => {
                if(user.justin_compilation_video_used_media_ids != undefined && user.justin_compilation_video_used_media_ids.length > 0) {
                    resolve(user.justin_compilation_video_used_media_ids);
                } else {
                    resolve([0]);
                }
            });

            let usedPopulatedIDs = await new Promise((resolve, reject) => {
                if(user.justin_compilation_video_used_populated_ids != undefined && user.justin_compilation_video_used_populated_ids.length > 0) {
                    resolve(user.justin_compilation_video_used_populated_ids);
                } else {
                    resolve([0]);
                }
            });

            if(userJustinDeletedLikedIDs.length > 0 && userJustinDeletedLikedIDs[0].deleted_populated_images_ids != undefined) {
                if(userJustinDeletedLikedIDs[0].deleted_populated_images_ids.length > 0) {
                    deletePopulatedIDs  =   deletePopulatedIDs.concat(userJustinDeletedLikedIDs[0].deleted_populated_images_ids);
                    usedPopulatedIDs    =   usedPopulatedIDs.concat(userJustinDeletedLikedIDs[0].deleted_populated_images_ids);
                    usedPopulatedIDs    =   [...new Set(usedPopulatedIDs)];
                }
            }

            let usedMusicIDs = await new Promise((resolve, reject) => {
                if(user.justin_compilation_video_used_music_ids != undefined && user.justin_compilation_video_used_music_ids.length > 0) {
                    resolve(user.justin_compilation_video_used_music_ids);
                } else {
                    resolve([0]);
                }
            });

            var checkVideo = [...usedMediaIDs];

            var checkImages = [...usedMediaIDs];

            const userRef               =   await db.doc(Users.collection.name+'/'+user.id.toString());
            const mediaCollectionRef    =   await db.collection(MediaGroup.collection.name)
                                                /* .select('media_group_id', 'type', 'media_type', 'caption', 'liked_user_ids', 'created_by', 'medias_details', 'liked_user_ids') */
                                                .where('reference_ids', 'array-contains', userRef)
                                                .where('status', '==', 1)
                                                .where('type', '==', 3)
                                                /* .where('media_types', 'not-in', [3]) */
                                                .where('is_temporary_media', '==', 0)
                                                .where('async_media_upload_response_code', '==', 200)
                                                .orderBy('created_on', 'desc');

            const justinCollectionRef    =   await db.collection(PopulateImages.collection.name)
                                                    .where('user_role', '==', 1)
                                                    .where('status', '==', 1)
                                                    .orderBy('created_on', 'desc');


            const musciCollectionRef    =   await db.collection(Music.collection.name)
                                                    .orderBy('created_on', 'desc');

            const compilationRef        =   await db.collection(CompilationMedias.collection.name)
                                                    .where('status', '==', 1);

            var getAllMedias    =   await getMediasContent(db, mediaCollectionRef, usedMediaIDs, 'medias', { user_id: parseInt(user.id) });
            var getAllJustins   =   await getMediasContent(db, justinCollectionRef, usedPopulatedIDs, 'justin', userJustinDeletedLikedIDs);
            var getAllMusics    =   await getMediasContent(db, musciCollectionRef, usedMusicIDs, 'music', {});
            /* var getCompilation  =   await getCompilationMedia(db, compilationRef, lastUsedCompilationID, {}); */
            

            if(user.music != null) {
                let musicID = user.music._path.segments[1];
                musics = await getCollectionDataWithDocID(Music.collection.name, musicID, next);
            } else {
                if(getAllMusics['unUsedMedias'].length > 0) {
                    musics = getAllMusics['unUsedMedias'];
                } else {
                    musics = getAllMusics['usedMedias'];
                }
            }

            assetCount = assetCount + getAllMedias['unUsedMedias'].length + getAllMedias['likedMedias'].length  + getAllMedias['usedMedias'].length;
            assetCount = assetCount + getAllJustins['unUsedMedias'].length + getAllJustins['likedMedias'].length  + getAllJustins['usedMedias'].length;
            /* assetCount = assetCount + getCompilation.length; */
            

            unUsedMediasCounts['medias']    =   unUsedMediasCounts['medias'] +  getAllMedias['unUsedMedias'].length;
            unUsedMediasCounts['populated'] =   unUsedMediasCounts['populated'] +  getAllJustins['unUsedMedias'].length;

            usedCounts['medias']        =   usedCounts['medias'] +  getAllMedias['usedMedias'].length;
            usedCounts['populated']     =   usedCounts['populated'] +  getAllJustins['usedMedias'].length;
            
            
            resolve({ 'status': true, 'asset_count': assetCount, 'musics': musics, 'get_all_medias': getAllMedias, 'get_all_justins': getAllJustins, 'un_used_medias_counts': unUsedMediasCounts, 'used_counts': usedCounts, 'get_compilation_media': [] /* 'get_compilation_media': getCompilation */ });

        } catch(e) {
            console.log(e);
            var errorLog = await saveErrorLogFileWithpath('justincompilation', 'Error: ---->'+e.stack);
            resolve({'status': false, 'message': 'Something went wrong.', 'message': e.stack});
        }
    });
});

export const getVideoFFMPEGCommands = expressAsyncHandler(async(videoMedias, unUsedMediasCounts, sourceThumbPath, usedIDs, ffmpegBuildData, offsetTiming, xfadeOffset, checkOffsetTiming, imageZoomFilter, mediaType, type, extadetails) => {
    return new Promise(async(resolve, reject) => {
        try {
            for(var i = 0; i < videoMedias.length; i++) {
                if(i > 14) {
                    break;
                } else if(ffmpegBuildData.length > 14) {
                    break;
                }/*  else if((i > 2) && ((ffmpegBuildData.length + imageMedias.length + populate.length) >= 15)) {
                    break;
                }  */else if(checkOffsetTiming >= 30) {
                    break;
                }/*  else if((extadetails['media_type'] == 'videos') && (unUsedMediasCounts['medias'] == 0) && (ffmpegBuildData.length + unUsedMediasCounts['medias'] + unUsedMediasCounts['populated']) > 15) {
                    break;
                } else if((extadetails['media_type'] == 'videos') && checkOffsetTiming >= 20 && (unUsedMediasCounts['image'] + unUsedMediasCounts['populated']) >= 12) {
                    break;
                } */

                const createrID =   videoMedias[i].created_by._path.segments[1];

                const tempVideo   =   await getMediaPath(MEDIA_PATH+type[videoMedias[i].type.toString()]+'/'+mediaType[videoMedias[i].media_type.toString()]+'/'+createrID+'/'+videoMedias[i].media, videoMedias[i]);

                if(tempVideo === "") {
                    break;
                }

                usedIDs['media'].push(parseInt(videoMedias[i].id));
                usedIDs['videos'].push(parseInt(videoMedias[i].id));

                //Build ffmpeg Data
                let pattern         = /^0?([0-9][0-2]?):[0-5][0-9]$/;
                let tempDuration    = pattern.test(videoMedias[i].duration) ? videoMedias[i].duration : "";
                var videoDuration = (tempDuration != "")
                                        ? "00:"+tempDuration
                                        : "00:00:02";
                var duration    = videoDuration.split(":");
                let seconds     = duration[0]*3600+duration[1]*60+(+duration[2]);
                seconds         = (parseInt(seconds) > 5) ? 5 : parseInt(seconds);
                seconds         = parseInt(seconds);
                seconds         = ((seconds + checkOffsetTiming) > 30) ? (seconds - (checkOffsetTiming + seconds - 30)) : seconds;
                offsetTiming    = offsetTiming + seconds;
                checkOffsetTiming = checkOffsetTiming + seconds;

                //console.log('1', checkOffsetTiming, seconds, videoMedias[i].id);

                let tempMedialength = ffmpegBuildData.length;

                let tempXfadeFilterStartKey = (ffmpegBuildData.length == 1) ? 'v'+(tempMedialength) : 'x'+(tempMedialength - 1);

                let tempXfadeFilter         = (checkOffsetTiming < 30)
                                                ? "["+tempXfadeFilterStartKey+"][v"+(tempMedialength + 1)+"]xfade=fade:duration=1:offset="+xfadeOffset+"[x"+(tempMedialength)+"];"
                                                : "["+tempXfadeFilterStartKey+"][v"+(tempMedialength + 1)+"]xfade=fade:duration=1:offset="+xfadeOffset+",format=yuv420p[v]";
                tempXfadeFilter             = (tempMedialength == 0) ? "" : tempXfadeFilter;

                ffmpegBuildData.push({
                    'media_url'         : tempVideo,
                    'input_option'      : ['-stream_loop -1', '-t 7'],
                    'complex_filter'    : "["+tempMedialength+"]split=2[blur][vid];[blur]scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720,boxblur=luma_radius=min(h\\,w)/20:luma_power=1:chroma_radius=min(cw\\,ch)/20:chroma_power=1[bg];[vid]scale=1280:720:force_original_aspect_ratio=decrease[ov];[bg][ov]overlay=(W-w)/2:(H-h)/2,fps=25[v"+(tempMedialength + 1)+"];",
                    'xfade_filter'      : tempXfadeFilter
                });

                xfadeOffset     = offsetTiming;

                //Set the thumbnail for video
                if(sourceThumbPath == '') {
                    sourceThumbPath     =   await getMediaPath(MEDIA_PATH+type[videoMedias[i].type.toString()]+'/'+mediaType[videoMedias[i].media_type.toString()]+'/'+createrID+'/thumbnail/'+videoMedias[i].thumbnail, videoMedias[i]);
                }
            }
            resolve({status: true, 'sourceThumbPath': sourceThumbPath, 'usedIDs': usedIDs, 'ffmpegBuildData': ffmpegBuildData, 'offsetTiming': offsetTiming, 'xfadeOffset': xfadeOffset, 'checkOffsetTiming': checkOffsetTiming });
        } catch(e) {
            console.log(e);
            var errorLog = await saveErrorLogFileWithpath('justincompilation', 'Error ---> getVideoFFMPEGCommands ==>'+e.stack);
            resolve({'status': false, 'message': 'Something went wrong.', 'message': e.stack});
        }
    });
});

export const getImageFFMPEGCommands = expressAsyncHandler(async(imageMedias, unUsedMediasCounts, sourceThumbPath, usedIDs, ffmpegBuildData, offsetTiming, xfadeOffset, checkOffsetTiming, imageZoomFilter, mediaType, type, extadetails) => {
    return new Promise(async(resolve, reject) => {
        try {

            console.log('Image part comes');

            for(var j = 0; j < imageMedias.length; j++) {
                if(j > 14) {
                    break;
                } else if(ffmpegBuildData.length > 14) {
                    break;
                }/*  else if((j > 2) && ((ffmpegBuildData.length + populate.length) >= 15)) {
                    break;
                }  */else if(checkOffsetTiming >= 30) {
                    break;
                }/*  else if((extadetails['media_type'] == 'images') && (unUsedMediasCounts['image'] == 0) && (ffmpegBuildData.length + unUsedMediasCounts['populated']) > 15) {
                    break;
                } else if((extadetails['media_type'] == 'images') && checkOffsetTiming >= 22 && (unUsedMediasCounts['populated']) >= 6) {
                    break;
                } */else if((extadetails['media_type'] == 'images') && checkOffsetTiming >= 22 && (unUsedMediasCounts['populated']) >= 6) {
                    break;
                }

                const createrID =   imageMedias[j].created_by._path.segments[1];

                const tempImage   =   await getMediaPath(MEDIA_PATH+type[imageMedias[j].type.toString()]+'/'+mediaType[imageMedias[j].media_type.toString()]+'/'+createrID+'/'+imageMedias[j].media, imageMedias[j]);

                if(tempImage === "") {
                    break;
                }

                //Build ffmpeg Data
                let seconds     = 2;
                seconds         = ((seconds + checkOffsetTiming) > 30) ? ((checkOffsetTiming + seconds - 30) - seconds) : seconds;
                offsetTiming        = offsetTiming + seconds;
                checkOffsetTiming   = checkOffsetTiming + seconds;

                let tempMedialength = ffmpegBuildData.length;

                let tempXfadeFilterStartKey = (ffmpegBuildData.length == 1) ? 'v'+(tempMedialength) : 'x'+(tempMedialength - 1);

                let tempXfadeFilter         = (checkOffsetTiming < 30)
                                                ? "["+tempXfadeFilterStartKey+"][v"+(tempMedialength + 1)+"]xfade=fade:duration=1:offset="+xfadeOffset+"[x"+(tempMedialength)+"];"
                                                : "["+tempXfadeFilterStartKey+"][v"+(tempMedialength + 1)+"]xfade=fade:duration=1:offset="+xfadeOffset+",format=yuv420p[v]";
                
                tempXfadeFilter             = (tempMedialength == 0) ? "" : tempXfadeFilter;

                //console.log('2', checkOffsetTiming);

                console.log("tempImage", tempImage);
                console.log("Complex filter", (extadetails['counter'] % 2), imageZoomFilter[(extadetails['counter'] % 2)]);

                ffmpegBuildData.push({
                    'media_url'         : tempImage,
                    'input_option'      : ['-loop 1', '-t 7'],
                    'complex_filter'    : "["+tempMedialength+"]"+imageZoomFilter[(extadetails['counter'] % 2)]+"[v"+(tempMedialength + 1)+"];",
                    'xfade_filter'      : tempXfadeFilter
                });

                xfadeOffset     = offsetTiming;

                usedIDs['media'].push(parseInt(imageMedias[j].id));
                usedIDs['images'].push(parseInt(imageMedias[j].id));

                if(sourceThumbPath == '' && j == 0) {
                    sourceThumbPath =   await getMediaPath(MEDIA_PATH+type[imageMedias[j].type.toString()]+'/'+mediaType[imageMedias[j].media_type.toString()]+'/'+createrID+'/'+imageMedias[j].media, imageMedias[j]);
                }
            }
            console.log('Image part end');
            resolve({status: true, 'sourceThumbPath': sourceThumbPath, 'usedIDs': usedIDs, 'ffmpegBuildData': ffmpegBuildData, 'offsetTiming': offsetTiming, 'xfadeOffset': xfadeOffset, 'checkOffsetTiming': checkOffsetTiming });
        } catch(e) {
            console.log(e);
            var errorLog = await saveErrorLogFileWithpath('justincompilation', 'Error ---> getImageFFMPEGCommands ==>'+e.stack);
            resolve({'status': false, 'message': 'Something went wrong.', 'message': e.stack});
        }
    });
});

export const getJustinFFMPEGCommands = expressAsyncHandler(async(populate, unUsedMediasCounts, sourceThumbPath, usedIDs, ffmpegBuildData, offsetTiming, xfadeOffset, checkOffsetTiming, imageZoomFilter, mediaType, type, extadetails) => {
    return new Promise(async(resolve, reject) => {
        try {
            for(var k = 0; k < populate.length; k++) {
                if(k > 14) {
                    break;
                } else if(ffmpegBuildData.length > 14) {
                    break;
                } else if(checkOffsetTiming >= 30) {
                    break;
                }

                const mediaFilePath =   (populate[k].media_type == 2)
                                            ? POPULATED_IMAGE_PATH+populate[k].populate_image
                                            : POPULATED_VIDEO_PATH+populate[k].populate_video;

                const tempMediaUrl  =   await getMediaPath(mediaFilePath, populate[k]);

                if(tempMediaUrl === "") {
                    break;
                }

                /* if(populate[k].media_type == 2) {
                    tempMediaUrl    =   await getMediaPath(POPULATED_IMAGE_PATH+populate[k].populate_image, populate[k]);
                } else {
                    tempMediaUrl    =   await getMediaPath(POPULATED_VIDEO_PATH+populate[k].populate_video, populate[k]);
                } */

                usedIDs['populated'].push(parseInt(populate[k].id));

                //Build ffmpeg Data
                var duration      = populate[k].populate_video_duration.split(":");
                let seconds         = duration[0]*3600+duration[1]*60+(+duration[2]);
                seconds             = (parseInt(seconds) > 5) ? 5 : parseInt(seconds);
                seconds             = (populate[k].media_type == 1) ? seconds : 2;
                seconds             = parseInt(seconds);
                seconds             = ((seconds + checkOffsetTiming) > 30) ? (seconds - (checkOffsetTiming + seconds - 30)) : seconds;
                offsetTiming        = offsetTiming + seconds;
                checkOffsetTiming   = checkOffsetTiming + seconds;

                let tempMedialength = ffmpegBuildData.length;

                let tempInputOption = (populate[k].media_type == 1)
                                        ? ['-stream_loop -1', '-t 7']
                                        : ['-loop 1', '-t 7'];

                let tempComplexFilter = (populate[k].media_type == 1)
                                        ? "["+tempMedialength+"]split=2[blur][vid];[blur]scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720,boxblur=luma_radius=min(h\\,w)/20:luma_power=1:chroma_radius=min(cw\\,ch)/20:chroma_power=1[bg];[vid]scale=1280:720:force_original_aspect_ratio=decrease[ov];[bg][ov]overlay=(W-w)/2:(H-h)/2,fps=25[v"+(tempMedialength + 1)+"];"
                                        : "["+tempMedialength+"]"+imageZoomFilter[k % 2]+"[v"+(tempMedialength + 1)+"];";

                let tempXfadeFilterStartKey = (ffmpegBuildData.length == 1) ? 'v'+(tempMedialength) : 'x'+(tempMedialength - 1);

                let tempXfadeFilter         = (checkOffsetTiming < 30)
                                                ? "["+tempXfadeFilterStartKey+"][v"+(tempMedialength + 1)+"]xfade=fade:duration=1:offset="+xfadeOffset+"[x"+(tempMedialength)+"];"
                                                : "["+tempXfadeFilterStartKey+"][v"+(tempMedialength + 1)+"]xfade=fade:duration=1:offset="+xfadeOffset+",format=yuv420p[v]";

                tempXfadeFilter             = (tempMedialength == 0) ? "" : tempXfadeFilter;

                //console.log('3', checkOffsetTiming);

                ffmpegBuildData.push({
                    'media_url'         : tempMediaUrl,
                    'input_option'      : tempInputOption,
                    'complex_filter'    : tempComplexFilter,
                    'xfade_filter'      : tempXfadeFilter
                });

                xfadeOffset     = offsetTiming;

                if(sourceThumbPath == '') {

                    const thumbFilePath =   (populate[k].media_type == 2)
                                                    ?  POPULATED_IMAGE_PATH+populate[k].populate_image
                                                    :  POPULATED_VIDEO_THUMBNAIL_PATH+populate[k].populate_thumbnail;

                    sourceThumbPath     =   await getMediaPath(thumbFilePath, populate[k]);

                    /* if(populate[k].media_type == 2) {
                        sourceThumbPath =   getMediaPath(POPULATED_IMAGE_PATH+populate[k].populate_image, populate[k]);
                    } else {
                        sourceThumbPath =   getMediaPath(POPULATED_VIDEO_THUMBNAIL_PATH+populate[k].populate_thumbnail, populate[k]);
                    } */
                }
            }
            resolve({status: true, 'sourceThumbPath': sourceThumbPath, 'usedIDs': usedIDs, 'ffmpegBuildData': ffmpegBuildData, 'offsetTiming': offsetTiming, 'xfadeOffset': xfadeOffset, 'checkOffsetTiming': checkOffsetTiming });
        } catch(e) {
            console.log(e);
            var errorLog = await saveErrorLogFileWithpath('justincompilation', 'Error ---> getJustinFFMPEGCommands ==>'+e.stack);
            resolve({'status': false, 'message': 'Something went wrong.', 'message': e.stack});
        }
    });
});

export const getCompilationFFMPEGCommands = expressAsyncHandler(async(compilationMedia, sourceThumbPath, usedIDs, ffmpegBuildData, offsetTiming, xfadeOffset, checkOffsetTiming, imageZoomFilter) => {
    return new Promise(async(resolve, reject) => {
        try {
            for(var k = 0; k < compilationMedia.length; k++) {
                if(k > 14) {
                    break;
                } else if(ffmpegBuildData.length > 14) {
                    break;
                } else if(checkOffsetTiming >= 30) {
                    break;
                }


                const mediaFilePath     =   (compilationMedia[k].media_type == 2)
                                                ? COMPILATION_IMAGE_FILE_PATH+compilationMedia[k].media
                                                : COMPILATION_VIDEO_FILE_PATH+compilationMedia[k].media;
                const tempMediaUrl      =     await getMediaPath(mediaFilePath, compilationMedia[k]);

                if(tempMediaUrl === "") {
                    break;
                }


                usedIDs['compilation'] = parseInt(compilationMedia[k].id);

                //Build ffmpeg Data
                var duration        =   compilationMedia[k].duration.split(":");
                let seconds         =   duration[0]*3600+duration[1]*60+(+duration[2]);
                seconds             =   (parseInt(seconds) > 5) ? 5 : parseInt(seconds);
                seconds             =   (compilationMedia[k].media_type == 1) ? seconds : 2;
                seconds             =   parseInt(seconds);
                seconds             =   ((seconds + checkOffsetTiming) > 30) ? (seconds - (checkOffsetTiming + seconds - 30)) : seconds;
                offsetTiming        =   offsetTiming + seconds;
                checkOffsetTiming   =   checkOffsetTiming + seconds;

                let tempMedialength = ffmpegBuildData.length;

                let tempInputOption = (compilationMedia[k].media_type == 1)
                                        ? ['-stream_loop -1', '-t 7']
                                        : ['-loop 1', '-t 7'];

                let tempComplexFilter = (compilationMedia[k].media_type == 1)
                                        ? "["+tempMedialength+"]split=2[blur][vid];[blur]scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720,boxblur=luma_radius=min(h\\,w)/20:luma_power=1:chroma_radius=min(cw\\,ch)/20:chroma_power=1[bg];[vid]scale=1280:720:force_original_aspect_ratio=decrease[ov];[bg][ov]overlay=(W-w)/2:(H-h)/2,fps=25[v"+(tempMedialength + 1)+"];"
                                        : "["+tempMedialength+"]"+imageZoomFilter[k % 2]+"[v"+(tempMedialength + 1)+"];";

                let tempXfadeFilterStartKey = (ffmpegBuildData.length == 1) ? 'v'+(tempMedialength) : 'x'+(tempMedialength - 1);

                let tempXfadeFilter         = (checkOffsetTiming < 30)
                                                ? "["+tempXfadeFilterStartKey+"][v"+(tempMedialength + 1)+"]xfade=fade:duration=1:offset="+xfadeOffset+"[x"+(tempMedialength)+"];"
                                                : "["+tempXfadeFilterStartKey+"][v"+(tempMedialength + 1)+"]xfade=fade:duration=1:offset="+xfadeOffset+",format=yuv420p[v]";

                tempXfadeFilter             = (tempMedialength == 0) ? "" : tempXfadeFilter;

                //console.log('3', checkOffsetTiming);

                ffmpegBuildData.push({
                    'media_url'         : tempMediaUrl,
                    'input_option'      : tempInputOption,
                    'complex_filter'    : tempComplexFilter,
                    'xfade_filter'      : tempXfadeFilter
                });

                xfadeOffset     = offsetTiming;

                if(sourceThumbPath == '' && k == 0) {

                    const thumbFilePath =   (compilationMedia[k].media_type == 2)
                                                ?   COMPILATION_IMAGE_FILE_PATH+compilationMedia[k].media
                                                :   COMPILATION_VIDEO_THUMBNAIL_FILE_PATH+compilationMedia[k].thumbnail;

                    sourceThumbPath =   await getMediaPath(thumbFilePath, compilationMedia[k]);

                    /* if(compilationMedia[k].media_type == 2) {
                        sourceThumbPath =   getMediaPath(COMPILATION_IMAGE_FILE_PATH+compilationMedia[k].media, compilationMedia[k]);
                    } else {
                        sourceThumbPath =   getMediaPath(COMPILATION_VIDEO_THUMBNAIL_FILE_PATH+compilationMedia[k].thumbnail, compilationMedia[k]);
                    } */
                }
            }
            resolve({status: true, 'sourceThumbPath': sourceThumbPath, 'usedIDs': usedIDs, 'ffmpegBuildData': ffmpegBuildData, 'offsetTiming': offsetTiming, 'xfadeOffset': xfadeOffset, 'checkOffsetTiming': checkOffsetTiming });
        } catch(e) {
            console.log(e);
            var errorLog = await saveErrorLogFileWithpath('justincompilation', 'Error ---> getJustinFFMPEGCommands ==>'+e.stack);
            resolve({'status': false, 'message': 'Something went wrong.', 'message': e.stack});
        }
    });
});

export const getMediaArrForVideoCon = expressAsyncHandler(async(getAllMedias, getAllJustins, getCompilationMedias, musics, userID, unUsedMediasCounts) => {
    return new Promise(async(resolve, reject) => {
        try {
            const mediaType             =   MEDIA_TYPE;
            const type                  =   TYPE;
            let captions                =   [
                                                'Caption 1',
                                                'Caption 2',
                                                'Caption 3',
                                                'Caption 4',
                                                'Caption 5',
                                                'Caption 6',
                                                'Caption 7',
                                                'Caption 8',
                                                'Caption 9',
                                                'Caption 10'
                                            ];
            let randomCaptionIndex      =   Math.floor(Math.random() * 10);
            let outputCaption           =   '';
            let outputMusic             =   '';
            let outputPath              =   '';
            let destThumbpath           =   '';
            let outputOption            =   [];
            
            let sourceThumbPath         =   '';
            let usedIDs                 =   {};
            usedIDs['media']            =   [];
            usedIDs['videos']           =   [];
            usedIDs['images']           =   [];
            usedIDs['populated']        =   [];
            usedIDs['music']            =   [];
            usedIDs['compilation']      =   0;
            let ffmpegBuildData         =   [];
            let offsetTiming            =   0;
            let xfadeOffset             =   0;
            let checkOffsetTiming       =   2;
            let imageZoomFilter         =   [
                "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=25,zoompan=z='min(zoom+0.0015,1.5)':d=700:x='if(gte(zoom,1.5),x,x+1/a)':y='if(gte(zoom,1.5),y,y+1)':s=1280x720",
                "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=25,zoompan=x='iw-iw/zoom':y='ih-ih/zoom':z='if(eq(on,1),1.2,zoom-0.002)':d=25*8:s=1280x720"
            ];
            var counter                 =   0;
            var lcounter                =   0;
            var ucounter                =   0;
            let zoomCounter             =   0;

            /* const compilationStatus = await getCompilationFFMPEGCommands(getCompilationMedias, sourceThumbPath, usedIDs, ffmpegBuildData, offsetTiming, xfadeOffset, checkOffsetTiming, imageZoomFilter);  //Send the arguments on correct order

            if(compilationStatus.status) {
                sourceThumbPath         =   compilationStatus.sourceThumbPath;
                usedIDs                 =   compilationStatus.usedIDs;
                ffmpegBuildData         =   compilationStatus.ffmpegBuildData;
                offsetTiming            =   compilationStatus.offsetTiming;
                xfadeOffset             =   compilationStatus.xfadeOffset;
                checkOffsetTiming       =   compilationStatus.checkOffsetTiming;
            } */

            //'usedMedias': [], 'unUsedMedias': [], 'likedMedias': [] 
            for await (const medias of getAllMedias['unUsedMedias']) {

                if(checkOffsetTiming >= 30 || ffmpegBuildData.length > 14) {
                    break;
                }

                console.log('checkOffsetTiming', checkOffsetTiming);

                console.log('Start Loop running on the unused medias', ++counter);
                

                for await (const mediaDetails of medias["medias_details"]) {

                    console.log('mediaDetails ====>', mediaDetails);

                    if(checkOffsetTiming >= 30 || ffmpegBuildData.length > 14) {
                        break;
                    }

                    const passMediaData     =   {
                        ...mediaDetails, "created_by": medias["created_by"], "id": medias["id"], "type": medias["type"]
                    };

                    console.log('1. mediaDetails', mediaDetails);

                    console.log(path.extname(mediaDetails["media"]), "File Extensions");

                    if(mediaDetails["media_type"] == 1 && CHECK_VIDEO_EXTENSION.includes(path.extname(mediaDetails["media"]))) {

                        const videoStatus = await getVideoFFMPEGCommands([passMediaData], unUsedMediasCounts, sourceThumbPath, usedIDs, ffmpegBuildData, offsetTiming, xfadeOffset, checkOffsetTiming, imageZoomFilter, mediaType, type, { 'media_type': 'videos', "counter": counter });  //Send the arguments on correct order

                        console.log('Video Response', videoStatus);

                        if(videoStatus.status) {
                            sourceThumbPath     =   videoStatus.sourceThumbPath;
                            usedIDs             =   videoStatus.usedIDs;
                            ffmpegBuildData     =   videoStatus.ffmpegBuildData;
                            offsetTiming        =   videoStatus.offsetTiming;
                            xfadeOffset         =   videoStatus.xfadeOffset;
                            checkOffsetTiming   =   videoStatus.checkOffsetTiming;
                        }

                    } else if(mediaDetails["media_type"] == 2 && CHECK_IMAGE_EXTENSION.includes(path.extname(mediaDetails["media"]))) {

                        const imageStatus = await getImageFFMPEGCommands([passMediaData],  unUsedMediasCounts, sourceThumbPath, usedIDs, ffmpegBuildData, offsetTiming, xfadeOffset, checkOffsetTiming, imageZoomFilter, mediaType, type, { 'media_type': 'images', "counter": zoomCounter });

                        if(imageStatus.status) {

                            zoomCounter =   zoomCounter + 1;

                            sourceThumbPath     =   imageStatus.sourceThumbPath;
                            usedIDs             =   imageStatus.usedIDs;
                            ffmpegBuildData     =   imageStatus.ffmpegBuildData;
                            offsetTiming        =   imageStatus.offsetTiming;
                            xfadeOffset         =   imageStatus.xfadeOffset;
                            checkOffsetTiming   =   imageStatus.checkOffsetTiming;
                        }                    
                    }

                }

                console.log('checkOffsetTiming', checkOffsetTiming);

                console.log('End Loop running on the unused medias');
            }

            console.log('Unsed completely finished');

            console.log('Used IDS', usedIDs);

            console.log('\n\n\n', '###############');
            

            if(checkOffsetTiming < 30 && ffmpegBuildData.length < 14) {
                const justinStatus = await getJustinFFMPEGCommands(getAllJustins['unUsedMedias'],  unUsedMediasCounts, sourceThumbPath, usedIDs, ffmpegBuildData, offsetTiming, xfadeOffset, checkOffsetTiming, imageZoomFilter, mediaType, type, { 'media_type': 'justin' });  //Send the arguments on correct order

                if(justinStatus.status) {
                    sourceThumbPath         =   justinStatus.sourceThumbPath;
                    usedIDs                 =   justinStatus.usedIDs;
                    ffmpegBuildData         =   justinStatus.ffmpegBuildData;
                    offsetTiming            =   justinStatus.offsetTiming;
                    xfadeOffset             =   justinStatus.xfadeOffset;
                    checkOffsetTiming       =   justinStatus.checkOffsetTiming;
                }
            }

            console.log('checkOffsetTiming', checkOffsetTiming);

            console.log('Justin Completed');

            console.log('Used IDS', usedIDs);

            console.log('\n\n\n', '###############');

            
            if(checkOffsetTiming < 30 && ffmpegBuildData.length < 14) {

                for await (const medias of getAllMedias['likedMedias']) {

                    if(checkOffsetTiming >= 30 || ffmpegBuildData.length > 14) {
                        break;
                    }

                    console.log('checkOffsetTiming', checkOffsetTiming);

                    console.log('Start Loop running on the liked medias', ++lcounter);

                    for await (const mediaDetails of medias["medias_details"]) {

                        if(checkOffsetTiming >= 30 || ffmpegBuildData.length > 14) {
                            break;
                        }

                        const passMediaData     =   {
                            ...mediaDetails, "created_by": medias["created_by"], "id": medias["id"], "type": medias["type"]
                        };

                        console.log('2. mediaDetails', mediaDetails);

                        console.log(path.extname(mediaDetails["media"]), "File Extensions");

                        if(mediaDetails["media_type"] == 1 && CHECK_VIDEO_EXTENSION.includes(path.extname(mediaDetails["media"]))) {

                            const likedVideoStatus = await getVideoFFMPEGCommands([passMediaData], unUsedMediasCounts, sourceThumbPath, usedIDs, ffmpegBuildData, offsetTiming, xfadeOffset, checkOffsetTiming, imageZoomFilter, mediaType, type, { 'media_type': 'videos', "counter": lcounter });  //Send the arguments on correct order

                            if(likedVideoStatus.status) {
                                sourceThumbPath     =   likedVideoStatus.sourceThumbPath;
                                usedIDs             =   likedVideoStatus.usedIDs;
                                ffmpegBuildData     =   likedVideoStatus.ffmpegBuildData;
                                offsetTiming        =   likedVideoStatus.offsetTiming;
                                xfadeOffset         =   likedVideoStatus.xfadeOffset;
                                checkOffsetTiming   =   likedVideoStatus.checkOffsetTiming;
                            }

                        } else if(mediaDetails["media_type"] == 2 && CHECK_IMAGE_EXTENSION.includes(path.extname(mediaDetails["media"]))) {
                            const likedImageStatus = await getImageFFMPEGCommands([passMediaData],  unUsedMediasCounts, sourceThumbPath, usedIDs, ffmpegBuildData, offsetTiming, xfadeOffset, checkOffsetTiming, imageZoomFilter, mediaType, type, { 'media_type': 'images', "counter": zoomCounter });

                            if(likedImageStatus.status) {

                                zoomCounter =   zoomCounter + 1;

                                sourceThumbPath     =   likedImageStatus.sourceThumbPath;
                                usedIDs             =   likedImageStatus.usedIDs;
                                ffmpegBuildData     =   likedImageStatus.ffmpegBuildData;
                                offsetTiming        =   likedImageStatus.offsetTiming;
                                xfadeOffset         =   likedImageStatus.xfadeOffset;
                                checkOffsetTiming   =   likedImageStatus.checkOffsetTiming;
                            }                    
                        }
                    }

                    console.log('End Loop running on the used medias');

                }
            }

            console.log('liked completely finished');

            console.log('checkOffsetTiming', checkOffsetTiming);

            console.log('Used IDS', usedIDs);

            console.log('\n\n\n', '###############');


            if(checkOffsetTiming < 30 && ffmpegBuildData.length < 14) {
                const usedJustinStatus = await getJustinFFMPEGCommands(getAllJustins['likedMedias'],  unUsedMediasCounts, sourceThumbPath, usedIDs, ffmpegBuildData, offsetTiming, xfadeOffset, checkOffsetTiming, imageZoomFilter, mediaType, type, { 'media_type': 'justin' });  //Send the arguments on correct order

                if(usedJustinStatus.status) {
                    sourceThumbPath         =   usedJustinStatus.sourceThumbPath;
                    usedIDs                 =   usedJustinStatus.usedIDs;
                    ffmpegBuildData         =   usedJustinStatus.ffmpegBuildData;
                    offsetTiming            =   usedJustinStatus.offsetTiming;
                    xfadeOffset             =   usedJustinStatus.xfadeOffset;
                    checkOffsetTiming       =   usedJustinStatus.checkOffsetTiming;
                }
            }

            console.log('liked completely finished');

            console.log('checkOffsetTiming', checkOffsetTiming);

            console.log('Used IDS', usedIDs);

            console.log('\n\n\n', '###############');

            if(checkOffsetTiming < 30 && ffmpegBuildData.length < 14) {

                for await (const medias of getAllMedias['usedMedias']) {

                    if(checkOffsetTiming >= 30 || ffmpegBuildData.length > 14) {
                        break;
                    }

                    console.log('checkOffsetTiming', checkOffsetTiming);

                    console.log('Start Loop running on the used medias', ++ucounter);

                    for await (const mediaDetails of medias["medias_details"]) {

                        if(checkOffsetTiming >= 30 || ffmpegBuildData.length > 14) {
                            break;
                        }

                        const passMediaData     =   {
                            ...mediaDetails, "created_by": medias["created_by"], "id": medias["id"], "type": medias["type"]
                        };

                        console.log('3. mediaDetails', mediaDetails);

                        console.log(path.extname(mediaDetails["media"]), "File Extensions");

                        if(mediaDetails["media_type"] == 1 && CHECK_VIDEO_EXTENSION.includes(path.extname(mediaDetails["media"]))) {

                            const usedVideoStatus = await getVideoFFMPEGCommands([passMediaData], unUsedMediasCounts, sourceThumbPath, usedIDs, ffmpegBuildData, offsetTiming, xfadeOffset, checkOffsetTiming, imageZoomFilter, mediaType, type, { 'media_type': 'videos', "counter": ucounter });  //Send the arguments on correct order

                            if(usedVideoStatus.status) {
                                sourceThumbPath     =   usedVideoStatus.sourceThumbPath;
                                usedIDs             =   usedVideoStatus.usedIDs;
                                ffmpegBuildData     =   usedVideoStatus.ffmpegBuildData;
                                offsetTiming        =   usedVideoStatus.offsetTiming;
                                xfadeOffset         =   usedVideoStatus.xfadeOffset;
                                checkOffsetTiming   =   usedVideoStatus.checkOffsetTiming;
                            }

                        } else if(mediaDetails["media_type"] == 2 && CHECK_IMAGE_EXTENSION.includes(path.extname(mediaDetails["media"]))) {
                            const usedImageStatus = await getImageFFMPEGCommands([passMediaData],  unUsedMediasCounts, sourceThumbPath, usedIDs, ffmpegBuildData, offsetTiming, xfadeOffset, checkOffsetTiming, imageZoomFilter, mediaType, type, { 'media_type': 'images', "counter": zoomCounter });

                            if(usedImageStatus.status) {

                                zoomCounter =   zoomCounter + 1;

                                sourceThumbPath     =   usedImageStatus.sourceThumbPath;
                                usedIDs             =   usedImageStatus.usedIDs;
                                ffmpegBuildData     =   usedImageStatus.ffmpegBuildData;
                                offsetTiming        =   usedImageStatus.offsetTiming;
                                xfadeOffset         =   usedImageStatus.xfadeOffset;
                                checkOffsetTiming   =   usedImageStatus.checkOffsetTiming;
                            }                    
                        }
                        
                    }

                    console.log('End Loop running on the used medias');
                    
                }
            }

            console.log('Used completely finished');

            console.log('checkOffsetTiming', checkOffsetTiming);

            console.log('Used IDS', usedIDs);

            console.log('\n\n\n', '###############');

            if(checkOffsetTiming < 30 && ffmpegBuildData.length < 14) {
                const usedJustinStatus = await getJustinFFMPEGCommands(getAllJustins['usedMedias'],  unUsedMediasCounts, sourceThumbPath, usedIDs, ffmpegBuildData, offsetTiming, xfadeOffset, checkOffsetTiming, imageZoomFilter, mediaType, type, { 'media_type': 'justin' });  //Send the arguments on correct order

                if(usedJustinStatus.status) {
                    sourceThumbPath         =   usedJustinStatus.sourceThumbPath;
                    usedIDs                 =   usedJustinStatus.usedIDs;
                    ffmpegBuildData         =   usedJustinStatus.ffmpegBuildData;
                    offsetTiming            =   usedJustinStatus.offsetTiming;
                    xfadeOffset             =   usedJustinStatus.xfadeOffset;
                    checkOffsetTiming       =   usedJustinStatus.checkOffsetTiming;
                }
            }

            console.log('Used  justin completely finished');

            console.log('Used IDS', usedIDs);

            console.log('\n\n\n', '###############');

            const music_ffmpeg = new Promise(async(resolve, reject) => {

                outputMusic =   await getMediaPath(MUSIC_PATH+musics[0].audio_file, musics[0]);

                usedIDs['music'].push(parseInt(musics[0].id));

                outputOption.push('-map [v]');
                outputOption.push('-map '+ffmpegBuildData.length+':a');
                outputOption.push('-t 30');
                outputOption.push('-c:v libx264');

                outputCaption = captions[randomCaptionIndex];

                let outputName = await getMediaName();

                let thumbExt = path.extname(sourceThumbPath);

                if(process.env.MODE == "development") {
                    let dir             =   path.resolve(FILE_ROOT_PATH+JUSTIN_COMPILATION_FILE_PATH+userID+'/');
                    let dirThum         =   path.resolve(FILE_ROOT_PATH+JUSTIN_COMPILATION_FILE_PATH+userID+'/thumbnail/');
                    let statusDir       =   await createDirectoryLocal(dir);
                    let statusDirThum   =   await createDirectoryLocal(dirThum);
                    outputPath          =   path.resolve(FILE_ROOT_PATH+JUSTIN_COMPILATION_FILE_PATH+userID+'/'+outputName+'.mp4');
                    destThumbpath       =   path.resolve(FILE_ROOT_PATH+JUSTIN_COMPILATION_FILE_PATH+userID+'/thumbnail/thumbnail_'+outputName+thumbExt);
                } else {
                    outputPath      =   JUSTIN_COMPILATION_FILE_PATH+userID+'/'+outputName+'.mp4';
                    destThumbpath   =   JUSTIN_COMPILATION_FILE_PATH+userID+'/thumbnail/thumbnail_'+outputName+thumbExt;
                }
                resolve(outputPath);
            });

            console.log('Music  completely finished');

            console.log('checkOffsetTiming', checkOffsetTiming);

            console.log('Used IDS', usedIDs);

            console.log('\n\n\n', '###############');

            Promise.all([music_ffmpeg]).then((values) => {

                console.log('Start all converstion process');

                let temp = {
                    'status'                : true,
                    'used_ids'              : usedIDs,
                    'output_caption'        : outputCaption,
                    'ffmpeg_build_data'     : ffmpegBuildData,
                    'output_music'          : outputMusic,
                    'output_option'         : outputOption,
                    'output_path'           : outputPath,
                    'dest_thumb_path'       : destThumbpath,
                    'source_thumb_path'     : sourceThumbPath,
                    'duration'              : '00:30',
                    'checkOffsetTiming'     : checkOffsetTiming,
                    'offsetTiming'          : offsetTiming
                };
                if(checkOffsetTiming >= 30) {  
                    console.log('All Collected Data',temp);
                    resolve(temp);
                } else {
                    console.log('All Collected Data',temp);
                    temp['status'] = false;
                    resolve(temp);
                }
            });
        } catch(e) {
            console.log(e);
            var errorLog = await saveErrorLogFileWithpath('justincompilation', 'Error: ---->'+e.stack);
            resolve(false);
        }
    });
});

export const deleteTempFiles = expressAsyncHandler(async(files) => {
    return await Promise.all(files.map(async(file, index) => {
        return new Promise(async function(resolve, reject){
            try {
                fs.unlinkSync(file);
                resolve(true);
            } catch(e) {
                var errorLog = await saveErrorLogFileWithpath('justincompilation', 'deleteTempFiles Error: ---->'+e.stack);
                resolve(false);
            }
        });
    }));
});


export const downloadMultipleFiles = expressAsyncHandler(async(bucket, files) => {
    return await Promise.all(files.map(async(file, index) => {
        return new Promise(async function(resolve, reject){
            try {
                await bucket.file(file.original).download({ destination: file.destination }, function(err) {
                    if(!err) {
                        resolve(true)
                    } else {
                        var errorLog = saveErrorLogFileWithpath('justincompilation', 'Error: ---->'+err.message);
                        resolve(false);
                    }
                });
            } catch(e) {
                console.log(e, 'downloadMultipleFiles');
                var errorLog = saveErrorLogFileWithpath('justincompilation', 'downloadMultipleFiles Error: ---->'+e.message);
                resolve(false);
            }
        });
    }))
});

export const downloadMultipleFilesLocal = expressAsyncHandler(async(bucket, files) => {
    return await Promise.all(files.map(async(file, index) => {
        return new Promise(async function(resolve, reject){
            try {
                await fs.copyFile(file.original, file.destination, (err) => {
                    if(err) {
                        var errorLog = saveErrorLogFileWithpath('justincompilation', 'Error: ---->'+err.message);
                        
                        console.log(err);
                        resolve(false);
                    } else {
                        resolve(true);
                    }
                });
            } catch(e) {
                console.log(e, 'downloadMultipleFilesLocal');
                var errorLog = saveErrorLogFileWithpath('justincompilation', 'downloadMultipleFilesLocal Error: ---->'+e.message);
                resolve(false);
            }
        })
    }))
});

export const uploadMultipleFiles = expressAsyncHandler(async(bucket, files) => {
    return await Promise.all(files.map(async(file, index) => {
        return new Promise(async function(resolve, reject){
            try {
                let options = {
                    destination: bucket.file(file.destination),
                    resumable: false
                };
                    
                bucket.upload(file.original, options, function(err, newFile) {
                    if(!err) {
                        console.log('File copied successfully');
                        resolve(true)
                    } else {
                        var errorLog = saveErrorLogFileWithpath('justincompilation', 'Error: ---->'+err.message);
                        resolve(false);
                    }
                });
            } catch(e) {
                console.log(e, 'uploadMultipleFiles');
                var errorLog = saveErrorLogFileWithpath('justincompilation', 'uploadMultipleFiles Error: ---->'+e.message);
                resolve(false);
            }
        });
    }));
});

export const uploadMultipleFilesLocal = expressAsyncHandler(async(bucket, files) => {
    return await Promise.all(files.map(async(file, index) => {
        return new Promise(async function(resolve, reject){
            try {
                await fs.copyFile(file.original, file.destination, async(err) => {
                    if(err) {
                        var errorLog = await saveErrorLogFileWithpath('justincompilation', 'Error: ---->'+err.message);
                        resolve(false);
                    } else {
                        resolve(true);
                    }
                });
            } catch(e) {
                console.log(e, 'uploadMultipleFilesLocal');
                var errorLog = saveErrorLogFileWithpath('justincompilation', 'uploadMultipleFilesLocal Error: ---->'+e.message);
                resolve(false);
            }
        });
    }));
});

export const getSupportersDailyNotifications = expressAsyncHandler(async(index) => {
    //Don't change the array order
    const notificationMessages = [
        {
            "id"      :   0,
            "title"   :   "Positive affirmations",
            "message" :   "Hi [[SUPPORTER_NAME]] now would be a great time to send [[USER_NAMES]] a positive message. Feel free to share some of the positive affirmations we put in your feed."
        },
        {
            "id"      :   1,
            "title"   :   "Loaded an affirmation",
            "message" :   "Hi [[SUPPORTER_NAME]], we just loaded an affirmation in for you that we think [[USER_NAMES]] might like. Feel free to share it with them."
        },
        {
            "id"      :   2,
            "title"   :   "Thinking about them",
            "message" :   "Hi [[SUPPORTER_NAME]], let [[USER_NAMES]] know your thinking about them."
        },
        {
            "id"      :   3,
            "title"   :   "Lift their spirits",
            "message" :   "Hi [[SUPPORTER_NAME]], How's [[USER_NAMES]] doing? Lift their spirits with a message of support."
        },
        {
            "id"      :   4,
            "title"   :   "Send photo",
            "message" :   "Hi [[SUPPORTER_NAME]], Why don't you send [[USER_NAMES]] a photo that will make them smile."
        },
        {
            "id"      :   5,
            "title"   :   "Message them",
            "message" :   "Hi [[SUPPORTER_NAME]], How's [[USER_NAMES]] doing? Lift their spirits with a message of support."
        },
        {
            "id"      :   6,
            "title"   :   "Checked in",
            "message" :   "Hi [[SUPPORTER_NAME]], Have you checked in on [[USER_NAMES]] lately?"
        }
    ];
    return notificationMessages[index];
});

export const getSendNotificationMessage = expressAsyncHandler(async(type) => {
    const notificationMessages = {
        'media_view' : {
            "id"      :   0,
            "title"   :   "Checked in",
            "message" :   "Hi [[TO]], [[FROM]] has viewed your Time message. Please record a new one."
        }
    }
    return notificationMessages[type];
});

export const getNotification = expressAsyncHandler((title, message, token, userDetail) => {
    var notification                =   {};
    notification['notification']    =   { 'title': title, 'body': message };
    notification['android']         =   { 'notification': { 'sound': 'time_notification.wav', 'priority': 'high' } };
    notification['apns']            =   { 'payload': { 'aps': { 'sound': 'time_notification.wav', 'headers': { 'apns-priority': '5' } } } };
    notification['token']           =   token;
    notification['data']            =   { 'action_type' : title.toUpperCase(), 'user_role': userDetail.user_role.toString() };
    return notification;
});

export const pushNotification = expressAsyncHandler(async(messages) => {
    return new Promise((resolve, reject) => {
        const notification_options = {
            priority: "high",
            timeToLive: 60 * 60 * 24
        };
        //console.log('Message ==>', messages);
        admin.messaging().send(messages)
        .then((response) => {
            console.log('Successfully sent message:', response);
            let tempObj = {
                'status': true,
                'response': response
            }
            resolve(tempObj);
        })
        .catch((error) => {
            //console.log('Error sending message:', error);
            let tempObj = {
                'status': false,
                'response': error.toString()
            }
            console.log(tempObj);
            let logError = saveErrorLogFileWithpath('pushNotification', error.toString());
            resolve(tempObj);
        });
    });
});


export const getActivities = expressAsyncHandler(async() => {
    const activities = {
        "user_sms_verified": {
            "type": 1,
            "message": "[[FROM]] verified sms.",
            "user_message": "[[FROM]] verified sms.",
            "supporter_message": "[[FROM]] verified sms."
        },
        "add_onborading_media": {
            "type": 4,
            "message": "[[FROM]] added [[MEDIA]] on [[TYPE]].",
            "user_message": "[[FROM]] recorded your first [[TYPE]].",
            "supporter_message": "[[FROM]] recorded your first [[TYPE]]."
        },
        "add_media": {
            "type": 4,
            "message": "[[FROM]] added [[MEDIA]] on [[TYPE]].",
            "user_message": "[[FROM]] saved [[CONTENT_OR_MESSAGE]] to your [[TYPE]].",
            "supporter_message": "[[FROM]] saved [[CONTENT_OR_MESSAGE]] to your [[TYPE]]."
        },
        "assign_media": {
            "type": 3,
            "message": "[[FROM]] added [[MEDIA]] on [[TYPE]] for [[TO]].",
            "user_message": "[[FROM]] saved [[CONTENT_OR_MESSAGE]] to your [[TYPE]].",
            "supporter_message": "[[FROM]] saved [[CONTENT_OR_MESSAGE]] to [[TO]]'s [[TYPE]]."
        },
        "invite_new_helpinghand": {
            "type": 2,
            "message": "[[FROM]] invited new helpinghand [[TO]].",
            "user_message": "You sent [[TO]] an invitation.",
            "supporter_message": "You received an invitation from [[FROM]]."
        },
        "request_accepted": {
            "type": 2,
            "message": "[[FROM]] accepted [[TO]] request.",
            "user_message": "[[FROM]] accepted your invitation.",
            "supporter_message": "You accepted [[TO]]'s invitation."
        },
        "user_viewed_assigned_media": {
            "type": 3,
            "message": "[[FROM]] viewed [[TO]] assigned media [[MEDIA]] on [[TYPE]].",
            "user_message": "[[FROM]] viewed [[TO]] [[CONTENT_OR_MESSAGE]] on [[TYPE]].",
            "supporter_message": "[[FROM]] viewed your message on [[TYPE]], please reach out."
        },
        "media_like": {
            "type": 4,
            "message": "[[FROM]] liked media [[MEDIA]] on [[TYPE]].",
            "user_message": "[[FROM]] liked [[CONTENT_OR_MESSAGE]] on [[TYPE]].",
            "supporter_message": "[[FROM]] liked [[CONTENT_OR_MESSAGE]] on [[TYPE]]."
        },
        "assigned_media_like": {
            "type": 3,
            "message": "[[FROM]] liked [[TO]] assigned media [[MEDIA]] on [[TYPE]].",
            "user_message": "[[FROM]] liked your [[CONTENT_OR_MESSAGE]] on [[TYPE]].",
            "supporter_message": "[[FROM]] liked your [[CONTENT_OR_MESSAGE]] on [[TYPE]]."
        },
        "justin_media_like": {
            "type": 5,
            "message": "[[FROM]] liked justin media.",
            "user_message": "[[FROM]] liked justin content.",
            "supporter_message": "[[FROM]] liked justin content."
        },
        "media_unlike": {
            "type": 4,
            "message": "[[FROM]] unliked media [[MEDIA]] on [[TYPE]].",
            "user_message": "[[FROM]] unliked justin content.",
            "supporter_message": "[[FROM]] unliked justin content."
        },
        "assigned_media_unlike": {
            "type": 3,
            "message": "[[FROM]] unliked [[TO]] assigned media [[MEDIA]] on [[TYPE]].",
            "user_message": "[[FROM]] unliked your [[CONTENT_OR_MESSAGE]] sent [[date]] on [[TYPE]].",
            "supporter_message": "[[FROM]] unliked [[TO]] [[CONTENT_OR_MESSAGE]] sent [[date]] on [[TYPE]]."
        },
        "justin_media_unlike": {
            "type": 5,
            "message": "[[FROM]] unliked justin content.",
            "user_message": "[[FROM]] unliked justin content.",
            "supporter_message": "[[FROM]] unliked justin content."
        },
        "delete_created_media": {
            "type": 3,
            "message": "[[FROM]] deleted your [[TYPE]].",
            "user_message": "[[FROM]] deleted your [[TYPE]].",
            "supporter_message": "[[FROM]] deleted your [[TYPE]]."
        },
        "delete_assigned_media": {
            "type": 3,
            "message": "[[FROM]] deleted [[TO]] assigned media [[MEDIA]] on [[TYPE]].",
            "user_message": "[[FROM]] deleted [[TO]] assigned media [[MEDIA]] on [[TYPE]].",
            "supporter_message": "[[FROM]] deleted [[TO]] assigned media [[MEDIA]] on [[TYPE]]."
        },
        "delete_justin_media": {
            "type": 5,
            "message": "[[FROM]] deleted justin media.",
            "user_message": "[[FROM]] deleted justin media.",
            "supporter_message": "[[FROM]] deleted justin media."
        },
        "delete_justin_compilation_video": {
            "type": 5,
            "message": "[[FROM]] deleted justin compilation video.",
            "user_message": "[[FROM]] deleted justin compilation video.",
            "supporter_message": "[[FROM]] deleted justin compilation video."
        },
        "justin_compilation_video_like": {
            "type": 5,
            "message": "[[FROM]] liked justin compilation video.",
            "user_message": "[[FROM]] liked justin compilation video.",
            "supporter_message": "[[FROM]] liked justin compilation video."
        },
        "justin_compilation_video_unlike": {
            "type": 5,
            "message": "[[FROM]] unliked justin compilation video.",
            "user_message": "[[FROM]] unliked justin compilation video.",
            "supporter_message": "[[FROM]] unliked justin compilation video."
        },
        "user_press_time": {
            "type": 3,
            "message": "[[FROM]] has viewed TIME. Please reach out.",
            "user_message": "[[FROM]] has viewed TIME. Please reach out.",
            "supporter_message": "[[FROM]] has viewed TIME. Please reach out.",
            "title": "Viewed Time"
        },
        "time_media_viewed": {
            "type": 3,
            "message": "Now would be a good moment to save [[FROM]] a new TIME message.",
            "user_message": "Now would be a good moment to save [[FROM]] a new TIME message.",
            "supporter_message": "Now would be a good moment to save [[FROM]] a new TIME message.",
            "title": "Viewed Time"
        }
    }
    return activities;
});

export const addActivity = expressAsyncHandler(async(activityType, fromUser, toUser, linkID, LinkCollectionName, activityInfo) => {
    return new Promise(async(resolve, reject) => {
        try {
            const db = await getDBConnection();
            //let activities = await getActivities();
            //console.log(activityType, fromUser, toUser, linkID, LinkCollectionName, activityInfo);

            let activityObj = {};
            activityObj[Activities.fields.activity_type.key] = activityType;
            activityObj[Activities.fields.activity_from_ref.key] = await db.doc(Users.collection.name+'/'+fromUser.toString());
            activityObj[Activities.fields.activity_info.key] = activityInfo;
            activityObj[Activities.fields.created_by.key] = await db.doc(Users.collection.name+'/'+fromUser.toString());
            activityObj[Activities.fields.created_on.key] =  await admin.firestore.FieldValue.serverTimestamp();

            if(toUser != undefined && toUser != null && toUser != 0 && toUser != '') {
                if(activityType == "invite_new_helpinghand") {
                    activityObj[Activities.fields.activity_to_ref.key] = await db.doc(TemporaryHelpinghandUsers.collection.name+'/'+toUser.toString());
                    activityObj[Activities.fields.reference_ids.key] = [await db.doc(Users.collection.name+'/'+fromUser.toString()), await db.doc(TemporaryHelpinghandUsers.collection.name+'/'+toUser.toString())];
                } else if(activityType == "user_press_time") {  //This acivity only for supporters.
                    activityObj[Activities.fields.activity_to_ref.key] = await db.doc(Users.collection.name+'/'+toUser.toString());
                    activityObj[Activities.fields.reference_ids.key] = [await db.doc(Users.collection.name+'/'+toUser.toString())];
                } else if(activityType == "time_media_viewed") {
                    activityObj[Activities.fields.activity_to_ref.key] = await db.doc(Users.collection.name+'/'+toUser.toString());
                    activityObj[Activities.fields.reference_ids.key] = [await db.doc(Users.collection.name+'/'+toUser.toString())];
                } else {
                    activityObj[Activities.fields.activity_to_ref.key] = await db.doc(Users.collection.name+'/'+toUser.toString());
                    activityObj[Activities.fields.reference_ids.key] = [await db.doc(Users.collection.name+'/'+fromUser.toString()), await db.doc(Users.collection.name+'/'+toUser.toString())];
                }
            } else {
                activityObj[Activities.fields.activity_to_ref.key] = null;
                activityObj[Activities.fields.reference_ids.key] = [await db.doc(Users.collection.name+'/'+fromUser.toString())];
            }
            if(linkID != undefined && LinkCollectionName != undefined && linkID != null && LinkCollectionName != null && linkID != "" && LinkCollectionName != "" && linkID != 0) {
                activityObj[Activities.fields.activity_link_ref.key] = await db.doc(LinkCollectionName+'/'+linkID.toString());
            } else {
                activityObj[Activities.fields.activity_link_ref.key] = null;
            }
            const activityID = await insertData(Activities, activityObj, Activities.fields.activity_id.key);
            resolve(activityID);
        } catch(e) {
            reject(false);
            console.log('Catch error in common function addActivity()', e);
            var errorLog = await saveErrorLogFileWithpath('addActivity', e.stack);
            throw new Error(e.message);
        }
    });
});

export const getMediaPath = (filepath, mediaDetail) => {
    return new Promise(async(resolve, reject) => {
        try {
            
            if(process.env.MODE == "development") {
                const convertedFilePath =   await checkFileExists(path.resolve(FILE_ROOT_PATH+filepath), mediaDetail);
                resolve(convertedFilePath);
            } else {
                const convertedFilePath =   await checkFileExists(filepath, mediaDetail);
                resolve(convertedFilePath);
            }
        } catch(e) {
            resolve(false);
            console.log('Catch error in common function getMediaPath()', e);
            var errorLog = saveErrorLogFileWithpath('getMediaPath', e.stack);
            throw new Error(e.message);
        }
    })
};

export const getMediaBaseURL    =  (mediaType, hostname, urlDetails, next) => {
    return new Promise(function(resolve, reject){
        try {

            const localRootLink =   'http://'+hostname+':'+process.env.PORT+'/public/';
            const liveRootLink  =   process.env.STORAGE_BASE_URL+'public%2F';

            if(process.env.MODE == 'development') {
                switch (mediaType) {
                    case 'medias':
                        resolve(localRootLink+'media/'+urlDetails['type']+'/'+urlDetails['media_type']+'/'+urlDetails['user_id']+'/'+urlDetails['media_name']);
                        break;
                    case 'media_thumbnails':
                        resolve(localRootLink+'media/'+urlDetails['type']+'/'+urlDetails['media_type']+'/'+urlDetails['user_id']+'/thumbnail/'+urlDetails['media_name']);
                        break;
                    case 'profile':
                        resolve(localRootLink+'profile/'+urlDetails['user_id']+'/'+urlDetails['profile_image']);
                        break;
                    case 'temp_profile':
                        resolve('http://'+hostname+':'+process.env.PORT+'/public/temp_user/profile/'+urlDetails['user_id']+'/'+urlDetails['profile_image']);
                        break;
                    case 'compilation':
                        if(urlDetails['media_type'] === 1) {
                            resolve(localRootLink+'compilation/videos/'+urlDetails['media']);
                        } else {
                            resolve(localRootLink+'compilation/images/'+urlDetails['media']);
                        }
                        break;
                    case 'compilation_thumbnail':
                        resolve(localRootLink+'compilation/videos/thumbnails/'+urlDetails['thumbnail']);
                        break;
                    case 'music':
                        resolve('http://'+hostname+':'+process.env.PORT+'/public/music/'+urlDetails['music']);
                        break;
                    case 'music_thumbnail':
                        resolve('http://'+hostname+':'+process.env.PORT+'/public/music/thumbnail/'+urlDetails['thumbnail']);
                        break;
                    default:
                        resolve(localRootLink+'media/'+urlDetails['type']+'/'+urlDetails['media_type']+'/'+urlDetails['user_id']+'/'+urlDetails['media_name']);
                }
            } else {
                switch (mediaType) {
                    case 'medias':
                        resolve(liveRootLink+'media%2F'+urlDetails['type']+'%2F'+urlDetails['media_type']+'%2F'+urlDetails['user_id']+'%2F'+urlDetails['media_name']+'?alt=media');
                        break;
                    case 'media_thumbnails':
                        resolve(liveRootLink+'media%2F'+urlDetails['type']+'%2F'+urlDetails['media_type']+'%2F'+urlDetails['user_id']+'%2Fthumbnail%2F'+urlDetails['media_name']+'?alt=media');
                        break;
                    case 'profile':
                            resolve(liveRootLink+'profile%2F'+urlDetails['user_id']+'%2F'+urlDetails['profile_image']+'?alt=media');
                            break;
                    case 'temp_profile':
                            resolve(liveRootLink+'temp_user%2Fprofile%2F'+urlDetails['user_id']+'%2F'+urlDetails['profile_image']+'?alt=media');
                            break;
                    case 'compilation':
                        if(urlDetails['media_type'] === 1) {
                            resolve(liveRootLink+'compilation%2Fvideos%2F'+urlDetails['media']+'?alt=media');
                        } else {
                            resolve(liveRootLink+'compilation%2Fimages%2F'+urlDetails['media']+'?alt=media');
                        }
                        break;
                    case 'compilation_thumbnail':
                        resolve(liveRootLink+'compilation%2Fvideos%2Fthumbnails%2F'+urlDetails['thumbnail']+'?alt=media');
                        break;
                    case 'music':
                        resolve(process.env.STORAGE_BASE_URL+'public%2Fmusic%2F'+urlDetails['music']+'?alt=media');
                        break;
                    case 'music_thumbnail':
                        resolve(process.env.STORAGE_BASE_URL+'public%2Fmusic%2Fthumbnail%2F'+urlDetails['thumbnail']+'?alt=media');
                        break;
                    default:
                        resolve(liveRootLink+'media%2F'+urlDetails['type']+'%2F'+urlDetails['media_type']+'%2F'+urlDetails['user_id']+'%2F'+urlDetails['media_name']+'?alt=media');
                }
            }
        } catch(e) {
            var errorLog = saveErrorLogFileWithpath('getMediaBaseURL', e.stack);
            reject(e.message);
        }
    });
};

export const checkFileExists = (path, mediaDetail) => {
    return new Promise(async(resolve, reject) => {
        try {
            if(process.env.MODE == 'development') {
                if(fs.existsSync(path)) {
                    return resolve(path);
                } else {
                    const mediaID   =   (mediaDetail["id"] !== undefined) ? mediaDetail["id"]: 0;
                    await saveErrorLogFileWithpath('checkFileExists', "Media ID ===>"+mediaID+" ===>This path is not found  ===>"+path);
                    return resolve("");
                }
            } else {

                const storage   =   await getStorageConnection();
                const bucket    =   await storage.bucket();
                const file      =   await bucket.file(path);

                file.exists().then(async function(data) {
                    if(data[0]) {
                        return resolve(path);
                    } else {
                        const mediaID   =   (mediaDetail["id"] !== undefined) ? mediaDetail["id"]: 0;
                        await saveErrorLogFileWithpath('checkFileExists', "Media ID ===>"+mediaID+" ===>This path is not found  ===>"+path);
                        return resolve("");
                    }
                });
            }
        } catch(e) {
            await saveErrorLogFileWithpath('checkFileExists', e.stack);
            return resolve("");
        }
    });
}

export const checkFileError = (err) => {
    return new Promise((resolve, reject) => {
        if(err instanceof multer.MulterError) {
            if(err.code == "LIMIT_UNEXPECTED_FILE") {
                return resolve({ status: true, message: 'Invalid field name.' });
            } else if(err.code == "LIMIT_FILE_COUNT") {
                return resolve({ status: true, message: 'Too many files uploaded.' });
            } else {
                return resolve({ status: true, message: err.message });
            }
        } else if (err) {
            return resolve({ status: true, message: err.message });
        } else {
            return resolve({ status: false, message: '' });
        }
    });
};