import { saveErrorLogFile, saveErrorLogFileWithpath } from '../common/commonFunctions.js';


const notFound = (req, res, next) => {
    res.status(200).json({status: 'error', message: `Not Found - ${req.originalUrl}`});
}

const errorHandler = (err, req, res, next) => {
    let msg;
    console.log(err);
    if(process.env.NODE_ENV == 'development') {
        msg = err.stack;
        //saveErrorLogFile(err.message);
        saveErrorLogFileWithpath('admin_errors', msg);
    } else {
        //saveErrorLogFile(err.message);
        saveErrorLogFileWithpath('admin_errors', err.stack);
        msg = "Something went wrong.";
    }
    res.status(200).json({
        status: 'error',
        message: msg,
        error: err.stack
    });
}

export { notFound, errorHandler }