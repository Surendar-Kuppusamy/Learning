import express from 'express';
import bodyParser from 'body-parser';
import path from 'path';
import dotenv from 'dotenv';
import cors from 'cors';
import { connectDB } from './config/db.js';

import { notFound, errorHandler } from './middleware/errorMiddleware.js';

import usersRoutes from './routers/usersRoutes.js';
import adminRoutes from './routers/adminRoutes.js'; // Admin
import musicRoutes from './routers/musicRoutes.js'; // Music
import justinRoutes from './routers/justinRoutes.js'; // Justin
import faqRoutes from './routers/faqRoutes.js'; // FAQ
import blogRoutes from './routers/blogsRoutes.js'; // Blog
import helpingHandRoutes from './routers/helpingHandRoutes.js';
import uploadMediaLive from './routers/uploadMediaLive.js';
import onboardingVideoRoutes from './routers/onboardingVideoRoutes.js';
import compilationRoutes from './routers/compilationRoutes.js';

import cronRoutes from './routers/cronRoutes.js';

dotenv.config({path: './.env'});

const app = express();
app.use(cors());

const __dirname = path.resolve()
//app.use('/public', express.static(path.join(__dirname, '/public')))
if(process.env.NODE_ENV == 'development') {
	app.use('/public', express.static(path.resolve("../../Work/Justin/public/")));
}

connectDB();

// for parsing application/xwww-form-urlencoded// for parsing application/json
//app.use(bodyParser.urlencoded({ extended: true }));
//app.use(bodyParser.json());
app.use(express.json());
//app.disable('etag');


app.use('/admin/api/users/', usersRoutes);

app.use('/admin/api/admin/', adminRoutes); // Admin 
app.use('/admin/api/music/', musicRoutes); // Music 
app.use('/admin/api/justin/', justinRoutes); // justinRoutes
app.use('/admin/api/faq/', faqRoutes); // faq
app.use('/admin/api/blog/', blogRoutes); // blog

app.use('/admin/api/onboarding/video/', onboardingVideoRoutes);

app.use('/admin/api/compilation/', compilationRoutes);

app.use('/admin/api/helpinghand/', helpingHandRoutes);

app.use('/admin/api/cron/', cronRoutes);

app.use('/admin/api/upload/', uploadMediaLive);


if(process.env.NODE_ENV != 'development') {
	var options = {
		dotfiles: 'ignore',
		etag: false,
		setHeaders: function (res, path, stat) {
		  res.set('x-timestamp', Date.now())
		}
	}
	const headers = { 'Last-Modified': (new Date()).toUTCString(), "Cache-Control": "no-cache, no-store, must-revalidate", "Pragma": "no-cache", "Expires": 0 };
	app.use(express.static(path.join(__dirname, '/frontend/build'), options))
	app.get('*', (req, res) =>
	  	//res.sendFile(path.resolve(__dirname, 'frontend', 'build', 'index.html'), {'headers': headers})
		res.sendFile(path.resolve(__dirname, 'frontend', 'build', 'v6', 'index.html'), {'headers': headers})
	);
} else {
	app.get('/',(req,res) => {
		res.send('JUSTIN API HOME.....');
	})
}

app.use(notFound)
app.use(errorHandler)

app.listen(process.env.PORT,() => {
	console.log(`Running on PORT ${process.env.PORT}`);
})