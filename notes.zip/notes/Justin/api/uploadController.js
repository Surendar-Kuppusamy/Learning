import admin from 'firebase-admin';
import expressAsyncHandler from 'express-async-handler';
import fs from 'fs';
import path from 'path';
import express from 'express';
import multer from 'multer';
import { getDBConnection, getStorageConnection } from '../config/db.js';
import { deleteMediaFiles, generalFileUpload, fileUpload, fileUploadLocal, deleteFile, deleteFileLocal, copyFile, getAllReferenceData, getCollectionDataWithDocID, getCollectionData, insertBulkData, insertData, updateData, getMediaName, addActivity, addActivityData, checkMediaIsDupilicate, addNotification, updateMediaUploadResponse, moveMediaFromTimeoutToInspiration, getLastInsertedID, checkIsDocExists, addActivities, getMediaBaseURL, generalDeleteFile, generateInviteCode, checkFileError, jsonResponse } from '../common/commonFunctions.js';
import { CHECK_VIDEO_EXTENSION, CHECK_IMAGE_EXTENSION, CHECK_AUDIO_EXTENSION, MEDIA_TYPE, TYPE, MAXIMUM_SUPPORTING_COUNT } from '../constants/globalConstants.js';
import { getUserId, getUserRole, verifyToken } from '../middleware/authMiddleware.js';
import { Users } from '../models/UsersModel.js';
import { TemporaryHelpinghandUsers } from '../models/TemporaryHelpinghandUsersModel.js';
import { TemporaryUsers } from '../models/TemporaryUsersModel.js';
import { InviteHelpinghand } from '../models/InviteHelpinghandModel.js';
import { MediaGroup } from '../models/MediasGroupModel.js';
import { Music } from '../models/MusicModel.js';
import { AllCollectionsDocumentID } from '../models/AllCollectionsDocumentID.js';


export const uploadMediaThumbnail = expressAsyncHandler(async function (req, res, err, next) {

    const resFiles	=	req.files;

    const errorStatus   =   await checkFileError(err);

    if(errorStatus['status']) {
        return jsonResponse(res, 400, 'error', errorStatus['message']);
    }

    const db 					=	await getDBConnection();
    const userID 				=	await getUserId(req);
    const userRole 				=	await getUserRole(userID);
    const createrRef 			=	await db.doc(Users.collection.name+'/'+userID.toString());
    const uniqueID				=	await getLastInsertedID('media_group_unique_id', 'media_group_unique_id', next);
    const params 				=	req.params;
    const postData 				=	JSON.parse(JSON.stringify(req.body));
    const mediaType 			=	MEDIA_TYPE;
    const type 					=	TYPE;
    const isOnboarding 			=	(parseInt(params.flag) == 1) ? 1 : 0;
    let caption 				=	"";
    let durations 				=	[];
    let mediaDetails			=	[];
    let userAssignIDs 			=	[];
    let tempUserAssignID        =   [];
    let filUserAssignIDs        =	[];
    let filUserAssignRefs       =   [];
    let filTempUserAssignIDs    =   [];
    let savedThumbnailFileNames =	[];
    let tempMediaDetails 		=	[];
    let buildFileNameDetail		=	[];
    let uploadMediaTypes		=	[];
    let isAlreadyShared			=	false;
    let sourceID 				=	0;
    let iCount					=	0;
    let errorMsg 				=	'';
    let fileUploadStatus        =   true;

    //console.log('postData', postData);

    if(postData.caption != undefined && postData.caption != null) {
        caption = postData.caption;
    }
    if(postData.media_details != undefined && postData.media_details != null) {
        mediaDetails = JSON.parse(postData.media_details);
        console.log('mediaDetails', mediaDetails);
    }

    //console.log(postData.user_assign_id,'postData.user_assign_id');
    //console.log(postData.temp_user_assign_id,'postData.temp_user_assign_id');

    if(postData.user_assign_id != undefined && Array.isArray(postData.user_assign_id) && postData.user_assign_id.length != 0) {
        userAssignIDs =  postData.user_assign_id.filter(userID => {  return (userID.trim() !== '' && userID.trim() !== '0');  });
    }
    if(postData.temp_user_assign_id != undefined && Array.isArray(postData.temp_user_assign_id) && postData.temp_user_assign_id.length != 0) {
        tempUserAssignID =  postData.temp_user_assign_id.filter(userID => {  return (userID.trim() !== '' && userID.trim() !== '0');  });
    }
    if(postData.source_id != undefined && postData.source_id != null && postData.source_id != 0 && postData.source_id != '') {
        sourceID = postData.source_id;
    }

    if(typeof mediaDetails != 'object' || mediaDetails.length == 0) {
        console.log('Media Detail is required.');
        return jsonResponse(res, 400, 'error', 'Media Detail is required.');
    }


    if(errorMsg != '') {
        console.log(errorMsg);
        return jsonResponse(res, 400, 'error', errorMsg);
    }
    

    /* if(sourceID != 0) {
        if(sourceID != 0 && userAssignIDs.length == 0) {
            console.log('Assigned user ID required.');
            jsonResponse(res, 400, 'error', 'Assigned user ID required.');
            return;
        } else {
            let checkUserAlreadyShared = await Promise.all(userAssignIDs.map(expressAsyncHandler(async(user_id, index) => {
                return new Promise(async function(resolve, reject){

                    let checkDuplicateStatus = await checkMediaIsDupilicate(sourceID, userID, user_id, next);
                    if(checkDuplicateStatus) {
                        let tempID = userAssignIDs.indexOf(user_id);
                        userAssignIDs.splice(tempID, 1);
                    }
                    resolve(checkDuplicateStatus);

                });
            })));

            isAlreadyShared = (userAssignIDs.length == 0) ? true : false;
        }
    } */
    

    if(isAlreadyShared) {
        console.log('Media is already shared for this users.');
        return jsonResponse(res, 400, 'error', 'Media is already shared for this users.');
    }

    //console.log('userAssignIDs', userAssignIDs);

    for await (const id of userAssignIDs) {
        const checkUserRef      =   await db.collection(Users.collection.name).doc(id.toString());
        const checkUserExists   =  await checkUserRef.get();
        //const checkUserExists   =   await db.collection(Users.collection.name).doc(id.toString()).get();
        if(checkUserExists.exists && !filUserAssignIDs.includes(id)) {
            filUserAssignIDs.push(id);
            filUserAssignRefs.push(checkUserRef);
        }
    }

    //console.log('filUserAssignIDs', filUserAssignIDs);

    //console.log('tempUserAssignID', tempUserAssignID);

    for await (const id of tempUserAssignID) {
        const checkUserExists   =   await db.collection(TemporaryUsers.collection.name).doc(id.toString()).get();
        if(checkUserExists.exists && !filTempUserAssignIDs.includes(id)) {
            filTempUserAssignIDs.push(id);
        }
    }

    //console.log('filUserAssignIDs', filTempUserAssignIDs);

    for await (const md of mediaDetails) {

        if(!md.hasOwnProperty('media_type') || md['media_type'] == '' || md['media_type'] == 0) {
            errorMsg = 'Media Type is missing on media detail.';
        } else if(!md.hasOwnProperty('duration')) {
            errorMsg = 'Duration is missing on media detail.';
        }

    }
    
    for(var i = 0; i < mediaDetails.length; i++) {
        uploadMediaTypes.push(parseInt(mediaDetails[i]['media_type']));
        durations.push(mediaDetails[i]['duration']);
        tempMediaDetails.push({ 'duration': mediaDetails[i]['duration'], 'media_type': parseInt(mediaDetails[i]['media_type']), 'media': '', 'thumbnail': '' });
    }

    //console.log('Thumbnails', resFiles['thumbnail']);
    if(resFiles['thumbnail'] != undefined && resFiles['thumbnail'].length > 0) {

        iCount = 0;
        for await (const  file of resFiles['thumbnail']) {
            let thumbnailFilePath	=	'public/media/'+type[params.type]+'/'+mediaType[mediaDetails[iCount]['media_type']]+'/'+userID+'/thumbnail/';
            let mediaName			=	await getMediaName(next);
            let thumbnailfileName	=	await `${mediaName}${path.extname(file.originalname)}`;
            
            fileUploadStatus =   await generalFileUpload(file, thumbnailFilePath, thumbnailfileName, next);

            if(fileUploadStatus) {
                tempMediaDetails[iCount].thumbnail	=	thumbnailfileName;
                savedThumbnailFileNames.push(thumbnailfileName);

                buildFileNameDetail.push(tempMediaDetails[iCount]);

                iCount = iCount + 1;
            }
            
        }
    } else if(mediaDetails[0]['media_type'] !== undefined && mediaDetails[0]['media_type'] !== '3' && mediaDetails[0]['media_type'] !== 3) {
        console.log('Thumbnail file required.');
        return jsonResponse(res, 400, 'error', 'Thumbnail file required.');
    }

    if(!fileUploadStatus) {
        return jsonResponse(res, 400, 'error', 'Thumbnail file upload failed.');
    }

    //Thumbnail not required for audio.
    /* if(savedThumbnailFileNames.length === 0) {
        return jsonResponse(res, 400, 'error', 'Thumbnail file upload failed.');
    } */

    var tempUserIDs =	filUserAssignIDs.map(Number);

    let mediaData = {
        media_group_unique_id	:	parseInt(uniqueID),
        caption					:	caption,
        durations				:	durations,
        is_onboarding			:	isOnboarding,
        media_types				:	uploadMediaTypes,
        type					:	parseInt(params.type),
        type_for_user			:	parseInt(params.type),
        mission_flag			:	0,
        medias_details 			:	tempMediaDetails,
        medias_thumbnail_names	:	savedThumbnailFileNames,
        user_assign_id		    :	filUserAssignIDs,
        temp_user_assign_id		:   filTempUserAssignIDs,
        source_id				:	parseInt(sourceID),
        is_temporary_media		:	1,
        created_on				: 	await admin.firestore.FieldValue.serverTimestamp(),
        created_by				: 	createrRef,
        reference_ids			: 	[createrRef, ...filUserAssignRefs],
        all_ids					:	[parseInt(userID), ...tempUserIDs],
        status                  :   0
    };

    /* let requestedData = {
        post_data	:	postData,
        params		:	params,
        user_id		:	userID,
        created_on	: 	await admin.firestore.FieldValue.serverTimestamp(),
        created_by	: 	await db.doc(Users.collection.name+'/'+userID.toString())
    }; */

    //let mediaTempID = await insertData(TempMediaGroup, requestedData, 'temp_media_group_id', next);
    let mediaID = await insertData(MediaGroup, mediaData, MediaGroup.fields.media_group_id.key, next);

    //console.log('Media is inserted successully.');
    return jsonResponse(res, 200, 'success', 'Media is inserted successully.', { media_group_id : mediaID });
});

export const uploadMedias = expressAsyncHandler(async function (req, res, err, next) {

    const resFiles = req.files;

    const errorStatus   =   await checkFileError(err);
    if(errorStatus['status']) {
        var updateMedia = await updateMediaUploadResponse(req, 400, errorStatus['message'], next);
        return jsonResponse(res, 400, 'error', errorStatus['message']);
    }
    
    if(resFiles['media'] == undefined) {
        var updateMedia = await updateMediaUploadResponse(req, 400, 'File required.', next);
        return jsonResponse(res, 400, 'error', 'File required.');
    }
    if(resFiles['media'].length == 0) {
        var updateMedia = await updateMediaUploadResponse(req, 400, 'File required.', next);
        return jsonResponse(res, 400, 'error', 'File required.');
    }

    const db 					=	await getDBConnection();
    const userID 				=	await getUserId(req);
    const userRole 				=	await getUserRole(userID);
    const mediaID 				=	await parseInt(req.params.media_id);
    const createrRef 			=	await db.doc(Users.collection.name+'/'+userID.toString());
    const currentTime			=	await admin.firestore.FieldValue.serverTimestamp();
    const incrementID 			=	await admin.firestore.FieldValue.increment(1);
    const collectionIDRef		=	await db.doc(AllCollectionsDocumentID.collection.name+'/1');
    const updateMediaRef		=	await db.doc(MediaGroup.collection.name+'/'+mediaID.toString());
    let missionFlagMediaRef		=	[];


    const mediaGroupRef         =   await updateMediaRef.get();

    if(!mediaGroupRef.exists) {
        return jsonResponse(res, 400, 'error', 'Invalid temporary media ID.');
    }

    const mediaData     =	await { id: mediaGroupRef.id, ... await mediaGroupRef.data() };
    

    if(mediaData[MediaGroup.fields.is_temporary_media.key] != 1 && mediaData['async_media_upload_response_message'] != '') {
        return jsonResponse(res, 400, 'error', 'File already uploaded on this ID.', { media_group_id: mediaID });
    }
    
    if(!mediaData[MediaGroup.fields.all_ids.key].includes(parseInt(userID))) {
        return jsonResponse(res, 400, 'error', 'Access Denied. Request is not initiated by this user.');
    }

    const tempMediaData         =	mediaData;

    var tempParams				=	{
                                        'type'	:	tempMediaData.type,
                                        /* 'media'	:	tempMediaData.media_type, */
                                        'flag'	:	tempMediaData.is_onboarding
                                    };
                                    
    var tempPostData			=	{
                                        'caption'		        :	tempMediaData.caption,
                                        'durations'		        :	tempMediaData.durations,
                                        'user_assign_id'        :	tempMediaData.user_assign_id,
                                        'temp_user_assign_id'   :	tempMediaData.temp_user_assign_id,
                                        'source_id' 	        :	tempMediaData.source_id,
                                        'media_types'	        :	tempMediaData.media_types,
                                        'medias_details'        :	tempMediaData.medias_details
                                    };

    //console.log('tempPostData', tempPostData);

    const params 				=	tempParams;
    const postData 				=	tempPostData;
    let step 					=	params.type.toString();
    let mediaType 				=	MEDIA_TYPE;
    let type 					=	TYPE;
    let savedFileNames 			=	[];
    let savedThumbnailFileNames =	[];
    let mediaGroupID 			=	mediaID;
    let buildFileNameDetail 	=	[];
    let caption 				=	"";
    let durations 				=	[];
    let userAssignIDs 			=	[];
    let tempUserAssignID        =   [];
    let assginUserIDs           =   [];
    let insertedMediaIDs		=	[];
    let mediaFilesArr			=	[];
    let mediaDetails			=	[];
    let uploadMediaTypes		=	[];
    let responseArr				=	[];
    let isAlreadyShared			=	false;
    let sourceID 				=	0;
    let isOnboarding 			=	(parseInt(params.flag) == 1) ? 1 : 0;
    let iCount 					=	0;
    let fileUploadError         =   "";
    let missTimFileUplSt        =   true;
    let missInspFileUplSt       =   true;

    if(postData.caption != undefined && postData.caption != null) {
        caption = postData.caption;
    }
    if(postData.medias_details != undefined && postData.medias_details != null) {
        mediaDetails = postData.medias_details;
    }
    if(postData.user_assign_id != undefined && Array.isArray(postData.user_assign_id) && postData.user_assign_id.length != 0) {
        userAssignIDs =  postData.user_assign_id.filter(userID => {  return userID.trim() !== '';  });
        //console.log(userAssignIDs, 'userAssignIDs');
    }
    if(postData.temp_user_assign_id != undefined && Array.isArray(postData.temp_user_assign_id) && postData.temp_user_assign_id.length != 0) {
        tempUserAssignID =  postData.temp_user_assign_id.filter(userID => {  return userID.trim() !== '';  });
        //console.log(userAssignIDs, 'userAssignIDs');
    }
    if(postData.source_id != undefined && postData.source_id != null && postData.source_id != 0 && postData.source_id != '') {
        sourceID = postData.source_id;
    }

    /* if(sourceID != 0) {
        if(sourceID != 0 && userAssignIDs.length == 0) {
            var updateMedia = await updateMediaUploadResponse(req, 400, 'Assigned user ID required.', next);
            return jsonResponse(res, 400, 'error', 'Assigned user ID required.');
        } else {
            let checkUserAlreadyShared = await Promise.all(userAssignIDs.map(expressAsyncHandler(async(user_id, index) => {
                return new Promise(async function(resolve, reject){

                    let checkDuplicateStatus = await checkMediaIsDupilicate(sourceID, userID, user_id, next);
                    if(checkDuplicateStatus) {
                        let tempID = userAssignIDs.indexOf(user_id);
                        userAssignIDs.splice(tempID, 1);
                    }
                    resolve(checkDuplicateStatus);

                });
            })));

            isAlreadyShared = (userAssignIDs.length == 0) ? true : false;
        }
    } */

    if(isAlreadyShared) {
        var updateMedia = await updateMediaUploadResponse(req, 400, 'Media is already shared for this users.', next);
        return jsonResponse(res, 400, 'error', 'Media is already shared for this users.');
    }

    for await (const id of userAssignIDs) {
        assginUserIDs.push({ 'flag': 1, 'user_type': 'exists', 'id': id });
    }

    for await (const id of tempUserAssignID) {
        assginUserIDs.push({ 'flag': 2, 'user_type': 'temp', 'id': id });
    }

    iCount = 0;

    for await (const  file of resFiles['media']) {

        const fileExtension =   path.extname(file.originalname);

        const setMediaType  =   await new Promise((resolve, reject) => {
            if(CHECK_VIDEO_EXTENSION.includes(fileExtension)) {
                return resolve(1);
            } else if(CHECK_IMAGE_EXTENSION.includes(fileExtension)) {
                return resolve(2);
            } else if(CHECK_AUDIO_EXTENSION.includes(fileExtension)) {
                return resolve(3);
            } else {
                fileUploadError =   "File type not allowed.";
                return resolve(mediaDetails[iCount]['media_type']);
            }
        });

        if(fileUploadError !== "") {
            break;
        }

        let filePath	=	'public/media/'+type[params.type]+'/'+mediaType[setMediaType]+'/'+userID+'/';
        let mediaName	=	await getMediaName(next);
        let fileName	=	await `${mediaName}${fileExtension}`;

        const uploadedFileName  =	await generalFileUpload(file, filePath, fileName, next);

        if(!uploadedFileName) {
            fileUploadError =   "Media file upload failed";
            break;
        }

        //Mission Statment
        if(params.type == "1") {
            let copyOfTimeoutFilePath = 'public/media/'+type["2"]+'/'+mediaType[setMediaType]+'/'+userID+'/';
            let copyOfInspirationFilePath = 'public/media/'+type["3"]+'/'+mediaType[setMediaType]+'/'+userID+'/';  

            missTimFileUplSt		=	await generalFileUpload(file, copyOfTimeoutFilePath, fileName, next);
            missInspFileUplSt       =	await generalFileUpload(file, copyOfInspirationFilePath, fileName, next);
        }

        uploadMediaTypes.push(setMediaType);
        durations.push(mediaDetails[iCount]['duration']);
        savedFileNames.push(fileName);

        var tempThumbnail   =   (tempMediaData[MediaGroup.fields.medias_details.key][iCount]['thumbnail'] !== undefined)
                                ? tempMediaData[MediaGroup.fields.medias_details.key][iCount]['thumbnail']
                                :'';

        if(tempThumbnail !== '') {
            savedThumbnailFileNames.push(tempThumbnail);
        }

        mediaFilesArr.push({'media': fileName, 'media_type': setMediaType,  'thumbnail': tempThumbnail, "duration": mediaDetails[iCount]['duration'] });

        iCount = iCount + 1;

    }

    if(fileUploadError !== "") {
        var updateMedia = await updateMediaUploadResponse(req, 400, fileUploadError, next);
        return jsonResponse(res, 400, 'error', fileUploadError);
    }

    //Deleting old files
    /* const deleteFiles = tempMediaData.medias_details.map(async(media, index) => {
        if(media.thumbnail != '') {
            let file_delete = 'public/media/'+type[params.type]+'/'+mediaType[mediaDetails[index]['media_type']]+'/'+userID+'/thumbnail/'+media.thumbnail;
            let del = await generalDeleteFile(file_delete, next);
        }
    }); */
    
    if(resFiles['thumbnail'] != undefined) {

        iCount = 0;
        //savedThumbnailFileNames =   [];

        for await (const  file of resFiles['thumbnail']) {

            if(mediaFilesArr[iCount]["media_type"] === undefined || mediaFilesArr[iCount]["media_type"] === null || mediaFilesArr[iCount]["media_type"] === '') {
                break;
            }

            if(fileUploadError !== "") {
                break;
            }

            const setMediaType  =   (mediaFilesArr[iCount]["media_type"] !== undefined)
                                        ?   mediaFilesArr[iCount]["media_type"]
                                        :   mediaType[mediaDetails[iCount]['media_type']];

            let thumbnailFilePath	=	'public/media/'+type[params.type]+'/'+mediaType[setMediaType]+'/'+userID+'/thumbnail/';
            let mediaName			=	await getMediaName(next);
            let thumbnailfileName	=	await `${mediaName}${path.extname(file.originalname)}`;

            const uploadedthumbnailFileName	=	await generalFileUpload(file, thumbnailFilePath, thumbnailfileName, next);

            if(!uploadedthumbnailFileName) {
                fileUploadError =   "Thumbnail file upload failed.";
                break;
            }

            mediaFilesArr[iCount]['thumbnail'] = thumbnailfileName;
            savedThumbnailFileNames.push(thumbnailfileName);
            
            if(params.type == "1") {
                var copyOfThumbnailTimeoutFilePath	= 'public/media/'+type["2"]+'/'+mediaType[setMediaType]+'/'+userID+'/thumbnail/';
                var copyOfThumbnailInspirationFilePath	= 'public/media/'+type["3"]+'/'+mediaType[setMediaType]+'/'+userID+'/thumbnail/';

                missTimFileUplSt        =   await generalFileUpload(file, copyOfThumbnailTimeoutFilePath, thumbnailfileName, next);
                missInspFileUplSt       =   await generalFileUpload(file, copyOfThumbnailInspirationFilePath, thumbnailfileName, next);
            }

            //buildFileNameDetail.push(mediaFilesArr[iCount]);

            iCount = iCount + 1;
        }
    }

    if(fileUploadError !== "") {
        var updateMedia = await updateMediaUploadResponse(req, 400, fileUploadError, next);
        return jsonResponse(res, 400, 'error', fileUploadError);
    }

    if(!missTimFileUplSt) {
        var updateMedia = await updateMediaUploadResponse(req, 400, "Goal media upload failed.", next);
        return jsonResponse(res, 400, 'error', "Goal media upload failed.");
    }

    if(!missInspFileUplSt) {
        var updateMedia = await updateMediaUploadResponse(req, 400, "Goal media upload failed.", next);
        return jsonResponse(res, 400, 'error', "Goal media upload failed.");
    }
    
    buildFileNameDetail = mediaFilesArr;

    //Start: Build Media Group data
    let mediaGroupData = {
        [MediaGroup.fields.caption.key]					:	caption,
        /* [MediaGroup.fields.media_type.key]				:	parseInt(params.media), */
        [MediaGroup.fields.media_types.key]				:	uploadMediaTypes,
        [MediaGroup.fields.medias_names.key]			:	savedFileNames,
        [MediaGroup.fields.medias_thumbnail_names.key]	:	savedThumbnailFileNames,
        [MediaGroup.fields.mission_flag.key]			:	0,
        [MediaGroup.fields.is_onboarding.key]			:	isOnboarding,
        [MediaGroup.fields.durations.key]				:	durations,
        [MediaGroup.fields.medias_details.key]			:	buildFileNameDetail,
        [MediaGroup.fields.source_id.key]				:	sourceID,
        [MediaGroup.fields.is_temporary_media.key]		:	0,
        [MediaGroup.fields.type.key]					:	parseInt(params.type),
        [MediaGroup.fields.type_for_user.key]			:	parseInt(params.type),
        [MediaGroup.fields.modified_on.key]				:	currentTime,
        [MediaGroup.fields.modified_by.key]				:	createrRef,
        [MediaGroup.fields.status.key]				    :	1
    };
    //End: Build Media Group data

    /* mediaGroupData['assigned_to_ids']		=	[]; */


    const allCollectionIDs		=	await collectionIDRef.get();

    if(!allCollectionIDs.exists) {
        return jsonResponse(res, 400, 'error', 'Something went wrong. Cannot get IDs.');
    }

    const allColIDs		=	await allCollectionIDs.data();

    if(allColIDs[MediaGroup.fields.media_group_id.key] == undefined) {
        return jsonResponse(res, 400, 'error', 'Something went wrong. Add media ID on the collection.');
    }

    console.log('userAssignIDs', assginUserIDs);


    var activityType	=	'add_media';
    if(assginUserIDs.length > 0) {
        activityType	=	'assign_media';
    } else if(parseInt(params.flag) == 1) {
        activityType	=	'add_onborading_media';
    }

    mediaGroupData['reference_ids']		=	[createrRef];
    mediaGroupData['all_ids'] 			=	[parseInt(userID)];

    if(assginUserIDs.length != 0) {
        
        var counter 		=	0;

        console.log('Before', assginUserIDs);

        var tempAssignedIds = [...assginUserIDs];

        console.log('After', assginUserIDs);

        const collectionName        =   (tempAssignedIds[0]['user_type'] === 'exists')
                                            ? Users.collection.name
                                            : TemporaryUsers.collection.name;

        const firstAssignedUserRef	=	await db.collection(collectionName).doc(tempAssignedIds[0]['id'].toString());

        const firstAssingedUserID	=	parseInt(tempAssignedIds[0]['id']);

        mediaGroupData['reference_ids'].push(firstAssignedUserRef);

        if(tempAssignedIds[0]['user_type'] === 'exists') {
            mediaGroupData['all_ids'].push(firstAssingedUserID);
        }
        
        /* mediaGroupData['assigned_to_ids']	=	[firstAssignedUserRef]; */

        mediaGroupData['assigned_user_id']	=	firstAssingedUserID;
        mediaGroupData['assigned_user_ref']	=	firstAssignedUserRef;

        mediaGroupID = await updateData(MediaGroup.collection.name, mediaGroupData, mediaID, next);

        insertedMediaIDs.push(parseInt(mediaGroupID));
        
        if(parseInt(params.type) != 2 && tempAssignedIds[0]['user_type'] === 'exists') {
            var activity = await addActivity('assign_media', userID, firstAssingedUserID, mediaGroupID, MediaGroup.collection.name, {'type': parseInt(params.type), 'type_for_user': parseInt(params.type), 'media': uploadMediaTypes});
        } else if(parseInt(params.type) != 2) {
            var activity = await addActivity('assign_media_for_temp_user', userID, firstAssingedUserID, mediaGroupID, MediaGroup.collection.name, {'type': parseInt(params.type), 'type_for_user': parseInt(params.type), 'media': uploadMediaTypes});
        }

        await tempAssignedIds.shift();

        mediaGroupData['created_on']	=	currentTime;
        mediaGroupData['created_by']	=	createrRef;

        for await (const userIDInfo of tempAssignedIds) {

            console.log('Counter ', counter);

            const collectionType        =   (userIDInfo['user_type'] === 'exists')
                                                ? Users.collection.name
                                                : TemporaryUsers.collection.name;

            const assingedUserRef		= 	await db.collection(collectionType).doc(userIDInfo['id'].toString());
            
            mediaGroupData['assigned_user_id']	=	parseInt(userIDInfo['id']);
            mediaGroupData['assigned_user_ref']	=	assingedUserRef;

            /* mediaGroupData['assigned_to_ids'].push(assingedUserRef); */
            mediaGroupData['reference_ids'] = [createrRef, assingedUserRef];

            if(userIDInfo['user_type'] === 'exists') {
                mediaGroupData['all_ids'] = [parseInt(userID), parseInt(userIDInfo['id'])];
            } else {
                mediaGroupData['all_ids'] = [parseInt(userID)];
            }

            var insertedID = await insertData(MediaGroup, {...mediaGroupData}, MediaGroup.fields.media_group_id.key, next);

            insertedMediaIDs.push(parseInt(insertedID));

            if(parseInt(params.type) != 2 && userIDInfo['user_type'] === 'exists') {
                var activity = await addActivity('assign_media', userID, userIDInfo['id'], insertedID, MediaGroup.collection.name, {'type': parseInt(params.type), 'type_for_user': parseInt(params.type), 'media': uploadMediaTypes});
            } else if(parseInt(params.type) != 2) {
                var activity = await addActivity('assign_media_for_temp_user', userID, userIDInfo['id'], insertedID, MediaGroup.collection.name, {'type': parseInt(params.type), 'type_for_user': parseInt(params.type), 'media': uploadMediaTypes});
            }

            console.log('Inserted ID', insertedID);

            counter = counter + 1;

        }

        console.log('After All', assginUserIDs);

        console.log('All completed');

    } else {

        mediaGroupID = await updateData(MediaGroup.collection.name, mediaGroupData, mediaID, next);
        insertedMediaIDs.push(parseInt(mediaGroupID));
        var activity = await addActivity(activityType, userID, 0, mediaGroupID, MediaGroup.collection.name, {'type': parseInt(params.type), 'type_for_user': parseInt(params.type), 'media': uploadMediaTypes});
    }

    //mediaGroupID = await insertData(MediaGroup, mediaGroupData, MediaGroup.fields.media_group_id.key, next);
    //mediaGroupID = await updateData(MediaGroup.collection.name, mediaGroupData, mediaID, next);

    //Its for mission upload copy on both timeout and inspiration
    if(params.type == "1") {
        let copyOfTimeoutBuildFileNameDetail = [];
        let copyOfInspirationBuildFileNameDetail = [];
        copyOfTimeoutBuildFileNameDetail = buildFileNameDetail.map((value) => value);
        copyOfInspirationBuildFileNameDetail = buildFileNameDetail.map((value) => value);
        let copyTimeoutMediaGroupData = {};
        let copyInspirationMediaGroupData = {};
        Object.assign(copyTimeoutMediaGroupData, mediaGroupData);
        Object.assign(copyInspirationMediaGroupData, mediaGroupData);
        copyTimeoutMediaGroupData[MediaGroup.fields.type.key] = 2;
        copyInspirationMediaGroupData[MediaGroup.fields.type.key] = 3;
        copyTimeoutMediaGroupData[MediaGroup.fields.type_for_user.key] = 2;
        copyInspirationMediaGroupData[MediaGroup.fields.type_for_user.key] = 3;
        /* delete copyTimeoutMediaGroupData[MediaGroup.fields.medias_ref.key];
        delete copyInspirationMediaGroupData[MediaGroup.fields.medias_ref.key]; */

        //Is onboarding value must be only for onboarding medias, not for mission copy files
        copyInspirationMediaGroupData[MediaGroup.fields.is_onboarding.key] = 0;
        copyTimeoutMediaGroupData[MediaGroup.fields.is_onboarding.key] = 0;
        

        copyTimeoutMediaGroupData[MediaGroup.fields.mission_flag.key] = 1;
        copyTimeoutMediaGroupData[MediaGroup.fields.created_by.key] = await db.doc(Users.collection.name+'/'+userID.toString());
        copyTimeoutMediaGroupData[MediaGroup.fields.created_on.key] = await admin.firestore.FieldValue.serverTimestamp();
        copyTimeoutMediaGroupData[MediaGroup.fields.modified_by.key] = null;
        copyTimeoutMediaGroupData[MediaGroup.fields.modified_on.key] = null;


        if(missTimFileUplSt) {

            const mtmediaGroupID = await insertData(MediaGroup, copyTimeoutMediaGroupData, MediaGroup.fields.media_group_id.key, next);
            missionFlagMediaRef.push(parseInt(mtmediaGroupID));

        }

        

        

        copyInspirationMediaGroupData[MediaGroup.fields.mission_flag.key] = 1;

        copyInspirationMediaGroupData[MediaGroup.fields.mission_flag.key] = 1;
        copyInspirationMediaGroupData[MediaGroup.fields.created_by.key] = await db.doc(Users.collection.name+'/'+userID.toString());
        copyInspirationMediaGroupData[MediaGroup.fields.created_on.key] = await admin.firestore.FieldValue.serverTimestamp();
        copyInspirationMediaGroupData[MediaGroup.fields.modified_by.key] = null;
        copyInspirationMediaGroupData[MediaGroup.fields.modified_on.key] = null;

        if(missInspFileUplSt) {

            const mimediaGroupID    =   await insertData(MediaGroup, copyInspirationMediaGroupData, MediaGroup.fields.media_group_id.key, next);
            missionFlagMediaRef.push(parseInt(mimediaGroupID));

        }

        
    }

    //End: Build Media Group data

    //Replacement and other activity
    let userDetails   = 	await getCollectionDataWithDocID(Users.collection.name, userID, next);

    let dataObj = {};
    dataObj[Users.fields.steps.key] = userDetails[0]['steps'];
    
    if(params.flag == "1" || params.type == "1") {
        
        let tempUserDetails		=	userDetails[0];

        if(params.type == "1") {

            let isMediaUploaded         =   tempUserDetails['steps']['1']['media_group_ref'];
            let missionFlagMediasIDs    =   tempUserDetails['steps']['1']['mission_flag_medias_ids'];
            //let isMediaUploaded       =   tempUserDetails[Users.fields.steps.key][params.type.toString()][Users.fields.steps.values[params.type.toString()].media_group_ref.key];


            if(isMediaUploaded != undefined && isMediaUploaded != null) {

                if(missionFlagMediasIDs.length > 0) {
                    const batch = await db.batch();

                    let updateMissionFlag = await Promise.all(missionFlagMediasIDs.map(expressAsyncHandler(async(mediaID, index) => {
                        return new Promise(async function(resolve, reject){

                            var isExists = await checkIsDocExists(MediaGroup.collection.name, mediaID.toString());

                            if(isExists) {
                                var updateMediaGroupdataObj = {
                                    [MediaGroup.fields.mission_flag.key]: 0,
                                    [MediaGroup.fields.modified_on.key]: await admin.firestore.FieldValue.serverTimestamp()
                                };
                                var updateQuery = await db.collection(MediaGroup.collection.name).doc(mediaID.toString());
                                await batch.update(updateQuery, updateMediaGroupdataObj);
                                resolve(true);
                            } else {
                                resolve(true);
                            }
                        });
                    })));

                    await batch.commit();
                }

                let deleteAllFiles = await deleteMediaFiles(isMediaUploaded, userID, userRole);

            }


            dataObj[Users.fields.steps.key][step][Users.fields.steps.values[step].media_group_ref.key]			=	await db.doc(MediaGroup.collection.name+'/'+mediaGroupID.toString());

            dataObj[Users.fields.steps.key][step][Users.fields.steps.values[step].is_media_uploaded.key]		=	1;

            dataObj[Users.fields.steps.key][step][Users.fields.steps.values[step].mission_flag_medias_ids.key]	=	await admin.firestore.FieldValue.arrayUnion(...missionFlagMediaRef)

            /* dataObj[Users.fields.steps.key][step] = {
                [Users.fields.steps.values[step].media_group_ref.key]: await db.doc(MediaGroup.collection.name+'/'+mediaGroupID.toString()),
                [Users.fields.steps.values[step].is_media_uploaded.key]: 1,
                [Users.fields.steps.values[step].mission_flag_medias_ids.key]: await admin.firestore.FieldValue.arrayUnion(...missionFlagMediaRef)
            }; */
            dataObj[Users.fields.modified_on.key] = await admin.firestore.FieldValue.serverTimestamp();

            console.log('dataObj', dataObj);

            let updatedID = await updateData(Users.collection.name, dataObj, userID, next);

        } else {

            var isMediaUploaded = tempUserDetails['steps'][step]['media_group_ref'];

            if(isMediaUploaded != undefined && isMediaUploaded != null) {
                var deleteUploadedMedia = await deleteMediaFiles(isMediaUploaded, userID, userRole);
            }

            dataObj[Users.fields.steps.key][step][Users.fields.steps.values[step].media_group_ref.key]		=	await db.doc(MediaGroup.collection.name+'/'+mediaGroupID.toString());

            dataObj[Users.fields.steps.key][step][Users.fields.steps.values[step].is_media_uploaded.key]	=	1;

            /* dataObj[Users.fields.steps.key][step] = {
                [Users.fields.steps.values[step].media_group_ref.key]: await db.doc(MediaGroup.collection.name+'/'+mediaGroupID.toString()),
                [Users.fields.steps.values[step].is_media_uploaded.key]: 1
            }; */
            dataObj[Users.fields.modified_on.key] = await admin.firestore.FieldValue.serverTimestamp();

            console.log('dataObj', dataObj);

            var updatedID = await updateData(Users.collection.name, dataObj, userID, next);

        }
    } else {
        if(userAssignIDs != undefined && userAssignIDs != null && userAssignIDs.length > 0) {
            
            if(parseInt(params.type) != 2) {

                let pushNotification = await addNotification("assign_media", userID, [...userAssignIDs], mediaGroupID, MediaGroup.collection.name, {'type': parseInt(params.type), 'type_for_user': parseInt(params.type), 'media': uploadMediaTypes});
            }
        }
    }

    //Its only for response message
    iCount = 0;
    for await (const  fileDetail of buildFileNameDetail) {
        var tempFileObj			=	{};
        var tempMediaDetails	= 	{
                                        'type'			:	type[params.type],
                                        'media_type'	:	mediaType[fileDetail["media_type"]],
                                        'user_id'		:	userID,
                                        'media_name'	:	''
                                    };
        tempMediaDetails['media_name']		=	fileDetail["media"];
        tempFileObj['file_path']			=	await getMediaBaseURL('medias', req.hostname, tempMediaDetails, next);
        tempFileObj['file_extension_type']	=	path.extname(fileDetail.media).toLowerCase().substr(1);

        if(fileDetail.thumbnail != undefined && fileDetail.thumbnail != '') {
            tempMediaDetails['media_name']	=	fileDetail.thumbnail;
            tempFileObj['thumbnail_path']	=	await getMediaBaseURL('media_thumbnails', req.hostname, tempMediaDetails, next);
        } else {
            tempFileObj['thumbnail_path']	=	"";
        }

        tempFileObj['duration']		=	fileDetail["duration"];
        tempFileObj['media_type']	=	fileDetail["media_type"];
        
        responseArr.push(tempFileObj);

    }

    var updateMedia = await updateMediaUploadResponse(req, 200, 'Media file uploaded successfully.', next);

    var updateTime 	= await moveMediaFromTimeoutToInspiration(db, mediaGroupID, userID, userRole, params, userAssignIDs, next);
    
    jsonResponse(res, 200, 'success', 'Media file uploaded successfully.', { updateMedia: updateMedia, updateTime: updateTime, media_details: responseArr, media_group_id: mediaGroupID, insertedMediaIDs: insertedMediaIDs});
    
});

export const uploadProfile = expressAsyncHandler(async function (req, res, err, next) {

    const errorStatus   =   await checkFileError(err);

    if(errorStatus['status']) {
        return jsonResponse(res, 400, 'error', errorStatus['message']);
    }

    const db            =   await getDBConnection();
    const userID        =   await getUserId(req);
    const userDetails   =   JSON.parse(JSON.stringify(req.body));

    let error_msg       =   '';
    let response        =   {};
    let dobTimestamp    =   null;
    let fileUploadStatus    =   true;

    if(!userDetails.hasOwnProperty('dob')) {
        error_msg = 'DOB required';
    }
    if(!userDetails.hasOwnProperty('email')) {
        error_msg = 'Email required';
    }
    if(!userDetails.hasOwnProperty('last_name')) {
        error_msg = 'Last name required';
    }
    if(!userDetails.hasOwnProperty('first_name')) {
        error_msg = 'First name required';
    }
    if(userDetails.hasOwnProperty('first_name') && userDetails.first_name == '') {
        error_msg = 'First name should not be empty';
    }

    /* var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    if(userDetails.hasOwnProperty('email') && userDetails.email != '' && !userDetails.email.match(validRegex)) {
        error_msg = 'Invalid email.';
    } */
    if(userDetails.hasOwnProperty('dob') && userDetails.dob != '') {
        let dob = userDetails.dob;
        let dobArr = dob.split("/");
        dobTimestamp = admin.firestore.Timestamp.fromDate(new Date(parseInt(dobArr[2]), (parseInt(dobArr[1] - 1)), parseInt(dobArr[0])));
    }

    if(error_msg != '') {
        return res.status(400).json({
            status: 'error',
            message: error_msg
        });
    }

    let updateDataObj = {
        [Users.fields.first_name.key]: userDetails.first_name,
        [Users.fields.last_name.key]: userDetails.last_name,
        [Users.fields.dob.key]: dobTimestamp,
        [Users.fields.email.key]: userDetails.email,
        [Users.fields.modified_on.key]:  await admin.firestore.FieldValue.serverTimestamp()
    };

    const isProfileExists   =   await getCollectionDataWithDocID(Users.collection.name, userID, next);
    const profileRef        =   isProfileExists[0][Users.fields.profile_image.key];

    if(req.file != undefined) {
        const filePath      =   'public/profile/'+userID+'/';
        const mediaName     =   await getMediaName(next);
        const fileName      =   await `${mediaName}${path.extname(req.file.originalname)}`;

        fileUploadStatus    =   await generalFileUpload(req.file, filePath, fileName, next);
        response['url']     =   await getMediaBaseURL('profile', req.hostname, { 'profile_image': fileName, 'user_id': userID }, next);

        updateDataObj[Users.fields.profile_image.key]   =   fileName;

        if(isProfileExists.length > 0 && profileRef != "") {
            const file_delete   =   'public/profile/'+userID+'/'+profileRef;
            const delStatus     =   await generalDeleteFile(file_delete, next);
        }
    }

    if(!fileUploadStatus) {
        return jsonResponse(res, 200, 'success', 'Profile image upload failed.', response);
    }

    const updatedID =   await updateData(Users.collection.name, updateDataObj, parseInt(userID), next);

    response['id']      =   parseInt(userID);
    response['data']    =   updateDataObj;

    if(response['data'].dob != null && response['data'].dob != "") {
        
        var dob                 =   new Date(response['data'].dob.toDate());
        response['data'].dob    =   dob.getDate()+'/'+(dob.getMonth() + 1)+'/'+dob.getFullYear();
        response['data'].dob    =   response['data'].dob.toString();

    }

    if(response['data'].profile_image != null && response['data'].profile_image != "") {

        response['data'].profile_image  =   response['url'];
        delete response['url'];

    } else if(profileRef != null && profileRef != "") {

        response['data']['profile_image']   =   await getMediaBaseURL('profile', req.hostname, { 'profile_image': profileRef, 'user_id': userID }, next);

    }
    response['data']['id']              =   response['id'];
    response['data']['mobile_number']   =   isProfileExists[0][Users.fields.mobile_number.key].toString();
    response['data']['country_code']    =   isProfileExists[0][Users.fields.country_code.key];
    response['data']['created_on']      =   isProfileExists[0][Users.fields.created_on.key].toDate();
    response['user_profile']            =   response['data'];

    delete response['id'];
    delete response['data'];

    jsonResponse(res, 200, 'success', 'User updated successfully.', response);

});

export const uploadInviteNewUser = expressAsyncHandler(async function (req, res, err, next) {

    const errorStatus   =   await checkFileError(err);

    if(errorStatus['status']) {
        return jsonResponse(res, 400, 'error', errorStatus['message']);
    }

    const db            =   await getDBConnection();
    const userID        =   await getUserId(req);
    const userRole      =   await getUserRole(userID);
    const userDetails   =   JSON.parse(JSON.stringify(req.body));
    const sessionRef    =   await db.collection(Users.collection.name).doc(userID);
    const currentTime   =   await admin.firestore.FieldValue.serverTimestamp();
    const inviteCode    =   await generateInviteCode(userDetails.first_name, userID, next);
    let dobTimestamp    =   null;
    let fileUploadStatus=   true;

    const sessionUserRefKey =   (userRole == 1)
                                    ? InviteHelpinghand.fields.user_reference.key
                                    : InviteHelpinghand.fields.helpinghand_reference.key;

    const linkedUserRefKey  =   (userRole != 1)
                                    ? InviteHelpinghand.fields.user_reference.key
                                    : InviteHelpinghand.fields.helpinghand_reference.key;

    const tempUserRefkey    =   (userRole == 1)
                                    ? InviteHelpinghand.fields.temporary_helpinghand_user_id.key
                                    : InviteHelpinghand.fields.temporary_user_id.key;

    const tempUserRole      =   (userRole == 1) ? 2 : 1;

    /* if(userRole == 1) {
        return jsonResponse(res, 400, 'error', 'Access Denied.');
    } */

    const inviteRef     =   await db.collection(InviteHelpinghand.collection.name)
                                    .where(InviteHelpinghand.fields.is_resigned.key, '==', 0)
                                    .where(InviteHelpinghand.fields.helpinghand_reference.key, '==', sessionRef)
                                    .get();

    if(inviteRef.size >= MAXIMUM_SUPPORTING_COUNT) {
        return jsonResponse(res, 400, 'error', 'You reached maximum supporting users.');
    }

    if(userDetails.hasOwnProperty('dob') && userDetails.dob != '') {
        let dob         =   userDetails.dob;
        let dobArr      =   dob.split("/");
        dobTimestamp    =   await admin.firestore.Timestamp.fromDate(new Date(parseInt(dobArr[2]), (parseInt(dobArr[1] - 1)), parseInt(dobArr[0])));
    }

    const userRef   =   await db.collection(Users.collection.name)
                                .where(Users.fields.mobile_number.key, '==', userDetails.mobile_number)
                                .where(Users.fields.user_role.key, '==', 1)
                                .where(Users.fields.status.key, '==', 1)
                                .limit(1)
                                .get();

    /* if(userRef.size > 0) {
        return jsonResponse(res, 400, 'error', 'Mobile number already exists.');
    } */

    if(userRef.size == 0) {
        
        let insertDataObj   =   {
            [TemporaryUsers.fields.user_role.key]                :   tempUserRole,
            [TemporaryUsers.fields.invite_code.key]              :   inviteCode,
            [TemporaryUsers.fields.first_name.key]               :   userDetails.first_name,
            [TemporaryUsers.fields.last_name.key]                :   (userDetails.last_name != undefined) ? userDetails.last_name : '',
            [TemporaryUsers.fields.email.key]                    :   userDetails.email,
            [TemporaryUsers.fields.dob.key]                      :   dobTimestamp,
            [TemporaryUsers.fields.mobile_number.key]            :   userDetails.mobile_number,
            [TemporaryUsers.fields.refered_user_reference.key]   :   sessionRef,
            [TemporaryUsers.fields.created_by.key]               :   sessionRef,
            [TemporaryUsers.fields.created_on.key]               :   currentTime
        };
    
        const tempUserID    =   await insertData(
                                    TemporaryUsers,
                                    insertDataObj,
                                    TemporaryUsers.fields.temporary_users_id.key, next
                                );

        if(req.file != undefined) {
            const filePath      =   'public/temp_user/profile/'+tempUserID+'/';
            const mediaName     =	await getMediaName(next);
            const fileName      =	await `${mediaName}${path.extname(req.file.originalname)}`;
            fileUploadStatus    =   await generalFileUpload(req.file, filePath, fileName, next);
    
            //insertDataObj[TemporaryUsers.fields.profile_image.key]   =   fileName;
            const updateTempUserData    =   {
                [TemporaryUsers.fields.profile_image.key]   :   fileName,
                [TemporaryUsers.fields.modified_by.key]     :   sessionRef,
                [TemporaryUsers.fields.modified_on.key]     :   currentTime,
            }

            const updateID  =   await updateData(TemporaryUsers.collection.name, updateTempUserData, tempUserID, next);
        }
    
        const tempUserRef   =   await db.collection(TemporaryUsers.collection.name).doc(tempUserID.toString());
    
        const inviteDataObj =   {
            [InviteHelpinghand.fields.invite_code.key]                  :   inviteCode,
            [sessionUserRefKey]                                         :   sessionRef,
            [tempUserRefkey]                                            :   tempUserRef,
            [InviteHelpinghand.fields.status.key]                       :   0,
            [InviteHelpinghand.fields.created_by.key]                   :   sessionRef,
            [InviteHelpinghand.fields.created_on.key]                   :   currentTime,
            'all_ids'                                                   :   await admin.firestore.FieldValue.arrayUnion(parseInt(userID))
        };
    
        const insertedInviteID = await insertData(InviteHelpinghand, inviteDataObj, InviteHelpinghand.fields.invite_helpinghand_id.key, next);

        const activity  =   await addActivity('invite_new_user', userID, tempUserID, 0, '', {});

        return jsonResponse(res, 200, 'success', 'New user invited successfully.', { invite_helpinghand_id: insertedInviteID, invite_code: inviteCode });

    } else {

        let userRefID  =   {};

        for await (const [index, user] of userRef.docs.entries()) {
            userRefID   =   user.id;
        }

        const userIDRef     =   await db.doc(Users.collection.name+'/'+userRefID.toString());

        const inviteDataObj =   {
            [InviteHelpinghand.fields.invite_code.key]                  :   inviteCode,
            [InviteHelpinghand.fields.helpinghand_reference.key]        :   sessionRef,
            [InviteHelpinghand.fields.user_reference.key]               :   userIDRef,
            [InviteHelpinghand.fields.status.key]                       :   0,
            [InviteHelpinghand.fields.created_by.key]                   :   sessionRef,
            [InviteHelpinghand.fields.created_on.key]                   :   currentTime,
            'all_ids'                                                   :   await admin.firestore.FieldValue.arrayUnion(parseInt(userID), parseInt(userRefID))
        };

        const insertedInviteID = await insertData(InviteHelpinghand, inviteDataObj, InviteHelpinghand.fields.invite_helpinghand_id.key, next);

        //Start: Activity log
        const activity      =   await addActivity('invite_new_user', userID, userRefID, 0, '', {});
        //End: Activity log

        return jsonResponse(res, 200, 'success', 'Invited successfully.', {invite_helpinghand_id: insertedInviteID, invite_code: inviteCode});

    }
});

export const editInviteNewUser = expressAsyncHandler(async function (req, res, err, next) {

    const errorStatus   =   await checkFileError(err);

    if(errorStatus['status']) {
        return jsonResponse(res, 400, 'error', errorStatus['message']);
    }

    const db            =   await getDBConnection();
    const userID        =   await getUserId(req);
    const userRole      =   await getUserRole(userID);
    const userDetails   =   JSON.parse(JSON.stringify(req.body));
    const sessionRef    =   await db.collection(Users.collection.name).doc(userID);
    const currentTime   =   await admin.firestore.FieldValue.serverTimestamp();
    const inviteCode    =   await generateInviteCode(userDetails.first_name, userID, next);
    let dobTimestamp    =   null;
    let profileImage    =   '';

    if(!userDetails.hasOwnProperty('id') || userDetails['id'] == '') {
        return jsonResponse(res, 400, 'error', 'Temporary User ID required.');
    }

    if(userDetails.hasOwnProperty('dob') && userDetails.dob != '') {
        let dob = userDetails.dob;
        let dobArr = dob.split("/");
        dobTimestamp = admin.firestore.Timestamp.fromDate(new Date(parseInt(dobArr[2]), (parseInt(dobArr[1] - 1)), parseInt(dobArr[0])));
    }

    const tempUserRef           =   await db.collection(TemporaryUsers.collection.name).doc(userDetails['id'].toString());

    const tempUserDetailRef     =   await tempUserRef.get();

    if(!tempUserDetailRef.exists) {
        return jsonResponse(res, 400, 'error', 'Invalid Temporary User ID.');
    }

    const tempUserDetials   =   await { id: tempUserDetailRef.id, ... await tempUserDetailRef.data() };

    const inviteRef         =   await db.collection(InviteHelpinghand.collection.name)
                                        .where(InviteHelpinghand.fields.helpinghand_reference.key, '==', sessionRef)
                                        .where(InviteHelpinghand.fields.temporary_user_id.key, '==', tempUserRef)
                                        .get();

    if(inviteRef.empty) {
        return jsonResponse(res, 400, 'error', 'Access Denied.');
    }

    let updateDataObj   =   {
        /* [TemporaryUsers.fields.user_role.key]                :   1,
        [TemporaryUsers.fields.invite_code.key]              :   inviteCode, */
        [TemporaryUsers.fields.first_name.key]               :   userDetails.first_name,
        [TemporaryUsers.fields.last_name.key]                :   (userDetails.last_name != undefined) ? userDetails.last_name : '',
        [TemporaryUsers.fields.email.key]                    :   userDetails.email,
        [TemporaryUsers.fields.dob.key]                      :   dobTimestamp,
        [TemporaryUsers.fields.mobile_number.key]            :   userDetails.mobile_number,
        /* [TemporaryUsers.fields.refered_user_reference.key]   :   sessionRef, */
        [TemporaryUsers.fields.modified_by.key]              :   sessionRef,
        [TemporaryUsers.fields.modified_on.key]              :   currentTime
    };

    if(req.file != undefined) {

        const filePath      =   'public/temp_user/profile/'+tempUserDetials['id']+'/';
        const mediaName     =	await getMediaName(next);
        const fileName      =	await `${mediaName}${path.extname(req.file.originalname)}`;

        if(tempUserDetials[TemporaryUsers.fields.profile_image.key] != '') {
            const file_delete   =   'public/temp_user/profile/'+tempUserDetials['id']+'/'+tempUserDetials[TemporaryUsers.fields.profile_image.key];
            const delStatus     =   await generalDeleteFile(file_delete, next);
            if(delStatus) {
                const profileStatus =   await generalFileUpload(req.file, filePath, fileName, next);
                updateDataObj[TemporaryUsers.fields.profile_image.key]  =   fileName;
            }
        } else {
            const profileStatus =   await generalFileUpload(req.file, filePath, fileName, next);
            updateDataObj[TemporaryUsers.fields.profile_image.key]  =   fileName;
        }

        profileImage  =   await getMediaBaseURL('temp_profile', req.hostname, { 'user_id': tempUserDetials['id'], 'profile_image': fileName }, next);

    } else if(tempUserDetials[TemporaryUsers.fields.profile_image.key] != '') {
        profileImage  =   await getMediaBaseURL('temp_profile', req.hostname, { 'user_id': tempUserDetials['id'], 'profile_image': tempUserDetials[TemporaryUsers.fields.profile_image.key] }, next);
    }

    const updateID  =   await updateData(TemporaryUsers.collection.name, updateDataObj, tempUserDetials['id'], next);

    return jsonResponse(res, 200, 'success', 'Temporary user updated successfully.', { profileImage: profileImage });

});

export const uploadMusicFiles = expressAsyncHandler(async function (req, res, err, next) {

    const resFiles  =   req.files;

    const errorStatus   =   await checkFileError(err);

    if(errorStatus['status']) {
        return jsonResponse(res, 400, 'error', errorStatus['message']);
    }

    if(resFiles['music'].length == 0) {
        return jsonResponse(res, 400, 'error', 'File required.');
    }
    
    const db            =   await getDBConnection();
    const userID        =   await getUserId(req);
    let musicPostData   =   JSON.parse(JSON.stringify(req.body));

    let buildMusicFileNameDetail    =   [];
    let buildUrls                   =   [];
    let error_msg                   =   "";

    if(!musicPostData.hasOwnProperty('title')) {
        error_msg = 'Title required';
    } else if(musicPostData.title == "") {
        error_msg = 'Title should not be empty';
    }
    if(!musicPostData.hasOwnProperty('album_name')) {
        musicPostData['album_name'] = "";
    }

    if(error_msg != "") {
        return jsonResponse(res, 400, 'error', error_msg);
    }

    let musicFilesArr = await Promise.all(resFiles['music'].map(expressAsyncHandler(async(file, index) => {
        return new Promise(async function(resolve, reject){
            const filePath  =   'public/music/';
            const mediaName =   await getMediaName(next);
            const fileName  =   await `${mediaName}${path.extname(file.originalname)}`;

            const musicStatus   =   await generalFileUpload(file, filePath, fileName, next);

            resolve({'music': fileName, 'thumbnail': ""});
        });
    })));

    if(resFiles['thumbnail'] != undefined) {
        buildMusicFileNameDetail = await Promise.all(resFiles['thumbnail'].map(expressAsyncHandler(async(file, index) => {
            return new Promise(async function(resolve, reject){
                const thumbnailFilePath         =   'public/music/thumbnail/';
                const mediaName                 =   await getMediaName(next);
                const thumbnailfileName         =   await `${mediaName}${path.extname(file.originalname)}`;

                const uploadedthumbnailFileName =   await generalFileUpload(file, thumbnailFilePath, thumbnailfileName, next);

                musicFilesArr[index]['thumbnail'] = thumbnailfileName;

                resolve(musicFilesArr[index]);
            });
        })));
    } else {
        buildMusicFileNameDetail = musicFilesArr;
    }

    let dataArr = await Promise.all(buildMusicFileNameDetail.map(expressAsyncHandler(async(file, index) => {
        return new Promise(async function(resolve, reject){

            let tempDataObj = {
                    [Music.fields.title.key]: musicPostData.title,
                    [Music.fields.album_name.key]: musicPostData.album_name,
                    [Music.fields.audio_file.key]: file.music,
                    [Music.fields.thumbnail_image.key]: file.thumbnail,
                    [Music.fields.created_on.key]: await admin.firestore.FieldValue.serverTimestamp(),
                    //[Music.fields.created_by.key]: await db.doc(Users.collection.name+'/'+userID.toString())
            };


            const musicUrl  =   await getMediaBaseURL('music', req.hostname, { 'music': file.music}, next);
            
            if(file.thumbnail != "") {

                const thumbanilUrl  =   await getMediaBaseURL('music_thumbnail', req.hostname, { 'thumbnail': file.thumbnail}, next);
                
                buildUrls.push({'music_url': musicUrl, 'thumbnail_url': thumbanilUrl });

            } else {

                buildUrls.push({'music_url': musicUrl, 'thumbnail_url': "" });

            }
            resolve(tempDataObj);
        });
    })));
    
    const bulkInsertedData  =   await insertBulkData(Music, dataArr, 'music_id', next);

    jsonResponse(res, 200, 'success', 'Music files uploaded', {'urls': buildUrls});

});