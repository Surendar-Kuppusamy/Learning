import admin from 'firebase-admin';
import expressAsyncHandler from 'express-async-handler';
import fs from 'fs';
import path from 'path';
import multer from 'multer';
import twilio from 'twilio';
import { getUserId, getUserRole } from '../middleware/authMiddleware.js';
import { getDBConnection, getStorageConnection } from '../config/db.js';
import { AllCollectionsDocumentID } from '../models/AllCollectionsDocumentID.js';
import { Activities } from '../models/ActivitiesModel.js';
import { Users } from '../models/UsersModel.js';
import { InviteHelpinghand } from '../models/InviteHelpinghandModel.js';
import { MediaGroup } from '../models/MediasGroupModel.js';
import { Notifications } from '../models/NotificationsModel.js';
import { TemporaryUsers } from '../models/TemporaryUsersModel.js';
import { PopulateImages } from '../models/PopulateImagesModel.js';
import { PopulatedImagesLikeDeteleDetails } from '../models/PopulatedImagesLikeDeteleDetailsModel.js';
import { JustinCompilation } from '../models/JustinCompilationModel.js';
import { SendNotification } from '../models/SendNotificationModel.js';
import { MEDIA_TYPE, TYPE } from '../constants/globalConstants.js';
import { Checkin } from '../models/CheckinModel.js';


//Below function is used to get the last inserted ID of collection. It will return ID, which will be used to insert new record. Function Arguments(collection[String data type], field[String data type]) => [collection] = "Collection name" and [field] = "On which field is having auto increment ID in the collections."
export const getLastInsertedID = expressAsyncHandler(async(collection, field, next) => {
    return new Promise((resolve, reject) => {
        setTimeout(expressAsyncHandler(async() => {
            try {
                const db = await getDBConnection();
                const collectionRef = await db.collection(AllCollectionsDocumentID.collection.name).doc('1');
                let doc = await collectionRef.get();
                if(!doc.exists) {   //If there is empty record in collection then insert default value
                    let docID = await collectionRef.set(AllCollectionsDocumentID.default, { merge: true });
                }
                let dataObj = {
                    [AllCollectionsDocumentID.fields.modified_on.key]: await admin.firestore.FieldValue.serverTimestamp(),
                    [field]: admin.firestore.FieldValue.increment(1)
                };
                let updated = await collectionRef.set(dataObj, {merge: true});
                let allIDs = await  collectionRef.get();
                //return allIDs.get(field);
                resolve(allIDs.get(field));
            } catch(e) {
                console.log('Catch error in common function getLastInsertedID()');
                var errorLog = await saveErrorLogFileWithpath('getLastInsertedID', e.stack);
                throw new Error(e.message);
                //let error = new Error(e.message);
                //next(error);
            }
        }));
    });
});
/* export const getLastInsertedID = expressAsyncHandler(async(collection, field) => {
    try {
        const db = await getDBConnection();
        const collectionRef = await db.collection(collection).orderBy(field, 'desc').limit(1).get();
        if(collectionRef.empty) {   //If there is empty record in collection then return 1
            return 1;
        } else {
            let lastID = await collectionRef.docs[0].data()[field];
            lastID = lastID + 1;
            return lastID;
        }
    } catch(e) {
        console.log('Catch error in common function');
        errorLogger.error('Error occured on common function method "getLastInsertedID()", for logging', e);
        throw new Error(e.message);
    }
}); */

//Below function is used to get the collection data with document ID[Note: It will not get reference link data]. It will return data. Function Arguments(collection[String data type], document[Integer data type]) => [collection] = "Collection name",  [docID] = "In which document ID"
export const getCollectionDataWithDocID = expressAsyncHandler(async(collection, docID, next) => {
    return new Promise((resolve, reject) => {
        setTimeout(expressAsyncHandler(async() => {
            try {
                const db = await getDBConnection();
                let snapshot = await db.collection(collection).doc(docID.toString());
                let doc = await snapshot.get();
                if(!doc.exists) {
                    resolve([]);
                    //return [];
                } else {
                    let data = [{id: parseInt(doc.id), ...doc.data()}];
                    resolve(data);
                    //return data;
                }
            } catch(e) {
                console.log('Catch error in common function getCollectionDataWithDocID()');
                var errorLog = await saveErrorLogFileWithpath('getCollectionDataWithDocID', e.stack);
                throw new Error(e.message);
                //let error = new Error(e.message);
                //next(error);
            }
        }));
    });
});

//Below function is used to get the collection data with document ID along with select fields options[Note: It will not get reference link data]. It will return data. Function Arguments(collection[String data type], docID[Integer data type], selectFieldsArr[Array data type]) => [collection] = "Collection name",  [docID] = "In which document ID", [selectFieldsArr] => "Array of fields which you want to select"
export const getCollectionDataWithSelectAndDocID = expressAsyncHandler(async(collection, docID, selectFieldsArr, next) => {
    return new Promise((resolve, reject) => {
        setTimeout(expressAsyncHandler(async() => {
            try {
                const db = await getDBConnection();
                let snapshot = await db.collection(collection).doc(docID.toString());
                let doc = await snapshot.get();
                if(!doc.exists) {
                    resolve([]);
                    //return [];
                } else {
                    //let tempData = [{id: parseInt(doc.id), ...doc.data()}];
                    let data = [];
                    data[0] = {};
                    data[0]['id'] = parseInt(doc.id);
                    for(var i = 0; i < selectFieldsArr.length; i++) {
                        data[0][selectFieldsArr[i]] = doc.data()[selectFieldsArr[i]];
                        //data[0][selectFieldsArr[i]] = doc.get([selectFieldsArr[i]]);  //It shows error
                    }
                    resolve(data);
                    //return data;
                }
            } catch(e) {
                console.log('Catch error in common function getCollectionDataWithSelectAndDocID()');
                var errorLog = await saveErrorLogFileWithpath('getCollectionDataWithSelectAndDocID', e.stack);
                throw new Error(e.message);
                //let error = new Error(e.message);
                //next(error);
            }
        }));
    });
});

//Below function is used to get the collection data with custom condition along with offset and limit[Note: It will not get reference link data]. It will return data. Function Arguments(collection[String data type], allCondition[Object data type], offset[Integer data type], limit[Integer data type]) => [collection] = "Collection name",  [allCondition] = "On which add your required custom conditions. In which add orderby data at last.", [offset] = "Offset of the collection list for pagination", [limit] = "Limit of the collection list for pagination"
export const getCollectionData = expressAsyncHandler(async(collection, allCondition, offset, limit, next) => {
    try {
        const db = await getDBConnection();
        let query = await db.collection(collection);
        if(Object.keys(allCondition).length != 0) {
            let result = await Promise.all(Object.keys(allCondition).map(async(key, index) => {
                return new Promise(function(resolve, reject){
                    setTimeout(expressAsyncHandler(async() => {
                        setTimeout(async() => {
                            if(allCondition[key].type == 'where') {
                                query = await query.where(allCondition[key].field, allCondition[key].operator, allCondition[key].value);
                            } else if(allCondition[key].type == 'orderby') {
                                query = await query.orderBy(allCondition[key].field, allCondition[key].order);
                            } else if(allCondition[key].type == 'select') {
                                query = await query.select(...allCondition[key].fields);//In which fields used instead of field, because select fields in an array
                            }
                            resolve(allCondition[key]);
                        });
                    }));
                })
            }));
        }
        if(offset != 0) {
            query = query.offset(offset);
        }
        if(limit != 0) {
            query = query.limit(limit);
        }
        let snapshot = await query.get();
        if(snapshot.empty) {
            return [];
        } else {
            let data = snapshot.docs.map(doc => {return{id: parseInt(doc.id), ...doc.data()}});
            return data;
        }
    } catch(e) {
        console.log('Catch error in common function getCollectionData()');
        var errorLog = await saveErrorLogFileWithpath('getCollectionDataWithSelectAndDocID', e.stack);
        throw new Error(e.message);
        //let error = new Error(e.message);
        //next(error);
    }
});


export const getCollectionIDsOnly = expressAsyncHandler(async(collection, allCondition, offset, limit, next) => {
    try {
        const db = await getDBConnection();
        let query = await db.collection(collection);
        if(Object.keys(allCondition).length != 0) {
            let result = await Promise.all(Object.keys(allCondition).map(async(key, index) => {
                return new Promise(function(resolve, reject){
                    setTimeout(expressAsyncHandler(async() => {
                        setTimeout(async() => {
                            if(allCondition[key].type == 'where') {
                                query = await query.where(allCondition[key].field, allCondition[key].operator, allCondition[key].value);
                            } else if(allCondition[key].type == 'orderby') {
                                query = await query.orderBy(allCondition[key].field, allCondition[key].order);
                            } else if(allCondition[key].type == 'select') {
                                query = await query.select(...allCondition[key].fields);//In which fields used instead of field, because select fields in an array
                            }
                            resolve(allCondition[key]);
                        });
                    }));
                })
            }));
        }
        if(offset != 0) {
            query = query.offset(offset);
        }
        if(limit != 0) {
            query = query.limit(limit);
        }
        let snapshot = await query.get();
        if(snapshot.empty) {
            return [];
        } else {
            let data = snapshot.docs.map(doc => {return parseInt(doc.id)});
            return data;
        }
    } catch(e) {
        console.log('Catch error in common function getCollectionData()');
        var errorLog = await saveErrorLogFileWithpath('getCollectionData', e.stack);
        throw new Error(e.message);
        //let error = new Error(e.message);
        //next(error);
    }
});


export const getCollectionDataTotalCount = expressAsyncHandler(async(collection, allCondition, offset, limit, next) => {
    try {
        const db = await getDBConnection();
        let query = await db.collection(collection);
        if(Object.keys(allCondition).length != 0) {
            let result = await Promise.all(Object.keys(allCondition).map(async(key, index) => {
                return new Promise(function(resolve, reject){
                    setTimeout(expressAsyncHandler(async() => {
                        setTimeout(async() => {
                            if(allCondition[key].type == 'where') {
                                query = await query.where(allCondition[key].field, allCondition[key].operator, allCondition[key].value);
                            } else if(allCondition[key].type == 'orderby') {
                                query = await query.orderBy(allCondition[key].field, allCondition[key].order);
                            } else if(allCondition[key].type == 'select') {
                                query = await query.select(...allCondition[key].fields);//In which fields used instead of field, because select fields in an array
                            }
                            resolve(allCondition[key]);
                        });
                    }));
                })
            }));
        }
        if(offset != 0) {
            query = query.offset(offset);
        }
        if(limit != 0) {
            query = query.limit(limit);
        }
        let snapshot = await query.get();
        if(snapshot.empty) {
            return 0;
        } else {
            return snapshot.size;
        }
    } catch(e) {
        console.log('Catch error in common function getCollectionData()');
        var errorLog = await saveErrorLogFileWithpath('getCollectionData', e.stack);
        throw new Error(e.message);
        //let error = new Error(e.message);
        //next(error);
    }
});

//Below function is used to check is document exists or not. Function Arguments(collection[String data type], docID[Integer data type]). [collection] => "Collection name", [docID] => "Document ID"
export const checkIsDocExists = expressAsyncHandler(async(collection, docID, next) => {
    return new Promise(async(resolve, reject) => {
        try {
            const db = await getDBConnection();
            let doc = await db.collection(collection).doc(docID.toString()).get();
            if(!doc.exists) {
                resolve(false);
                //return false;
            } else {
                resolve(true);
                //return true;
            }
        } catch(e) {
            console.log('Catch error in common function checkIsDocExists()');
            var errorLog = await saveErrorLogFileWithpath('checkIsDocExists', e.stack);
            throw new Error(e.message);
            //let error = new Error(e.message);
            //next(error);
        }
    });
});

//Below function is used to check is data exists or not and it will return true. Function Arguments(collection[String data type], allCondition[Object data type], offset[Integer data type], limit[Integer data type]) => [collection] = "Collection name",  [allCondition] = "On which add your required custom conditions. In which add orderby data at last.", [offset] = "Offset of the collection list for pagination", [limit] = "Limit of the collection list for pagination"
export const checkIsDataExists = expressAsyncHandler(async(collection, allCondition, offset, limit, next) => {
    try {
        const db = await getDBConnection();
        let query = await db.collection(collection);
        //Start: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        if(Object.keys(allCondition).length != 0) {
            let result = await Promise.all(Object.keys(allCondition).map(async(key, index) => {
                return new Promise(function(resolve, reject){
                    setTimeout(expressAsyncHandler(async() => {
                        setTimeout(async() => {
                            if(allCondition[key].type == 'where') {
                                query = await query.where(allCondition[key].field, allCondition[key].operator, allCondition[key].value);
                            } else if(allCondition[key].type == 'orderby') {
                                query = await query.orderBy(allCondition[key].field, allCondition[key].order);
                            } else if(allCondition[key].type == 'select') {
                                query = await query.select(...allCondition[key].fields);//In which fields used instead of field, because select fields in an array
                            }
                            resolve(allCondition[key]);
                        });
                    }));
                })
            }));
        }
        //End: This block is used instead of "for" loop, for the reason of "wait untill loop is going to finish and then execute next code"
        if(offset != 0) {
            query = query.offset(offset);
        }
        if(limit != 0) {
            query = query.limit(limit);
        }
        let snapshot = await query.get();
        if(snapshot.empty) {
            return false;
        } else {
            return true;
        }
    } catch(e) {
        console.log('Catch error in common function checkIsDataExists()');
        var errorLog = await saveErrorLogFileWithpath('checkIsDataExists', e.stack);
        throw new Error(e.message);
        //let error = new Error(e.message);
        //next(error);
    }
});

//[Child function]Below function is used to return, what are all the reference link is wanted its data[We should mention it and what name should use on get data and delete reference field from data. Function Arguments(data[Object data type], referenceFieldsArray[Array data type], referenceFieldsNameSetArray[Array data type]) => [data] = "It have data which is getted from collection which is from parent function",  [referenceFieldsArray] = "Which have the list of fields with reference data type.", [referenceFieldsNameSetArray] = "It list the what kind of name should be used on data get."
export const getAllReferenceFields = expressAsyncHandler(async(data, referenceFieldsArray, referenceFieldsNameSetArray, next) => {
    try {
        return new Promise(function(resolve, reject){
            let referenceFieldsWithLinkAndnames = {
                links: [],
                names: []
            };
            let referenceFieldsWithLink = [];
            let referenceFieldsNames = [];
            for(var i = 0; i < referenceFieldsArray.length; i++) {
                if(data.hasOwnProperty(referenceFieldsArray[i]) && data[referenceFieldsArray[i]] != null) {
                    referenceFieldsWithLink.push(data[referenceFieldsArray[i]]);
                    referenceFieldsNames.push(referenceFieldsNameSetArray[i]);
                    delete data[referenceFieldsArray[i]];
                }
            }
            referenceFieldsWithLinkAndnames['links'] = referenceFieldsWithLink;
            referenceFieldsWithLinkAndnames['names'] = referenceFieldsNames;
            referenceFieldsWithLinkAndnames['data'] = data; //It is been not used. But don't remove it.
            resolve(referenceFieldsWithLinkAndnames);
        });
    } catch(e) {
        console.log('Catch error in common function getAllReferenceFields()');
        var errorLog = await saveErrorLogFileWithpath('getAllReferenceFields', e.stack);
        throw new Error(e.message);
        //let error = new Error(e.message);
        //next(error);
    }
});

//Below function is used to get data from collection along with the reference link. Function Arguments(collection[String data type], allCondition[Object data type], offset[Integer data type], limit[Integer data type], referenceFieldsArray[Array data type], referenceFieldsNameSetArray[Array data type]) => [collection] = "Collection name",  [allCondition] = "On which add your required custom conditions. In which add orderby data at last.", [offset] = "Offset of the collection list for pagination", [limit] = "Limit of the collection list for pagination", [referenceFieldsArray] = "Which have the list of fields with reference data type.", [referenceFieldsNameSetArray] = "It list the what kind of name should be used on data get."
export const getCollectionDataWithReferenceLinkData = expressAsyncHandler(async(collection, allCondition, offset, limit, referenceFieldsArray, referenceFieldsNameSetArray, next) => {
    try {
        const db = await getDBConnection();
        let query = await db.collection(collection);
        //Start: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        if(Object.keys(allCondition).length != 0) {
            let result = await Promise.all(Object.keys(allCondition).map(expressAsyncHandler(async(key, index) => {
                return new Promise(function(resolve, reject){
                    setTimeout(expressAsyncHandler(async() => {
                        setTimeout(async() => {
                            if(allCondition[key].type == 'where') {
                                query = await query.where(allCondition[key].field, allCondition[key].operator, allCondition[key].value);
                            } else if(allCondition[key].type == 'orderby') {
                                query = await query.orderBy(allCondition[key].field, allCondition[key].order);
                            } else if(allCondition[key].type == 'select') {
                                query = await query.select(...allCondition[key].fields);//In which fields used instead of field, because select fields in an array
                            }
                            resolve(allCondition[key]);
                        });
                    }));
                })
            })));
        }
        //Start: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        if(offset != 0) {
            query = query.offset(offset);
        }
        if(limit != 0) {
            query = query.limit(limit);
        }
        let snapshot = await query.get();
        if(snapshot.empty) {
            return [];
        } else {
            let datas = await Promise.all(snapshot.docs.map(expressAsyncHandler(async(doc) => {
                let temp = {
                    id: parseInt(doc.id),
                    ...doc.data()
                };
                let allReferenceDetails = await getAllReferenceFields(temp, referenceFieldsArray, referenceFieldsNameSetArray, next);
                temp = allReferenceDetails['data'];
                let tempObj = await getAllReferenceData(allReferenceDetails['names'], allReferenceDetails['links'], next);
                temp = Object.assign(temp, tempObj); //Merge or override the reference link data on the main data.
                return temp;
                /* let temp = {};
                temp['id'] = parseInt(doc.id);
                temp['data'] = await doc.data();
                let allReferenceDetails = await getAllReferenceFields(temp['data'], referenceFieldsArray, referenceFieldsNameSetArray);
                temp['data'] = allReferenceDetails['data'];
                let tempObj = await getAllReferenceData(allReferenceDetails['names'], allReferenceDetails['links']);
                temp['data'] = Object.assign(temp['data'], tempObj); //Merge or override the reference link data on the main data.
                return temp; */
            })));
            return datas;
        }
    } catch(e) {
        console.log('Catch error in common function getCollectionDataWithReferenceLinkData()');
        var errorLog = await saveErrorLogFileWithpath('getCollectionDataWithReferenceLinkData', e.stack);
        throw new Error(e.message);
        //let error = new Error(e.message);
        //next(error);
    }
});

//[Child function]Below function is used to get reference link data from collection. Function Arguments(refArr[Array data type], references[Array data type]). [refArr] => It list the what kind of name should be used on data get., [references] => Array of reference links.
export const getAllReferenceData = expressAsyncHandler(async(refArr, references, next) => {
    try {
        const db = await getDBConnection();
        return new Promise(function(resolve, reject){
            db.getAll(...references).then(docs => {
                const data = docs.map(doc => doc.data());
                let tempData = {};
                for(var i=0; i < data.length; i++) {
                    tempData[refArr[i]] = {
                        id: parseInt(docs[i].id),
                        ...data[i]
                    }
                }
                resolve(tempData);
            }).catch(err => reject(err));
        });
    } catch(e) {
        console.log('Catch error in common function getAllReferenceData()');
        var errorLog = await saveErrorLogFileWithpath('getAllReferenceData', e.stack);
        throw new Error(e.message);
        //let error = new Error(e.message);
        //next(error);
    }
});


//[Child function]Below function is used to return, what are all the reference link is wanted its data[We should mention it and what name should use on get data and delete reference field from data. Function Arguments(data[Object data type], referenceFieldsArray[Array data type], referenceFieldsNameSetArray[Array data type], removeFieldsArr[Array data type], selectFieldsObj[Object data type]) => [data] = "It have data which is getted from collection which is from parent function",  [referenceFieldsArray] = "Which have the list of fields with reference data type.", [referenceFieldsNameSetArray] = "It list the what kind of name should be used on data get.", [removeFieldsArr] = "Array of fields should be removed", [selectFieldsObj] = "Get the fields you want to select in a array of object, First object key represents the parent and then next number keys represents reference link by order, so don't change order."
export const getAllReferenceSelectFields = expressAsyncHandler(async(data, referenceFieldsArray, referenceFieldsNameSetArray, selectFieldsObj, next) => {
    try {
        return new Promise(function(resolve, reject){
            let referenceFieldsWithLinkAndnames = {
                links: [],
                names: []
            };
            let referenceFieldsWithLink = [];
            let referenceFieldsNames = [];
            let referenceFieldsSelect = {};
            let count = 0;
            for(var i = 0; i < referenceFieldsArray.length; i++) {
                if(data.hasOwnProperty(referenceFieldsArray[i]) && data[referenceFieldsArray[i]] != null) {
                    referenceFieldsWithLink.push(data[referenceFieldsArray[i]]);
                    referenceFieldsNames.push(referenceFieldsNameSetArray[i]);
                    referenceFieldsSelect[count.toString()] = selectFieldsObj[(i+1).toString()];
                    if(selectFieldsObj.hasOwnProperty('process_name')) {
                        referenceFieldsSelect['process_name'] = selectFieldsObj['process_name'];
                    }
                    if(data.hasOwnProperty(referenceFieldsArray[i])) {
                        delete data[referenceFieldsArray[i]];
                    }
                    count = count + 1;
                } else {
                    data[referenceFieldsNameSetArray[i]] = data[referenceFieldsArray[i]];   //Over write the key name for reference link
                    delete data[referenceFieldsArray[i]];
                }
            }
            /* referenceFieldsWithLinkAndnames['data'] = {};
            for(var j = 0; j < selectFieldsObj["1"].length; j++) {
                referenceFieldsWithLinkAndnames['data']['id'] = parseInt(data.id);
                if(data.hasOwnProperty(selectFieldsObj["1"][j])) {
                    referenceFieldsWithLinkAndnames['data'][selectFieldsObj["1"][j]] = data[selectFieldsObj["1"][j]];
                }
            } */
            referenceFieldsWithLinkAndnames['data'] = data; //It is been not used. But don't remove it.
            referenceFieldsWithLinkAndnames['links'] = referenceFieldsWithLink;
            referenceFieldsWithLinkAndnames['names'] = referenceFieldsNames;
            referenceFieldsWithLinkAndnames['select'] = referenceFieldsSelect;
            resolve(referenceFieldsWithLinkAndnames);
        });
    } catch(e) {
        console.log('Catch error in common function getAllReferenceSelectFields()');
        var errorLog = await saveErrorLogFileWithpath('getAllReferenceSelectFields', e.stack);
        throw new Error(e.message);
        //let error = new Error(e.message);
        //next(error);
    }
});


//Below function is used to get data from collection along with the reference link. Function Arguments(collection[String data type], allCondition[Object data type], offset[Integer data type], limit[Integer data type], referenceFieldsArray[Array data type], referenceFieldsNameSetArray[Array data type], selectFieldsObj[Object data type]) => [collection] = "Collection name",  [allCondition] = "On which add your required custom conditions. In which add orderby data at last.", [offset] = "Offset of the collection list for pagination", [limit] = "Limit of the collection list for pagination", [referenceFieldsArray] = "Which have the list of fields with reference data type.", [referenceFieldsNameSetArray] = "It list the what kind of name should be used on data get.", [selectFieldsObj] => "Get the fields you want to select in a array of object, First object key represents the parent and then next number keys represents reference link by order, so don't change order."
export const getCollectionDataWithReferenceLinkSelectData = expressAsyncHandler(async(collection, allCondition, offset, limit, referenceFieldsArray, referenceFieldsNameSetArray, selectFieldsObj, next) => {
    try {
        const db = await getDBConnection();
        let query = await db.collection(collection);
        //Start: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        if(Object.keys(allCondition).length != 0) {
            let result = await Promise.all(Object.keys(allCondition).map(expressAsyncHandler(async(key, index) => {
                return new Promise(function(resolve, reject){
                    setTimeout(expressAsyncHandler(async() => {
                        setTimeout(async() => {
                            if(allCondition[key].type == 'where') {
                                query = await query.where(allCondition[key].field, allCondition[key].operator, allCondition[key].value);
                            } else if(allCondition[key].type == 'orderby') {
                                query = await query.orderBy(allCondition[key].field, allCondition[key].order);
                            } else if(allCondition[key].type == 'select') {
                                query = await query.select(...allCondition[key].fields);//In which fields used instead of field, because select fields in an array
                            }
                            resolve(allCondition[key]);
                        });
                    }));
                })
            })));
        }
        //Start: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        if(offset != 0) {
            query = query.offset(offset);
        }
        if(limit != 0) {
            query = query.limit(limit);
        }
        
        let snapshot = await query.get();
        
        if(snapshot.empty) {
            return [];
        } else {
            let datas = await Promise.all(snapshot.docs.map(expressAsyncHandler(async(doc, index) => {
                let temp = {
                    id: parseInt(doc.id),
                    ...doc.data()
                };
                let allReferenceDetails = await getAllReferenceSelectFields(temp, referenceFieldsArray, referenceFieldsNameSetArray, selectFieldsObj, next);
                temp = allReferenceDetails['data'];
                let tempObj = await getAllReferenceSelectData(allReferenceDetails['names'], allReferenceDetails['select'], allReferenceDetails['links'], next);

                if(selectFieldsObj.hasOwnProperty('process_name') && selectFieldsObj['process_name'] == 'helpinghand_list') {
                    let supporterColors = ['#F1B54D', '#E1703A', '#748C8E', '#E2D74B', '#C0A594'];
                    if(index < supporterColors.length ) {
                        tempObj['color'] = supporterColors[index];
                    } else {
                        let rndInt = Math.floor(Math.random() * 4) + 1;
                        tempObj['color'] = supporterColors[rndInt];
                    }
                }

                if(selectFieldsObj.hasOwnProperty('process_name') && selectFieldsObj['process_name'] == 'supporter_list') {
                    temp['media_view_like_count']    =   (temp.hasOwnProperty('media_view_like_count')) ? temp['media_view_like_count'] : 0;
                }

                temp = Object.assign(temp, tempObj); //Merge or override the reference link data on the main data.
                return temp;
                /* let temp = {};
                temp['id'] = parseInt(doc.id);
                temp['data'] = await doc.data();
                let allReferenceDetails = await getAllReferenceSelectFields(temp['data'], referenceFieldsArray, referenceFieldsNameSetArray, selectFieldsObj);
                temp['data'] = allReferenceDetails['data'];
                let tempObj = await getAllReferenceSelectData(allReferenceDetails['names'], allReferenceDetails['select'], allReferenceDetails['links']);
                temp['data'] = Object.assign(temp['data'], tempObj); //Merge or override the reference link data on the main data.
                return temp; */
            })));
            return datas;
        }
    } catch(e) {
        console.log('Catch error in common function getCollectionDataWithReferenceLinkSelectData()', e);
        var errorLog = await saveErrorLogFileWithpath('getCollectionDataWithReferenceLinkSelectData', e.stack);
        throw new Error(e.message);
        //let error = new Error(e.message);
        //throw new Error('Something went wrong.');
    }
});

//[Child function]Below function is used to get reference link data from collection with the fields selection option. Function Arguments(refArr[Array data type], selectFieldsObj[Object data type], references[Array data type]). [refArr] => It list the what kind of name should be used on data get., [references] => Array of reference links, [selectFieldsObj] => Get the fields you want to select in a array of object, First object key represents the parent and then next number keys represents reference link by order, so don't change order.
export const getAllReferenceSelectData = expressAsyncHandler(async(refArr, selectFieldsObj, references, next) => {
    try {
        const db = await getDBConnection();
        return new Promise(function(resolve, reject){
            db.getAll(...references).then(docs => {
                /* let tempData = {};
                const data = docs.map((doc, i) => {
                    console.log(selectFieldsObj);
                    tempData[refArr[i]] = {};
                    for(var j = 0; j < selectFieldsObj[i.toString()].length; j++) {
                        tempData[refArr[i]]['id'] = parseInt(doc.id);
                        tempData[refArr[i]][selectFieldsObj[i.toString()][j]] = doc.get(selectFieldsObj[i.toString()][j]);
                    }
                });
                resolve(tempData); */
                const data = docs.map(doc => doc.data());
                let tempData = {};
                
                for(var i=0; i < data.length; i++) {
                    tempData[refArr[i]] = {};
                    for(var j = 0; j < selectFieldsObj[i.toString()].length; j++) {
                        tempData[refArr[i]]['id'] = parseInt(docs[i].id);
                        if(data[i].hasOwnProperty(selectFieldsObj[i.toString()][j])) {
                            tempData[refArr[i]][selectFieldsObj[i.toString()][j]] = data[i][selectFieldsObj[i.toString()][j]];
                        }
                        if(selectFieldsObj.hasOwnProperty('process_name') && selectFieldsObj['process_name'] == 'helpinghand_list') {
                            if(data[i].hasOwnProperty('temporary_helpinghand_user_id')) {
                                tempData[refArr[i]]['flag'] = 2;
                            } else if(data[i].hasOwnProperty('users_id')) {
                                tempData[refArr[i]]['flag'] = 1;
                                if(selectFieldsObj[i.toString()][j] == "profile_image") {
                                    tempData[refArr[i]]['image'] = data[i][selectFieldsObj[i.toString()][j]];
                                    if(tempData[refArr[i]]['image'] != "") {
                                        if(process.env.MODE == "development") {
                                            tempData[refArr[i]]['profile_image'] = 'http://172.21.4.120:'+process.env.PORT+'/public/profile/'+parseInt(docs[i].id)+'/'+tempData[refArr[i]]['image'];
                                        } else {
                                            tempData[refArr[i]]['profile_image'] = process.env.STORAGE_BASE_URL+'public%2Fprofile'+'%2F'+parseInt(docs[i].id)+'%2F'+tempData[refArr[i]]['image']+'?alt=media';
                                        }
                                        delete tempData[refArr[i]]['image'];
                                    }
                                }                               
                            }
                        } else {
                            //console.log(selectFieldsObj);
                        }
                    }
                }
                resolve(tempData);
            }).catch(err => reject(err));
        });
    } catch(e) {
        console.log('Catch error in common function getAllReferenceSelectData()');
        var errorLog = await saveErrorLogFileWithpath('getAllReferenceSelectData', e.stack);
        throw new Error(e.message);
        //let error = new Error(e.message);
        //next(error);
    }
});



//Below function is used to insert data into collection. Function Arguments(collection[Object data type], dataObj[Object data type], idField[String data type]). [collection] => "Collection Object from models", [dataObj] => "Data is going to insert", [idField] => "On which field is auto increment ID is stored for this collection"
export const insertData = expressAsyncHandler(async(Collection, dataObj, idField, next) => {
    return new Promise(async(resolve, reject) => {
        try {
            const db = await getDBConnection();
            let docID = await getLastInsertedID(Collection.collection.name, idField, next);
            dataObj[idField] = docID;
            var collectionDefaultVal    =   JSON.parse(JSON.stringify(Collection.default));
            let insertDataObj = Object.assign(collectionDefaultVal, dataObj); //By default add all fields on this insert record from the collection model
            const insertedDetail = await db.collection(Collection.collection.name).doc(docID.toString()).set(insertDataObj, { merge: true });
            resolve(docID);
            //return docID;
        } catch(e) {
            console.log('Catch error in common function insertData()', e);
            var errorLog = await saveErrorLogFileWithpath('insertData', e.stack);
            reject(e);
            throw new Error(e.message);
            //let error = new Error(e.message);
            //next(error);
        }
    });
});

//Below function is used to update data into collection. Function Arguments(collection[String data type], dataObj[Object data type], docID[Integer data type]). [collection] => "Collection name", [dataObj] => "Data is going to insert", [docID] => "On which document is going to updated on collections"
export const updateData = expressAsyncHandler(async(collection, dataObj, docID, next) => {
    return new Promise((resolve, reject) => {
        setTimeout(expressAsyncHandler(async() => {
            try {
                const db = await getDBConnection();
                const updatedDetail = await db.collection(collection).doc(docID.toString()).set(dataObj, { merge: true });
                resolve(docID);
                //return docID;
            } catch(e) {
                //console.log(dataObj);
                console.log('Catch error in common function updateData()');
                var errorLog = await saveErrorLogFileWithpath('updateData', e.stack);
                throw new Error(e.message);
                //let error = new Error(e.message);
                //next(error);
            }
        }));
    });
});

//Below function is used to delete documents from collection. Function Arguments(collection[String data type], docIDArr[Array data type]). [collection] => "Collection name", [docIDArr] => "All this doument ID's are going to deleted from the collection"
export const deleteDataWithDocumentID = expressAsyncHandler(async(collection, docIDArr, next) => {
    try {
        const db = await getDBConnection();
        const batch = await db.batch();
        //Start: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        let result = await Promise.all(docIDArr.map(async (docID) => {
            return new Promise(function(resolve, reject){
                setTimeout(expressAsyncHandler(async() => {
                    let docRef = await db.collection(collection).doc(docID.toString());
                    let res = await batch.delete(docRef);
                    resolve(res);
                }));
            });
        }));
        //End: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        await batch.commit();
        return result;
    } catch(e) {
        console.log('Catch error in common function deleteDataWithDocumentID()');
        var errorLog = await saveErrorLogFileWithpath('deleteDataWithDocumentID', e.stack);
        throw new Error(e.message);
        //let error = new Error(e.message);
        //next(error);
    }
});

//Below function is used to delete the fields on the document of collection. Function Arguments(collection[String data type], docIDArr[Array data type], fieldObj[Object data type]). [collection] => "Collection name", [docIDArr] => "All this doument ID's are going to used for delete field deletion", [fieldObj] => "In represents the field which is going to delete Ex: let fieldObj = {capital: admin.firestore.FieldValue.delete()};"
export const deleteFieldWithDocumentID = expressAsyncHandler(async(collection, docIDArr, fieldObj, next) => {
    try {
        const db = await getDBConnection();
        //Start: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        let result = await Promise.all(docIDArr.map(async (docID) => {
            return new Promise(function(resolve, reject){
                setTimeout(expressAsyncHandler(async() => {
                    let docRef = await db.collection(collection).doc(docID.toString());
                    const res = await docRef.set(fieldObj, { merge: true });
                    resolve(res);
                }));
            });
        }));
        //End: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        return result;
    } catch(e) {
        console.log('Catch error in common function deleteFieldWithDocumentID()');
        var errorLog = await saveErrorLogFileWithpath('deleteFieldWithDocumentID', e.stack);
        throw new Error(e.message);
        //let error = new Error(e.message);
        //next(error);
    }
});

//Below function is used to delete documents of collection with the conditions. Function Arguments(collection[String data type], allCondition[Object data type]). [collection] => "Collection name", [allCondition] => "On which add your required custom conditions. In which add orderby data at last."
export const deleteDataWithCondition = expressAsyncHandler(async(collection, allCondition, next) => {    //Mostly don't use it. It will delete the all records in the collection with matched condition, if no condition then it delete all records of collection. It will not delete collection.
    try {
        const db = await getDBConnection();
        let query = await db.collection(collection);
        //Start: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        if(Object.keys(allCondition).length != 0) {
            let result = await Promise.all(Object.keys(allCondition).map(async(key, index) => {
                return new Promise(function(resolve, reject){
                    setTimeout(expressAsyncHandler(async() => {
                        setTimeout(async() => {
                            if(allCondition[key].type == 'where') {
                                query = await query.where(allCondition[key].field, allCondition[key].operator, allCondition[key].value);
                            } else if(allCondition[key].type == 'orderby') {
                                query = await query.orderBy(allCondition[key].field, allCondition[key].order);
                            } else if(allCondition[key].type == 'select') {
                                query = await query.select(...allCondition[key].fields);//In which fields used instead of field, because select fields in an array
                            }
                            resolve(allCondition[key]);
                        });
                    }));
                })
            }));
        }
        //End: This block is used instead of "for" loop for "wait untill loop is going to finish and then execute next code"
        let snapshot = await query.get();
        if(snapshot.empty) {
            return false;
        } else {
            return new Promise((resolve, reject) => {
                deleteQueryBatch(db, query, resolve, next).catch(reject);
            });
        }
    } catch(e) {
        console.log('Catch error in common function deleteDataWithCondition()');
        var errorLog = await saveErrorLogFileWithpath('deleteDataWithCondition', e.stack);
        throw new Error(e.message);
        //let error = new Error(e.message);
        //next(error);
    }
});

//[Child Function]Below function is used to delete documents of collection. Function Arguments(db[object data type], query[query string], resolve[callback function from promise]). [db] => "Database connections", [query] => "Firestore query with all condition applied", [resolve] => "Call back function from promise"
async function deleteQueryBatch(db, query, resolve, next) {
    return new Promise((resolve, reject) => {
        setTimeout(expressAsyncHandler(async() => {
            try {
                let snapshot = await query.get();
                const batchSize = snapshot.size;
                if (batchSize === 0) {  //If no data then resolve and 
                    // When there are no documents left, we are done
                    resolve(true);
                    return;
                }
                // Delete documents in a batch
                const batch = db.batch();
                snapshot.docs.forEach((doc) => {
                    batch.delete(doc.ref);
                });
                await batch.commit();
                // Recurse on the next process tick, to avoid
                // exploding the stack.
                process.nextTick(() => {    //If data exists it recalls function.
                    deleteQueryBatch(db, query, resolve, next);
                });
            } catch(e) {
                console.log('Catch error in common function deleteQueryBatch()');
                var errorLog = await saveErrorLogFileWithpath('deleteQueryBatch', e.stack);
                throw new Error(e.message);
                //let error = new Error(e.message);
                //next(error);
            }
        }));
    });
}

//Below function is used to insert bulk data into the collection. Function Arguments(collection[Object data type], dataArr[Array data type], idField[String data type]). [collection] => "Collection Object from models", [dataArr] => "Data going to insert", [idField] => "On which field has the auto increment ID"
export const insertBulkData = expressAsyncHandler(async(Collection, dataArr, idField, next) => {
    try {
        const db = await getDBConnection();
        const batch = db.batch();
        let docID = await getLastInsertedID(Collection.collection.name, idField, next);
        let result = await Promise.all(dataArr.map(async (doc, index) => {
            return new Promise(function(resolve, reject){
                setTimeout(expressAsyncHandler(async() => {
                    if(index != 0) {
                        docID = docID + 1;
                    }
                    doc[idField] = docID;
                    let insertDataObj = {};
                    insertDataObj = Object.assign(Collection.default, doc); //By default add all fields on this insert record from the collection model
                    let updateIDTable = await batch.set(db.collection(AllCollectionsDocumentID.collection.name).doc('1'), {[AllCollectionsDocumentID.fields[idField].key]: docID}, { merge: true });    //It update the collection ID's table
                    let res = await batch.update(db.collection(Collection.collection.name).doc(docID.toString()), insertDataObj, { merge: true });
                    //resolve(res);
                    resolve(doc);
                }));
            });
        }));
        await batch.commit();
        return result;
    } catch(e) {
        console.log('Catch error in common function insertBulkData()');
        var errorLog = await saveErrorLogFileWithpath('insertBulkData', e.stack);
        throw new Error(e.message);
        //let error = new Error(e.message);
        //next(error);
    }
});


//Below function is used to update bulk data into the collection. Function Arguments(collection[string data type], dataArr[Array data type], docID[Array data type]). [collection] => "Collection name", [dataArr] => "Data going to update", [docID] => "ID's which is used to update document on this collection"
export const updateBulkData = expressAsyncHandler(async(collection, dataObj, docID, next) => {
    try {
        const db = await getDBConnection();
        const batch = db.batch();
        let result = await Promise.all(docID.map(async (docID, index) => {
            return new Promise(function(resolve, reject){
                setTimeout(expressAsyncHandler(async() => {
                    let res = await batch.set(db.collection(collection).doc(docID.toString()), dataObj, { merge: true });
                    resolve(res);
                    //resolve(dataObj);
                }));
            });
        }));
        await batch.commit();
        return result;
    } catch(e) {
        console.log('Catch error in common function updateBulkData()');
        var errorLog = await saveErrorLogFileWithpath('updateBulkData', e.stack);
        throw new Error(e.message);
        //let error = new Error(e.message);
        //next(error);
    }
});

export const generateSMSVerificationCode = expressAsyncHandler(async(countryCode, mobileNumber, data, next) => {
    return new Promise((resolve, reject) => {
        setTimeout(expressAsyncHandler(async() => {
            try {
                const client = new twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN, { logLevel: 'debug' });

                let toNumber = countryCode+mobileNumber;

                const twillioMessageServiceID   =   (countryCode === '+1')
                                                        ? process.env.TWILIO_MESSAGING_SERVICES_ID_FOR_US
                                                        : process.env.TWILIO_MESSAGING_SERVICES_ID;

                let smsCode = Math.floor(Math.random() * 899999 + 100000);
                smsCode = smsCode.toString().substring(0, 4);
                smsCode =  parseInt(smsCode);

                if(mobileNumber === '0409774429') {
                    smsCode =  2022;
                }

                let smsMessage = "Your JUSTIN APP code is "+smsCode.toString()+" but you can simply Tap on the number in keyboard below.";

                if(data.sms_flag != undefined && data.sms_flag != null && data.sms_flag == 1) {
                    resolve(smsCode);
                } else {
                    client.messages.create({
                        messagingServiceSid: twillioMessageServiceID,
                        body: smsMessage,
                        to: toNumber
                        //from: '+61255001114'
                    }).then(async(message) => {
                        //console.log(message);
                        let smsTracking = {
                            collection: {
                                name: 'sms_tracking'
                            },
                            default: {
                                "message_id": "",
                                "date_created": "",
                                "body": "",
                                "status": "",
                                "error_code": null,
                                "error_message": null
                            }
                        };
                        let responseObject = {};
                        responseObject['message_id']    = (message.sid != undefined) ? message.sid : null;
                        responseObject['created_on']    = (message.date_created != undefined) ? message.date_created : null;
                        responseObject['to']            = (message.to != undefined) ? message.to : null;
                        responseObject['body']          = (message.body != undefined) ? message.body : null;
                        responseObject['status']        = (message.status != undefined) ? message.status : null;
                        responseObject['error_code']    = (message.error_code != undefined) ? message.error_code : null;
                        responseObject['error_message'] = (message.error_message != undefined) ? message.error_message : null;

                        const activityID = await insertData(smsTracking, responseObject, 'sms_tracking_id');
                        //var errorLog = await saveErrorLogFileWithpath('twilio', JSON.stringify(message));
                        resolve(smsCode);
                    })
                    .catch(async (error) => {
                        console.log(error);
                        var errorLog = await saveErrorLogFileWithpath('twilio', error.message);
                        if(error.code != undefined && error.code != null && error.code == 21211) {
                            resolve(21211);
                        } else {
                            resolve(false);
                        }
                    });
                }

                
                
                //return smsCode;
            } catch(e) {
                console.log('Catch error in common function generateSMSVerificationCode()', e);
                var errorLog = await saveErrorLogFileWithpath('generateSMSVerificationCode', e.stack);
                throw new Error(e.message);
                //let error = new Error(e.message);
                //next(error);
            }
        }));
    });
});

export const regenerateInviteCode = expressAsyncHandler(async(name, userID, next) => {
    return new Promise(async(resolve, reject) => {
        try {
            let numbers = "0123456789";
            let alphabets = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            let oneExtraChar = alphabets.charAt(Math.floor(Math.random() * alphabets.length));
            let twoExtraChar = oneExtraChar+alphabets.charAt(Math.floor(Math.random() * alphabets.length));

            let oneExtraNum = numbers.charAt(Math.floor(Math.random() * numbers.length));
            let twoExtraNum = oneExtraNum+numbers.charAt(Math.floor(Math.random() * numbers.length));
            let threeExtraNum = twoExtraNum+numbers.charAt(Math.floor(Math.random() * numbers.length));

            let code = name.substring(0, 3);
            code = code.toUpperCase();

            code = (code.length == 3) ? code : (code.length == 2) ? code+oneExtraChar : code+twoExtraChar;

            let userIDCode = userID.toString().substring(0, 3);

            //userIDCode = (userIDCode.length == 3) ? userIDCode : (userIDCode.length == 2) ? userIDCode+oneExtraNum : userIDCode+twoExtraNum;
            
            code = code+'-'+threeExtraNum;
            resolve(code);
        } catch(e) {
            console.log('Catch error in common function regenerateInviteCode()');
            var errorLog = await saveErrorLogFileWithpath('regenerateInviteCode', e.stack);
            throw new Error(e.message);
            //let error = new Error(e.message);
            //next(error);
        }
    });
});

export const generateInviteCode = expressAsyncHandler(async(name, userID, next) => {
    return new Promise(async(resolve, reject) => {
        try {
            const db            =   await getDBConnection();
            const numbers       =   "0123456789";
            const alphabets     =   "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            const oneExtraChar  =   alphabets.charAt(Math.floor(Math.random() * alphabets.length));
            const twoExtraChar  =   oneExtraChar+alphabets.charAt(Math.floor(Math.random() * alphabets.length));

            const oneExtraNum   =   numbers.charAt(Math.floor(Math.random() * numbers.length));
            const twoExtraNum   =   oneExtraNum+numbers.charAt(Math.floor(Math.random() * numbers.length));

            const threeExtraNum     =   Math.floor(100 + Math.random() * 900);
            const threeExtraNum1    =   Math.floor(100 + Math.random() * 900);
            const threeExtraNum2    =   Math.floor(100 + Math.random() * 900);
            const threeExtraNum3    =   Math.floor(100 + Math.random() * 900);
            const threeExtraNum4    =   Math.floor(100 + Math.random() * 900);
            const threeExtraNum5    =   Math.floor(100 + Math.random() * 900);
            const threeExtraNum6    =   Math.floor(100 + Math.random() * 900);
            const threeExtraNum7    =   Math.floor(100 + Math.random() * 900);
            const threeExtraNum8    =   Math.floor(100 + Math.random() * 900);
            const threeExtraNum9    =   Math.floor(100 + Math.random() * 900);
            const threeExtraNum10   =   Math.floor(100 + Math.random() * 900);



            let code    =   name.substring(0, 3);
            code        =   code.toUpperCase();

            code = (code.length == 3) ? code : (code.length == 2) ? code+oneExtraChar : code+twoExtraChar;

            /* let userIDCode = userID.toString().substring(0, 3);

            userIDCode = (userIDCode.length == 3) ? userIDCode : (userIDCode.length == 2) ? userIDCode+oneExtraNum : userIDCode+twoExtraNum; */

            let userIDCode  =   threeExtraNum;
            
            code        =   code+'-'+userIDCode;

            const inviteRef         =   await db.collection(InviteHelpinghand.collection.name);
            const checkinviteRef1   =   await inviteRef.where(InviteHelpinghand.fields.invite_code.key, '==', code).get();

            if(checkinviteRef1.empty) {
                return resolve(code);
            }

            userIDCode  =   threeExtraNum1;
            code        =   code+'-'+userIDCode;

            const checkinviteRef2   =   await inviteRef.where(InviteHelpinghand.fields.invite_code.key, '==', code).get();

            if(checkinviteRef2.empty) {
                return resolve(code);
            }

            userIDCode  =   threeExtraNum2;
            code        =   code+'-'+userIDCode;

            const checkinviteRef3   =   await inviteRef.where(InviteHelpinghand.fields.invite_code.key, '==', code).get();

            if(checkinviteRef3.empty) {
                return resolve(code);
            }

            userIDCode  =   threeExtraNum3;
            code        =   code+'-'+userIDCode;

            const checkinviteRef4   =   await inviteRef.where(InviteHelpinghand.fields.invite_code.key, '==', code).get();

            if(checkinviteRef4.empty) {
                return resolve(code);
            }

            userIDCode  =   threeExtraNum4;
            code        =   code+'-'+userIDCode;

            const checkinviteRef5   =   await inviteRef.where(InviteHelpinghand.fields.invite_code.key, '==', code).get();

            if(checkinviteRef5.empty) {
                return resolve(code);
            }


            userIDCode  =   threeExtraNum5;
            code        =   code+'-'+userIDCode;

            const checkinviteRef6   =   await inviteRef.where(InviteHelpinghand.fields.invite_code.key, '==', code).get();

            if(checkinviteRef6.empty) {
                return resolve(code);
            }

            userIDCode  =   threeExtraNum6;
            code        =   code+'-'+userIDCode;

            const checkinviteRef7   =   await inviteRef.where(InviteHelpinghand.fields.invite_code.key, '==', code).get();

            if(checkinviteRef7.empty) {
                return resolve(code);
            }

            userIDCode  =   threeExtraNum7;
            code        =   code+'-'+userIDCode;

            const checkinviteRef8   =   await inviteRef.where(InviteHelpinghand.fields.invite_code.key, '==', code).get();

            if(checkinviteRef8.empty) {
                return resolve(code);
            }

            userIDCode  =   threeExtraNum8;
            code        =   code+'-'+userIDCode;

            const checkinviteRef9   =   await inviteRef.where(InviteHelpinghand.fields.invite_code.key, '==', code).get();

            if(checkinviteRef9.empty) {
                return resolve(code);
            }

            userIDCode  =   threeExtraNum9;
            code        =   code+'-'+userIDCode;

            const checkinviteRef10   =   await inviteRef.where(InviteHelpinghand.fields.invite_code.key, '==', code).get();

            if(checkinviteRef10.empty) {
                return resolve(code);
            }

            userIDCode  =   threeExtraNum10;
            code        =   code+'-'+userIDCode;

            const checkinviteRef11   =   await inviteRef.where(InviteHelpinghand.fields.invite_code.key, '==', code).get();

            if(checkinviteRef11.empty) {
                return resolve(code);
            }

            //return smsCode;
        } catch(e) {
            console.log('Catch error in common function generateSMSVerificationCode()');
            var errorLog = await saveErrorLogFileWithpath('generateSMSVerificationCode', e.stack);
            throw new Error(e.message);
            //let error = new Error(e.message);
            //next(error);
        }
    });
});

//Below function used to send the response. Function Arguments(res[Express response object], statusCode[Integer data type], status[String data type], message[String data type], data[Object data type]). [res] => "Express response object", [statusCode] => "Here comes the status code of the response", [status] => "Here comes the status of the API nor 'success' or 'error'", [message] => "Here comes the response message of the API", [data] => "Here comes the extra data need to return to response API"
export const jsonResponse = expressAsyncHandler(async(res, statusCode, status, message, data) => {
    try {
        if(data) {
            res.status(statusCode).json({
                status: status,
                message: message,
                data: data
            });
        } else {
            res.status(statusCode).json({
                status: status,
                message: message
            });
        }
    } catch(e) {
        console.log('Catch error in common function jsonResponse()', e);
        var errorLog = await saveErrorLogFileWithpath('jsonResponse', e.stack);
        throw new Error(e.message);
    }
});

export const getActivities = expressAsyncHandler(async() => {
    const activities = {
        "user_sms_verified": {
            "type": 1,
            "message": "[[FROM]] verified sms.",
            "user_message": "[[FROM]] verified sms.",
            "supporter_message": "[[FROM]] verified sms."
        },
        "add_onborading_media": {
            "type": 4,
            "message": "[[FROM]] added on [[TYPE]].",
            "user_message": "[[FROM]] recorded your first [[TYPE]].",
            "supporter_message": "[[FROM]] recorded your first [[TYPE]]."
        },
        "add_media": {
            "type": 4,
            "message": "[[FROM]] added on [[TYPE]].",
            "user_message": "[[FROM]] saved [[CONTENT_OR_MESSAGE]] to your [[TYPE]].",
            "supporter_message": "[[FROM]] saved [[CONTENT_OR_MESSAGE]] to your [[TYPE]]."
        },
        "assign_media": {
            "type": 3,
            "message": "[[FROM]] added on [[TYPE]] for [[TO]].",
            "user_message": "[[FROM]] saved [[CONTENT_OR_MESSAGE]] to your [[TYPE]].",
            "supporter_message": "[[FROM]] saved [[CONTENT_OR_MESSAGE]] to [[TO]]'s [[TYPE]]."
        },
        "assign_media_for_temp_user": {
            "type": 3,
            "message": "[[FROM]] added on [[TYPE]] for [[TO]].",
            "user_message": "[[FROM]] saved [[CONTENT_OR_MESSAGE]] to your [[TYPE]].",
            "supporter_message": "[[FROM]] saved [[CONTENT_OR_MESSAGE]] to [[TO]]'s [[TYPE]]."
        },
        "invite_new_helpinghand": {
            "type": 2,
            "message": "[[FROM]] invited new helpinghand [[TO]].",
            "user_message": "You sent [[TO]] an invitation.",
            "supporter_message": "You received an invitation from [[FROM]]."
        },
        "invite_new_user": {
            "type": 2,
            "message": "[[FROM]] invited new user [[TO]].",
            "user_message": "You sent [[TO]] an invitation.",
            "supporter_message": "You received an invitation from [[FROM]]."
        },
        "request_accepted": {
            "type": 2,
            "message": "[[FROM]] accepted [[TO]] request.",
            "user_message": "[[FROM]] accepted your invitation.",
            "supporter_message": "[[FROM]] accepted your invitation."
        },
        "user_viewed_assigned_media": {
            "type": 3,
            "message": "[[FROM]] viewed [[TO]] assigned media on [[TYPE]].",
            "user_message": "[[FROM]] viewed [[TO]] [[CONTENT_OR_MESSAGE]] on [[TYPE]].",
            "supporter_message": "[[FROM]] viewed your message on [[TYPE]], please reach out."
        },
        "media_like": {
            "type": 4,
            "message": "[[FROM]] liked media on [[TYPE]].",
            "user_message": "[[FROM]] liked [[CONTENT_OR_MESSAGE]] on [[TYPE]].",
            "supporter_message": "[[FROM]] liked [[CONTENT_OR_MESSAGE]] on [[TYPE]]."
        },
        "assigned_media_like": {
            "type": 3,
            "message": "[[FROM]] liked [[TO]] assigned media on [[TYPE]].",
            "user_message": "[[FROM]] liked [[TO]] [[CONTENT_OR_MESSAGE]] on [[TYPE]].",
            "supporter_message": "[[FROM]] liked your [[CONTENT_OR_MESSAGE]] on [[TYPE]]."
        },
        "justin_media_like": {
            "type": 5,
            "message": "[[FROM]] liked justin media.",
            "user_message": "[[FROM]] liked justin content.",
            "supporter_message": "[[FROM]] liked justin content."
        },
        "media_unlike": {
            "type": 4,
            "message": "[[FROM]] unliked media on [[TYPE]].",
            "user_message": "[[FROM]] unliked justin content.",
            "supporter_message": "[[FROM]] unliked justin content."
        },
        "assigned_media_unlike": {
            "type": 3,
            "message": "[[FROM]] unliked [[TO]] assigned media on [[TYPE]].",
            "user_message": "[[FROM]] unliked your [[CONTENT_OR_MESSAGE]] sent [[date]] on [[TYPE]].",
            "supporter_message": "[[FROM]] unliked [[TO]] [[CONTENT_OR_MESSAGE]] sent [[date]] on [[TYPE]]."
        },
        "justin_media_unlike": {
            "type": 5,
            "message": "[[FROM]] unliked justin content.",
            "user_message": "[[FROM]] unliked justin content.",
            "supporter_message": "[[FROM]] unliked justin content."
        },
        "delete_created_media": {
            "type": 3,
            "message": "[[FROM]] deleted your [[TYPE]].",
            "user_message": "[[FROM]] deleted your [[TYPE]].",
            "supporter_message": "[[FROM]] deleted your [[TYPE]]."
        },
        "delete_assigned_media": {
            "type": 3,
            "message": "[[FROM]] deleted [[TO]] assigned media on [[TYPE]].",
            "user_message": "[[FROM]] deleted [[TO]] assigned media on [[TYPE]].",
            "supporter_message": "[[FROM]] deleted [[TO]] assigned media on [[TYPE]]."
        },
        "delete_justin_media": {
            "type": 5,
            "message": "[[FROM]] deleted justin media.",
            "user_message": "[[FROM]] deleted justin media.",
            "supporter_message": "[[FROM]] deleted justin media."
        },
        "delete_justin_compilation_video": {
            "type": 5,
            "message": "[[FROM]] deleted justin compilation video.",
            "user_message": "[[FROM]] deleted justin compilation video.",
            "supporter_message": "[[FROM]] deleted justin compilation video."
        },
        "justin_compilation_video_like": {
            "type": 5,
            "message": "[[FROM]] liked justin compilation video.",
            "user_message": "[[FROM]] liked justin compilation video.",
            "supporter_message": "[[FROM]] liked justin compilation video."
        },
        "justin_compilation_video_unlike": {
            "type": 5,
            "message": "[[FROM]] unliked justin compilation video.",
            "user_message": "[[FROM]] unliked justin compilation video.",
            "supporter_message": "[[FROM]] unliked justin compilation video."
        },
        "user_press_time": {
            "type": 3,
            "message": "[[FROM]] has viewed TIME. Please reach out.",
            "user_message": "[[FROM]] has viewed TIME. Please reach out.",
            "supporter_message": "[[FROM]] has viewed TIME. Please reach out.",
            "title": "Viewed Time"
        },
        "time_media_viewed": {
            "type": 3,
            "message": "Now would be a good moment to save [[FROM]] a new TIME message.",
            "user_message": "Now would be a good moment to save [[FROM]] a new TIME message.",
            "supporter_message": "Now would be a good moment to save [[FROM]] a new TIME message.",
            "title": "Viewed Time"
        }
    }
    return activities;
});

export const addActivity = expressAsyncHandler(async(activityType, fromUser, toUser, linkID, LinkCollectionName, activityInfo) => {
    return new Promise(async(resolve, reject) => {
        try {
            const db    =   await getDBConnection();
            //let activities = await getActivities();
            //console.log(activityType, fromUser, toUser, linkID, LinkCollectionName, activityInfo);

            const fromUserRef   =   await db.doc(Users.collection.name+'/'+fromUser.toString());
            let toUserRef       =   null;
            if(activityType != "invite_new_helpinghand" && activityType != "invite_new_user" && activityType != "assign_media_for_temp_user") {
                toUserRef   =   await db.doc(Users.collection.name+'/'+toUser.toString());
            } else {
                toUserRef   =   await db.collection(TemporaryUsers.collection.name).doc(toUser.toString());
            }

            let activityObj = {};
            activityObj[Activities.fields.activity_type.key]        =   activityType;
            activityObj[Activities.fields.activity_from_ref.key]    =   fromUserRef;
            activityObj[Activities.fields.activity_info.key]        =   activityInfo;
            activityObj[Activities.fields.created_by.key]           =   fromUserRef;
            activityObj[Activities.fields.created_on.key]           =   await admin.firestore.FieldValue.serverTimestamp();

            if(toUser != undefined && toUser != null && toUser != 0 && toUser != '') {
                if(activityType == "invite_new_helpinghand" || activityType == "invite_new_user" && activityType != "assign_media_for_temp_user") {
                    activityObj[Activities.fields.activity_to_ref.key]  =   toUserRef;
                    activityObj[Activities.fields.reference_ids.key]    =   [fromUserRef, toUserRef];
                    activityObj['all_ids']                              =   [parseInt(fromUser)];
                } else if(activityType == "user_press_time" || activityType == "assigned_media_like") {  //This acivity only for supporters.
                    activityObj[Activities.fields.activity_to_ref.key]  =   toUserRef;
                    activityObj[Activities.fields.reference_ids.key]    =   [toUserRef];
                    activityObj['all_ids']                              =   [parseInt(toUser)];
                } else if(activityType == "time_media_viewed") {  //This acivity only for supporters.
                    activityObj[Activities.fields.activity_to_ref.key]  =   toUserRef;
                    activityObj[Activities.fields.reference_ids.key]    =   [toUserRef];
                    activityObj['all_ids']                              =   [parseInt(toUser)];
                } else {
                    activityObj[Activities.fields.activity_to_ref.key]  =   toUserRef;
                    activityObj[Activities.fields.reference_ids.key]    =   [fromUserRef, toUserRef];
                    activityObj['all_ids']                              =   [parseInt(fromUser), parseInt(toUser)];
                }
            } else {
                activityObj[Activities.fields.activity_to_ref.key]      =   null;
                activityObj[Activities.fields.reference_ids.key]        =   [fromUserRef];
                activityObj['all_ids']                                  =   [parseInt(fromUser)];
            }

            if(linkID != undefined && LinkCollectionName != undefined && linkID != null && LinkCollectionName != null && linkID != "" && LinkCollectionName != "" && linkID != 0) {
                activityObj[Activities.fields.activity_link_ref.key]    =   await db.doc(LinkCollectionName+'/'+linkID.toString());
            } else {
                activityObj[Activities.fields.activity_link_ref.key]    =   null;
            }
            const activityID = await insertData(Activities, activityObj, Activities.fields.activity_id.key);
            resolve(activityID);
        } catch(e) {
            reject(false);
            console.log('Catch error in common function addActivity()', e);
            var errorLog = await saveErrorLogFileWithpath('addActivity', e.stack);
            throw new Error(e.message);
        }
    });
});


export const addActivityData = expressAsyncHandler(async(db, activityType, fromUserRef, toUserRef, linkRef, currentTime, activityInfo, lastActivityID) => {
    return new Promise(async(resolve, reject) => {
        try {

            let activityObj = {};

            activityObj['activity_type']        =   activityType;
            activityObj['activity_from_ref']    =   fromUserRef;
            activityObj['activity_info']        =   activityInfo;
            activityObj['created_by']           =   fromUserRef;
            activityObj['created_on']           =   currentTime;
            activityObj['activity_id']          =   parseInt(lastActivityID);
            

            if(toUserRef != undefined && toUserRef != null && toUserRef != 0 && toUserRef != '') {
                activityObj['activity_to_ref']  =   toUserRef;
                activityObj['reference_ids']    =   [fromUserRef, toUserRef];
            } else {
                activityObj['activity_to_ref']  =   null;
                activityObj['reference_ids']    =   [fromUserRef];
            }

            if(linkRef != undefined && linkRef != null && linkRef != "" && linkRef != 0) {
                activityObj['activity_link_ref']    =   linkRef;
            } else {
                activityObj['activity_link_ref']    =   null;
            }

            resolve(activityObj);
        } catch(e) {
            reject(false);
            console.log('Catch error in common function addActivityData()', e);
            var errorLog = await saveErrorLogFileWithpath('addActivityData', e.stack);
            throw new Error(e.message);
        }
    });
});


export const addActivities = expressAsyncHandler(async(activityType, fromUser, toUsers, linkID, LinkCollectionName, activityInfo) => {
    return new Promise(async(resolve, reject) => {
        try {
            const db = await getDBConnection();
            //let activities = await getActivities();
            //console.log(activityType, fromUser, toUser, linkID, LinkCollectionName, activityInfo);

            let activityObj = {};
            activityObj[Activities.fields.activity_type.key] = activityType;
            activityObj[Activities.fields.activity_from_ref.key] = await db.doc(Users.collection.name+'/'+fromUser.toString());
            activityObj[Activities.fields.activity_info.key] = activityInfo;
            activityObj[Activities.fields.created_by.key] = await db.doc(Users.collection.name+'/'+fromUser.toString());
            activityObj[Activities.fields.created_on.key] =  await admin.firestore.FieldValue.serverTimestamp();

            if(linkID != undefined && LinkCollectionName != undefined && linkID != null && LinkCollectionName != null && linkID != "" && LinkCollectionName != "" && linkID != 0) {
                activityObj[Activities.fields.activity_link_ref.key] = await db.doc(LinkCollectionName+'/'+linkID.toString());
            } else {
                activityObj[Activities.fields.activity_link_ref.key] = null;
            }

            let docID = await getLastInsertedID(Activities.collection.name, Activities.fields.activity_id.key);

            if(toUsers != undefined && toUsers != null && toUsers.length > 0) {

                /* const batch = await db.batch(); */

                let addActivityDatas = await Promise.all(toUsers.map(expressAsyncHandler(async(toUserID, index) => {
                    return new Promise(async function(resolve, reject){

                        if(activityType == "invite_new_helpinghand") {
                            activityObj[Activities.fields.activity_to_ref.key] = await db.collection(TemporaryUsers.collection.name).doc(toUserID.toString());
                            activityObj[Activities.fields.reference_ids.key] = await [await db.doc(Users.collection.name+'/'+fromUser.toString()), await db.collection(TemporaryUsers.collection.name).doc(toUserID.toString())];

                            const activityID = await insertData(Activities, activityObj, Activities.fields.activity_id.key);
                            resolve(activityID);

                        } else if(activityType == "user_press_time" || activityType == "assigned_media_like" || activityType == "time_media_viewed") {  //This acivity only for supporters.
                            activityObj[Activities.fields.reference_ids.key] = await [await db.doc(Users.collection.name+'/'+toUserID.toString())];
                            activityObj[Activities.fields.activity_to_ref.key] = activityObj[Activities.fields.reference_ids.key][0];
                        } else {
                            activityObj[Activities.fields.reference_ids.key] = await [await db.doc(Users.collection.name+'/'+fromUser.toString()), await db.doc(Users.collection.name+'/'+toUserID.toString())];
                            activityObj[Activities.fields.activity_to_ref.key] = activityObj[Activities.fields.reference_ids.key][1];
                        }

                        //console.log('Activity', docID);

                        /* var collectionDefaultVal    =   JSON.parse(JSON.stringify(Activities.default));
                        let insertDataObj           =   Object.assign(collectionDefaultVal, activityObj);

                        const activityRef = await db.collection(Activities.collection.name).doc(docID.toString());
                        await batch.set(activityRef, insertDataObj);

                        docID = parseInt(docID) + 1; */

                        /* const activityID = await insertData(Activities, activityObj, Activities.fields.activity_id.key); */

                        const tempObj = Object.assign({}, activityObj);

                        resolve(tempObj);
                    });
                })));

                addActivityDatas.then(async(resData) => {
                    var addActivityStatus = await insertBulkData(Activities, resData, Activities.fields.activity_id.key);
                    resolve(addActivityStatus);
                }).catch(async(error) => {
                    console.log('Catch Error 2', error);
                    var errorLog = await saveErrorLogFileWithpath('ActivityError', JSON.stringify(error));
                    reject(error);
                });
                /* await batch.commit(); */
                resolve(addActivityStatus);
            } else {
                activityObj[Activities.fields.activity_to_ref.key] = null;
                activityObj[Activities.fields.reference_ids.key] = [await db.doc(Users.collection.name+'/'+fromUser.toString())];
                const activityID = await insertData(Activities, activityObj, Activities.fields.activity_id.key);
                resolve(activityID);
            }
        } catch(e) {
            reject(false);
            console.log('Catch error in common function addActivity()', e);
            var errorLog = await saveErrorLogFileWithpath('addActivity', e.stack);
            throw new Error(e.message);
        }
    });
});

export const getNotifications = expressAsyncHandler(async() => {
    const notifications = {
        "user_sms_verified": {
            "type": 1,
            "message": "[[FROM]] verified sms.",
            "user_message": "[[FROM]] verified sms.",
            "supporter_message": "[[FROM]] verified sms.",
            "title": "SMS Verified"
        },
        "add_onborading_media": {
            "type": 4,
            "message": "[[FROM]] added on [[TYPE]].",
            "user_message": "[[FROM]] recorded your first [[TYPE]].",
            "supporter_message": "[[FROM]] recorded your first [[TYPE]].",
            "title": "Added onboarding"
        },
        "check_in": {
            "type": 4,
            "message": "[[FROM]] has checked in the mood [[CHECK_IN_TYPE]]. Please reach out.",
            "user_message": "[[FROM]] has checked in the mood [[CHECK_IN_TYPE]]. Please reach out.",
            "supporter_message": "[[FROM]] has checked in the mood [[CHECK_IN_TYPE]]. Please reach out.",
            "title": "Check in"
        },
        "request_accepted": {
            "type": 2,
            "message": "[[FROM]] accepted [[TO]] request.",
            "user_message": "[[FROM]] accepted your invitation",
            "supporter_message": "[[FROM]] accepted your invitation",
            "title": "Accepted Invitation"
        },
        "assigned_media_like": {
            "type": 3,
            "message": "[[FROM]] liked [[TO]] assigned media on [[TYPE]].",
            "user_message": "[[FROM]] liked your content.",
            "supporter_message": "[[FROM]] liked your content.",
            "title": "Liked Your Content"
        },
        "assigned_media_unlike": {
            "type": 3,
            "message": "[[FROM]] unliked [[TO]] assigned media on [[TYPE]].",
            "user_message": "[[FROM]] has liked your content.",
            "supporter_message": "[[FROM]] has liked your content.",
            "title": "Unliked Your Content"
        },
        "assign_media": {
            "type": 3,
            "message": "[[FROM]] saved [[CONTENT_OR_MESSAGE]] to your [[TYPE]].",
            "user_message": "[[FROM]] saved [[CONTENT_OR_MESSAGE]] to your [[TYPE]].",
            "supporter_message": "[[FROM]] saved [[CONTENT_OR_MESSAGE]] to your [[TYPE]].",
            "title": "New Message on [[TYPE]]"
        },
        "assign_media_for_temp_user": {
            "type": 3,
            "message": "[[FROM]] saved [[CONTENT_OR_MESSAGE]] to your [[TYPE]].",
            "user_message": "[[FROM]] saved [[CONTENT_OR_MESSAGE]] to your [[TYPE]].",
            "supporter_message": "[[FROM]] saved [[CONTENT_OR_MESSAGE]] to your [[TYPE]].",
            "title": "New Message on [[TYPE]]"
        },
        "user_resigned_supporter": {
            "type": 3,
            "message": "[[FROM]] resigned [[TO]] supporter.",
            "user_message": "[[FROM]] has resigned you from being a helping hand.",
            "supporter_message": "[[FROM]] has resigned you from being a helping hand.",
            "title": "Resigned"
        },
        "supporter_resigned_user": {
            "type": 3,
            "message": "[[FROM]] resigned [[TO]] user.",
            "user_message": "[[FROM]] has resigned from being a supporting hand.",
            "supporter_message": "[[FROM]] has resigned from being a supporting hand.",
            "title": "Resigned"
        },
        "user_viewed_assigned_media": {
            "type": 3,
            "message": "[[FROM]] viewed [[TO]] assigned media on [[TYPE]].",
            "user_message": "[[FROM]] has viewed your content.",
            "supporter_message": "[[FROM]] has viewed your content.",
            "title": "Viewed Your Content"
        },
        "user_press_time": {
            "type": 3,
            "message": "[[FROM]] has viewed TIME. Please reach out.",
            "user_message": "[[FROM]] has viewed TIME. Please reach out.",
            "supporter_message": "[[FROM]] has viewed TIME. Please reach out.",
            "title": "Viewed Time"
        },
        "intimate_media_on_register": {
            "type": 3,
            "message": "[[FROM]] posted media.",
            "user_message": "[[FROM]] posted media",
            "supporter_message": "[[FROM]] posted media",
            "title": "Posted media"
        }
    };
    return notifications;
});

export const pushNotification = expressAsyncHandler(async(db, messages) => {
    return new Promise((resolve, reject) => {
        const notification_options = {
            priority: "high",
            timeToLive: 60 * 60 * 24
        };
        //console.log(messages);
        admin.messaging().send(messages)
        .then((response) => {
            console.log('Successfully sent message:', response);
            let tempObj = {
                'status': true,
                'response': response
            }
            resolve(tempObj);
        })
        .catch((error) => {
            //console.log('Error sending message:', error);
            let tempObj = {
                'status': false,
                'response': error.toString()
            }
            //let logError = saveErrorLogFile(error.toString());
            let logError = saveErrorLogFileWithpath('sendPushNotification', error.toString());
            resolve(tempObj);
        });        
    });
});

export const buildPushNotificationMessage = expressAsyncHandler(async(sessionUserRole, notificationType, fromUserDetail, toUserDetail, detail) => {
    let notifications = await getNotifications();
    return new Promise(async (resolve, reject) => {
        try {
            let check_in_type = { "1": "GREAT", "2":"SO SO", "3": "STRUGGLING" };
            let globalMediaType = {"1": "videos", "2": "photos", "3": "audios"};
            let globalType = {"1": "goal statement", "2": "Time", "3": "inspiration"};
            let globalType2 = {"1": "goal statement", "2": "Time", "3": "Inspiration"};

            let title = notifications[notificationType]['title'];
            let message = (toUserDetail['user_role'] == 1) ? notifications[notificationType]['user_message'] : notifications[notificationType]['supporter_message'];
            let fromUserName = fromUserDetail['first_name']+' '+fromUserDetail['last_name'];
            fromUserName = fromUserName.trim();
            //fromUserName = "You";
            let toUserName =  (toUserDetail['first_name'] != undefined) ? toUserDetail['first_name']+' '+toUserDetail['last_name'] : '';
            toUserName = toUserName.trim();
            message = message.replace("[[FROM]]", fromUserName);
            message = message.replace("[[TO]]", toUserName);

            if(detail.hasOwnProperty('type') && detail.hasOwnProperty('type_for_user') && detail.hasOwnProperty('media')) {

                //message = message.replace("[[MEDIA]]", globalMediaType[detail['media'].toString()]);
                                
                message = message.replace("[[CONTENT_OR_MESSAGE]]", (detail['type'] == 2) ? 'a message' : 'content');

                message = message.replace("[[TYPE]]", globalType[detail['type'].toString()]);

                title = title.replace("[[TYPE]]", globalType2[detail['type'].toString()]);

            } else if(detail.hasOwnProperty('check_in_type')) {
                message = message.replace("[[CHECK_IN_TYPE]]", detail['check_in_type']);
            }

            resolve({'message': message, 'title': title});
        } catch(e) {
            var logError = await saveErrorLogFileWithpath('buildPushNotificationMessage', e.stack);
            reject(e.stack);
        }
    });
});


export const addNotification = expressAsyncHandler(async(notificationType, fromUser, toUsers, linkID, LinkCollectionName, notificationInfo) => {
    return new Promise(async(resolve, reject) => {
        try {
            const db                =   await getDBConnection();
            const sessionUserRole   =   await getUserRole(fromUser);
            
            let fromUserDetail      =   [];
            let insertNotification  =   [];

            let notificationObj     =   {};

            const fromUserRef       =   await db.collection(Users.collection.name).doc(fromUser.toString());
            const currentTime       =   await admin.firestore.FieldValue.serverTimestamp();

            notificationObj[Notifications.fields.notification_type.key]     =   notificationType;
            notificationObj[Notifications.fields.notification_from_ref.key] =   fromUserRef;
            notificationObj[Notifications.fields.notification_info.key]     =   notificationInfo;
            notificationObj[Notifications.fields.created_by.key]            =   fromUserRef;
            notificationObj[Notifications.fields.created_on.key]            =   currentTime;

            const fromUserDocRef    =   await db.collection(Users.collection.name).doc(fromUser.toString()).get();

            if(!fromUserDocRef.exists) {
                return reject(false);
            }

            fromUserDetail  =   await { 'id': fromUserDocRef.id, ... await fromUserDocRef.data() };

            if(linkID != undefined && LinkCollectionName != undefined && linkID != null && LinkCollectionName != null && linkID != "" && LinkCollectionName != "" && linkID != 0) {
                notificationObj[Notifications.fields.notification_link_ref.key] =   await db.collection(LinkCollectionName).doc(linkID.toString());
            } else {
                notificationObj[Notifications.fields.notification_link_ref.key] = null;
            }

            if(toUsers != undefined && toUsers != null && toUsers.length > 0) {

                for await (const toUser of toUsers) {

                    let tempPushNotification    =   {};
                    let pushNotificationResponse;

                    console.log('User ID ==>', toUser);

                    const toUserDocRef    =   await db.collection(Users.collection.name).doc(toUser.toString()).get();

                    if(!toUserDocRef.exists) {
                        continue;
                    }

                    const tempToUserDetail  =   await { 'id': toUserDocRef.id, ... await toUserDocRef.data() };

                    const toUserRef         =   await db.collection(Users.collection.name).doc(toUser.toString());

                    let tempNotification    =   { ...notificationObj };

                    tempNotification[Notifications.fields.notification_to_ref.key]  =   toUserRef;
                    tempNotification[Notifications.fields.reference_ids.key]        =   [fromUserRef, toUserRef];
                    tempNotification[Notifications.fields.all_ids.key]              =   [parseInt(fromUser), parseInt(toUser)];
                    
                    tempNotification[Notifications.fields.device_token.key]         =   tempToUserDetail['device_token'];

                    const notificationMessage   =   await buildPushNotificationMessage(sessionUserRole, notificationType, fromUserDetail, tempToUserDetail, notificationInfo);

                    tempNotification[Notifications.fields.message.key]  =   notificationMessage['message'];

                    tempPushNotification['notification']    =   { 'title': notificationMessage['title'], 'body': notificationMessage['message'] };
                    tempPushNotification['android']         =   { notification: { sound: 'time_notification.wav', priority: "high" } };
                    tempPushNotification['apns']            =   { payload: { aps: { sound: 'time_notification.wav', "headers": { "apns-priority": "5" } } } };
                    tempPushNotification['token']           =   tempToUserDetail['device_token'];

                    tempPushNotification['data'] = {
                        'action_type'   :   notificationType.toUpperCase(),
                        'user_role'     :   tempToUserDetail['user_role'].toString()
                    };

                    if(tempToUserDetail['device_token'] != '') {

                        pushNotificationResponse = await pushNotification(db, tempPushNotification);

                        if(pushNotificationResponse.status) {
                            tempNotification[Notifications.fields.status.key] = 1;
                            tempNotification[Notifications.fields.fcm_response.key] = pushNotificationResponse.response;
                        } else {
                            tempNotification[Notifications.fields.status.key] = 0;
                            tempNotification[Notifications.fields.fcm_response.key] = pushNotificationResponse.response;
                        }
                    } else {
                        tempNotification[Notifications.fields.status.key] = 0;
                        tempNotification[Notifications.fields.fcm_response.key] = "FCM token is empty.";
                    }

                    insertNotification.push(tempNotification);

                    //console.log('tempNotification', tempNotification);

                    //const insertStatus = await insertData(Notifications, tempNotification, Notifications.fields.notification_id.key);
                }
            }

            //console.log('insertNotification', insertNotification);

            const notificationID = await insertBulkData(Notifications, insertNotification, Notifications.fields.notification_id.key);
            resolve(true);
        } catch(e) {
            reject(false);
            console.log('Catch error in common function addNotification()', e);
            saveErrorLogFileWithpath('addNotification', e.stack);
            throw new Error(e.message);
        }
    });
});

export const getUserActivities = expressAsyncHandler(async(userID) => {
    const db = await getDBConnection();
    let defaultActivities = await getActivities();
    let allActivity = db.collection(Activities.collection.name).where(Activities.fields.activity_from_ref.key, 'in', [db.doc(Users.collection.name+'/'+userID.toString())]).where(Activities.fields.activity_to_user_view_status.key, 'in', [db.doc(Users.collection.name+'/'+userID.toString())]).orderBy(Activities.fields.created_on.key, 'desc').get();
    let activitiesList = await Promise.all(allActivity.docs.map(async (activity, index) => {
        return new Promise(function(resolve, reject){
            setTimeout(expressAsyncHandler(async() => {
                let tempActivity = await activity.data();
                tempActivity['activity_message'] = activity[Activities.fields.activity_type.key];
                tempActivity['activity_message'] = defaultActivities[tempActivity['activity_message']];
                let getReferenceLinks = [activity[Activities.fields.activity_from_ref.key]];
                if(activity[Activities.fields.activity_to_ref.key] == null) {
                    getReferenceLinks.push(activity[Activities.fields.activity_to_ref.key]);
                }
                if(activity[Activities.fields.activity_link_ref.key] == null) {
                    getReferenceLinks.push(activity[Activities.fields.activity_link_ref.key]);
                }
                db.getAll(getReferenceLinks).then(docs => {
                    let fromUserName = docs[0].get('first_name')+' '+docs[0].get('last_name');
                    tempActivity['activity_message'] = tempActivity['activity_message'].replace("[[FROM]]", fromUserName);
                    if(docs.length > 1) {
                        let toUserName = docs[1].get('first_name')+' '+docs[1].get('last_name');
                        tempActivity['activity_message'] = tempActivity['activity_message'].replace("[[TO]]", toUserName);
                    } else if(docs.length > 2) {
                        let linkID = '<a id="'+docs[1].id+'">';
                        tempActivity['activity_message'] = tempActivity['activity_message'].replace("[[LINK]]", linkID);
                        tempActivity['activity_message'] = tempActivity['activity_message'].replace("[[/LINK]]", '</a>');
                    }
                    resolve(tempActivity);
                }).catch(err => reject(err));
            }));
        });
    }));
});



export const fileUploadLocal = expressAsyncHandler(async(file, filePath, fileName, next) => {
    try {
        let createPath = await createDirectoryLocal(filePath);
        return new Promise(function(resolve, reject) {
            fs.writeFileSync(filePath+fileName, file.buffer);
            resolve(fileName);
        });
    } catch(e) {
        console.log('Catch error in common function fileUpload()');
        var errorLog = await saveErrorLogFileWithpath('fileUpload', e.stack);
        throw new Error(e.message);
    }
});

export const generalFileUpload = expressAsyncHandler(async(file, filePath, fileName, next) => {
    return new Promise(async function(resolve, reject) {
        try {
            if(process.env.MODE == "development") {

                const createPath    =   await createDirectoryLocal(filePath);
                fs.writeFileSync(filePath+fileName, file.buffer);
                resolve(true);

            } else {

                const storage       =   await getStorageConnection();
                const bucket        =   await storage.bucket();

                const blob          =   await bucket.file(filePath+fileName);
                const blobWriter    =   await blob.createWriteStream({
                    metadata: {
                        contentType: file.mimetype
                    }
                });
                
                blobWriter.on('error', async(err) => {
                    var errorLog = await saveErrorLogFileWithpath('generalFileUpload', err.toString());
                    console.log('File upload generalFileUpload error', err);
                    resolve(false);
                });
                
                blobWriter.on('finish', () => {
                    resolve(true); // when successful
                });
                blobWriter.end(file.buffer)

            }
        } catch(e) {
            console.log('Catch error in common function generalFileUpload()');
            var errorLog = await saveErrorLogFileWithpath('generalFileUpload', e.stack);
            resolve(false);
        }
    });
});

export const fileUpload = expressAsyncHandler(async(file, filePath, fileName, next) => {
    try {
        const storage = await getStorageConnection();
        var bucket = await storage.bucket();
        return new Promise(function(myResolve, myReject) {
            const blob = bucket.file(filePath+fileName);
            const blobWriter = blob.createWriteStream({
                metadata: {
                    contentType: file.mimetype
                }
            })
            
            blobWriter.on('error', async(err) => {
                var errorLog = await saveErrorLogFileWithpath('fileupload', err.toString());
                console.log('File upload error', err);
                throw new Error('Something went wrong');
                //next(error);
                //myReject(err);  // when error
            })
            
            blobWriter.on('finish', () => {
                myResolve(fileName); // when successful
            });
            blobWriter.end(file.buffer)
        });
    } catch(e) {
        console.log('Catch error in common function fileUpload()');
        var errorLog = await saveErrorLogFileWithpath('fileUpload', e.stack);
        throw new Error(e.message);
        //let error = new Error(e.message);
        //next(error);
    }
});

export const copyFile = expressAsyncHandler(async(sourceFileName, destinationPath, next) => {
    return new Promise((resolve, reject) => {
        setTimeout(expressAsyncHandler(async() => {
            try {
                const storage = await getStorageConnection();
                var bucket = await storage.bucket();
                let fileDetail = await bucket.file(sourceFileName);
                fileDetail.exists().then(function(data) {
                    const exists = data[0];
                    if(data[0]) {
                        fileDetail.get().then(function(data) {
                            const file = data[0];
                            const apiResponse = data[1];
                            setTimeout(expressAsyncHandler(async() => {
                                await bucket.file(apiResponse.name).copy(destinationPath).then(function(data) {
                                    if(data) {
                                        console.log('File copy is success');
                                        resolve(true);
                                    } else {
                                        console.log('File copy is failed');
                                        let error = new Error('Something went wrong.');
                                        next(error);
                                        resolve(false);
                                    }
                                });
                            }));
                        });
                    } else {
                        console.log('File copy is failed');
                        resolve(false);
                    }
                });
            } catch(e) {
                reject(false);
                console.log('Catch error in common function', e);
                var errorLog = await saveErrorLogFileWithpath('copyFile', e.stack);
                throw new Error(e.message);
                //let error = new Error(e.message);
                //next(error);
            }
        }));
    });
});

export const generalFileCopy = expressAsyncHandler(async(sourceFile, destination, destinationFolder, next) => {
    return new Promise(async(resolve, reject) => {
        if(process.env.MODE == "development") {
            try {
                const createFolder    =   await createDirectoryLocal(destinationFolder);
                await fs.copyFile(sourceFile, destination, (err) => {
                    if(err) {
                        console.log(err);
                        saveErrorLogFileWithpath('generalFileCopy', err.message);
                        resolve(false);
                    } else {
                        resolve(true);
                    }
                });
            } catch(e) {
                reject(false);
                console.log('Catch error in common function', e);
                var errorLog = await saveErrorLogFileWithpath('generalFileCopy', e.stack);
                throw new Error(e.message);
                //let error = new Error(e.message);
                //next(error);
            }
        } else {
            try {
                const storage   =   await getStorageConnection();
                var bucket      =   await storage.bucket();
                let fileDetail  =   await bucket.file(sourceFile);

                fileDetail.exists().then(function(data) {
                    
                    const exists = data[0];

                    if(data[0]) {
                        fileDetail.get().then(async function(data) {
                            const file          =   data[0];
                            const apiResponse   =   data[1];

                            await bucket.file(apiResponse.name).copy(destination).then(function(data) {
                                if(data) {
                                    console.log('File copy is success');
                                    resolve(true);
                                } else {
                                    console.log('File copy is failed');
                                    let error = new Error('Something went wrong.');
                                    next(error);
                                    resolve(false);
                                }
                            });
                        });
                    } else {
                        console.log('File copy is failed');
                        resolve(false);
                    }
                });
            } catch(e) {
                reject(false);
                console.log('Catch error in common function', e);
                var errorLog = await saveErrorLogFileWithpath('generalFileCopy', e.stack);
                throw new Error(e.message);
                //let error = new Error(e.message);
                //next(error);
            }
        }
    });
});

export const generalDeleteFile = expressAsyncHandler(async(filePath, next) => {
    return new Promise(async(resolve, reject) => {

        var pathLog = await saveErrorLogFileWithpath('generalDeleteFile', 'Deleting path ==> '+filePath);

        if(process.env.MODE == "development") {
            try {
                await fs.unlink(filePath, (async(err) => {
                    if(err) {
                        console.log('error', err);
                        resolve(false);
                    } else {
                        resolve(true);
                    }
                }));
            } catch(e) {
                reject(false);
                console.log('Catch error in common function', e);
                var errorLog = await saveErrorLogFileWithpath('generalDeleteFile', e.stack);
                throw new Error(e.message);
                //let error = new Error(e.message);
                //next(error);
            }
        } else {
            try {
                const storage = await getStorageConnection();
                var bucket = await storage.bucket();
                let fileDetail = await bucket.file(filePath);
                fileDetail.exists().then(function(data) {
                    const exists = data[0];
                    if(data[0]) {
                        fileDetail.get().then(async function(data) {
                            const file = data[0];
                            const apiResponse = data[1];
                            await bucket.file(apiResponse.name).delete();
                            console.log('Delete success');
                            resolve(true);
                        });
                    } else {
                        console.log('Delete Failed');
                        resolve(false);
                    }
                });
            } catch(e) {
                reject(false);
                console.log('Catch error in common function', e);
                var errorLog = await saveErrorLogFileWithpath('generalDeleteFile', e.stack);
                throw new Error(e.message);
                //let error = new Error(e.message);
                //next(error);
            }
        }
    });
});

export const deleteFile = expressAsyncHandler(async(fileName, next) => {
    return new Promise(async (resolve, reject) => {
        try {
            const storage = await getStorageConnection();
            var bucket = await storage.bucket();
            let fileDetail = await bucket.file(fileName);
            fileDetail.exists().then(function(data) {
                const exists = data[0];
                if(data[0]) {
                    fileDetail.get().then(function(data) {
                        const file = data[0];
                        const apiResponse = data[1];
                        setTimeout(expressAsyncHandler(async() => {
                            await bucket.file(apiResponse.name).delete();
                            console.log('Delete success');
                            resolve(true);
                        }));
                    });
                } else {
                    console.log('Delete Failed');
                    resolve(false);
                }
            });
        } catch(e) {
            reject(false);
            console.log('Catch error in common function', e);
            var errorLog = await saveErrorLogFileWithpath('deleteFile', e.stack);
            throw new Error(e.message);
            //let error = new Error(e.message);
            //next(error);
        }
    });
});

export const createDirectoryLocal = expressAsyncHandler(async(createDirectory, next) => {
    return new Promise((resolve, reject) => {
        setTimeout(expressAsyncHandler(async() => {
            try {
                let isDirectoryExists = await fs.existsSync(createDirectory);
                if(!isDirectoryExists) {
                    await fs.mkdirSync(createDirectory, { recursive: true });	//Create path, if directory not exists
                }
                resolve(true);
            } catch(e) {
                reject(false);
                console.log('Catch error in common function', e);
                var errorLog = await saveErrorLogFileWithpath('createDirectoryLocal', e.stack);
                throw new Error(e.message);
                //let error = new Error(e.message);
                //next(error);
            }
        }));
    });
});

export const copyFileLocal = expressAsyncHandler(async(sourceFile, destination, next) => {
    return new Promise(async(resolve, reject) => {
        try {
            await fs.copyFile(sourceFile, destination, (err) => {
                if(err) {
                    console.log(err);
                    resolve(false);
                } else {
                    resolve(true);
                }
            });
        } catch(e) {
            reject(false);
            console.log('Catch error in common function', e);
            var errorLog = await saveErrorLogFileWithpath('copyFileLocal', e.stack);
            throw new Error(e.message);
            //let error = new Error(e.message);
            //next(error);
        }
    });
});

export const deleteFileLocal = expressAsyncHandler(async(file, next) => {
    return new Promise((resolve, reject) => {
        setTimeout(expressAsyncHandler(async() => {
            try {
                await fs.unlink(file, (async(err) => {
                    if(err) {
                        resolve(false);
                    } else {
                        resolve(true);
                    }
                }));
            } catch(e) {
                reject(false);
                console.log('Catch error in common function', e);
                var errorLog = await saveErrorLogFileWithpath('deleteFileLocal', e.stack);
                throw new Error(e.message);
                //let error = new Error(e.message);
                //next(error);
            }
        }));
    });
});

export const getCurrentGMTTime = expressAsyncHandler(async(next) => {
    return new Promise((resolve, reject) => {
        setTimeout(expressAsyncHandler(async() => {
            let currentTime = await admin.firestore.Timestamp.now(Date.now());
            resolve(currentTime);
            //return currentTime;
        }));
    });
});

export const getMediaName = expressAsyncHandler(async(next) => {
    return new Promise((resolve, reject) => {
        setTimeout(expressAsyncHandler(async() => {
            let mediaName = Date.now();
            let randomNumber = Math.floor(Math.random() * 899999 + 100000);
            randomNumber = randomNumber.toString().substring(0, 2);
            randomNumber =  parseInt(randomNumber);
            mediaName = randomNumber+'_'+mediaName;
            resolve(mediaName);
            //return mediaName;
        }));
    });
});


export const saveErrorLogFileWithpath = expressAsyncHandler(async(path, message) => {
    try {
        return new Promise(async function(resolve, reject) {
            const storage = await getStorageConnection();
            var bucket = await storage.bucket();
            var date = new Date();
            //var name = date.getDate()  + "-" + (date.getMonth()+1) + "-" + date.getFullYear()+'_'+date.getTime()+'.log';
            var name = date.getDate()  + "-" + (date.getMonth()+1) + "-" + date.getFullYear()+'.log';
            var time = date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
            var fileName = 'public/logs/'+path+'/'+name;
            const file = bucket.file(fileName);
            message = message +' =====> ['+time+']';
            let existingMessage = "";
            file.exists().then(async function(data) {
                if(data[0]) {
                    file.createReadStream()
                        .on('error', function(err) {
                            console.log(err);
                            resolve(true);
                        })
                        .on('data', function(datas) {
                            var buf             =   Buffer.from(datas);
                            existingMessage     =   existingMessage + " " + buf.toString();
                        })
                        .on('end', function() {
                            message     =   existingMessage+"\n\n"+message;
                            file.save(message, { resumable: false }, function(err) {
                                if(err) {
                                    console.log('Catch error in common function saveFile()', err);
                                    //throw new Error('Catch error in common function saveFile()');
                                }
                                resolve(true);
                            });
                        });
                } else {
                    file.save(message, function(err) {
                        if(err) {
                            console.log('Catch error in common function saveFile()', err);
                            //throw new Error('Catch error in common function saveFile()');
                        }
                        resolve(true);
                    });
                }
            });
        });    
    } catch(e) {
        console.log('Catch error in common function saveFile()', e);
        var errorLog = await saveErrorLogFileWithpath('saveFile', e.stack);
        /* let error = new Error(e.message);
        next(error); */
        //throw new Error(e.message);
    }
});

export const saveErrorLogFile = expressAsyncHandler(async(message) => {
    try {
        const storage = await getStorageConnection();
        var bucket = await storage.bucket();
        var date = new Date();
        var name = date.getDate()  + "-" + (date.getMonth()+1) + "-" + date.getFullYear()+'_'+date.getTime()+'.log';
        var fileName = 'public/logs/'+name;
        const file = bucket.file(fileName);
        file.save(message, function(err) {
            if(err) {
                console.log('Catch error in common function saveFile()');
                throw new Error('Catch error in common function saveFile()');
            }
        });
    } catch(e) {
        console.log('Catch error in common function saveFile()');
        /* let error = new Error(e.message);
        next(error); */
        throw new Error(e.message);
    }
});

export const getJustinPopulatedImages = expressAsyncHandler(async(req, userID, mediaFilters, currentPage, minDateTime, detail, next) => {
    return new Promise(async function(resolve, reject) {
        try {
            const db            =   await getDBConnection();
            const userRole 	    =   await getUserRole(userID);
            let total           =   0;

            if(mediaFilters.type == 3) {
                let populateRef	= await db.collection(PopulateImages.collection.name);
                //Working
                let likedPopulatedIDs       =   [];
                let deletedPopulatedIDs     =   [];
                let reportedPopulatedIDs    =   [];
                let removePopulatedIDs      =   [];

                const userPopRef            =   await db.collection(PopulatedImagesLikeDeteleDetails.collection.name).doc(userID.toString()).get();

                if(userPopRef.exists) {
                    const userpopDetails    =   await { id: userPopRef.id, ... await userPopRef.data() };

                    if(userpopDetails["deleted_populated_images_ids"] !== undefined && userpopDetails["deleted_populated_images_ids"].length > 0) {
                        deletedPopulatedIDs =   userpopDetails["deleted_populated_images_ids"];
                        removePopulatedIDs.push(...userpopDetails["deleted_populated_images_ids"]);
                    }
                    if(userpopDetails["liked_populated_images_ids"] !== undefined && userpopDetails["liked_populated_images_ids"].length > 0) {
                        likedPopulatedIDs =   userpopDetails["liked_populated_images_ids"];
                    }
                    if(userpopDetails["reported_populated_images_ids"] !== undefined && userpopDetails["reported_populated_images_ids"].length > 0) {
                        reportedPopulatedIDs    =   userpopDetails["reported_populated_images_ids"];
                        removePopulatedIDs.push(...userpopDetails["reported_populated_images_ids"]);
                    }
                }

                populateRef		    =   await populateRef.where('user_role', '==', parseInt(userRole));
                populateRef		    =   await populateRef.where(PopulateImages.fields.status.key, '==', 1);

                let getMediasTotal  =   await populateRef.get();
                total               =   await getMediasTotal.size;
                total               =   total - deletedPopulatedIDs.length;

                var filMeMaxDateTi  =   (mediaFilters.max_date_time != undefined) ? mediaFilters.max_date_time : 0;

                if(currentPage != null && currentPage != 1 && minDateTime == 0 && filMeMaxDateTi == 0) {
                    return resolve({ 'total': total, populated_medias: []  });
                }

                //console.log('currentPage', currentPage, 'minDateTime', minDateTime, 'filMeMaxDateTi', filMeMaxDateTi);

                if(currentPage != null && minDateTime != 0 && filMeMaxDateTi != 0) {
                    let fromDate    =   await admin.firestore.Timestamp.fromDate(new Date(filMeMaxDateTi));
                    let toDate      =   await admin.firestore.Timestamp.fromDate(new Date(minDateTime));
                    populateRef		=   await populateRef.where(PopulateImages.fields.created_on.key, '<', fromDate);
                    populateRef		=   await populateRef.where(PopulateImages.fields.created_on.key, '>=', toDate);
                } else if(currentPage != null && minDateTime != 0) {
                    let toDate      =   await admin.firestore.Timestamp.fromDate(new Date(minDateTime));
                    populateRef		=   await populateRef.where(PopulateImages.fields.created_on.key, '>=', toDate);
                } else if(currentPage != null && filMeMaxDateTi != 0) {
                    let toDate      =   await admin.firestore.Timestamp.fromDate(new Date(filMeMaxDateTi));
                    populateRef		=   await populateRef.where(PopulateImages.fields.created_on.key, '<', toDate);
                }

                /* if(minDateTime != 0 && maxDateTime != 0 && perPage != 0 && totalMedias > perPage) {
                    let fromDate    =   await admin.firestore.Timestamp.fromDate(new Date(minDateTime));
                    let toDate      =   await admin.firestore.Timestamp.fromDate(new Date(maxDateTime));
                    populateRef		=   await populateRef.where(PopulateImages.fields.created_on.key, '>=', fromDate);
                    populateRef		=   await populateRef.where(PopulateImages.fields.created_on.key, '<=', toDate);
                } */

                populateRef		    =   await populateRef.orderBy(PopulateImages.fields.created_on.key, 'desc');

                let populatelist    =   await populateRef.get();

                //console.log(populatelist.size, 'populatelist.size');

                if(populatelist.empty) {
                    return resolve({ 'total': total, populated_medias: []  });
                } else {

                    let all_populatelist   =   [];

                    //console.log("populatelist", populatelist.size);

                    for await(const popDoc of populatelist.docs) {

                        //console.log("removePopulatedIDs", removePopulatedIDs.includes(parseInt(popDoc.id)), mediaFilters.show_favorite_medias_only && !likedPopulatedIDs.includes(parseInt(popDoc.id)));

                        if(removePopulatedIDs.includes(parseInt(popDoc.id))) {
                            continue;
                        }

                        if(mediaFilters.show_favorite_medias_only && !likedPopulatedIDs.includes(parseInt(popDoc.id))) {
                            continue;
                        }

                        let temopiObj                   =   {};
                        const mediaData                 =   await popDoc.data();
                        temopiObj['id'] 		        =   parseInt(popDoc.id);
                        temopiObj['caption'] 		    =   mediaData.caption;
                        temopiObj['populate_image']		=   mediaData.populate_image;
                        temopiObj['populate_video']		=   mediaData.populate_video;
                        temopiObj['populate_thumbnail']	=   mediaData.populate_thumbnail;
                        temopiObj['created_on'] 		=   mediaData.created_on.toDate();
                        temopiObj['media_types'] 		=   [mediaData.media_type];
                        temopiObj['created_user_name'] 	=   "All";

                        let tempDate                    =   new Date(temopiObj['created_on']);
                        let tempTime                    =   tempDate.getTime();
                        temopiObj['sort_date']          =   tempTime;

                        if(temopiObj['populate_image'] != '' && temopiObj['populate_image'].length > 0) {
                            temopiObj['populate_image'] =   await getMediaBaseURL('populate_image', req.hostname, temopiObj);
                        }

                        if(temopiObj['populate_video'] != undefined && temopiObj['populate_video'] != '') {
                            temopiObj['populate_video'] =   await getMediaBaseURL('populate_video', req.hostname, temopiObj);
                        }

                        if(temopiObj['populate_thumbnail'] != undefined && temopiObj['populate_thumbnail'] != '') {
                            temopiObj['populate_thumbnail'] =   await getMediaBaseURL('populate_thumbnail', req.hostname, temopiObj);
                        }

                        temopiObj['is_liked']   =   likedPopulatedIDs.includes(parseInt(temopiObj['id'])) ? true : false;

                        all_populatelist.push(temopiObj);

                    }

                    return resolve({ 'total': total, populated_medias: all_populatelist  });
                }
            } else {
                return resolve({ 'total': total, populated_medias: [] });
            }
        } catch(e) {
            console.log('Catch error in common function', e);
            var errorLog = await saveErrorLogFileWithpath('getJustinPopulatedImages', e.stack);
            //throw new Error(e.message);
            //next(e.message);
            return resolve({ 'total': 0, populated_medias: [] });
        } 
    });
});


export const getJustinCompilationVideos = expressAsyncHandler(async(req, userID, mediaFilters) => {
    try {
        let db = await getDBConnection();
        if(mediaFilters.type == 3) {
            let justinCompilationRef	= await db.collection(JustinCompilation.collection.name);
            let skipVideos = await justinCompilationRef.where(JustinCompilation.fields.deleted_user_ids.key, 'array-contains', parseInt(userID)).get();
            if(skipVideos.size > 0) {
                let deletedCompiledVideosIDS = await Promise.all(skipVideos.docs.map(async (doc, index) => {
                    return new Promise(function(resolve, reject){
                        setTimeout(expressAsyncHandler(async() => {
                            resolve(doc.get(JustinCompilation.fields.justincompilation_id.key));
                        }));
                    })
                }));
                justinCompilationRef = await justinCompilationRef.where(JustinCompilation.fields.justincompilation_id.key, 'not-in', deletedCompiledVideosIDS);
            }      
            if(mediaFilters.show_favorite_medias_only) {
                justinCompilationRef		= await justinCompilationRef.where(JustinCompilation.fields.liked_user_ids.key, 'array-contains', parseInt(userID));
            }
            justinCompilationRef		= await justinCompilationRef.where(JustinCompilation.fields.status.key, '==', 1).orderBy(JustinCompilation.fields.justincompilation_id.key, 'desc');
            let justinCompilationList= await justinCompilationRef.get();
            if(justinCompilationList.empty) {
                return [];
            } else {
                let allJustinComiplationVideos = await Promise.all(justinCompilationList.docs.map(async (doc, index) => {
                    return new Promise(function(resolve, reject){
                        setTimeout(expressAsyncHandler(async() => {
                            let temopiObj = {};
                            temopiObj['id'] 		                = await doc.id;
                            temopiObj['justincompilation_id'] 		= await doc.get(JustinCompilation.fields.justincompilation_id.key);
                            temopiObj['video_file']		            = await doc.get(JustinCompilation.fields.video_file.key);
                            temopiObj['thumbnail_name']		        = await doc.get(JustinCompilation.fields.thumbnail_name.key);
                            temopiObj['durations']		            = await doc.get(JustinCompilation.fields.durations.key);
                            temopiObj['created_on'] 		        = await doc.get(JustinCompilation.fields.created_on.key).toDate();
                            temopiObj['liked_user_ids']             = await doc.get(JustinCompilation.fields.liked_user_ids.key);
                            temopiObj['media_type'] 		        = 1;
                            temopiObj['created_user_name'] 	        = "Justin";
                            if(temopiObj['video_file'] != undefined && temopiObj['video_file'].length > 0) {
                                if(process.env.MODE == "development") {
                                    temopiObj['video_file']         =   'http://'+req.hostname+':'+process.env.PORT+'/public/justincompilation/'+temopiObj['video_file'];
                                    temopiObj['thumbnail_name']     =   'http://'+req.hostname+':'+process.env.PORT+'/public/justincompilation/thumbnail/'+temopiObj['thumbnail_name'];
                                } else {
                                    temopiObj['video_file']         =   process.env.STORAGE_BASE_URL+'public%2Fjustincompilation%2F'+temopiObj['video_file']+'?alt=media';
                                    temopiObj['thumbnail_name']     =   process.env.STORAGE_BASE_URL+'public%2Fjustincompilation%2Fthumbnail%2F'+temopiObj['thumbnail_name']+'?alt=media';
                                }
                            }
                            if(temopiObj['liked_user_ids'] != undefined && temopiObj['liked_user_ids'].length > 0 && temopiObj['liked_user_ids'].includes(parseInt(userID))) {
                                temopiObj['is_liked'] = true;
                                delete temopiObj['liked_user_ids'];
                            } else {
                                temopiObj['is_liked'] = false;
                                delete temopiObj['liked_user_ids'];
                            }
                            resolve(temopiObj);
                        }));
                    });
                }));
                return allJustinComiplationVideos;
            }
        } else {
            return [];
        }
    } catch(e) {
        console.log('Catch error in common function', e);
        var errorLog = await saveErrorLogFileWithpath('getJustinCompilationVideos', e.stack);
        throw new Error(e.message);
    }
});


export const deleteMediaFiles = expressAsyncHandler(async(mediaRef, userID, userRole) => {
    return new Promise(async (resolve, reject) => {
        try {
            const mediaType     =   MEDIA_TYPE;
            const type          =   TYPE;
            //const mediaGroup    =   await getAllReferenceData(['details'], [mediaRef]);
            const db            =   await getDBConnection();
            let mediaGroup      =   {};

            await db.getAll(mediaRef).then(async(docs) => {
                for await (const media of docs) {
                    mediaGroup    =   await { "id": media["id"], ... await media.data() };

                    const fileDetails   =   JSON.stringify(mediaGroup["medias_details"]);
                    const userDeleteLikeDetail  =  await saveErrorLogFileWithpath('deleteMediaFileRequest', "User ID is ===>"+userID+" and Media ID is ===>"+mediaGroup["id"]+" Media Type is ===>"+mediaGroup["type"]+"\n\n"+fileDetails);


                    for await (const mediaDetail of mediaGroup["medias_details"]) {

                        const mediaFile         =   'public/media/'+type[mediaGroup["type"]]+'/'+mediaType[mediaDetail["media_type"]]+'/'+userID+'/'+mediaDetail["media"];
                        const thumbnailFile     =   'public/media/'+type[mediaGroup["type"]]+'/'+mediaType[mediaDetail["media_type"]]+'/'+userID+'/thumbnail/'+mediaDetail["thumbnail"];

                        if(mediaDetail["media"] !== '') {
                            const mDelStatus     =   await generalDeleteFile(mediaFile);
                        }

                        if(mediaDetail["thumbnail"] !== '') {
                            const tDelStatus     =   await generalDeleteFile(thumbnailFile);
                        }
                    }
                }

                const deleteMediaGroup  =   await db.collection(MediaGroup.collection.name).doc(mediaGroup["id"].toString()).delete();

                return resolve(true);

            }).catch(err => reject(err));

            resolve(true);
        } catch (e) {
            console.log(e.stack);
            var errorLog = await saveErrorLogFileWithpath('deleteMediaFiles', e.stack);
            resolve(false);
        }
    });
});

export const deleteMediaFilesOnly = expressAsyncHandler(async(db, mediaRef, userID, userRole) => {
    return new Promise(async (resolve, reject) => {
        try {
            const mediaType     =   MEDIA_TYPE;
            const type          =   TYPE;

            await db.getAll(mediaRef).then(async(docs) => {
                for await (const media of docs) {
                    const mediaGroup    =   { "id": media["id"], ... await media.data() };

                    const fileDetails   =   JSON.stringify(mediaGroup["medias_details"]);
                    const userDeleteLikeDetail  =  await saveErrorLogFileWithpath('deleteMediaFileRequest', "User ID is ===>"+userID+" and Media ID is ===>"+mediaGroup["id"]+" Media Type is ===>"+mediaGroup["type"]+"\n\n"+fileDetails);

                    for await (const mediaDetail of mediaGroup["medias_details"]) {

                        const mediaFile         =   'public/media/'+type[mediaGroup["type"]]+'/'+mediaType[mediaDetail["media_type"]]+'/'+userID+'/'+mediaDetail["media"];
                        const thumbnailFile     =   'public/media/'+type[mediaGroup["type"]]+'/'+mediaType[mediaDetail["media_type"]]+'/'+userID+'/thumbnail/'+mediaDetail["thumbnail"];

                        if(mediaDetail["media"] !== '') {
                            const mDelStatus     =   await generalDeleteFile(mediaFile);
                        }

                        if(mediaDetail["thumbnail"] !== '') {
                            const tDelStatus     =   await generalDeleteFile(thumbnailFile);
                        }
                    }
                }

                //const deleteMediaGroup  =   await db.collection(MediaGroup.collection.name).doc(mediaGroup["id"].toString()).delete();

                return resolve(true);

            }).catch(err => reject(err));

            resolve(true);
        } catch (e) {
            console.log(e.stack);
            var errorLog = await saveErrorLogFileWithpath('deleteMediaFiles', e.stack);
            resolve(false);
        }
    });
});

export const updateAllMediaViewStatus = expressAsyncHandler(async(db, userID, all_media, next) => {
    return new Promise(async (resolve, reject) => {
        try {

            const updateMediaRef    =   await db.collection(MediaGroup.collection.name);
            const userRef           =   await db.doc(Users.collection.name+'/'+userID.toString());
            const currentTime       =   await admin.firestore.FieldValue.serverTimestamp();
            const userIDAdd         =   await admin.firestore.FieldValue.arrayUnion(parseInt(userID));

            const res = await db.runTransaction(async t => {
                //const medias = await t.get(mediaRef);
                
                /* for(var i=0; i < all_media.length; i++) { */
                for await (const media of all_media) {

                    var updateID = media.id.toString();

                    if(media['media_viewed_user_ids'].includes(parseInt(userID))) {
                        continue;
                    }/*  else if(media['media_type'] != 2) {
                        continue;
                    } */

                    var updateData  =   {
                        /* [MediaGroup.fields.media_viewed_user_ids.key]               :   userIDAdd, */
                        [MediaGroup.fields.is_media_viewed_by_assigned_user.key]    :   media.update_media_view_status,
                        [MediaGroup.fields.modified_by.key]                         :   userRef,
                        [MediaGroup.fields.modified_on.key]                         :   currentTime
                    };

                    await t.update(updateMediaRef.doc(updateID), { ...updateData });
                    
                }
                return true;
            });
            resolve(true);
        } catch (e) {
            console.log(e.stack);
            var errorLog = await saveErrorLogFileWithpath('updateAllMediaViewStatus', e.stack);
            resolve(false);
        }
    });
});


export const checkMediaIsDupilicate = expressAsyncHandler(async(sourceID, userID, supporterID, next) => {
    const db = await getDBConnection();
    let allCondition = {
        cond1: {
            type: 'where',
            field: MediaGroup.fields.created_by.key,
            operator: '==',
            value: await db.doc(Users.collection.name+'/'+userID.toString())
        },
        cond2: {
            type: 'where',
            field: MediaGroup.fields.assigned_user_ref.key,
            operator: '==',
            value: await db.doc(Users.collection.name+'/'+supporterID.toString())
        },
        cond3: {
            type: 'where',
            field: MediaGroup.fields.source_id.key,
            operator: '==',
            value: parseInt(sourceID)
        },
        /* cond4: {
            type: 'where',
            field: MediaGroup.fields.is_temporary_media.key,
            operator: '==',
            value: 0
        } */
    };
    let isDuplicate = await getCollectionData(MediaGroup.collection.name, allCondition, 0, 0, next);
    if(isDuplicate.length == 0) {
        return true;
    } else {
        return false;
    }
});


export const getHelpinghandIDs = expressAsyncHandler(async(collection, allCondition, offset, limit, next) => {
    try {
        const db = await getDBConnection();
        let query = await db.collection(collection);
        if(Object.keys(allCondition).length != 0) {
            let result = await Promise.all(Object.keys(allCondition).map(async(key, index) => {
                return new Promise(function(resolve, reject){
                    setTimeout(expressAsyncHandler(async() => {
                        setTimeout(async() => {
                            if(allCondition[key].type == 'where') {
                                query = await query.where(allCondition[key].field, allCondition[key].operator, allCondition[key].value);
                            } else if(allCondition[key].type == 'orderby') {
                                query = await query.orderBy(allCondition[key].field, allCondition[key].order);
                            } else if(allCondition[key].type == 'select') {
                                query = await query.select(...allCondition[key].fields);//In which fields used instead of field, because select fields in an array
                            }
                            resolve(allCondition[key]);
                        });
                    }));
                })
            }));
        }
        if(offset != 0) {
            query = query.offset(offset);
        }
        if(limit != 0) {
            query = query.limit(limit);
        }
        let snapshot = await query.get();
        if(snapshot.empty) {
            return [];
        } else {
            let data = await snapshot.docs.map(doc => { return parseInt(doc.get('helpinghand_reference')._path.segments[1]); });
            return data;
        }
    } catch(e) {
        console.log('Catch error in common function getHelpinghandIDs()');
        var errorLog = await saveErrorLogFileWithpath('getHelpinghandIDs', e.stack);
        throw new Error(e.message);
        //let error = new Error(e.message);
        //next(error);
    }
});

export const updateLikeViewCountOnHelpinghand = expressAsyncHandler(async(db, userID, supporterID, detail, next) => {
    return new Promise(async function(resolve, reject){
        try {
            if(userID == undefined || supporterID == undefined || userID == null || supporterID == null || userID == 0 || supporterID == 0 || userID == '' || supporterID == '') {
                return resolve(false);
            } else if(parseInt(userID) == parseInt(supporterID)) {
                return resolve(false);
            }

            var inviteHelpinghandQuery  =   await db.collection(InviteHelpinghand.collection.name)
                                                    .where(InviteHelpinghand.fields.user_reference.key, '==', await db.doc(Users.collection.name+'/'+userID.toString()))
                                                    .where(InviteHelpinghand.fields.helpinghand_reference.key, '==', await db.doc(Users.collection.name+'/'+supporterID.toString()))
                                                    .where(InviteHelpinghand.fields.is_resigned.key, '==', 0)
                                                    .where(InviteHelpinghand.fields.status.key, '==', 1);

            let helpingDetails          =   await inviteHelpinghandQuery.get();

            if(helpingDetails.empty) {
                return resolve(false);
            } else {
                let inviteHelpinghandData   =   await helpingDetails.docs.map(doc => { return { id: doc.id, ...doc.data() }; });
                inviteHelpinghandData       =   inviteHelpinghandData[0];

                let tempViewLikeCount       =   (inviteHelpinghandData.hasOwnProperty('media_view_like_count'))
                                                    ? inviteHelpinghandData.media_view_like_count
                                                    : 0;

                tempViewLikeCount           =   tempViewLikeCount + 1;

                let updateDataObj = {
                    [InviteHelpinghand.fields.media_view_like_count.key]    :   tempViewLikeCount,
                    [InviteHelpinghand.fields.modified_by.key]              :   await db.doc(Users.collection.name+'/'+userID.toString()),
                    [InviteHelpinghand.fields.modified_on.key]              :   await admin.firestore.FieldValue.serverTimestamp()
                };

                let update                  =   await updateData(InviteHelpinghand.collection.name, updateDataObj, inviteHelpinghandData.id);
                return resolve(true);
            }
        } catch(e) {
            var errorLog = await saveErrorLogFileWithpath('updateLikeViewCountOnHelpinghand', e.stack);
            resolve(e.message);
        }
    });
});

export const resetSupporterUserViewLikeCount = expressAsyncHandler(async(db, supporter_id, user_id, next) => {
    return new Promise(async function(resolve, reject){
    console.log('Comes In for clear count');
        try {
            let allCondition = {
                cond1: {
                    type: 'where',
                    field: InviteHelpinghand.fields.helpinghand_reference.key,
                    operator: '==',
                    value: await db.doc(Users.collection.name+'/'+supporter_id.toString())
                },
                cond2: {
                    type: 'where',
                    field: InviteHelpinghand.fields.user_reference.key,
                    operator: '==',
                    value: await db.doc(Users.collection.name+'/'+user_id.toString())
                },
                cond3: {
                    type        :   'where',
                    field       :   InviteHelpinghand.fields.status.key,
                    operator    :   '==',
                    value       :   1
                },
                cond4: {
                    type        :   'where',
                    field       :   InviteHelpinghand.fields.is_resigned.key,
                    operator    :   '==',
                    value       :   0
                }
            };

            let inviteDetails   =   await getCollectionData(InviteHelpinghand.collection.name, allCondition, 0, 0, next);

            if(inviteDetails.length == 0) {
                console.log('Empty no count to clear');
                resolve(false);
            } else {

                console.log('Clearing the data');
                var resetCount      =   await inviteDetails.map(async(detail, index) => {

                    let updateDataObj = {
                        [InviteHelpinghand.fields.media_view_like_count.key]    :   0,
                        [InviteHelpinghand.fields.modified_by.key]              :   await db.doc(Users.collection.name+'/'+supporter_id.toString()),
                        [InviteHelpinghand.fields.modified_on.key]              :   await admin.firestore.FieldValue.serverTimestamp()
                    };

                    let updateValueStatus   =   await updateData(InviteHelpinghand.collection.name, updateDataObj, parseInt(detail.id), next);
                    return updateValueStatus;
                });

                resolve(resetCount);
            }
        } catch(e) {
            console.log('Comes into the error path');
            var errorLog = await saveErrorLogFileWithpath('resetSupporterUserViewLikeCount', e.stack);
            resolve(e.message);
        }
    });
});

export const updateMediaUploadResponse = expressAsyncHandler(async(req, responseCode, responseMessage, next) => {
    return new Promise(async function(resolve, reject){
        try {
            const db 					=	await getDBConnection();
            const userID 				=	await getUserId(req);
            const mediaID 				=	await parseInt(req.params.media_id);
            let updateDataObj = {
                [MediaGroup.fields.async_media_upload_response_code.key]    :   responseCode,
                [MediaGroup.fields.async_media_upload_response_message.key] :   responseMessage,
                [MediaGroup.fields.modified_by.key]                         :   await db.doc(Users.collection.name+'/'+userID.toString()),
                [MediaGroup.fields.modified_on.key]                         :   await admin.firestore.FieldValue.serverTimestamp()
            };

            let update                  =   await updateData(MediaGroup.collection.name, updateDataObj, mediaID);
            return resolve(true);
        } catch(e) {
            var errorLog = await saveErrorLogFileWithpath('updateMediaUploadResponse', e.stack);
            resolve(e.message);
        }
    });
});

export const checkAllUserViewedMedia = expressAsyncHandler(async(mediaDetail, userID, next) => {
    return new Promise(async function(resolve, reject){
        try {
            var createrID       =   mediaDetail['created_by']._path.segments[1];
            var timesDupID      =   (mediaDetail['time_to_inspiration_media_id'] != undefined)
                                        ? mediaDetail['time_to_inspiration_media_id']
                                        : 0;

            var allIDs          =   mediaDetail['all_ids'];
            var viewedUserIDs   =   (mediaDetail['media_viewed_user_ids'] != undefined)
                                        ? mediaDetail['media_viewed_user_ids']
                                        : [];

            viewedUserIDs.push(parseInt(userID));

            var viewIndex       =   viewedUserIDs.indexOf(parseInt(createrID));
            var allIndex        =   allIDs.indexOf(parseInt(createrID));
    
            if(viewIndex !== -1) {
                viewedUserIDs.splice(viewIndex, 1);
            }
    
            if(allIndex !== -1) {
                allIDs.splice(allIndex, 1);
            }
    
            var mediaViewStatus =   (allIDs.length == viewedUserIDs.length) ? 1 : 0;

            resolve(mediaViewStatus);
        } catch(e) {
            var errorLog = await saveErrorLogFileWithpath('checkMediaViewStatus', e.stack);
            reject(e.message);
        }
    });
});

export const removeTimeNotification = expressAsyncHandler(async(db, mediaGroupID, userID, userRole, params, userAssignIDs, next) => {
    return new Promise(async function(resolve, reject) {
        try {
            if(userRole != 2 || params.type != 2) {
                return resolve(false);
            }

            let result = await Promise.all(userAssignIDs.map(async(doc, index) => {
                return new Promise(async function(resolve, reject){

                    var sendNotificationQuery  =   await db.collection(SendNotification.collection.name)
                                                            .where(SendNotification.fields.to_user_ref.key, '==', await db.doc(Users.collection.name+'/'+userID.toString()))
                                                            .where(SendNotification.fields.from_user_ref.key, '==', await db.doc(Users.collection.name+'/'+userAssignIDs[i].toString()))
                                                            .where(SendNotification.fields.status.key, '==', 0)
                                                            .get();
    
                    if(!sendNotificationQuery.empty) {
                        var updateNotificationStatus = await sendNotificationQuery.docs.map(async(doc) => {
                            var updateStatus = {
                                [SendNotification.fields.status.key]        :   2,
                                [SendNotification.fields.comments.key]      :   "Supporter already reached user. No need to send notification.",
                                [SendNotification.fields.modified_on.key]   :   await admin.firestore.FieldValue.serverTimestamp()
                            }
                            var updatedMediaID = await updateData(SendNotification.collection.name, updateStatus, parseInt(doc.id));
                        });
                        resolve(updateNotificationStatus);
                    } else {
                        resolve(true);
                    }
                });
            }));

            return resolve(result);

        } catch(e) {
            var errorLog = await saveErrorLogFileWithpath('removeTimeNotification', e.stack);
            resolve(e.message);
        }
    });
});

export const moveMediaFromTimeoutToInspiration = expressAsyncHandler(async(db, mediaGroupID, userID, userRole, params, userAssignIDs, next) => {
    return new Promise(async function(resolve, reject) {
        try {

            if(parseInt(userRole) != 2 || parseInt(params.type) != 2) {
                return resolve(false);
            }
            
            const updateMediaRef    =   await db.collection(MediaGroup.collection.name);

            var mediaQuery  =   await db.collection(MediaGroup.collection.name)
                                    .where(MediaGroup.fields.created_by.key, '==', await db.doc(Users.collection.name+'/'+userID.toString()))
                                    //.where(MediaGroup.fields.all_ids.key, 'array-contains-any', userAssignIDs)
                                    .where(MediaGroup.fields.type.key, '==', 2)
                                    .where(MediaGroup.fields.is_onboarding.key, '==', 0);

            
                                    

            if(userAssignIDs.length > 0) {
                userAssignIDs       =   userAssignIDs.map(Number);
                /* var assingedIDsRef  =   await userAssignIDs.map(user_id => db.doc(Users.collection.name+'/'+user_id.toString()));
                mediaQuery          =   await mediaQuery.where(MediaGroup.fields.assigned_to.key, 'array-contains-any', assingedIDsRef); */
                mediaQuery          =   await mediaQuery.where(MediaGroup.fields.assigned_user_id.key, 'in', userAssignIDs);
            }

            let medias      =   await mediaQuery.get();

            if(!medias.empty) {

                 console.log('Start loop');
                 
                var count = 0;

                for await (const doc of medias.docs) {
                    var media                   =   await doc.data();
                    var mediaID                 =   doc.id;
                    var updateID                =   mediaID;
                    var assignedUserID          =   media['assigned_user_id'];
                    var assignedRef             =   media['assigned_user_ref'];
                    var timesDupID              =   media['time_to_inspiration_media_id'];
                    var isAssingedUserViewed    =   media['is_media_viewed_by_assigned_user'];

                    if(isAssingedUserViewed == 1 && timesDupID != 0) {
                        var mediaRef    =   await db.doc(MediaGroup.collection.name+'/'+updateID.toString());
                        var deStatus    =   await deleteMediaFiles(mediaRef, userID, userRole);
                    }
                }
                console.log('Completed For loop');
                resolve(true);
            } else {
                resolve(true);
            }
        } catch(e) {
            var errorLog = await saveErrorLogFileWithpath('moveMediaFromTimeoutToInspiration', e.stack);
            resolve(e.message);
        }
    });
});

export const copyFilesFromTimeToInspiration = expressAsyncHandler(async(mediaDetails, mediaGroupType, mediaGroupMediaType, createrID, type, mediaType, deleteStatus, next) => {
    return new Promise(async function(resolve, reject) {
        try {
            for await (const media of mediaDetails) {
                let sourceMedia             = 'public/media/'+type[mediaGroupType]+'/'+media["media_type"]+'/'+createrID+'/'+media.media;
                let sourceThumbMedia        = 'public/media/'+type[mediaGroupType]+'/'+media["media_type"]+'/'+createrID+'/thumbnail/'+media.thumbnail;

                let destinationFile         = 'public/media/'+type["3"]+'/'+media["media_type"]+'/'+createrID+'/'+media.media;
                let destinationThumFile     = 'public/media/'+type["3"]+'/'+media["media_type"]+'/'+createrID+'/thumbnail/'+media.thumbnail;

                let destinationFolder       = 'public/media/'+type["3"]+'/'+media["media_type"]+'/'+createrID+'/';
                let destinationThumFolder   = 'public/media/'+type["3"]+'/'+media["media_type"]+'/'+createrID+'/thumbnail/';

                if(process.env.MODE == "development") {
                    let createFolder    =   await createDirectoryLocal(destinationFolder);
                    let copyStatus      =   await copyFileLocal(sourceMedia, destinationFile);
                    if(deleteStatus) {
                        let delMedia        =   await deleteFileLocal(sourceMedia, next);
                    }
                    //console.log(createFolder, copyStatus, delMedia);
                    if(media.thumbnail != undefined && media.thumbnail != '') {
                        let createThumbFolder   =   await createDirectoryLocal(destinationThumFolder);
                        let copyThumStatus      =   await copyFileLocal(sourceThumbMedia, destinationFile);
                        if(deleteStatus) {
                            let delThumbnailMedia   =   await deleteFileLocal(sourceThumbMedia, next);
                        }
                    }
                } else {
                    let copyStatus  =   await copyFile(sourceMedia, destinationFile);
                    if(deleteStatus) {
                        let delMedia    =   await deleteFile(sourceMedia, next);
                    }
                    if(media.thumbnail != undefined && media.thumbnail != '') {
                        let copyStatus          =   await copyFile(sourceThumbMedia, destinationThumFile);
                        //let delThumbnailMedia   =   await deleteFile(sourceThumbMedia, next);
                        if(deleteStatus) {
                            let delThumbnailMedia   =   await deleteFile(sourceThumbMedia, next);
                        }
                    }
                }
            }
            resolve(true);
        }catch(e) {
            var errorLog = await saveErrorLogFileWithpath('copyFilesFromTimeToInspiration', e.stack);
            reject(e.message);
        }
    });
});


export const addNotificationCron = expressAsyncHandler(async(db, params, userID, createrID, createrRef, assignedRef, currentTime, mediaGroupType, detail, next) => {
    return new Promise(async function(resolve, reject){
        try {
            
            if(parseInt(userID) == parseInt(createrID)) {
                return resolve(false);
            } else if(parseInt(mediaGroupType) != 2) {
                return resolve(false);
            }

            var sendNotificationStatus  =   await db.collection(SendNotification.collection.name)
                                                .where(SendNotification.fields.type.key, '==', 'media_view')
                                                .where(SendNotification.fields.from_user_ref.key, '==', assignedRef)
                                                .where(SendNotification.fields.to_user_ref.key, '==', createrRef)
                                                .where(SendNotification.fields.status.key, '==', 0)
                                                .get();

            if(sendNotificationStatus.empty) {
                let insertNotification  =   {
                    [SendNotification.fields.type.key]          :   'media_view',
                    [SendNotification.fields.reference.key]     :   await db.doc(MediaGroup.collection.name+'/'+params.media_id.toString()),
                    [SendNotification.fields.from_user_ref.key] :   assignedRef,
                    [SendNotification.fields.to_user_ref.key]   :   createrRef,
                    [SendNotification.fields.created_on.key]    :   currentTime
                };
                var notificationStatus  =   await insertData(SendNotification, insertNotification, 'send_notification_id', next);

                console.log('Notification Inserted');
                return resolve(true);
            } else {
                return resolve(true);
            }

        } catch(e) {
            var errorLog = await saveErrorLogFileWithpath('addnotificationCron', e.stack);
            reject(e.message);
        }
    });
});

export const getMediaBaseURL = expressAsyncHandler(async(mediaType, hostname, urlDetails, next) => {
    return new Promise(async function(resolve, reject){
        try {
            if(process.env.MODE == 'development') {
                switch (mediaType) {
                    case 'medias':
                        resolve('http://'+hostname+':'+process.env.PORT+'/public/media/'+urlDetails['type']+'/'+urlDetails['media_type']+'/'+urlDetails['user_id']+'/'+urlDetails['media_name']);
                        break;
                    case 'media_thumbnails':
                        resolve('http://'+hostname+':'+process.env.PORT+'/public/media/'+urlDetails['type']+'/'+urlDetails['media_type']+'/'+urlDetails['user_id']+'/thumbnail/'+urlDetails['media_name']);
                        break;
                    case 'profile':
                        resolve('http://'+hostname+':'+process.env.PORT+'/public/profile/'+urlDetails['user_id']+'/'+urlDetails['profile_image']);
                        break;
                    case 'temp_profile':
                        resolve('http://'+hostname+':'+process.env.PORT+'/public/temp_user/profile/'+urlDetails['user_id']+'/'+urlDetails['profile_image']);
                        break;
                    case 'onboardvideos':
                        resolve('http://'+hostname+':'+process.env.PORT+'/public/onboardvideos/'+urlDetails['video_file']);
                        break;
                    case 'onboardvideos_thumbnails':
                        resolve('http://'+hostname+':'+process.env.PORT+'/public/onboardvideos/thumbnail/'+urlDetails['image_file']);
                        break;
                    case 'justincompilation':
                        resolve('http://'+hostname+':'+process.env.PORT+'/public/justincompilation/'+urlDetails['user_id']+'/'+urlDetails['video']);
                        break;
                    case 'justincompilation_thumbnail':
                        resolve('http://'+hostname+':'+process.env.PORT+'/public/justincompilation/'+urlDetails['user_id']+'/thumbnail/'+urlDetails['thumbnail']);
                        break;
                    case 'default_justincompilation':
                        resolve('http://'+hostname+':'+process.env.PORT+'/public/justincompilation/default_justin_compilation_video/'+urlDetails['video']);
                        break;
                    case 'default_justincompilation_thumbnail':
                        resolve('http://'+hostname+':'+process.env.PORT+'/public/justincompilation/default_justin_compilation_video/thumbnail/'+urlDetails['thumbnail']);
                        break;
                    case 'music':
                        resolve('http://'+hostname+':'+process.env.PORT+'/public/music/'+urlDetails['music']);
                        break;
                    case 'music_thumbnail':
                        resolve('http://'+hostname+':'+process.env.PORT+'/public/music/thumbnail/'+urlDetails['thumbnail']);
                        break;
                    case 'populate_image':
                        resolve('http://'+hostname+':'+process.env.PORT+'/public/populate_images/'+urlDetails['populate_image']);
                        break;
                    case 'populate_video':
                        resolve('http://'+hostname+':'+process.env.PORT+'/public/populate_images/videos/'+urlDetails['populate_video']);
                        break;
                    case 'populate_thumbnail':
                        resolve('http://'+hostname+':'+process.env.PORT+'/public/populate_images/videos/thumbnails/'+urlDetails['populate_thumbnail']);
                        break;
                    default:
                        resolve('http://'+hostname+':'+process.env.PORT+'/public/media/'+urlDetails['type']+'/'+urlDetails['media_type']+'/'+urlDetails['user_id']+'/'+urlDetails['media_name']);
                }
            } else {
                switch (mediaType) {
                    case 'medias':
                        resolve(process.env.STORAGE_BASE_URL+'public%2Fmedia%2F'+urlDetails['type']+'%2F'+urlDetails['media_type']+'%2F'+urlDetails['user_id']+'%2F'+urlDetails['media_name']+'?alt=media');
                        break;
                    case 'media_thumbnails':
                        resolve(process.env.STORAGE_BASE_URL+'public%2Fmedia%2F'+urlDetails['type']+'%2F'+urlDetails['media_type']+'%2F'+urlDetails['user_id']+'%2Fthumbnail%2F'+urlDetails['media_name']+'?alt=media');
                        break;
                    case 'profile':
                        resolve(process.env.STORAGE_BASE_URL+'public%2Fprofile%2F'+urlDetails['user_id']+'%2F'+urlDetails['profile_image']+'?alt=media');
                        break;
                    case 'temp_profile':
                        resolve(process.env.STORAGE_BASE_URL+'public%2Ftemp_user%2Fprofile%2F'+urlDetails['user_id']+'%2F'+urlDetails['profile_image']+'?alt=media');
                        break;
                    case 'onboardvideos':
                        resolve(process.env.STORAGE_BASE_URL+'public%2Fonboardvideos%2F'+urlDetails['video_file']+'?alt=media');
                        break;
                    case 'onboardvideos_thumbnails':
                        resolve(process.env.STORAGE_BASE_URL+'public%2Fonboardvideos%2Fthumbnail%2F'+urlDetails['image_file']+'?alt=media');
                        break;
                    case 'justincompilation':
                        resolve(process.env.STORAGE_BASE_URL+'public%2Fjustincompilation%2F'+urlDetails['user_id']+'%2F'+urlDetails['video']+'?alt=media');
                        break;
                    case 'justincompilation_thumbnail':
                        resolve(process.env.STORAGE_BASE_URL+'public%2Fjustincompilation%2F'+urlDetails['user_id']+'%2Fthumbnail%2F'+urlDetails['thumbnail']+'?alt=media');
                        break;
                    case 'default_justincompilation':
                        resolve(process.env.STORAGE_BASE_URL+'public%2Fjustincompilation%2Fdefault_justin_compilation_video%2F'+urlDetails['video']+'?alt=media');
                        break;
                    case 'default_justincompilation_thumbnail':
                        resolve(process.env.STORAGE_BASE_URL+'public%2Fjustincompilation%2Fdefault_justin_compilation_video%2Fthumbnail%2F'+urlDetails['thumbnail']+'?alt=media');
                        break;
                    case 'music':
                        resolve(process.env.STORAGE_BASE_URL+'public%2Fmusic%2F'+urlDetails['music']+'?alt=media');
                        break;
                    case 'music_thumbnail':
                        resolve(process.env.STORAGE_BASE_URL+'public%2Fmusic%2Fthumbnail%2F'+urlDetails['thumbnail']+'?alt=media');
                        break;
                    case 'populate_image':
                        resolve(process.env.STORAGE_BASE_URL+'public%2Fpopulate_images%2F'+urlDetails['populate_image']+'?alt=media');
                        break;
                    case 'populate_video':
                        resolve(process.env.STORAGE_BASE_URL+'public%2Fpopulate_images%2Fvideos%2F'+urlDetails['populate_video']+'?alt=media');
                        break;
                    case 'populate_thumbnail':
                        resolve(process.env.STORAGE_BASE_URL+'public%2Fpopulate_images%2Fvideos%2Fthumbnails%2F'+urlDetails['populate_thumbnail']+'?alt=media');
                        break;
                    default:
                        resolve(process.env.STORAGE_BASE_URL+'public%2Fmedia%2F'+urlDetails['type']+'%2F'+urlDetails['media_type']+'%2F'+urlDetails['user_id']+'%2F'+urlDetails['media_name']+'?alt=media');
                }
            }
        } catch(e) {
            var errorLog = await saveErrorLogFileWithpath('getMediaBaseURL', e.stack);
            reject(e.message);
        }
    });
});

export const sendSMS = expressAsyncHandler(async(smsMessage, toNumber, next) => {
    return new Promise(async function(resolve, reject){
        try {
            const client = new twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN, { logLevel: 'debug' });
                client.messages.create({
                    messagingServiceSid: process.env.TWILIO_MESSAGING_SERVICES_ID,
                    body: smsMessage,
                    to: toNumber
                    //from: '+61255001114'
                }).then(async(message) => {
                    var errorLog = await saveErrorLogFileWithpath('sendSMS', JSON.stringify(message));
                    resolve(true);
                })
                .catch(async (error) => {
                    console.log(error);
                    var errorLog = await saveErrorLogFileWithpath('sendSMS', error.message);
                    resolve(false);
                });
        } catch(e) {
            var errorLog = await saveErrorLogFileWithpath('sendSMS', e.stack);
            reject(e.message);
        }
    });
});

export const checkFileError = (err) => {
    return new Promise((resolve, reject) => {
        if(err instanceof multer.MulterError) {
            if(err.code == "LIMIT_UNEXPECTED_FILE") {
                return resolve({ status: true, message: 'Invalid field name.' });
            } else if(err.code == "LIMIT_FILE_COUNT") {
                return resolve({ status: true, message: 'Too many files uploaded.' });
            } else {
                return resolve({ status: true, message: err.message });
            }
        } else if (err) {
            return resolve({ status: true, message: err.message });
        } else {
            return resolve({ status: false, message: '' });
        }
    });
};

export const saveTracking = expressAsyncHandler((userID, path, message) => {
    return new Promise(async function(resolve, reject) {
        try {
            const storage       =   await getStorageConnection();
            const bucket        =   await storage.bucket();
            const fileName      =   'public/tracking/'+userID+'/'+path;
            const file          =   bucket.file(fileName);

            let existingMessage =   "";

            file.exists().then(async function(data) {
                if(data[0]) {
                    file.createReadStream()
                        .on('error', function(err) {
                            console.log(err);
                            resolve(true);
                        })
                        .on('data', function(datas) {
                            var buf             =   Buffer.from(datas);
                            existingMessage     =   existingMessage + "" + buf.toString();
                        })
                        .on('end', function() {
                            message     =   existingMessage+message;
                            file.save(message, { resumable: false }, function(err) {
                                if(err) {
                                    console.log('Catch error in common function saveFile()', err);
                                    //throw new Error('Catch error in common function saveFile()');
                                }
                                resolve(true);
                            });
                        });
                } else {
                    file.save(message, function(err) {
                        if(err) {
                            console.log('Catch error in common function saveFile()', err);
                            //throw new Error('Catch error in common function saveFile()');
                        }
                        resolve(true);
                    });
                }
            });
        } catch(e) {
            console.log('Catch error in common function saveTracking()', e);
            var errorLog = await saveErrorLogFileWithpath('saveTracking', e.stack);
            reject(e);
        }
    });
});

export const getTracking = expressAsyncHandler((userID, path, message) => {
    return new Promise(async function(resolve, reject) {
        try {
            const storage       =   await getStorageConnection();
            const bucket        =   await storage.bucket();
            const fileName      =   'public/tracking/'+userID+'/'+path;
            const file          =   bucket.file(fileName);

            let existingMessage =   "";

            file.exists().then(function(data) {
                if(data[0]) {
                    file.createReadStream()
                        .on('error', function(err) {
                            console.log(err);
                            resolve(true);
                        })
                        .on('data', function(datas) {
                            var buf             =   Buffer.from(datas);
                            existingMessage     =   buf.toString();
                        })
                        .on('end', function() {
                            resolve(existingMessage)
                        });
                } else {
                    file.save(message, function(err) {
                        if(err) {
                            console.log('Catch error in common function saveFile()', err);
                            //throw new Error('Catch error in common function saveFile()');
                        }
                        resolve(true);
                    });
                }
            });
        } catch(e) {
            console.log('Catch error in common function saveTracking()', e);
            var errorLog = await saveErrorLogFileWithpath('saveTracking', e.stack);
            reject(e);
        }
    });
});


export const deleteUserDatas = (db, userID) => {

    return new Promise(async(resolve, reject) => {

        let logger  =   'Start user delete action for userID ===> '+userID;

        try {

            let batch                   =   await db.batch();

            const userRef               =   await db.collection(Users.collection.name).doc(userID.toString());

            const userDetailRef         =   await userRef.get();

            const userDetails           =   await { id: userDetailRef.id, ... await userDetailRef.data() };

            logger                      =   logger+'\n\n'+JSON.stringify(userDetails);

            const mobileNumWithCounCode =   await userDetails["country_code"]+''+userDetails["mobile_number"];

            /* const assingnedMediaRefs    =   await db.collection(MediaGroup.collection.name)
                                                .where(MediaGroup.fields.assigned_user_ref.key, '==', userRef)
                                                .get();
            const createdMediaRefs      =   await db.collection(MediaGroup.collection.name)
                                                .where(MediaGroup.fields.created_by.key, '==', userRef)
                                                .get(); */

            const allMediaRefs          =   await db.collection(MediaGroup.collection.name)
                                                .where(MediaGroup.fields.reference_ids.key, 'array-contains', userRef)
                                                .get();

            const activityRefs          =   await db.collection(Activities.collection.name)
                                                    .where(Activities.fields.reference_ids.key, 'array-contains', userRef)
                                                    .get();

            const checkInRefs           =   await db.collection(Checkin.collection.name)
                                                    .where(Checkin.fields.user_id.key, '==', userRef)
                                                    .get();

            const inviteUserRefs        =   await db.collection(InviteHelpinghand.collection.name)
                                                    .where(InviteHelpinghand.fields.user_reference.key, '==', userRef)
                                                    .get();

            const inviteSupRefs         =   await db.collection(InviteHelpinghand.collection.name)
                                                    .where(InviteHelpinghand.fields.helpinghand_reference.key, '==', userRef)
                                                    .get();

            const jusComRefs            =   await db.collection(JustinCompilation.collection.name)
                                                    .where(JustinCompilation.fields.user_id.key, '==', parseInt(userID))
                                                    .get();

            const notifyRefs            =   await db.collection(Notifications.collection.name)
                                                    .where(Notifications.fields.reference_ids.key, 'array-contains', userRef)
                                                    .get();

            const popLikeDelRefs        =   await db.collection(PopulatedImagesLikeDeteleDetails.collection.name).doc(userID.toString());

            const sendFromNotifyRefs    =   await db.collection(SendNotification.collection.name)
                                                    .where(SendNotification.fields.from_user_ref.key, '==', userRef)
                                                    .get();

            const sendToNotifyRefs      =   await db.collection(SendNotification.collection.name)
                                                    .where(SendNotification.fields.to_user_ref.key, '==', userRef)
                                                    .get();

            const smsTrackingRefs       =   await db.collection('sms_tracking')
                                                    .where('to', '==', mobileNumWithCounCode)
                                                    .get();

            const mediasDelStatus           =   await generalCollectionRecordDelete(db, logger, userDetails, batch, MediaGroup.collection.name, allMediaRefs);

            batch       =   mediasDelStatus["batch"];
            logger      =   mediasDelStatus["logger"];

            const activityDelStatus         =   await generalCollectionRecordDelete(db, logger, userDetails, batch, Activities.collection.name, activityRefs);

            batch       =   activityDelStatus["batch"];
            logger      =   activityDelStatus["logger"];

            const checkInDelStatus          =   await generalCollectionRecordDelete(db, logger, userDetails, batch, Checkin.collection.name, checkInRefs);

            batch       =   checkInDelStatus["batch"];
            logger      =   checkInDelStatus["logger"];

            const inviteUserDelStatus       =   await generalCollectionRecordDelete(db, logger, userDetails, batch, InviteHelpinghand.collection.name, inviteUserRefs);

            batch       =   inviteUserDelStatus["batch"];
            logger      =   inviteUserDelStatus["logger"];

            const inviteSupDelStatus        =   await generalCollectionRecordDelete(db, logger, userDetails, batch, InviteHelpinghand.collection.name, inviteSupRefs);

            batch       =   inviteSupDelStatus["batch"];
            logger      =   inviteSupDelStatus["logger"];

            const jusComDelStatus           =   await generalCollectionRecordDelete(db, logger, userDetails, batch, JustinCompilation.collection.name, jusComRefs);

            batch       =   jusComDelStatus["batch"];
            logger      =   jusComDelStatus["logger"];

            const notifyDelStatus           =   await generalCollectionRecordDelete(db, logger, userDetails, batch, Notifications.collection.name, notifyRefs);

            batch       =   notifyDelStatus["batch"];
            logger      =   notifyDelStatus["logger"];

            const sendFromNotifyDelStatus   =   await generalCollectionRecordDelete(db, logger, userDetails, batch, SendNotification.collection.name, sendFromNotifyRefs);

            batch       =   sendFromNotifyDelStatus["batch"];
            logger      =   sendFromNotifyDelStatus["logger"];

            const sendToNotifyDelStatus     =   await generalCollectionRecordDelete(db, logger, userDetails, batch, SendNotification.collection.name, sendToNotifyRefs);

            batch       =   sendToNotifyDelStatus["batch"];
            logger      =   sendToNotifyDelStatus["logger"];

            const smsTrackingDelStatus      =   await generalCollectionRecordDelete(db, logger, userDetails, batch, 'sms_tracking', smsTrackingRefs);

            batch       =   smsTrackingDelStatus["batch"];
            logger      =   smsTrackingDelStatus["logger"];

            const checkPopLikeDelRefs       =   await popLikeDelRefs.get();

            if(checkPopLikeDelRefs.exists) {
                await batch.delete(popLikeDelRefs);
            }

            //Finally Delete user
            const userProfile       =   'public/profile/'+userDetails['id']+'/'+userDetails['profile_image'];
            if(userDetails['profile_image'] !== '') {
                const userProfDelStatus =   await generalDeleteFile(userProfile);
            }

            await batch.delete(userRef);

            logger  =   logger+'\n\n'+'User ID ===>'+userDetails["id"]+', mediasDelStatus ===> '+mediasDelStatus["status"];
            logger  =   logger+'\n\n'+'User ID ===>'+userDetails["id"]+', activityDelStatus ===> '+activityDelStatus["status"];
            logger  =   logger+'\n\n'+'User ID ===>'+userDetails["id"]+', checkInDelStatus ===> '+checkInDelStatus["status"];
            logger  =   logger+'\n\n'+'User ID ===>'+userDetails["id"]+', inviteUserDelStatus ===> '+inviteUserDelStatus["status"];
            logger  =   logger+'\n\n'+'User ID ===>'+userDetails["id"]+', inviteSupDelStatus ===> '+inviteSupDelStatus["status"];
            logger  =   logger+'\n\n'+'User ID ===>'+userDetails["id"]+', jusComDelStatus ===> '+jusComDelStatus["status"];
            logger  =   logger+'\n\n'+'User ID ===>'+userDetails["id"]+', notifyDelStatus ===> '+notifyDelStatus["status"];
            logger  =   logger+'\n\n'+'User ID ===>'+userDetails["id"]+', sendFromNotifyDelStatus ===> '+sendFromNotifyDelStatus["status"];
            logger  =   logger+'\n\n'+'User ID ===>'+userDetails["id"]+', sendToNotifyDelStatus ===> '+sendToNotifyDelStatus["status"];
            logger  =   logger+'\n\n'+'User ID ===>'+userDetails["id"]+', smsTrackingDelStatus ===> '+smsTrackingDelStatus["status"];

            logger  =   logger+'\n\n'+'User delete ended for user ID ===> '+userDetails["id"];

            var errorLog    =   await saveErrorLogFileWithpath('deleteUserLogger', logger);

            await batch.commit();

            resolve(true);

        } catch(e) {
            console.log('Catch error in common function deleteUserDatas()', e);
            var errorLog            =   await saveErrorLogFileWithpath('deleteUserDatas', e.stack);
            logger                  =   logger+'\n\n'+e.stack;
            var deleteUserLogger    =   await saveErrorLogFileWithpath('deleteUserLogger', logger);
            reject(e);
        }
    });
};

export const generalCollectionRecordDelete = (db, logger, userDetails, batch, collectionName, deleteRefs) => {
    return new Promise(async(resolve, reject) => {

        try {

            logger    =   logger+"\n\n"+'Custom Logger -- Start delete Collection ==>'+collectionName+ ', for user ID ===> '+userDetails["id"];

            if(!deleteRefs.empty) {

                for await(const deleteDoc of deleteRefs.docs) {

                    const deleteRecordRef =   await db.collection(collectionName).doc(deleteDoc.id.toString());

                    logger    =   logger+"\n\n"+"Custom Logger -- Delete collection ===> "+collectionName+", of ID ===>"+deleteDoc.id+ ', for user ID ===> '+userDetails["id"];

                    if(collectionName === MediaGroup.collection.name) {

                        const mediaNames                    =   await deleteDoc.get(MediaGroup.fields.medias_names.key);
                        const isMediaAssignedToAnotherUser  =   await db.collection(collectionName)
                                                                    .where(MediaGroup.fields.medias_names.key, 'array-contains', mediaNames[0])
                                                                    .where(MediaGroup.fields.mission_flag.key, '==', 0)
                                                                    .get();

                        if(isMediaAssignedToAnotherUser.size === 1) {

                            logger    =   logger+"\n\n"+"Custom Logger -- Delete media files ID is ===> "+deleteDoc.id+ ', for user ID ===> '+userDetails["id"];
                            logger    =   logger+"\n\n"+"Custom Logger -- Delete media names ===> "+mediaNames.toString()+ ', for user ID ===> '+userDetails["id"];

                            const mediaFileDelStatus    =   await deleteMediaFilesOnly(db, deleteRecordRef, userDetails["id"], userDetails["user_role"]);

                            await batch.delete(deleteRecordRef);

                        } else {

                            await batch.delete(deleteRecordRef);

                        }

                    } else if(collectionName === InviteHelpinghand.collection.name) {

                        const tempUserRef           =   await deleteDoc.get(InviteHelpinghand.fields.temporary_user_id.key);
                        const tempHelpinghandRef    =   await deleteDoc.get(InviteHelpinghand.fields.temporary_helpinghand_user_id.key);

                        if(tempUserRef !== null) {
                            const tempUserID        =   tempUserRef._path.segments[1].toString();
                            const delTempUserRef    =   await db.collection(TemporaryUsers.collection.name).doc(tempUserID);
                            const tempUserDetailRef =   await delTempUserRef.get();
                            const tempUserProfImg   =   await tempUserDetailRef.get(TemporaryUsers.fields.profile_image.key);
                            const tempProfilePath   =   'public/temp_user/profile/'+tempUserID+'/'+tempUserProfImg;

                            if(tempUserProfImg !== '') {
                                const tempProfDelStatus =   await generalDeleteFile(tempProfilePath);
                            }

                            logger    =   logger+"\n\n"+"Custom Logger -- Delete temp user ID is ===> "+tempUserID+ ', for user ID ===> '+userDetails["id"];

                            await batch.delete(delTempUserRef);
                        }

                        if(tempHelpinghandRef !== null) {
                            const tempHelpinghandID         =   tempHelpinghandRef._path.segments[1].toString();
                            const delTempHelpinhgandRef     =   await db.collection(TemporaryUsers.collection.name).doc(tempHelpinghandID.toString());
                            const tempHelpinghandDetailRef  =   await delTempHelpinhgandRef.get();
                            const tempHelpinghandProfImg    =   await tempHelpinghandDetailRef.get(TemporaryUsers.fields.profile_image.key);
                            const tempProfilePath           =   'public/temp_user/profile/'+tempHelpinghandID+'/'+tempHelpinghandProfImg;

                            if(tempHelpinghandProfImg !== '') {
                                const tempProfDelStatus =   await generalDeleteFile(tempProfilePath);
                            }
                            
                            logger    =   logger+"\n\n"+"Custom Logger -- Delete temp helpinghand ID is ===> "+tempHelpinghandID+ ', for user ID ===> '+userDetails["id"];

                            await batch.delete(delTempHelpinhgandRef);
                        }

                        await batch.delete(deleteRecordRef);

                    } else if(collectionName === JustinCompilation.collection.name) {

                        const justinVideo       =   await deleteDoc.get(JustinCompilation.fields.video.key);
                        const justinThumbnail   =   await deleteDoc.get(JustinCompilation.fields.thumbnail.key);
                        const justinUserID      =   await deleteDoc.get(JustinCompilation.fields.user_id.key);

                        const videoPath         =   'public/justincompilation/'+justinUserID+'/'+justinVideo;
                        const thumbnailPath     =   'public/justincompilation/'+justinUserID+'/thumbnail/'+justinThumbnail;

                        logger    =   logger+"\n\n"+"Custom Logger -- Delete justin compilation video path ===> "+videoPath+ ', for user ID ===> '+userDetails["id"];
                        logger    =   logger+"\n\n"+"Custom Logger -- Delete justin compilation thumbnail path ===> "+thumbnailPath+ ', for user ID ===> '+userDetails["id"];

                        const jusCompVideoDelStatus     =   await generalDeleteFile(videoPath);
                        const jusCompThumbDelStatus     =   await generalDeleteFile(thumbnailPath);


                        await batch.delete(deleteRecordRef);

                    } else {

                        await batch.delete(deleteRecordRef);

                    }

                }

                //var deleteUserLogger    =   await saveErrorLogFileWithpath('deleteUserLogger', customLogger);

                resolve({ status: true, batch: batch, logger: logger });

            } else {
                resolve({ status: true, batch: batch, logger: logger });
            }
        } catch(e) {

            console.log("generalCollectionRecordDelete, Collection Name ===>", collectionName);
            console.log('Catch error in common function generalCollectionRecordDelete()', e);

            var errorLog    =   await saveErrorLogFileWithpath('generalCollectionRecordDelete', "Collection Name ===> "+collectionName);
            errorLog        =   await saveErrorLogFileWithpath('generalCollectionRecordDelete', e.stack);

            logger    =   logger+"\n\n"+"User ID ===>"+userDetails["id"]+', Collection name'+collectionName;
            logger    =   logger+"\n\n"+"Error ===> "+e.stack;
            //deleteUserLogger    =   await saveErrorLogFileWithpath('deleteUserLogger', customLogger);

            resolve({ status: false, batch: batch, logger: logger });
        }

    });

};