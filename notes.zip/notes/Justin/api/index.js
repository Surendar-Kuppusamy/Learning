import express from 'express';
import bodyParser from 'body-parser';
import path from 'path';
import dotenv from 'dotenv';
import cors from 'cors';
import { connectDB } from './config/db.js';

import { notFound, errorHandler } from './middleware/errorMiddleware.js';

import usersRoutes from './routers/usersRoutes.js';
import helpingHandRoutes from './routers/helpingHandRoutes.js';
import uploadMediaLive from './routers/uploadMediaLive.js';
import mediaRoutes from './routers/mediaRoutes.js';

import collectionUpdateRoutes from './routers/collectionUpdateRoutes.js';


dotenv.config({path: './.env'});

const app = express();

app.use(cors())

const __dirname = path.resolve()
app.use('/public', express.static(path.join(__dirname, '/public')))


connectDB();

// for parsing application/xwww-form-urlencoded// for parsing application/json
/* app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json()); */
app.use(express.json({ limit: '2MB' }));



app.get('/',(req,res) => {
	res.send('JUSTIN API HOME');
})

app.use('/api/users/', usersRoutes);
app.use('/api/helpinghand/', helpingHandRoutes);
app.use('/api/media/', mediaRoutes);

app.use('/api/upload/', uploadMediaLive);


app.use('/api/collection/', collectionUpdateRoutes);



app.use(notFound)
app.use(errorHandler)

app.listen(process.env.PORT,() => {
	console.log(`Running on PORT ${process.env.PORT}`);
})