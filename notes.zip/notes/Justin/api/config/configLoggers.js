import morgan from 'morgan';
import winston from 'winston';
import path from 'path';
import rfs from 'rotating-file-stream';

const { format } = winston;
const { combine } = format;
var today = new Date();
let day = today.getDate();
let month = today.getMonth()+1;
let year = today.getFullYear();
let curDate = day+'-'+month+'-'+year;

const configLogs = (app) => {   //It will print in UTC time
    const __dirname = path.resolve()
    var accessLogStream = rfs.createStream(curDate+'_access.log', {
        //interval: '1d', // rotate daily
        path: path.join(__dirname, 'public' ,'logs', 'access')
    })
    app.use(morgan('combined', { stream: accessLogStream }));
}

const errorLogger = winston.createLogger({  //It will print in UTC time
    format: combine(
        winston.format.json(),
        winston.format.splat()
    ),
    defaultMeta: { time: new Date() },  //Append time on logger
    transports: [
        // - Write all logs with level `error` and below to `error.log`
        new winston.transports.File({ filename: 'public/logs/errors/'+curDate+'_error.log', level: 'error' })
    ]
});

const infoLogger = winston.createLogger({   //It will print in UTC time
    format: combine(
        winston.format.json(),
        winston.format.splat()
    ),
    defaultMeta: { time: new Date() },  //Append time on logger
    transports: [
        // - Write all logs with level `info` and below to `combined.log
        new winston.transports.File({ filename: 'public/logs/data/'+curDate+'_combined.log', level:'info' })
    ]
});

export {configLogs, errorLogger, infoLogger};