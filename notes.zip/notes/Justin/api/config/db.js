import admin from 'firebase-admin';
import { dbConfig } from './serviceAccountKey.js';
//import { errorLogger } from './configLoggers.js';

let dbConnection;
let storageConnection;

export const connectDB = async () => {
    let key = dbConfig();
    let storage="";
    if(process.env.MODE == "development") {
        storage = process.env.LOCAL_STORAGE
    } else {
        storage = process.env.LIVE_STORAGE
    }

    try {
        admin.initializeApp({
            credential: admin.credential.cert(key),
            storageBucket: storage
        });
        dbConnection = admin.firestore();
        storageConnection = admin.storage();
        console.log('DB Connected');
        //await db.terminate();
        return dbConnection;
    } catch (error) {
        //errorLogger.error(error.message);
        console.error(`Error: ${error.message}`)
        process.exit(1)
    }
}

export const getDBConnection = async () => {
    return dbConnection;
}

export const getStorageConnection = async () => {
    return storageConnection;
}

export const deleteConnection = async () => {
    console.log('Connection Delete');
    admin.app().delete();
}
