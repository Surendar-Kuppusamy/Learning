import expressAsyncHandler from 'express-async-handler';
import nodemailer from 'nodemailer';
//import { errorLogger, infoLogger } from '../config/configLoggers.js';


export const sendMail = expressAsyncHandler(async(toMail, ccMail, bccMail, subject, body, attachments, res) => {
    try {
        let transporter = nodemailer.createTransport({
            host: process.env.HOST,
            port: 587,
            secure: false, // true for 465, false for other ports
            auth: {
                user: process.env.USER,
                pass: process.env.PASS
            }
        });

        let mailOptions = {
            from: process.env.FROM_EMAIL,
            to: toMail,
            cc: ccMail,
            bcc: bccMail,
            subject: subject,
            html: body,
            attachments: attachments,
            headers: {
                'x-justin': 'JUSTIN',
            }
        };

        transporter.sendMail(mailOptions, function(err, info) {
            if(err) {
                /* if(process.env.MODE == 'development') {
                    errorLogger.error('Send mail has error', err);
                } */
                console.log(err);
                res.status(500).json({
                    status: 'error',
                    message: 'Mail send failed.'
                });
            } else {
                /* if(process.env.MODE == 'development') {
                    infoLogger.info('Mail send', info);
                } */
                console.log(info);
                res.status(200).json({
                    status: 'success',
                    message: 'Mail send.'
                });
            }
        });
    } catch(e) {
        if(process.env.MODE == 'development') {
            errorLogger('Send mail has error', err);
        }
        throw new Error('Mail send is failed');
    }
});