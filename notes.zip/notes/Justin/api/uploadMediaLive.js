import path from 'path';
import express from 'express';
import multer from 'multer';
import { IMAGE_EXTENSIONS, AUDIO_EXTENSIONS, ALL_EXTENSIONS, MEDIA_TYPE, TYPE } from '../constants/globalConstants.js';
import { verifyToken } from '../middleware/authMiddleware.js';
import { uploadMediaThumbnail, uploadMedias, uploadProfile, uploadInviteNewUser, editInviteNewUser, uploadMusicFiles } from '../controllers/uploadController.js';


const router = express.Router();

const LIMIT			=	{ fileSize: 36 * 1024 * 1024, files: 12 };	//36MB
const PROFILE_LIMIT	=	{ fileSize: 1 * 1024 * 1024, files: 1 };	//1MB
const MUSIC_LIMIT	=	{ fileSize: 10 * 1024 * 1024, files: 6 };	//10MB

function checkFileType(req, file, cb) {

	const params = req.params;

	if(params.type != "1" && params.type != "2" && params.type != "3") {
		return cb({'message': 'Invalid type.'});
	}

	let ext = path.extname(file.originalname).toLowerCase();
	ext = ext.substr(1);

	if(file.fieldname == 'media') {

		if(ALL_EXTENSIONS.indexOf(ext) === -1) {
			return cb({'message': 'File extension not supported.'});
		} else {
			return cb(null, true)
		}

	} else if(file.fieldname == 'thumbnail') {

		if(IMAGE_EXTENSIONS.indexOf(ext) === -1) {
			return cb({'message': 'Thumbnail Image format not supported.'})
		} else {
			return cb(null, true)
		}

	}
}

function checkMediaFilesType(req, file, cb) {

	let ext = path.extname(file.originalname).toLowerCase();
	ext = ext.substr(1);

	if(file.fieldname == 'media') {

		if(ALL_EXTENSIONS.indexOf(ext) === -1) {
			return cb({'message': 'File extension not supported.'});
		} else {
			return cb(null, true)
		}

	} else if(file.fieldname == 'thumbnail') {

		if(IMAGE_EXTENSIONS.indexOf(ext) === -1) {
			return cb({'message': 'Thumbnail Image format not supported.'})
		} else {
			return cb(null, true)
		}

	}
	
}

function checkProfileFileType(req, file, cb) {
	
	let ext = path.extname(file.originalname).toLowerCase();
	ext = ext.substr(1);

	if(IMAGE_EXTENSIONS.indexOf(ext) === -1) {
		return cb({'message': 'Image format not supported.'})
	} else {
		return cb(null, true)
	}
}

function checkMusicFileType(req, file, cb) {
	if(file.fieldname == 'music') {

		var ext	=	path.extname(file.originalname).toLowerCase();
		ext		=	ext.substr(1);

		if(AUDIO_EXTENSIONS.indexOf(ext) === -1) {
			return cb({'message': 'Audio format not supported.'})
		} else {
			return cb(null, true)
		}
	} else if(file.fieldname == 'thumbnail') {

		var ext	=	path.extname(file.originalname).toLowerCase();
		ext		=	ext.substr(1);

		if(IMAGE_EXTENSIONS.indexOf(ext) === -1) {
			return cb({'message': 'Image format not supported.'})
		} else {
			return cb(null, true)
		}
	}
}


const mediaArrayUpload = multer({
	storage: multer.memoryStorage(),
	fileFilter: function (req, file, cb) {
		checkMediaFilesType(req, file, cb)
	},
	limits: LIMIT
}).fields([{ name: 'media', maxCount: 6 }, { name: 'thumbnail', maxcount: 6 }]);

const mediaThumUpload = multer({
	storage: multer.memoryStorage(),
	fileFilter: function (req, file, cb) {
		checkFileType(req, file, cb)
	},
	limits:  { fileSize: 36 * 1024 * 1024, files: 6 }	//1MB
}).fields([{ name: 'thumbnail', maxcount: 6 }]);

const profileUpload = multer({
	storage: multer.memoryStorage(),
	fileFilter: function (req, file, cb) {
		checkProfileFileType(req, file, cb)
	},
	limits: PROFILE_LIMIT
}).single('profile');

const musicArrayUpload = multer({
	storage: multer.memoryStorage(),
	fileFilter: function (req, file, cb) {
		checkMusicFileType(req, file, cb)
	},
	limits: MUSIC_LIMIT
}).fields([{ name: 'music', maxCount: 6 }, { name: 'thumbnail'}]);

const inviteUserUpload = multer({
	storage: multer.memoryStorage(),
	fileFilter: function (req, file, cb) {
		checkProfileFileType(req, file, cb)
	},
	limits: PROFILE_LIMIT
}).single('profile');

router.post('/media/data/:type/:flag', verifyToken, function (req, res, next) {
	mediaThumUpload(req, res, function (err) { return uploadMediaThumbnail(req, res, err, next); });
});

router.post('/media/:media_id', verifyToken, function (req, res, next) {
	mediaArrayUpload(req, res, function (err) {
		return uploadMedias(req, res, err, next);
	});
});

//Edit Profile API
router.post('/profile', verifyToken, function(req, res, next) {
	profileUpload(req, res, function (err) { return uploadProfile(req, res, err, next); });
});

//Invite New User API
router.post('/invite/user', verifyToken, function(req, res, next) {
	inviteUserUpload(req, res, function (err) { return uploadInviteNewUser(req, res, err, next); });
});

//Edit invite New User API
router.post('/edit/invite/user', verifyToken, function(req, res, next) {
	inviteUserUpload(req, res, function (err) { return editInviteNewUser(req, res, err, next); });
});

//Add Music
router.post('/music', verifyToken, function (req, res, next) {
	musicArrayUpload(req, res, function (err) { uploadMusicFiles(req, res, err, next); });
});

export default router;
