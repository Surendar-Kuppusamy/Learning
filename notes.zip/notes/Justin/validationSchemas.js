import validator from 'express-validator';
import { getDBConnection } from '../config/db.js';
import { Users } from '../models/UsersModel.js';

const { validationResult } = validator;

export const customValidationResult = validationResult.withDefaults({
    formatter: error => {
        return {
            status: 'error',
            message: error.msg,
            data: {
                params:error.param
            }
        };
    },
});

export const userStatusChangeValidationSchema = {
    userIds: {
        notEmpty: {
            errorMessage: "User ID is required."
        },
        custom: {
            options: async (value) => {
                if(value.length > 0) {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('User ID is required.');
                }
            }
        }
    },
    status: {
        notEmpty: {
            errorMessage: "Status is required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'number' && (value == 1 || value == 2)) {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Invalid user status.')
                }
            }
        }
    }
}

export const deleteJustinValidationSchema = {
    justinIds: {
        notEmpty: {
            errorMessage: "Justin ID is required."
        },
        custom: {
            options: async (value) => {
                if(value.length > 0) {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Justin ID is required.');
                }
            }
        }
    }
}

export const deleteMusicValidationSchema = {
    musicIds: {
        notEmpty: {
            errorMessage: "Music ID is required."
        },
        custom: {
            options: async (value) => {
                if(value.length > 0) {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Music ID is required.');
                }
            }
        }
    }
}

export const userRegisterValidationSchema = {
    user_role: {
        notEmpty: {
            errorMessage: "User role is required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'number') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('User role must be integer.')
                }
            }
        }
    },
    first_name: {
        trim: true,
        notEmpty: {
            errorMessage: "Name is required."
        },
        /* isAlphanumeric: {
            errorMessage: "Name should be alpha numeric."
        }, */
        isLength: {
            options: {
                min: 2
            },
            errorMessage: "Name should be greater than 2 characters."
        },
        isLength: {
            options: {
                max: 200
            },
            errorMessage: "Name should be less than 200 characters."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'string') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Name must be string.')
                }
            }
        }
    },
    last_name: {
        trim: true,
    },
    country: {
        trim:true,
        notEmpty: {
            errorMessage: "Country is required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'string') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Country value must be string.')
                }
            }
        }
    },
    country_code: {
        trim:true,
        notEmpty: {
            errorMessage: "Country code is required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'string') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Country code value must be string.')
                }
            }
        }
    },
    mobile_number: {
        notEmpty: {
            errorMessage: "Mobile number is required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'number') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Mobile number must be integer.');
                }
            }
        }
        /* custom: {
            options: async (value) => {
                const db = await getDBConnection();
                const userRefs = await db.collection(Users.collection.name);
                const userDetail = await userRefs.where(Users.fields.mobile_number.key, '==', value).get();
                if(userDetail.empty) {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Mobile number already exists.')
                }
            }
        } */
    }
};
export const adminLoginValidationSchema = {
    email: {
        notEmpty: {
            errorMessage: "Email is required."
        }
    },
    password: {
        notEmpty: {
            errorMessage: "Password is required."
        }
    }
};
export const userLoginValidationSchema = {
    /* user_role: {
        notEmpty: {
            errorMessage: "User role is required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'number') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('User role must be integer.')
                }
            }
        }
    }, */
    mobile_number: {
        notEmpty: {
            errorMessage: "Mobile number is required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'number') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Mobile number must be integer.');
                }
            }
        }
    }
};

export const onboardingStepsValidationSchema = {
    step: {
        notEmpty: {
            errorMessage: "Step required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'number') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Step value must be integer.');
                }
            }
        }
    },
    is_viewed_video: {
        notEmpty: {
            errorMessage: "Video viewed status required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'number') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Video viewed status value must be integer.');
                }
            }
        }
    }
};

export const inviteHelpingHandValidationSchema = {
    first_name: {
        trim:true,
        notEmpty: {
            errorMessage: "Name required."
        },
        isLength: {
            options: {
                min: 2
            },
            errorMessage: "Name should be greater than 2 characters."
        },
        isLength: {
            options: {
                max: 200
            },
            errorMessage: "Name should be less than 200 characters."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'string') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Name must be string.')
                }
            }
        }
    },
    invite_code: {
        trim:true,
        notEmpty: {
            errorMessage: "Invite code required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'string') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Invite code must be string.')
                }
            }
        }
    }
};


export const resignHelpingHandValidationSchema = {
    invite_helpinghand_id: {
        notEmpty: {
            errorMessage: "Invite helpinghand ID required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'number') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Invite helpinghand ID must be integer.');
                }
            }
        }
    },
    is_resign: {
        notEmpty: {
            errorMessage: "Is resign required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'number') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Is resign must be integer.');
                }
            }
        }
    }
};

export const verifyInviteCodeValidationSchema = {
    invite_code: {
        trim: true,
        notEmpty: {
            errorMessage: "Invite code is required."
        }
    }
};


export const helpinghandRegisterValidationSchema = {
    user_role: {
        notEmpty: {
            errorMessage: "User role is required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'number') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('User role must be integer.')
                }
            }
        }
    },
    first_name: {
        trim: true,
        notEmpty: {
            errorMessage: "Name is required."
        },
        /* isAlphanumeric: {
            errorMessage: "Name should be alpha numeric."
        }, */
        isLength: {
            options: {
                min: 2
            },
            errorMessage: "Name should be greater than 2 characters."
        },
        isLength: {
            options: {
                max: 200
            },
            errorMessage: "Name should be less than 200 characters."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'string') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Name must be string.')
                }
            }
        }
    },
    last_name: {
        trim: true,
    },
    country: {
        trim:true,
        notEmpty: {
            errorMessage: "Country is required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'string') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Country value must be string.')
                }
            }
        }
    },
    country_code: {
        trim:true,
        notEmpty: {
            errorMessage: "Country code is required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'string') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Country code value must be string.')
                }
            }
        }
    },
    mobile_number: {
        notEmpty: {
            errorMessage: "Mobile number is required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'number') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Mobile number must be integer.');
                }
            }
        }
    },
    invite_helpinghand_id: {
        notEmpty: {
            errorMessage: "Invite helpinghand ID is required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'number') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Invite helpinghand ID must be integer.');
                }
            }
        }
    },
    temporary_helpinghand_user_id: {
        notEmpty: {
            errorMessage: "Temporary helpinghand user ID is required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'number') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Temporary helpinghand user ID must be integer.');
                }
            }
        }
    },
};
export const profileEditValidationSchema = {
    first_name: {
        trim: true,
        notEmpty: {
            errorMessage: "Name is required."
        },
        /* isAlphanumeric: {
            errorMessage: "Name should be alpha numeric."
        }, */
        isLength: {
            options: {
                min: 2
            },
            errorMessage: "Name should be greater than 2 characters."
        },
        isLength: {
            options: {
                max: 200
            },
            errorMessage: "Name should be less than 200 characters."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'string') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Name must be string.')
                }
            }
        }
    },
    last_name: {
        trim: true,
    },
	email: {
        trim: true,
    },
	dob: {
        trim: true,
    }
};

export const faqAddValidationSchema = {
    title: {
        trim: true,
        notEmpty: {
            errorMessage: "Title is required."
        },
        isLength: {
            options: {
                min: 2
            },
            errorMessage: "Title should be greater than 2 characters."
        },
        isLength: {
            options: {
                max: 200
            },
            errorMessage: "Title should be less than 200 characters."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'string') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Title must be string.')
                }
            }
        }
    },
    description: {
        notEmpty: {
            errorMessage: "Description is required."
        },
        isLength: {
            options: {
                max: 100000
            },
            errorMessage: "Description should be less than 100000 characters."
        }
    },
    status: {
        notEmpty: {
            errorMessage: "Status is required."
        },
        custom: {
            options: async (value) => {
                if(value != 1 && value != 2) {
                    return Promise.reject('Invalid status.')
                } else {
                    return Promise.resolve(true);
                }
            }
        }
    }
}

export const faqBulkActionValidationSchema = {
    faqIds: {
        notEmpty: {
            errorMessage: "Faq ID is required."
        },
        custom: {
            options: async (value) => {
                if(value.length > 0) {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('FAQ ID is required.');
                }
            }
        }
    }
}

export const blogsStatusChangeValidationSchema = {
    blogIds: {
        notEmpty: {
            errorMessage: "Blog ID is required."
        },
        custom: {
            options: async (value) => {
                if(value.length > 0) {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Blog ID is required.');
                }
            }
        }
    },
    status: {
        notEmpty: {
            errorMessage: "Status is required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'number' && (value == 1 || value == 2)) {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Invalid blog status.')
                }
            }
        }
    }
}

export const deleteBlogValidationSchema = {
    blogIds: {
        notEmpty: {
            errorMessage: "Justin ID is required."
        },
        custom: {
            options: async (value) => {
                if(value.length > 0) {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Justin ID is required.');
                }
            }
        }
    }
}

export const musicStatusChangeValidationSchema = {
    musicIds: {
        notEmpty: {
            errorMessage: "Music ID is required."
        },
        custom: {
            options: async (value) => {
                if(value.length > 0) {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Music ID is required.');
                }
            }
        }
    },
    status: {
        notEmpty: {
            errorMessage: "Status is required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'number' && (value == 1 || value == 2)) {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Invalid music status.')
                }
            }
        }
    }
}

export const ServiceValidationSchema = {
    title: {
        trim: true,
        notEmpty: {
            errorMessage: "Title is required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'string') {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Title must be string.')
                }
            }
        }
    },
    description: {
        notEmpty: {
            errorMessage: "Description is required."
        },
        isLength: {
            options: {
                max: 100000
            },
            errorMessage: "Description should be less than 100000 characters."
        }
    }
}


export const justinStatusChangeValidationSchema = {
    justinIds: {
        notEmpty: {
            errorMessage: "Justin ID is required."
        },
        custom: {
            options: async (value) => {
                if(value.length > 0) {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Justin ID is required.');
                }
            }
        }
    },
    status: {
        notEmpty: {
            errorMessage: "Status is required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'number' && (value == 1 || value == 2)) {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Invalid status.')
                }
            }
        }
    }
}

export const OnboardingStatusChangeValidationSchema = {
    justinCompilationIds: {
        notEmpty: {
            errorMessage: "Justin compilation ID is required."
        },
        custom: {
            options: async (value) => {
                if(value.length > 0) {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Music ID is required.');
                }
            }
        }
    },
    status: {
        notEmpty: {
            errorMessage: "Status is required."
        },
        custom: {
            options: async (value) => {
                if(typeof value == 'number' && (value == 1 || value == 2)) {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Invalid music status.')
                }
            }
        }
    }
}