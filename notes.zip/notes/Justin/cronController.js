import admin from 'firebase-admin';
import path from 'path';
import { FireSQL } from 'firesql';
import expressAsyncHandler from 'express-async-handler';
import { getDBConnection, getStorageConnection } from '../config/db.js';
import { Users } from '../models/UsersModel.js';
import { InviteHelpinghand } from '../models/InviteHelpinghandModel.js';
import { JustinCompilation } from '../models/JustinCompilationModel.js';
import { SendNotification } from '../models/SendNotificationModel.js';
/* import { MediaGroup } from '../models/MediaGroupModel.js'; */
import { MediaGroup } from '../models/MediasGroupModel.js';

import { getCollectionData, insertData, updateData, updateBulkData, generateVideoFromImages, getMediaArrForVideoCon, checkUserCompilationStatus, copyFile, copyFileLocal, saveErrorLogFileWithpath, getNotification, getSupportersDailyNotifications, getSendNotificationMessage, deleteDataWithDocumentID, pushNotification, addActivity, getAllReferenceData, jsonResponse } from '../common/commonFunctions.js';


export const cronCreateJustinCompilationMedia = expressAsyncHandler(async(req, res, next) => {
    let logMessage          =   '';

    try {
        const db                =   await getDBConnection();
        const storage           =   await getStorageConnection();
        const bucket            =   await storage.bucket();
        const params            =   req.params;
        let detailResponse        =   {};

        //await saveErrorLogFileWithpath('justincompilation', 'Start ==> Justin video compilation process started.');
        logMessage              =   'Start ==> Justin video compilation process started.';

        let conversion;
        let thumbnail;

        var today           =   new Date();
        var startTime       =   today.setHours(0, 0, 0);
        //var endTime         =   today.setHours(23, 59, 59);

        var fromDate        =   await admin.firestore.Timestamp.fromDate(new Date(startTime));
        //var toDate          =   await admin.firestore.Timestamp.fromDate(new Date(endTime));

        let userRef     =   await db.collection(Users.collection.name)
                                    .where(Users.fields.user_role.key, "==", 1)
                                    .where(Users.fields.justin_compilation_video_view_status.key, "==", 1)
                                    .where(Users.fields.justin_compilation_status_checked_date.key, "<", fromDate);

        if(params.user_id !== undefined) {
            userRef     =   await userRef.where(Users.fields.users_id.key, "==", parseInt(params.user_id));
        }

        userRef     =   await userRef.orderBy(Users.fields.justin_compilation_status_checked_date.key, "ASC").limit(1).get();
                                    

        const users    =   await new Promise(async(resolve, reject) => {
            if(userRef.empty) {
                return resolve([]);
            }

            let collectUsers    =   [];

            for await (const userDoc of userRef.docs) {
                const tempUser  =   await { id: userDoc.id, ... await userDoc.data() };
                collectUsers.push(tempUser);
            }

            return resolve(collectUsers);
        });

        //Get user has viewed justin compilation video
        //let users = await getCollectionData('users', userCondition, 0, 1, next);

        if(users.length == 0 && params.user_id == undefined) {
            logMessage  =   logMessage+'\n\n'+'No users for justin compilation video.';
            logMessage  =   logMessage+'\n\n'+'End ==> Justin video compilation process ended.';
            await saveErrorLogFileWithpath('justincompilation', logMessage);
            jsonResponse(res, 200, 'error', 'No users for justin compilation video.', {/* users: users */});
            return false;
        } else if(users.length == 0) {
            logMessage  =   logMessage+'\n\n'+'This user is already generated justin compilation video.';
            logMessage  =   logMessage+'\n\n'+'End ==> Justin video compilation process ended.';
            await saveErrorLogFileWithpath('justincompilation', logMessage);
            jsonResponse(res, 200, 'error', 'This user is already generated justin compilation video.', {/* users: users */});
            return false;
        }

        //let user = users[0];

        var usersResposne = await Promise.all(users.map(expressAsyncHandler(async(user, index) => {
            return new Promise(async function(resolve, reject) {

                let resetUserRecords = {
                    'justin_compilation_status_checked_date' : await admin.firestore.FieldValue.serverTimestamp()
                }
                let updateRecUser = await updateData(Users.collection.name, resetUserRecords, user.id);

                //Get required medias for respected user
                let compilationDetials = await checkUserCompilationStatus(db, user, next);

                detailResponse['compilationDetials']  =   compilationDetials;

                if(compilationDetials['status'] === false) {
                    logMessage  =   logMessage+'\n\n'+user.id+' ==> Something went wrong on extracting data.';
                    return resolve(false);
                }

                //Check minimum 5 media is available
                if(compilationDetials['asset_count'] < 5 || compilationDetials['musics'].length == 0) {
                    logMessage  =   logMessage+'\n\n'+'[User ID --> '+user.id+'] ==> Images and videos are not available for video conversion.';
                    return resolve(false);
                }

                logMessage  =   logMessage+'\n\n'+'Un used medias count ==> '+JSON.stringify(compilationDetials['un_used_medias_counts']);

                logMessage  =   logMessage+'\n\n'+'used medias count ==> '+JSON.stringify(compilationDetials['used_counts']);

                /* logMessage  =   logMessage+'\n\n'+'Un used videos data ==> '+JSON.stringify(compilationDetials['get_all_medias']);

                logMessage  =   logMessage+'\n\n'+'Un used images data ==> '+JSON.stringify(compilationDetials['get_all_justins']); */

                //Convert medias to ffmpeg commands format
                let mediaDetailsForCon = await getMediaArrForVideoCon(compilationDetials['get_all_medias'], compilationDetials['get_all_justins'], compilationDetials['get_compilation_media'], compilationDetials['musics'], user.id, compilationDetials['un_used_medias_counts']);

                detailResponse['mediaDetailsForCon']  =   mediaDetailsForCon;

                if(mediaDetailsForCon['status'] != undefined && mediaDetailsForCon['status'] == false) {
                    logMessage  =   logMessage+'\n\n'+'[User ID --> '+user.id+'] ==> Images and videos are not available for video conversion.';
                    return resolve(false);
                }
                
                conversion = await generateVideoFromImages(bucket, mediaDetailsForCon);
                
                if(conversion.status == undefined) {
                    logMessage  =   logMessage+'\n\n'+'[User ID --> '+user.id+'] ==> Something went wrong.';
                    return resolve(false);
                } else if(conversion.status != true) {
                    logMessage  =   logMessage+'\n\n'+'[User ID --> '+user.id+'] ==> '+conversion.message;
                    return resolve(conversion);
                }

                if(process.env.MODE == "development") {
                    thumbnail = await copyFileLocal(mediaDetailsForCon['source_thumb_path'], mediaDetailsForCon['dest_thumb_path']);
                } else {
                    thumbnail = await copyFile(mediaDetailsForCon['source_thumb_path'], mediaDetailsForCon['dest_thumb_path']);
                }

                if(thumbnail != true) {
                    logMessage  =   logMessage+'\n\n'+'Thumbnail source ==> '+mediaDetailsForCon['source_thumb_path'];
                    logMessage  =   logMessage+'\n\n'+'[User ID --> '+user.id+'] ==> Error on thumbnail copy process.';
                    return resolve(false);
                }

                if(conversion.status == true && thumbnail == true) {
                    let justCompInsObj = {
                        'user_id'   : parseInt(user.id),
                        'caption'   : mediaDetailsForCon['output_caption'],
                        'video'     : path.basename(mediaDetailsForCon['output_path']),
                        'thumbnail' : path.basename(mediaDetailsForCon['dest_thumb_path']),
                        'durations' : mediaDetailsForCon['duration'],
                        'created_on': admin.firestore.FieldValue.serverTimestamp()
                    }
                    let insertCompilation = await insertData(JustinCompilation, justCompInsObj, JustinCompilation.fields.justincompilation_id.key);
                    let updateUser = {
                        'justin_compilation_video_view_status'          : 0,
                    }

                    logMessage  =   logMessage+'\n\n'+'[All Medias IDs] ==> '+JSON.stringify(mediaDetailsForCon['used_ids']);

                    if(mediaDetailsForCon['used_ids']['media'].length > 0) {
                        logMessage  =   logMessage+'\n\n'+'[Used Media IDs] ==> '+mediaDetailsForCon['used_ids']['media'].join(", ");
                        updateUser['justin_compilation_video_used_media_ids'] = await admin.firestore.FieldValue.arrayUnion(...mediaDetailsForCon['used_ids']['media']);
                    }
                    if(mediaDetailsForCon['used_ids']['populated'].length > 0) {
                        logMessage  =   logMessage+'\n\n'+'[Used Populated IDs] ==> '+mediaDetailsForCon['used_ids']['populated'].join(", ");
                        updateUser['justin_compilation_video_used_populated_ids'] = await admin.firestore.FieldValue.arrayUnion(...mediaDetailsForCon['used_ids']['populated']);
                    }
                    if(mediaDetailsForCon['used_ids']['music'].length > 0) {
                        logMessage  =   logMessage+'\n\n'+'[Used Music IDs] ==> '+mediaDetailsForCon['used_ids']['music'].join(", ");
                        updateUser['justin_compilation_video_used_music_ids'] = await admin.firestore.FieldValue.arrayUnion(...mediaDetailsForCon['used_ids']['music']);
                    }
                    
                    //console.log(logMessage);

                    let updateColUser = await updateData(Users.collection.name, updateUser, user.id);
                    logMessage  =   logMessage+'\n\n'+'[User ID --> '+user.id+'] ==> Justin compilation video is generated for respected user.';
                    return resolve(true);
                } else {
                    logMessage  =   logMessage+'\n\n'+'[User ID --> '+user.id+'] ==> Something went wrong. Please check error log.';
                    return resolve(true);
                }
            });
        })));

        logMessage  =   logMessage+'\n\n'+'End ==> Justin video compilation process ended.';
        await saveErrorLogFileWithpath('justincompilation', logMessage);

        jsonResponse(res, 200, 'success', 'Justin compilation process completed.', { usersResposne: usersResposne, detailResponse: detailResponse });
    } catch(e) {
        logMessage  =   logMessage+'\n\n'+'Something went wrong.';
        logMessage  =   logMessage+'\n\n'+e.stack;
        await saveErrorLogFileWithpath('justincompilation', logMessage);
        return jsonResponse(res, 400, 'error', 'Something went wrong.', { error: e.stack });
    }
});


export const cronSupportersNotifications = expressAsyncHandler(async(req, res, next) => {
    
    let logMessage              =   '';

    try { 

        req.setTimeout(900 * 1000);  //15 minutes

        const db                    =   await getDBConnection();
        const params                =   req.params;
        const repeatMsgID           =   1;
        let supportersNotifications =   {};

        

        logMessage                  =   'Start ==> Cron supporter notification started.';

        let inviteSupporterQuery    =   await db.collection(InviteHelpinghand.collection.name);
        inviteSupporterQuery        =   await inviteSupporterQuery.where('status', '==', 1);
        inviteSupporterQuery        =   await inviteSupporterQuery.where('is_resigned', '==', 0);
        

        if(params.supporter_id != undefined && params.supporter_id != null && params.supporter_id != 0) {
            inviteSupporterQuery    =   await inviteSupporterQuery.where('helpinghand_reference', '==', db.doc(Users.collection.name+'/'+params.supporter_id.toString()));
        }

        const inviteDetails         =   await inviteSupporterQuery.get();

        if(inviteDetails.empty) {
            logMessage  =   logMessage+'\n\n'+'There is no active supporters.';
            logMessage  =   logMessage+'\n\n'+'End ==> Cron supporter notification ended.';
            await saveErrorLogFileWithpath('dailyNotification', logMessage);
            return jsonResponse(res, 200, 'success', 'There is no active supporters.', {});
        }

        for await (const inviteRecords of inviteDetails.docs) {
            var invite                      =   await inviteRecords.data();
            var inviteID                    =   inviteRecords.id;
            const buildMessagePromise       =   await new Promise(async(resolve, reject) => {
                if(invite.helpinghand_reference != null && invite.user_reference != null) {
                    
                    await db.getAll(invite.user_reference, invite.helpinghand_reference).then(async(users) => {
                        const supporterDetail   =   await users[1].data();
                        const userDetail        =   await users[0].data();
                        const supporterID       =   users[1].id;

                        if(supporterDetail === undefined) {
                            console.log('inviteID', inviteID);
                            logMessage  =   logMessage+'\n\n'+'Check this invite ID, becuase device token is missing ===>'+inviteID;
                            return resolve(false);
                        }

                        var deviceToken         =   (supporterDetail["device_token"] !== undefined)
                                                        ? supporterDetail["device_token"]
                                                        : '' ;
                        var userRole            =   supporterDetail.user_role;
                        var userName            =   userDetail.first_name+" "+userDetail.last_name;
                        var supporterName       =   supporterDetail.first_name+" "+supporterDetail.last_name;

                        userName                =   userName.trim();
                        supporterName           =   supporterName.trim();

                        if(deviceToken != '') {

                            var messageID       =   (invite.daily_notification_message_id != undefined && invite.daily_notification_message_id != null) ? parseInt(invite.daily_notification_message_id + 1) : 0;

                            messageID           =   (messageID > 6) ? repeatMsgID : messageID;

                            messageID           =   messageID.toString();

                            supportersNotifications[supporterID]            =   (supportersNotifications.hasOwnProperty(supporterID))
                                                                                    ? supportersNotifications[supporterID]
                                                                                    : {};

                            supportersNotifications[supporterID][messageID] =    (supportersNotifications[supporterID].hasOwnProperty(messageID))
                                                                                    ? supportersNotifications[supporterID][messageID]
                                                                                    : { invite_ids: [], user_names: [] };

                            supportersNotifications[supporterID][messageID]['invite_ids'].push(inviteID);
                            supportersNotifications[supporterID][messageID]['user_names'].push(userName);
                            supportersNotifications[supporterID][messageID]['supporter_name']   =   supporterName;
                            supportersNotifications[supporterID][messageID]['device_token']     =   deviceToken;
                            supportersNotifications[supporterID][messageID]['user_role']        =   userRole;

                            logMessage  =   logMessage+'\n\n'+'Supporter ID ==>'+supporterID+'('+supporterName+'), notification message build successfully.';

                            return resolve(true);
                        } else {

                            logMessage  =   logMessage+'\n\n'+'Device token is missing for this Supporter ID ==>'+supporterID+'('+supporterName+').';

                            return resolve(false);
                        }
                    });
                } else {

                    logMessage  =   logMessage+'\n\n'+'Something went wrong on invite ID('+invite.id+').';
                    resolve(true);
                }

            });
        }


        for await (const [supporter_id, supporter_detail] of Object.entries(supportersNotifications)) {

            for await (const [message_id, message_detail] of Object.entries(supporter_detail)) {

                var messageID           =   message_id;
                messageID               =   parseInt(messageID);

                var notificationMessage =   await getSupportersDailyNotifications(messageID);
                var message             =   notificationMessage.message;
                var userNames           =   "";
                //var notification        =   {};

                if(message_detail.user_names.length > 1) {
                    var maxUserLength   =   Math.abs((message_detail.user_names.length - 1));
                    var tempUserName    =   message_detail.user_names[maxUserLength];
                    message_detail.user_names.pop();
                    userNames   =   message_detail.user_names.join(', ');
                    userNames   =   (messageID != 6) ? userNames+' and '+tempUserName : userNames+' or '+tempUserName;
                } else {
                    userNames   =   message_detail.user_names[0];
                }

                message                 =   message.replace("[[SUPPORTER_NAME]]", message_detail.supporter_name);
                message                 =   message.replace("[[USER_NAMES]]", userNames);

                //console.log('message_detail', message_detail.device_token);

                var notification        =   await getNotification(notificationMessage.title, message, message_detail.device_token, { 'user_role': message_detail.user_role });

                var notificationStatus  =   await pushNotification(notification);

                logMessage              =   logMessage+'\n\n'+'Message: '+ message;

                if(notificationStatus.status) {
                    logMessage  =   logMessage+'\n\n'+'Daily notification send successfully.';
                    var dataObj =   { 'daily_notification_message_id': messageID, 'modified_on': await admin.firestore.FieldValue.serverTimestamp() };
                    var status  =   await updateBulkData(InviteHelpinghand.collection.name, dataObj, message_detail.invite_ids, next);
                } else {
                    logMessage  =   logMessage+'\n\n'+'Daily notification send failed.';
                    logMessage  =   logMessage+'\n\n'+'Firebase Error: ==> '+notificationStatus.response;
                }
            }
        }

        logMessage  =   logMessage+'\n\n'+'End ==> Cron supporter notification ended.';
        await saveErrorLogFileWithpath('dailyNotification', logMessage);

        return jsonResponse(res, 200, 'success', 'Daily supporters notification send successfully.', supportersNotifications);
    } catch(e) {
        logMessage  =   logMessage+'\n\n'+'Something went wrong.';
        logMessage  =   logMessage+'\n\n'+e.stack;
        await saveErrorLogFileWithpath('dailyNotification', logMessage);
        return jsonResponse(res, 400, 'error', 'Something went wrong.', { error: e.stack });
    }
});

export const cronSendNotificaton = expressAsyncHandler(async(req, res, next) => {

    let logMessage              =   '';

    try {

        const db                    =   await getDBConnection();
        const params                =   req.params;
        const repeatMsgID           =   1;
        let notification            =   {};
        const afterHours            =   3;  //3 Hours
        let sendUsers               =   []; //One notification send users ID.

        let allresponse             =   [];


        
        logMessage                  =   'Start ==> Cron Send notification started.';

        var today           =   new Date();
        var startTime       =   today.setTime(today.getTime() - afterHours * 60 * 60 * 1000);
        var fromDate        =   await admin.firestore.Timestamp.fromDate(new Date(startTime));
        

        let sendNotificationQuery   =   await db.collection(SendNotification.collection.name);
        sendNotificationQuery       =   await sendNotificationQuery.where('status', '==', 0);
        sendNotificationQuery       =   await sendNotificationQuery.where('created_on', '<', fromDate);

        var notificationDetails     =   await sendNotificationQuery.get();

        if(notificationDetails.empty) {
            logMessage  =   logMessage+'\n\n'+'There is no notification for send.';
            logMessage  =   logMessage+'\n\n'+'End ==> Cron send notification ended.';
            await saveErrorLogFileWithpath('sendNotification', logMessage);
            return jsonResponse(res, 200, 'success', 'There is no notification for send.', {});
        }

        let sendNotification    =   await Promise.all(notificationDetails.docs.map(expressAsyncHandler(async(detailDoc) => {
            return new Promise(async function(resolve, reject){
                var detail                  =   { 'id': detailDoc.id, ...detailDoc.data() };
                var getAllReferenceLinks    =   [detail.from_user_ref, detail.to_user_ref];
                var getAllReferenceNames    =   ['fromUser', 'toUser'];
                if(detail.reference != undefined && detail.reference != null) {
                    getAllReferenceLinks.push(detail.reference);
                    getAllReferenceNames.push('reference');
                }

                let notificationType    =   detail.type;

                var getFromUserID   =   detail.from_user_ref._path.segments[1];
                var getToUserID     =   detail.to_user_ref._path.segments[1];

                var users           =   await getAllReferenceData(getAllReferenceNames, getAllReferenceLinks);

                var fromUserDetail      =   users['fromUser'];
                var toUserDetail        =   users['toUser'];
                var toUserID            =   fromUserDetail.id;
                var fromUserID          =   toUserDetail.id;
                var referenceID         =   (users['reference'] != undefined) ? parseInt(users['reference'].id) : null;

                var canNotificationSend =   (sendUsers.indexOf(toUserID) === -1) ? true : true;
                sendUsers.push(toUserID);

                var fromName            =   fromUserDetail.first_name+" "+fromUserDetail.last_name;
                fromName                =   fromName.trim();

                var toName              =   toUserDetail.first_name+" "+toUserDetail.last_name;
                toName                  =   toName.trim();

                var deviceToken         =   toUserDetail.device_token.trim();

                var activity            =   await addActivity('time_media_viewed', toUserID, fromUserID, referenceID, MediaGroup.collection.name, {'info': 'Activity from timeout media view cron.'});

                if(deviceToken != '') {

                    var notificationMessage =   await getSendNotificationMessage(notificationType);
                    var message             =   notificationMessage.message;

                    message                 =   message.replace("[[TO]]", toName);
                    message                 =   message.replace("[[FROM]]", fromName);

                    var notification        =   await getNotification(notificationMessage.title, message, deviceToken, toUserDetail);

                    var notificationStatus  =   await pushNotification(notification);
                    
                    allresponse.push(notificationStatus);

                    logMessage              =   logMessage+'\n\n'+'Message: '+ message;

                    if(notificationStatus.status) {
                        logMessage  =   logMessage+'\n\n'+'Notification and activity send successfully.';
                        logMessage  =   logMessage+'\n\n'+'Detail: '+JSON.stringify(detail);

                        logMessage  =   logMessage+'\n\n'+JSON.stringify(notificationStatus);
                        logMessage  =   logMessage+'\n\n'+'Noted From ID -->'+fromUserID;
                        logMessage  =   logMessage+'\n\n'+'Noted To ID -->'+toUserID;
                        logMessage  =   logMessage+'\n\n'+'Send Notification ID -->'+detail.id;

                        var updateStatus = {
                            'status'        :   2,
                            'comments'      :   'Notification and activity send successfully.',
                            'modified_on'   :   await admin.firestore.FieldValue.serverTimestamp()
                        }
                        var updateNotification  =   await updateData(SendNotification.collection.name, updateStatus, detail.id);
                        
                        //let deleteMediaGroup = await deleteDataWithDocumentID(SendNotification.collection.name, [parseInt(detail.id)], next);
                        resolve(true);

                    } else {
                        logMessage              =   logMessage+'\n\n'+'Daily notification send failed.';
                        logMessage              =   logMessage+'\n\n'+'Firebase Error: ==> '+notificationStatus.response;

                        logMessage  =   logMessage+'\n\n'+'Detail: '+JSON.stringify(detail);

                        //logMessage  =   logMessage+'\n\n'+JSON.stringify(notificationStatus);

                        var updateStatus = {
                            'status'        :   2,
                            'comments'      :   notificationStatus.response,
                            'modified_on'   :   await admin.firestore.FieldValue.serverTimestamp()
                        }
                        var updateNotification  =   await updateData(SendNotification.collection.name, updateStatus, detail.id);
                        resolve(false);
                    }
                } else {
                    logMessage  =   logMessage+'\n\n'+'Device Token is missing for this user ID ==> '+toUserID;
                    logMessage  =   logMessage+'\n\n'+'Detail: '+JSON.stringify(detail);
                    var updateStatus = {
                        'status'        :   2,
                        'comments'      :   'Device Token is not submited by the user.',
                        'modified_on'   :   await admin.firestore.FieldValue.serverTimestamp()
                    }
                    var updateNotification  =   await updateData(SendNotification.collection.name, updateStatus, detail.id);
                    resolve(true);
                }
            });
        })));

        logMessage      =   logMessage+'\n\n'+'End ==> Cron send notification ended.';
        var logStatus   =   await saveErrorLogFileWithpath('sendNotification', logMessage);

        return jsonResponse(res, 200, 'success', 'Notification send successfully.', {sendNotification: sendNotification, allresponse: allresponse});
    } catch(e) {
        logMessage  =   logMessage+'\n\n'+'Something went wrong.';
        logMessage  =   logMessage+'\n\n'+e.stack;
        await saveErrorLogFileWithpath('sendNotification', logMessage);
        return jsonResponse(res, 400, 'error', 'Something went wrong.', { error: e.stack });
    }
});