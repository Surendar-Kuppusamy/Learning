import { Component, OnInit, Input, EventEmitter, Output, ViewChild, AfterViewInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Http } from '@angular/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { interval, Subscription } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { PaginationService } from '../../../services/pagination.service';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DialogUserEditComponent } from '../dialog-user-edit/dialog-user-edit.component';
import * as $ from 'jquery';
//import 'datatables.net';
import { environment } from 'src/environments/environment';

interface userFilters {
  offset: Number;
  limit: Number;
  search: String;
  userRole: String;
  sort: String;
  total: Number;
}

@Component({
  selector: 'app-super-user',
  templateUrl: './super-user.component.html',
  styleUrls: ['./super-user.component.css']
})
export class SuperUserComponent implements OnInit {
  allUsers;
  downloadCsvForm;
  type;
  from;
  formdetail;
  to;


  loader: boolean = false;

  pagination:any

  filters = this.fb.group({ offset: this.fb.control(1), limit: this.fb.control(10), search: this.fb.control(''), sort: this.fb.control(''), total: this.fb.control(0) });

  showEntries = { offset: 1, limit: 50, search: '', sort: '', total: 0 };

  limits = [10, 50, 100, 1000, 5000, 10000, 20000];

  
  @Output() passEntry: EventEmitter<any> = new EventEmitter();
  editUserDialogRef: MatDialogRef<DialogUserEditComponent>;

  @ViewChild(DataTableDirective, {static: false}) dtElement: DataTableDirective;

  dtOptions: DataTables.Settings = {};

  dtTrigger: Subject<any> = new Subject();


  constructor(private dialog: MatDialog, private http: Http, private router: Router, private fb: FormBuilder, private paginationService: PaginationService) { }

  openEditUserDialog(userId) {

    this.passEntry.emit(userId);
    const editregAdminDialogRef = this.dialog.open(DialogUserEditComponent);
    editregAdminDialogRef.componentInstance.userId = userId;

  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }


  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }


  ngOnInit() {
    if (!sessionStorage.superAdminId) {
      this.router.navigate(['/super-login']);
    }

    this.dtOptions = {
      // Declare the use of the extension in the dom parameter
      //dom: 'Bfrtip',
      "language": {
        "emptyTable": "No Users",
        "processing": "Loading..."
      },
      "searching": false,
      "paging" : false,
      "info": false,
      "ordering": false,     
      // Configure the buttons
      /* buttons: [
        'csv',
        'excel'
      ], */
      order: [[ 0, "desc" ]]
  };
  this.downloadCsvForm = new FormGroup({
    from: new FormControl('', [Validators.required]),
    to: new FormControl('', [Validators.required])
  });

    this.getAllRegularAdmins();
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();
      // Call the dtTrigger to rerender again
      this.dtTrigger.next();
    });
  }

  loadTable() {
    //$('#example').DataTable();
  }

  changeLimit() {
    var tempFilter = this.filters.getRawValue();
    this.filters.patchValue({ offset: 1, limit: parseInt(tempFilter.limit) });
    this.getAllRegularAdmins();
    //this.rerender();
  }

  searchFilter() {
    var tempFilter = this.filters.getRawValue();
    this.filters.patchValue({ offset: 1 });
    this.getAllRegularAdmins();
  }

  getFilterData() {
    this.filters.patchValue({ offset: 1 });
    this.getAllRegularAdmins();
  }

  setPage(page) {
    this.filters.patchValue({ offset: parseInt(page) });
    this.getAllRegularAdmins();
  }

  superAdminLogout = () => {
    sessionStorage.removeItem('superAdminId');
    this.router.navigate(['/super-login']);
  }

  getAllRegularAdmins() {

    this.loader = true;
    var tempFilter = this.filters.getRawValue();
    this.showEntries = tempFilter;

    this.http.post(`${environment.apiUrl}/getAllUsers`, tempFilter).map((res) => res.json()).subscribe((data) => {

      console.log("Checking data", data);

      if (data.status == 200) {
        this.allUsers = data.data;

        this.pagination = this.paginationService.getPagination(data.total, (tempFilter.offset), tempFilter.limit);
        //console.log(this.pagination);
        this.filters.patchValue({ total: data.total });
        var tempFilters = this.filters.getRawValue();
        this.showEntries = tempFilters;

        /* const l = this.allUsers.length;
        this.allUsers = this.allUsers.map((v, i) => {
          return {
            ...v,
            sr_no: l - i
          }
        }); */

        this.rerender();
        this.loader = false;


      }
      else {
        this.rerender();

        this.allUsers = '';
        this.loader = false;

      }

    });

  }

  






  deleteUser(userId) {
    if (confirm('Are you sure to want to delete?')) {
      this.http.post(`${environment.apiUrl}/deleteUser`, { userId }).map((res) => res.json()).subscribe((data) => {

        if (data.status == 200) {
          alert('Successfully Deleted!');
          window.location.reload();
        }
        else {


        }

      });

    }

    else {

    }
  }




}
