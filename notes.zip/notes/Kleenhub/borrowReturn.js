dotenv = require('dotenv');
dotenv.config();

const  dbSchema= require('../../config/config'), 

mongoose = require('mongoose'),
alertMessages = require('../../config/alertMessages.js'), // Frontend alerts
globalsFunctions         = require('../../config/globals'),
co                  = require('co'),
jwt                  = require('jsonwebtoken'),
request              = require("request"),
ObjectId = require('mongodb').ObjectID;
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY_TEST);

// API LIST

module.exports = {

setting: function(req,res){
    co(function*(){
   var allTrans= yield dbSchema.BorrowReturn.find({});
   for(let t of allTrans)
   {
    let getType= yield dbSchema.Restaurant.findOne({_id:t.restaurantId},{type:1});
   let update= yield dbSchema.BorrowReturn.updateOne({_id:t._id},{$set:{type:getType.type}})
   console.log("done")
   }
    res.json("done");

     }).catch(function(err){
      console.log(err)
      err = err && err.errorCode ? err : {errorCode: 500, errorMessage: err};
      return res.status(200).json({status: 0, message: alertMessages.failure, data:err.errorMessage });
    });
   },


  // if(!checkUser.stripeCustomerId) return res.status(200).json({status: 2, message: "Please go to your account settings to add it.", data: [] });
       


  borrowBoxes: function(req, res) { 
   co(function*(){
    console.log("requet-----------", req.body)
    if(!(req.body.userId) || !(req.body.borrowUID)) return res.status(200).json({status: 0, message: "Bad Request!", data: [] });

    var reqObjectUser= {_id :req.body.userId,isActive:1};  
    const checkUser= yield dbSchema.User.findOne(reqObjectUser).exec();
    if(!checkUser) return res.status(200).json({status: 0, message: alertMessages.userNotFound, data: [] });

  if(!checkUser.stripeCustomerId) return res.status(200).json({status: 2, message: "Please go to your account settings to add it.", data: [] });
       

    var reqObjectRest= {borrowUID :req.body.borrowUID};  
    const checkRest= yield dbSchema.Restaurant.findOne(reqObjectRest).exec();

    if(!checkRest) return res.status(200).json({status: 0, message: alertMessages.restNotFound, data: [] });


// if(req.body.borrowNumberOfCleanCups === undefined || req.body.borrowNumberOfCleanCups == null)
// {
//   return res.status(200).json({status: 0, message:"Please update your application to use this feature!", data: [] });
// }


        if(checkRest.type == 'Restaurant')

{

     if(req.body.boxType === 'Box')
     {  
    var countOfRemainingBoxes= yield dbSchema.BorrowReturn.aggregate([{$match:{userId:ObjectId(req.body.userId),isActive:1,type:'Restaurant'}},
      {$group:{"_id": 1,"remainingNumberOfBoxes": { $sum:"$remainingNumberOfBoxes"}}}]);
    if(countOfRemainingBoxes != "")
    {
     var userCanBorrow= 15 - parseInt(countOfRemainingBoxes[0].remainingNumberOfBoxes);
     if(countOfRemainingBoxes[0].remainingNumberOfBoxes >= 15 || userCanBorrow < (parseInt(req.body.borrowNumberOfCleanBoxesMedium) + parseInt(req.body.borrowNumberOfCleanBoxesLarge)))
     {
      return res.status(200).json({status: 0, message: "Borrow limit exceeded!", data: [] });
    }
    else
    {
     if( checkRest.numberOfCleanBoxesMedium  >= req.body.borrowNumberOfCleanBoxesMedium && checkRest.numberOfCleanBoxesLarge >= req.body.borrowNumberOfCleanBoxesLarge)
     {
        
         var currentDate = new Date();  

         currentDate.setDate(currentDate.getDate() + 10); 
         currentDate.setSeconds(0);     
         currentDate.setMilliseconds(0);     

         let updatedCleanMediumBoxCountResturant= parseInt(checkRest.numberOfCleanBoxesMedium) -  parseInt(req.body.borrowNumberOfCleanBoxesMedium);
         let updatedCleanLargeBoxCountResturant=  parseInt(checkRest.numberOfCleanBoxesLarge) -  parseInt(req.body.borrowNumberOfCleanBoxesLarge);
         let totalCleanBoxCountResturant=  parseInt(updatedCleanMediumBoxCountResturant) +  parseInt(updatedCleanLargeBoxCountResturant);

         let updateBoxData= yield dbSchema.Restaurant.updateOne(reqObjectRest,{$set:{numberOfCleanBoxes: parseInt(totalCleanBoxCountResturant),numberOfCleanBoxesMedium:updatedCleanMediumBoxCountResturant ,numberOfCleanBoxesLarge:updatedCleanLargeBoxCountResturant}});

         let newEntry= {borrowType: 'Box',lastDateToRetrun:currentDate,'userId':req.body.userId ,type:checkRest.type  ,"restaurantId":checkRest._id ,"borrowNumberOfCleanBoxesMedium":req.body.borrowNumberOfCleanBoxesMedium ,     
         "borrowNumberOfCleanBoxesLarge":req.body.borrowNumberOfCleanBoxesLarge ,"borrowNumberOfCleanBoxes": parseInt(req.body.borrowNumberOfCleanBoxesLarge) + parseInt(req.body.borrowNumberOfCleanBoxesMedium),"borrowUID": req.body.borrowUID,"returnUID":checkRest.returnUID,
         remainingNumberOfBoxes:parseInt(req.body.borrowNumberOfCleanBoxesLarge) + parseInt(req.body.borrowNumberOfCleanBoxesMedium) ,remainingNumberOfBoxesMedium:req.body.borrowNumberOfCleanBoxesMedium ,createdOn:new Date(),remainingNumberOfBoxesLarge:req.body.borrowNumberOfCleanBoxesLarge};
         let newData= new dbSchema.BorrowReturn(newEntry);            
         let newDataSave= yield newData.save(); 


         let newEntryTransaction= {type:"Borrow",userRole :"User",borrowReturnId:newDataSave._id,'userId':req.body.userId ,"restaurantId":checkRest._id ,"borrowNumberOfCleanBoxesMedium":req.body.borrowNumberOfCleanBoxesMedium ,     
         "borrowNumberOfCleanBoxesLarge":req.body.borrowNumberOfCleanBoxesLarge ,"borrowNumberOfCleanBoxes": parseInt(req.body.borrowNumberOfCleanBoxesLarge) + parseInt(req.body.borrowNumberOfCleanBoxesMedium),createdOn:new Date()};
         let newDataTran= new dbSchema.Transactions(newEntryTransaction);            
         let newDataTranSave= yield newDataTran.save();     

         res.json({status:1,message: alertMessages.success,data:{detail:{restaurantName:checkRest.name,borrowNumberOfCleanBoxesMedium:req.body.borrowNumberOfCleanBoxesMedium,
           borrowNumberOfCleanBoxesLarge:req.body.borrowNumberOfCleanBoxesLarge,currentTime:new Date()}}}); 

		
 } 
 else
 {
  return res.status(200).json({status: 0, message: alertMessages.boxNotAvail, data: [] });
}
}
}
else
{
  if( checkRest.numberOfCleanBoxesMedium  >= req.body.borrowNumberOfCleanBoxesMedium && checkRest.numberOfCleanBoxesLarge >= req.body.borrowNumberOfCleanBoxesLarge)
  {
    if(!checkUser.stripeCustomerId) return res.status(200).json({status: 2, message: "Please go to your account settings to add it.", data: [] });
           
         var currentDate = new Date();  

         currentDate.setDate(currentDate.getDate() + 10); 
         currentDate.setSeconds(0);    
         currentDate.setMilliseconds(0);     


         let updatedCleanMediumBoxCountResturant= parseInt(checkRest.numberOfCleanBoxesMedium) -  parseInt(req.body.borrowNumberOfCleanBoxesMedium);
         let updatedCleanLargeBoxCountResturant=  parseInt(checkRest.numberOfCleanBoxesLarge) -  parseInt(req.body.borrowNumberOfCleanBoxesLarge);
         let totalCleanBoxCountResturant=  parseInt(updatedCleanMediumBoxCountResturant) +  parseInt(updatedCleanLargeBoxCountResturant);

         let updateBoxData= yield dbSchema.Restaurant.updateOne(reqObjectRest,{$set:{numberOfCleanBoxes: parseInt(totalCleanBoxCountResturant),numberOfCleanBoxesMedium:updatedCleanMediumBoxCountResturant ,numberOfCleanBoxesLarge:updatedCleanLargeBoxCountResturant}});

         let newEntry= {borrowType: 'Box',lastDateToRetrun:currentDate,'userId':req.body.userId ,"restaurantId":checkRest._id ,"borrowNumberOfCleanBoxesMedium":req.body.borrowNumberOfCleanBoxesMedium ,     
         "borrowNumberOfCleanBoxesLarge":req.body.borrowNumberOfCleanBoxesLarge ,"borrowNumberOfCleanBoxes": parseInt(req.body.borrowNumberOfCleanBoxesLarge) + parseInt(req.body.borrowNumberOfCleanBoxesMedium),"borrowUID": req.body.borrowUID,"returnUID":checkRest.returnUID,
         remainingNumberOfBoxes:parseInt(req.body.borrowNumberOfCleanBoxesLarge) + parseInt(req.body.borrowNumberOfCleanBoxesMedium) ,remainingNumberOfBoxesMedium:req.body.borrowNumberOfCleanBoxesMedium ,createdOn:new Date(),remainingNumberOfBoxesLarge:req.body.borrowNumberOfCleanBoxesLarge};
         let newData= new dbSchema.BorrowReturn(newEntry);            
         let newDataSave= yield newData.save(); 


         let newEntryTransaction= {type:"Borrow",userRole :"User",borrowReturnId:newDataSave._id,'userId':req.body.userId ,"restaurantId":checkRest._id ,"borrowNumberOfCleanBoxesMedium":req.body.borrowNumberOfCleanBoxesMedium ,     
         "borrowNumberOfCleanBoxesLarge":req.body.borrowNumberOfCleanBoxesLarge ,"borrowNumberOfCleanBoxes": parseInt(req.body.borrowNumberOfCleanBoxesLarge) + parseInt(req.body.borrowNumberOfCleanBoxesMedium),createdOn:new Date()};
         let newDataTran= new dbSchema.Transactions(newEntryTransaction);            
         let newDataTranSave= yield newDataTran.save();     

         res.json({status:1,message: alertMessages.success,data:{detail:{restaurantName:checkRest.name,borrowNumberOfCleanBoxesMedium:req.body.borrowNumberOfCleanBoxesMedium,
          borrowNumberOfCleanBoxesLarge:req.body.borrowNumberOfCleanBoxesLarge,currentTime:new Date()}}}); 


 }
 else
 {
  return res.status(200).json({status: 0, message: alertMessages.boxNotAvail, data: [] });
}
}

}

// Bowl borrow module By AppsMaven
else
{
	var countOfRemainingBowls= yield dbSchema.BorrowReturn.aggregate([{$match:{userId:ObjectId(req.body.userId),isActive:1,type:'Restaurant'}},
      {$group:{"_id": 1,"remainingNumberOfBowls": { $sum:"$remainingNumberOfBowls"}}}]);
    if(countOfRemainingBowls != "")
    {
     var userCanBorrow= 15 - parseInt(countOfRemainingBowls[0].remainingNumberOfBowls);
     if(countOfRemainingBowls[0].remainingNumberOfBowls >= 15 || userCanBorrow < (parseInt(req.body.borrowNumberOfCleanBowlsMedium) + parseInt(req.body.borrowNumberOfCleanBowlsLarge) + parseInt(req.body.borrowNumberOfCleanBowlsSmall)))
     {
      return res.status(200).json({status: 0, message: "Borrow limit exceeded!", data: [] });
    }
    else
    {
     if( checkRest.numberOfCleanBowlsMedium  >= req.body.borrowNumberOfCleanBowlsMedium && checkRest.numberOfCleanBowlsLarge >= req.body.borrowNumberOfCleanBowlsLarge && checkRest.numberOfCleanBowlsSmall >= req.body.borrowNumberOfCleanBowlsSmall)
     {
        
         var currentDate = new Date();  

         currentDate.setDate(currentDate.getDate() + 10); 
         currentDate.setSeconds(0);     
         currentDate.setMilliseconds(0);     

         let updatedCleanMediumBowlCountResturant= parseInt(checkRest.numberOfCleanBowlsMedium) -  parseInt(req.body.borrowNumberOfCleanBowlsMedium);
         let updatedCleanLargeBowlCountResturant=  parseInt(checkRest.numberOfCleanBowlsLarge) -  parseInt(req.body.borrowNumberOfCleanBowlsLarge);
         let updatedCleanSmallBowlCountResturant=  parseInt(checkRest.numberOfCleanBowlsSmall) -  parseInt(req.body.borrowNumberOfCleanBowlsSmall);
         let totalCleanBowlCountResturant=  parseInt(updatedCleanMediumBowlCountResturant) +  parseInt(updatedCleanLargeBowlCountResturant) +  parseInt(updatedCleanSmallBowlCountResturant);

         let updateBoxData= yield dbSchema.Restaurant.updateOne(reqObjectRest,{$set:{numberOfCleanBowls: parseInt(totalCleanBowlCountResturant),numberOfCleanBowlsMedium:updatedCleanMediumBowlCountResturant ,numberOfCleanBowlsLarge:updatedCleanLargeBowlCountResturant,numberOfCleanBowlsSmall:updatedCleanSmallBowlCountResturant}});

         let newEntry= {borrowType: 'Bowl',lastDateToRetrun:currentDate,'userId':req.body.userId ,type:checkRest.type  ,"restaurantId":checkRest._id ,"borrowNumberOfCleanBowlsSmall":req.body.borrowNumberOfCleanBowlsSmall ,     
         "borrowNumberOfCleanBowlsMedium":req.body.borrowNumberOfCleanBowlsMedium,"borrowNumberOfCleanBowlsLarge": req.body.borrowNumberOfCleanBowlsLarge ,"borrowNumberOfCleanBowls": parseInt(req.body.borrowNumberOfCleanBowlsMedium) + parseInt(req.body.borrowNumberOfCleanBowlsLarge) + parseInt(req.body.borrowNumberOfCleanBowlsSmall),"borrowUID": req.body.borrowUID,"returnUID":checkRest.returnUID,
         remainingNumberOfBowls:parseInt(req.body.borrowNumberOfCleanBowlsSmall) + parseInt(req.body.borrowNumberOfCleanBowlsMedium)  + parseInt(req.body.borrowNumberOfCleanBowlsLarge) ,remainingNumberOfBowlsMedium:req.body.borrowNumberOfCleanBowlsMedium ,createdOn:new Date(),remainingNumberOfBowlsSmall:req.body.borrowNumberOfCleanBowlsSmall, remainingNumberOfBowlsLarge: req.body.borrowNumberOfCleanBowlsLarge};
         let newData= new dbSchema.BorrowReturn(newEntry);            
         let newDataSave= yield newData.save(); 


         let newEntryTransaction= {type:"Borrow",userRole :"User",borrowReturnId:newDataSave._id,'userId':req.body.userId ,"restaurantId":checkRest._id ,"borrowNumberOfCleanBowlsSmall":req.body.borrowNumberOfCleanBowlsSmall ,     
         "borrowNumberOfCleanBowlsMedium":req.body.borrowNumberOfCleanBowlsMedium,"borrowNumberOfCleanBowlsLarge":req.body.borrowNumberOfCleanBowlsLarge ,"borrowNumberOfCleanBowls": parseInt(req.body.borrowNumberOfCleanBowlsSmall) + parseInt(req.body.borrowNumberOfCleanBowlsMedium) + parseInt(req.body.borrowNumberOfCleanBowlsLarge),createdOn:new Date()};
         let newDataTran= new dbSchema.Transactions(newEntryTransaction);            
         let newDataTranSave= yield newDataTran.save();     

         res.json({status:1,message: alertMessages.success,data:{detail:{restaurantName:checkRest.name,borrowNumberOfCleanBowlsMedium:req.body.borrowNumberOfCleanBowlsMedium,
           borrowNumberOfCleanBowlsLarge:req.body.borrowNumberOfCleanBowlsLarge,borrowNumberOfCleanBowlsSmall:req.body.borrowNumberOfCleanBowlsSmall,currentTime:new Date()}}}); 

		
 }
 else
 {
  return res.status(200).json({status: 0, message: alertMessages.boxNotAvail, data: [] });
}
}
}
else
{
   if( checkRest.numberOfCleanBowlsMedium  >= req.body.borrowNumberOfCleanBowlsMedium && checkRest.numberOfCleanBowlsLarge >= req.body.borrowNumberOfCleanBowlsLarge && checkRest.numberOfCleanBowlsSmall >= req.body.borrowNumberOfCleanBowlsSmall)

  {
   if(!checkUser.stripeCustomerId) return res.status(200).json({status: 2, message: "Please go to your account settings to add it.", data: [] });
           
        var currentDate = new Date();  

         currentDate.setDate(currentDate.getDate() + 10); 
         currentDate.setSeconds(0);     
         currentDate.setMilliseconds(0);     

         let updatedCleanMediumBowlCountResturant= parseInt(checkRest.numberOfCleanBowlsMedium) -  parseInt(req.body.borrowNumberOfCleanBowlsMedium);
         let updatedCleanLargeBowlCountResturant=  parseInt(checkRest.numberOfCleanBowlsLarge) -  parseInt(req.body.borrowNumberOfCleanBowlsLarge);
         let updatedCleanSmallBowlCountResturant=  parseInt(checkRest.numberOfCleanBowlsSmall) -  parseInt(req.body.borrowNumberOfCleanBowlsSmall);
         let totalCleanBowlCountResturant=  parseInt(updatedCleanMediumBowlCountResturant) +  parseInt(updatedCleanLargeBowlCountResturant) +  parseInt(updatedCleanSmallBowlCountResturant);

         let updateBoxData= yield dbSchema.Restaurant.updateOne(reqObjectRest,{$set:{numberOfCleanBowls: parseInt(totalCleanBowlCountResturant),numberOfCleanBowlsMedium:updatedCleanMediumBowlCountResturant ,numberOfCleanBowlsLarge:updatedCleanLargeBowlCountResturant,numberOfCleanBowlsSmall:updatedCleanSmallBowlCountResturant}});

         let newEntry= {borrowType: 'Bowl',lastDateToRetrun:currentDate,'userId':req.body.userId ,type:checkRest.type  ,"restaurantId":checkRest._id ,"borrowNumberOfCleanBowlsSmall":req.body.borrowNumberOfCleanBowlsSmall ,     
         "borrowNumberOfCleanBowlsMedium":req.body.borrowNumberOfCleanBowlsMedium,"borrowNumberOfCleanBowlsLarge": req.body.borrowNumberOfCleanBowlsLarge ,"borrowNumberOfCleanBowls": parseInt(req.body.borrowNumberOfCleanBowlsMedium) + parseInt(req.body.borrowNumberOfCleanBowlsLarge) + parseInt(req.body.borrowNumberOfCleanBowlsSmall),"borrowUID": req.body.borrowUID,"returnUID":checkRest.returnUID,
         remainingNumberOfBowls:parseInt(req.body.borrowNumberOfCleanBowlsSmall) + parseInt(req.body.borrowNumberOfCleanBowlsMedium)  + parseInt(req.body.borrowNumberOfCleanBowlsLarge) ,remainingNumberOfBowlsMedium:req.body.borrowNumberOfCleanBowlsMedium ,createdOn:new Date(),remainingNumberOfBowlsSmall:req.body.borrowNumberOfCleanBowlsSmall, remainingNumberOfBowlsLarge: req.body.borrowNumberOfCleanBowlsLarge};
         let newData= new dbSchema.BorrowReturn(newEntry);            
         let newDataSave= yield newData.save(); 


         let newEntryTransaction= {type:"Borrow",userRole :"User",borrowReturnId:newDataSave._id,'userId':req.body.userId ,"restaurantId":checkRest._id ,"borrowNumberOfCleanBowlsSmall":req.body.borrowNumberOfCleanBowlsSmall ,     
         "borrowNumberOfCleanBowlsMedium":req.body.borrowNumberOfCleanBowlsMedium,"borrowNumberOfCleanBowlsLarge":req.body.borrowNumberOfCleanBowlsLarge ,"borrowNumberOfCleanBowls": parseInt(req.body.borrowNumberOfCleanBowlsSmall) + parseInt(req.body.borrowNumberOfCleanBowlsMedium) + parseInt(req.body.borrowNumberOfCleanBowlsLarge),createdOn:new Date()};
         let newDataTran= new dbSchema.Transactions(newEntryTransaction);            
         let newDataTranSave= yield newDataTran.save();     

         res.json({status:1,message: alertMessages.success,data:{detail:{restaurantName:checkRest.name,borrowNumberOfCleanBowlsMedium:req.body.borrowNumberOfCleanBowlsMedium,
           borrowNumberOfCleanBowlsLarge:req.body.borrowNumberOfCleanBowlsLarge,borrowNumberOfCleanBowlsSmall:req.body.borrowNumberOfCleanBowlsSmall,currentTime:new Date()}}}); 

		


 }
 else
 {
  return res.status(200).json({status: 0, message: alertMessages.boxNotAvail, data: [] });
}
}


}

}




/*****************************/
/*****************************/
/*****************************/
/*****************************/
/*****************************/
/*****************************/




/*Cafe module*/
else
{

    var countOfRemainingBoxes= yield dbSchema.BorrowReturn.aggregate([{$match:{userId:ObjectId(req.body.userId),isActive:1,type:'Cafe'}},
      {$group:{"_id": 1,"remainingNumberOfBoxes": { $sum:"$remainingNumberOfCups"}}}]);
    if(countOfRemainingBoxes != "")
    {
     var userCanBorrow= 15 - parseInt(countOfRemainingBoxes[0].remainingNumberOfBoxes);
     if(countOfRemainingBoxes[0].remainingNumberOfBoxes >= 15 || userCanBorrow < (parseInt(req.body.borrowNumberOfCleanCupsSmall) + parseInt(req.body.borrowNumberOfCleanCupsLarge)))
     {
      return res.status(200).json({status: 0, message: "Borrow limit exceeded!", data: [] });
    }
    else
    {
     if( checkRest.numberOfCleanCupsLarge  >= req.body.borrowNumberOfCleanCupsLarge && checkRest.numberOfCleanCupsSmall >= req.body.borrowNumberOfCleanCupsSmall)
     {
            
         var currentDate = new Date();  

         currentDate.setDate(currentDate.getDate() + 10); 
         currentDate.setSeconds(0);     
         currentDate.setMilliseconds(0);     

         let updatedCleanLargeCupCount= parseInt(checkRest.numberOfCleanCupsLarge) -  parseInt(req.body.borrowNumberOfCleanCupsLarge);
         let updatedCleanSmallCupCount= parseInt(checkRest.numberOfCleanCupsSmall) -  parseInt(req.body.borrowNumberOfCleanCupsSmall);
     //   let totalCupsRemainingWithCafe = 
         let updateBoxData= yield dbSchema.Restaurant.updateOne(reqObjectRest,{$set:{numberOfCleanCups: parseInt(updatedCleanSmallCupCount) + parseInt(updatedCleanLargeCupCount),numberOfCleanCupsSmall: parseInt(updatedCleanSmallCupCount) ,numberOfCleanCupsLarge:parseInt(updatedCleanLargeCupCount)}});

  let newEntry= {borrowType: 'Cup',lastDateToRetrun:currentDate,'userId':req.body.userId ,type:checkRest.type  ,"restaurantId":checkRest._id ,"borrowNumberOfCleanCups": parseInt(req.body.borrowNumberOfCleanCupsLarge) + parseInt(req.body.borrowNumberOfCleanCupsSmall) ,"borrowNumberOfCleanCupsLarge": parseInt(req.body.borrowNumberOfCleanCupsLarge),"borrowNumberOfCleanCupsSmall": parseInt(req.body.borrowNumberOfCleanCupsSmall),     
        "borrowUID": req.body.borrowUID,"returnUID":checkRest.returnUID ,"remainingNumberOfCups": parseInt(req.body.borrowNumberOfCleanCupsLarge) + parseInt(req.body.borrowNumberOfCleanCupsSmall) ,"remainingNumberOfCupsLarge": parseInt(req.body.borrowNumberOfCleanCupsLarge),"remainingNumberOfCupsSmall": parseInt(req.body.borrowNumberOfCleanCupsSmall),createdOn:new Date()};
      
console.log("new entry-----------", newEntry)
         let newData= new dbSchema.BorrowReturn(newEntry);            
         let newDataSave= yield newData.save(); 


       
 let newEntryTransaction= {type:"Borrow",userRole :"User",borrowReturnId:newDataSave._id,'userId':req.body.userId ,"restaurantId":checkRest._id ,"totalNumberOfCleanCups": parseInt(req.body.borrowNumberOfCleanCupsLarge) + parseInt(req.body.borrowNumberOfCleanCupsSmall) ,"numberOfCleanCups": parseInt(req.body.borrowNumberOfCleanCupsLarge),"numberOfCleanCupsSmall": parseInt(req.body.borrowNumberOfCleanCupsSmall),createdOn:new Date()};
     

         let newDataTran= new dbSchema.Transactions(newEntryTransaction);            
         let newDataTranSave= yield newDataTran.save();     

         res.json({status:1,message: alertMessages.success,data:{detail:{restaurantName:checkRest.name,borrowNumberOfCleanCupsSmall:req.body.borrowNumberOfCleanCupsSmall,borrowNumberOfCleanCupsLarge:req.body.borrowNumberOfCleanCupsLarge,currentTime:new Date()}}}); 

    //}


 }
 else
 {
  return res.status(200).json({status: 0, message: alertMessages.cupsNotAvail, data: [] });
}
}
}
else
{
  if( checkRest.numberOfCleanCupsLarge  >= req.body.borrowNumberOfCleanCupsLarge && checkRest.numberOfCleanCupsSmall >= req.body.borrowNumberOfCleanCupsSmall)
     {
    if(!checkUser.stripeCustomerId) return res.status(200).json({status: 2, message: "Please go to your account settings to add it.", data: [] });
        
         var currentDate = new Date();  

         currentDate.setDate(currentDate.getDate() + 10); 
         currentDate.setSeconds(0);     
         currentDate.setMilliseconds(0);     

         let updatedCleanLargeCupCount= parseInt(checkRest.numberOfCleanCupsLarge) -  parseInt(req.body.borrowNumberOfCleanCupsLarge);
         let updatedCleanSmallCupCount= parseInt(checkRest.numberOfCleanCupsSmall) -  parseInt(req.body.borrowNumberOfCleanCupsSmall);
     //   let totalCupsRemainingWithCafe = 
         let updateBoxData= yield dbSchema.Restaurant.updateOne(reqObjectRest,{$set:{numberOfCleanCups: parseInt(updatedCleanSmallCupCount) + parseInt(updatedCleanLargeCupCount),numberOfCleanCupsSmall: parseInt(updatedCleanSmallCupCount) ,numberOfCleanCupsLarge:parseInt(updatedCleanLargeCupCount)}});

  let newEntry= {borrowType: 'Cup',lastDateToRetrun:currentDate,'userId':req.body.userId ,type:checkRest.type  ,"restaurantId":checkRest._id ,"borrowNumberOfCleanCups": parseInt(req.body.borrowNumberOfCleanCupsLarge) + parseInt(req.body.borrowNumberOfCleanCupsSmall) ,"borrowNumberOfCleanCupsLarge": parseInt(req.body.borrowNumberOfCleanCupsLarge),"borrowNumberOfCleanCupsSmall": parseInt(req.body.borrowNumberOfCleanCupsSmall),     
        "borrowUID": req.body.borrowUID,"returnUID":checkRest.returnUID ,"remainingNumberOfCups": parseInt(req.body.borrowNumberOfCleanCupsLarge) + parseInt(req.body.borrowNumberOfCleanCupsSmall) ,"remainingNumberOfCupsLarge": parseInt(req.body.borrowNumberOfCleanCupsLarge),"remainingNumberOfCupsSmall": parseInt(req.body.borrowNumberOfCleanCupsSmall),createdOn:new Date()};
         let newData= new dbSchema.BorrowReturn(newEntry);            
         let newDataSave= yield newData.save(); 


       
 let newEntryTransaction= {type:"Borrow",userRole :"User",borrowReturnId:newDataSave._id,'userId':req.body.userId ,"restaurantId":checkRest._id ,"totalNumberOfCleanCups": parseInt(req.body.borrowNumberOfCleanCupsLarge) + parseInt(req.body.borrowNumberOfCleanCupsSmall) ,"numberOfCleanCups": parseInt(req.body.borrowNumberOfCleanCupsLarge),"numberOfCleanCupsSmall": parseInt(req.body.borrowNumberOfCleanCupsSmall),createdOn:new Date()};
   

         let newDataTran= new dbSchema.Transactions(newEntryTransaction);            
         let newDataTranSave= yield newDataTran.save();     

          res.json({status:1,message: alertMessages.success,data:{detail:{restaurantName:checkRest.name,borrowNumberOfCleanCupsSmall:req.body.borrowNumberOfCleanCupsSmall,borrowNumberOfCleanCupsLarge:req.body.borrowNumberOfCleanCupsLarge,currentTime:new Date()}}}); 

   // }


 }
 else
 {
  return res.status(200).json({status: 0, message: alertMessages.cupsNotAvail, data: [] });
}
}

}

}).catch(function(err){
  console.log(err)
  err = err && err.errorCode ? err : {errorCode: 500, errorMessage: err};
  return res.status(200).json({status: 0, message: alertMessages.failure, data:err.errorMessage });
});
},


checkAvailableBoxes: function(req, res) { 
  co(function*(){
    if(!(req.body.userId) || !(req.body.borrowUID) || !(req.body.borrowNumberOfCleanBoxesMedium) || !(req.body.borrowNumberOfCleanBoxesLarge)) return res.status(200).json({status: 0, message: "Bad Request!", data: [] });

    var reqObjectUser= {_id :req.body.userId,isActive:1};  
    const checkUser= yield dbSchema.User.findOne(reqObjectUser).exec();
    if(!checkUser) return res.status(200).json({status: 0, message: alertMessages.userNotFound, data: [] });

    var reqObjectRest= {borrowUID :req.body.borrowUID};  
    const checkRest= yield dbSchema.Restaurant.findOne(reqObjectRest).exec();
    if(!checkRest) return res.status(200).json({status: 0, message: alertMessages.restNotFound, data: [] });

    var countOfRemainingBoxes= yield dbSchema.BorrowReturn.aggregate([{$match:{userId:ObjectId(req.body.userId),isActive:1}},
      {$group:{"_id": 1,"remainingNumberOfBoxes": { $sum:"$remainingNumberOfBoxes"}}}]);

    //Start: Surendar added for price details.[16-06-2022]
    const allPriceDetails = yield dbSchema.PriceDetails.find().exec();
    const userCountryDetails = yield getUserCountryDetails(checkUser.stripeCustomerId);
    var priceDetails = yield getPriceDetails(userCountryDetails.country, allPriceDetails);
    
    var mediumBoxesPrice = (priceDetails.mediumBoxesPrice != undefined) ? parseFloat(priceDetails.mediumBoxesPrice) : 10000;
    var largeBoxesPrice = (priceDetails.largeBoxesPrice != undefined) ? parseFloat(priceDetails.largeBoxesPrice) : 10000;

    /* let amount1= req.body.borrowNumberOfCleanBoxesMedium * 10000;
    let amount2= req.body.borrowNumberOfCleanBoxesLarge * 10000; */

    let amount1= req.body.borrowNumberOfCleanBoxesMedium * mediumBoxesPrice;
    let amount2= req.body.borrowNumberOfCleanBoxesLarge * largeBoxesPrice;

    //End: Surendar added for price details.[16-06-2022]

    let finalAmount= parseFloat(amount1) + parseFloat(amount2);


    if(countOfRemainingBoxes != "")
    {
     var userCanBorrow= 15 - parseInt(countOfRemainingBoxes[0].remainingNumberOfBoxes);

     if( checkRest.numberOfCleanBoxesMedium  >= req.body.borrowNumberOfCleanBoxesMedium && checkRest.numberOfCleanBoxesLarge >= req.body.borrowNumberOfCleanBoxesLarge)
     {
      res.json({status:1,message: alertMessages.success,cost:finalAmount,boxes:req.body}); 
    }

    else
     if(countOfRemainingBoxes[0].remainingNumberOfBoxes >= 15 || userCanBorrow < (parseInt(req.body.borrowNumberOfCleanBoxesMedium) + parseInt(req.body.borrowNumberOfCleanBoxesLarge)))
     {
      return res.status(200).json({status: 0, message: "Borrow limit exceeded!", data: [] });
    }

    else
    {
      return res.status(200).json({status: 0, message: alertMessages.boxNotAvail, data: [] });
    }
  }
  else
  {
    res.json({status:1,message: alertMessages.success,cost:finalAmount,boxes:req.body}); 
  }

}).catch(function(err){
  console.log(err)
  err = err && err.errorCode ? err : {errorCode: 500, errorMessage: err};
  return res.status(200).json({status: 0, message: alertMessages.failure, data:err.errorMessage });
});
},


borrowBoxesWithTransaction: function(req, res) { 
  co(function*(){
    if(!(req.body.userId) || !(req.body.transactionId) ||!(req.body.borrowUID) || !(req.body.borrowNumberOfCleanBoxesMedium) || !(req.body.borrowNumberOfCleanBoxesLarge)) return res.status(200).json({status: 0, message: "Bad Request!", data: [] });

    var reqObjectUser= {_id :req.body.userId,isActive:1};  
    const checkUser= yield dbSchema.User.findOne(reqObjectUser).exec();
    if(!checkUser) return res.status(200).json({status: 0, message: alertMessages.userNotFound, data: [] });

    var reqObjectRest= {borrowUID :req.body.borrowUID};  
    const checkRest= yield dbSchema.Restaurant.findOne(reqObjectRest).exec();
    if(!checkRest) return res.status(200).json({status: 0, message: alertMessages.restNotFound, data: [] });

    if( checkRest.numberOfCleanBoxesMedium  >= req.body.borrowNumberOfCleanBoxesMedium && checkRest.numberOfCleanBoxesLarge >= req.body.borrowNumberOfCleanBoxesLarge)
    {

      var currentDate = new Date();                                      
      currentDate.setDate(currentDate.getDate() + 10); 
      currentDate.setSeconds(0);     

      let updatedCleanMediumBoxCountResturant= parseInt(checkRest.numberOfCleanBoxesMedium) -  parseInt(req.body.borrowNumberOfCleanBoxesMedium);
      let updatedCleanLargeBoxCountResturant=  parseInt(checkRest.numberOfCleanBoxesLarge) -  parseInt(req.body.borrowNumberOfCleanBoxesLarge);
      let totalCleanBoxCountResturant=  parseInt(updatedCleanMediumBoxCountResturant) +  parseInt(updatedCleanLargeBoxCountResturant);

      let updateBoxData= yield dbSchema.Restaurant.updateOne(reqObjectRest,{$set:{numberOfCleanBoxes: parseInt(totalCleanBoxCountResturant),numberOfCleanBoxesMedium:updatedCleanMediumBoxCountResturant ,numberOfCleanBoxesLarge:updatedCleanLargeBoxCountResturant}});

      let newEntry= {lastDateToRetrun:currentDate,'userId':req.body.userId ,"restaurantId":checkRest._id ,"transactionId":req.body.transactionId,"borrowNumberOfCleanBoxesMedium":req.body.borrowNumberOfCleanBoxesMedium ,     
      "borrowNumberOfCleanBoxesLarge":req.body.borrowNumberOfCleanBoxesLarge ,"borrowNumberOfCleanBoxes": parseInt(req.body.borrowNumberOfCleanBoxesLarge) + parseInt(req.body.borrowNumberOfCleanBoxesMedium),"borrowUID": req.body.borrowUID,"returnUID":checkRest.returnUID,
      remainingNumberOfBoxes:parseInt(req.body.borrowNumberOfCleanBoxesLarge) + parseInt(req.body.borrowNumberOfCleanBoxesMedium) ,remainingNumberOfBoxesMedium:req.body.borrowNumberOfCleanBoxesMedium ,createdOn:new Date(),remainingNumberOfBoxesLarge:req.body.borrowNumberOfCleanBoxesLarge};
      let newData= new dbSchema.BorrowReturn(newEntry);            
      let newDataSave= yield newData.save(); 


      let newEntryTransaction= {type:"Borrow",userRole :"User",borrowReturnId:newDataSave._id,'userId':req.body.userId ,"restaurantId":checkRest._id ,"borrowNumberOfCleanBoxesMedium":req.body.borrowNumberOfCleanBoxesMedium ,     
      "borrowNumberOfCleanBoxesLarge":req.body.borrowNumberOfCleanBoxesLarge ,"borrowNumberOfCleanBoxes": parseInt(req.body.borrowNumberOfCleanBoxesLarge) + parseInt(req.body.borrowNumberOfCleanBoxesMedium),createdOn:new Date()};
      let newDataTran= new dbSchema.Transactions(newEntryTransaction);            
      let newDataTranSave= yield newDataTran.save();     

      res.json({status:1,message: alertMessages.success,data:{detail:{restaurantName:checkRest.name,borrowNumberOfCleanBoxesMedium:req.body.borrowNumberOfCleanBoxesMedium,
        borrowNumberOfCleanBoxesLarge:req.body.borrowNumberOfCleanBoxesLarge,currentTime:new Date(),cost: "1 DKK",transactionId:req.body.transactionId}}}); 

    }
    else
    {
      return res.status(200).json({status: 0, message: alertMessages.boxNotAvail, data: [] });
    }

  }).catch(function(err){
    console.log(err)
    err = err && err.errorCode ? err : {errorCode: 500, errorMessage: err};
    return res.status(200).json({status: 0, message: alertMessages.failure, data:err.errorMessage });
  });
},




returnBoxes: function(req, res) { 
  co(function*(){


    console.log("REQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ",req.body)
    if(!(req.body.userId) || !(req.body.returnUID) ) return res.status(200).json({status: 0, message: "Bad Request!", data: [] });

    var reqObjectUser= {_id :req.body.userId,isActive:1};  
    const checkUser= yield dbSchema.User.findOne(reqObjectUser).exec();
    if(!checkUser) return res.status(200).json({status: 0, message: alertMessages.userNotFound, data: [] });

    var reqObjectRest= {returnUID :req.body.returnUID};  
    const checkRest= yield dbSchema.Restaurant.findOne(reqObjectRest).exec();

    if(!checkRest) return res.status(200).json({status: 0, message: alertMessages.restNotFound, data: [] });




// if(req.body.returnNumberOfCups === undefined || req.body.returnNumberOfCups == null)
// {
//   return res.status(200).json({status: 0, message:"Please update your application to use this feature!", data: [] });
// }




    

         if(checkRest.type == 'Restaurant')
         {
           if(req.body.type == 'Box')
           {
           	console.log("Boxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
           	console.log("Boxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
           	console.log("Boxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
           	console.log("Boxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
           	console.log("Boxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
      var countOfRemainingBoxes= yield dbSchema.BorrowReturn.aggregate([{$match:{userId:ObjectId(req.body.userId),isActive:1}},
        {$group:{"_id": 1,"remainingNumberOfBoxesMedium": { $sum:"$remainingNumberOfBoxesMedium"},"remainingNumberOfBoxesLarge": { $sum:"$remainingNumberOfBoxesLarge"}}}]);
console.log("countOfRemainingBoxes-----------",countOfRemainingBoxes)
      if( countOfRemainingBoxes[0].remainingNumberOfBoxesMedium  >= req.body.returnNumberOfUsedBoxesMedium && countOfRemainingBoxes[0].remainingNumberOfBoxesLarge >= req.body.returnNumberOfUsedBoxesLarge)
      { 
        console.log("sdsdsd")

        var totalRowsOfTransactions= yield dbSchema.BorrowReturn.find({userId:req.body.userId,isActive:1,type:'Restaurant' , borrowType:"Box"}).sort({_id:1});
           //  var totalRowsOfTransactionsExceptRest= yield dbSchema.BorrowReturn.find({userId:req.body.userId,restaurantId:{$ne:checkRest._id},isActive:1}).sort({_id:1});
           if(!totalRowsOfTransactions)  return res.status(200).json({status: 0, message: "No transaction found!", data: [] });

                         //    var totalRowsOfTransactions= Array.prototype.push.apply(totalRowsOfTransactionsRest,totalRowsOfTransactionsExceptRest); 


                         var loopExit= 0;
                         requestLargeBoxes= req.body.returnNumberOfUsedBoxesLarge;
                         requestMediumBoxes= req.body.returnNumberOfUsedBoxesMedium;

                         var transactionPendingLargeBoxes= 0;
                         var transactionPendingMediumBoxes= 0;
                        


                           console.log(totalRowsOfTransactions)

                         for(let trans of totalRowsOfTransactions)
                         {
                          console.log("loop entered")

                           if(loopExit == 0)
                           {

              	// medium boxes
                if(requestMediumBoxes > trans.remainingNumberOfBoxesMedium)
                {
                 transactionPendingMediumBoxes= trans.remainingNumberOfBoxesMedium;
                 console.log(1)
                 requestMediumBoxes = parseInt(requestMediumBoxes) - parseInt(trans.remainingNumberOfBoxesMedium);
                 var updatedUsedMediumBoxCountBorrowReturnTable= parseInt(trans.returnNumberOfUsedBoxesMedium) + parseInt(trans.remainingNumberOfBoxesMedium);                
                 var updatedBoxRemainingCountMedium=0;
               }

               else
                 if(requestMediumBoxes == trans.remainingNumberOfBoxesMedium)
                 {
                  console.log(2)
                  transactionPendingMediumBoxes= requestMediumBoxes;

                  var updatedUsedMediumBoxCountBorrowReturnTable=parseInt(trans.returnNumberOfUsedBoxesMedium) + parseInt(requestMediumBoxes);                
                  var updatedBoxRemainingCountMedium=0;
                  requestMediumBoxes = 0;
                }

                else
                 if(requestMediumBoxes < trans.remainingNumberOfBoxesMedium)    
                 {
                  console.log(3)
                  transactionPendingMediumBoxes= requestMediumBoxes;

                  var updatedUsedMediumBoxCountBorrowReturnTable=parseInt(trans.returnNumberOfUsedBoxesMedium) + parseInt(requestMediumBoxes);
                  if(parseInt(trans.remainingNumberOfBoxesMedium) > parseInt(requestMediumBoxes))
                  {
                   var updatedBoxRemainingCountMedium=parseInt(trans.remainingNumberOfBoxesMedium) - parseInt(requestMediumBoxes);
                 }
                 else
                 {
                   var updatedBoxRemainingCountMedium=parseInt(requestMediumBoxes) - parseInt(trans.remainingNumberOfBoxesMedium);
                 }

                 requestMediumBoxes = 0;
               }


                // large boxes
                if(requestLargeBoxes > trans.remainingNumberOfBoxesLarge)
                {
                  console.log(11)
                  transactionPendingLargeBoxes= trans.remainingNumberOfBoxesLarge;
                  requestLargeBoxes = 	 parseInt(requestLargeBoxes) - parseInt(trans.remainingNumberOfBoxesLarge);

                  var updatedUsedLargeBoxCountBorrowReturnTable=parseInt(trans.returnNumberOfUsedBoxesLarge) + parseInt(trans.remainingNumberOfBoxesLarge);                
                  var updatedBoxRemainingCountLarge=0;
                }
                else 
                 if(requestLargeBoxes == trans.remainingNumberOfBoxesLarge)
                 {
                  console.log(22)
                  transactionPendingLargeBoxes= requestLargeBoxes;               

                  var updatedUsedLargeBoxCountBorrowReturnTable=parseInt(trans.returnNumberOfUsedBoxesLarge) + parseInt(requestLargeBoxes);                
                  var updatedBoxRemainingCountLarge=0;
                  requestLargeBoxes =   0;
                }

                else
                 if(requestLargeBoxes < trans.remainingNumberOfBoxesLarge)    
                 {
                  console.log(33)
                  transactionPendingLargeBoxes= requestLargeBoxes;

                  var updatedUsedLargeBoxCountBorrowReturnTable=parseInt(trans.returnNumberOfUsedBoxesLarge) + parseInt(requestLargeBoxes);
                  if(parseInt(trans.remainingNumberOfBoxesLarge) > parseInt(requestLargeBoxes))
                  {
                   var updatedBoxRemainingCountLarge= parseInt(trans.remainingNumberOfBoxesLarge) - parseInt(requestLargeBoxes);

                 }
                 else
                 {
                   var updatedBoxRemainingCountLarge=   parseInt(requestLargeBoxes) - parseInt(trans.remainingNumberOfBoxesLarge);
                 }


                 requestLargeBoxes =   0;
               }
               var totalUsedBoxCountBorrowReturnTable= parseInt(updatedUsedMediumBoxCountBorrowReturnTable) + parseInt(updatedUsedLargeBoxCountBorrowReturnTable);
               var totalBoxCountRemaining= parseInt(updatedBoxRemainingCountLarge) + parseInt(updatedBoxRemainingCountMedium);

             let updateBoxesRest= yield dbSchema.BorrowReturn.updateOne({_id:trans._id},{$set:{"returnNumberOfUsedBoxesMedium":updatedUsedMediumBoxCountBorrowReturnTable ,     
                 "returnNumberOfUsedBoxesLarge":updatedUsedLargeBoxCountBorrowReturnTable ,"returnNumberOfUsedBoxes": parseInt(totalUsedBoxCountBorrowReturnTable),"remainingNumberOfBoxes":totalBoxCountRemaining,
                 "remainingNumberOfBoxesMedium":updatedBoxRemainingCountMedium,"remainingNumberOfBoxesLarge":updatedBoxRemainingCountLarge,updatedOn:new Date()}});


               let finalUpdate= yield dbSchema.BorrowReturn.findOneAndUpdate({_id:trans._id,remainingNumberOfBoxes:0},{$set:{isActive:0,updatedOn:new Date()}});	

               if(requestMediumBoxes == 0 && requestLargeBoxes == 0)
               {
                loopExit=1;
                  if(transactionPendingLargeBoxes != 0 || transactionPendingMediumBoxes != 0 )
               {
               let newEntryTransaction= {type:"Return",userRole :"User","borrowReturnId":trans._id,'userId':req.body.userId ,"restaurantId":checkRest._id,"returnNumberOfUsedBoxesMedium":parseInt(req.body.returnNumberOfUsedBoxesMedium) ,     
               "returnNumberOfUsedBoxesLarge":parseInt(req.body.returnNumberOfUsedBoxesLarge) ,"returnNumberOfUsedBoxes": parseInt(req.body.returnNumberOfUsedBoxesMedium) + parseInt(req.body.returnNumberOfUsedBoxesLarge),createdOn:new Date()};
               let newDataTran= new dbSchema.Transactions(newEntryTransaction);            
               let newDataTranSave= yield newDataTran.save();

             }
               
              }

            }
          }

         
          if(checkRest.isDishwasher == "true")
          {

            let updatedCleanMediumBoxCountResturant=parseInt(checkRest.numberOfCleanBoxesMedium) + parseInt(req.body.returnNumberOfUsedBoxesMedium);
            let updatedCleanLargeBoxCountResturant= parseInt(checkRest.numberOfCleanBoxesLarge) + parseInt(req.body.returnNumberOfUsedBoxesLarge);
            let totalCleanBoxCountResturant= parseInt(updatedCleanMediumBoxCountResturant) + parseInt(updatedCleanLargeBoxCountResturant);

            let updateBoxData= yield dbSchema.Restaurant.updateOne(reqObjectRest,{$set:{numberOfCleanBoxes:totalCleanBoxCountResturant,numberOfCleanBoxesMedium:updatedCleanMediumBoxCountResturant ,numberOfCleanBoxesLarge:updatedCleanLargeBoxCountResturant}});
          }
          else
          {
            let updatedUsedMediumBoxCountResturant=parseInt(checkRest.numberOfUsedBoxesMedium) + parseInt(req.body.returnNumberOfUsedBoxesMedium);
            let updatedUsedLargeBoxCountResturant= parseInt(checkRest.numberOfUsedBoxesLarge) + parseInt(req.body.returnNumberOfUsedBoxesLarge);
            let totalUsedBoxCountResturant= parseInt(updatedUsedMediumBoxCountResturant) + parseInt(updatedUsedLargeBoxCountResturant);

            let updateBoxData= yield dbSchema.Restaurant.updateOne(reqObjectRest,{$set:{numberOfUsedBoxes:totalUsedBoxCountResturant,numberOfUsedBoxesMedium:updatedUsedMediumBoxCountResturant ,numberOfUsedBoxesLarge:updatedUsedLargeBoxCountResturant}});

          }


          res.json({status:1,message: alertMessages.success,boxes:req.body,Rest:checkRest}); 


        }
        else
        {
         return res.status(200).json({status: 0, message: alertMessages.boxNotAvail, data: [] });	
       }
      }

      // Bowls modules return
      else{


      	 	console.log("Bowlsssssssssssssssss")
      	 	console.log("Bowlsssssssssssssssss")
      	 	console.log("Bowlsssssssssssssssss")
      	 	console.log("Bowlsssssssssssssssss")
      	 	console.log("Bowlsssssssssssssssss")
         
        var countOfRemainingBowls= yield dbSchema.BorrowReturn.aggregate([{$match:{userId:ObjectId(req.body.userId),isActive:1}},
          {$group:{"_id": 1,"remainingNumberOfBowlsMedium": { $sum:"$remainingNumberOfBowlsMedium"},"remainingNumberOfBowlsLarge": { $sum:"$remainingNumberOfBowlsLarge"},"remainingNumberOfBowlsSmall": { $sum:"$remainingNumberOfBowlsSmall"}}}]);
  console.log("countOfRemainingBowls-----------",countOfRemainingBowls)
        if( countOfRemainingBowls[0].remainingNumberOfBowlsMedium  >= req.body.returnNumberOfUsedBowlsMedium && countOfRemainingBowls[0].remainingNumberOfBowlsLarge >= req.body.returnNumberOfUsedBowlsLarge && countOfRemainingBowls[0].remainingNumberOfBowlsSmall >= req.body.returnNumberOfUsedBowlsSmall)
        { 
          console.log("sdsdsd")
  
          var totalRowsOfTransactions= yield dbSchema.BorrowReturn.find({userId:req.body.userId,isActive:1,type:'Restaurant', borrowType:"Bowl"}).sort({_id:1});
             //  var totalRowsOfTransactionsExceptRest= yield dbSchema.BorrowReturn.find({userId:req.body.userId,restaurantId:{$ne:checkRest._id},isActive:1}).sort({_id:1});
             if(!totalRowsOfTransactions)  return res.status(200).json({status: 0, message: "No transaction found!", data: [] });
  
                           //    var totalRowsOfTransactions= Array.prototype.push.apply(totalRowsOfTransactionsRest,totalRowsOfTransactionsExceptRest); 
  
  
                           var loopExit= 0;
                           requestSmallBowls= req.body.returnNumberOfUsedBowlsSmall;
                           requestLargeBowls= req.body.returnNumberOfUsedBowlsLarge;
                           requestMediumBowls= req.body.returnNumberOfUsedBowlsMedium;
  
                           var transactionPendingLargeBowls= 0;
                           var transactionPendingMediumBowls= 0;
                           var transactionPendingSmallBowls= 0;
                             
  
  
                             console.log(totalRowsOfTransactions)
  
                           for(let trans of totalRowsOfTransactions)
                           {
                            console.log("loop entered")
  
                             if(loopExit == 0)
                             {


                              // small bowls
                  if(requestSmallBowls > trans.remainingNumberOfBowlsSmall)
                  {
                    transactionPendingSmallBowls= trans.remainingNumberOfBowlsSmall;
                   console.log(1)
                   requestSmallBowls = parseInt(requestSmallBowls) - parseInt(trans.remainingNumberOfBowlsSmall);
                   var updatedUsedSmallBowlCountBorrowReturnTable= parseInt(trans.returnNumberOfUsedBowlsSmall) + parseInt(trans.remainingNumberOfBowlsSmall);                
                   var updatedBowlRemainingCountSmall=0;
                 }
  
                 else
                   if(requestSmallBowls == trans.remainingNumberOfBowlsSmall)
                   {
                    console.log(2)
                    transactionPendingSmallBowls= requestSmallBowls;
  
                    var updatedUsedSmallBowlCountBorrowReturnTable=parseInt(trans.returnNumberOfUsedBowlsSmall) + parseInt(requestSmallBowls);                
                    var updatedBowlRemainingCountSmall=0;
                    requestSmallBowls = 0;
                  }
  
                  else
                   if(requestSmallBowls < trans.remainingNumberOfBowlsSmall)    
                   {
                    console.log(3)
                    transactionPendingSmallBowls= requestSmallBowls;
  
                    var updatedUsedSmallBowlCountBorrowReturnTable=parseInt(trans.returnNumberOfUsedBowlsSmall) + parseInt(requestSmallBowls);
                    if(parseInt(trans.remainingNumberOfBowlsSmall) > parseInt(requestSmallBowls))
                    {
                     var updatedBowlRemainingCountSmall=parseInt(trans.remainingNumberOfBowlsSmall) - parseInt(requestSmallBowls);
                   }
                   else
                   {
                     var updatedBowlRemainingCountSmall=parseInt(requestSmallBowls) - parseInt(trans.remainingNumberOfBoxesMedium);
                   }
  
                   requestSmallBowls = 0;
                 }
  
                  // medium bowls
                  if(requestMediumBowls > trans.remainingNumberOfBowlsMedium)
                  {
                    transactionPendingMediumBowls= trans.remainingNumberOfBowlsMedium;
                   console.log(1)
                   requestMediumBowls = parseInt(requestMediumBowls) - parseInt(trans.remainingNumberOfBowlsMedium);
                   var updatedUsedMediumBowlCountBorrowReturnTable= parseInt(trans.returnNumberOfUsedBowlsMedium) + parseInt(trans.remainingNumberOfBowlsMedium);                
                   var updatedBowlRemainingCountMedium=0;
                 }
  
                 else
                   if(requestMediumBowls == trans.remainingNumberOfBowlsMedium)
                   {
                    console.log(2)
                    transactionPendingMediumBowls= requestMediumBowls;
  
                    var updatedUsedMediumBowlCountBorrowReturnTable=parseInt(trans.returnNumberOfUsedBoxesMedium) + parseInt(requestMediumBowls);                
                    var updatedBowlRemainingCountMedium=0;
                    requestMediumBowls = 0;
                  }
  
                  else
                   if(requestMediumBowls < trans.remainingNumberOfBowlsMedium)    
                   {
                    console.log(3)
                    transactionPendingMediumBoxes= requestMediumBowls;
  
                    var updatedUsedMediumBowlCountBorrowReturnTable=parseInt(trans.returnNumberOfUsedBoxesMedium) + parseInt(requestMediumBowls);
                    if(parseInt(trans.remainingNumberOfBowlsMedium) > parseInt(requestMediumBowls))
                    {
                     var updatedBowlRemainingCountMedium=parseInt(trans.remainingNumberOfBowlsMedium) - parseInt(requestMediumBowls);
                   }
                   else
                   {
                     var updatedBowlRemainingCountMedium=parseInt(requestMediumBowls) - parseInt(trans.remainingNumberOfBowlsMedium);
                   }
  
                   requestMediumBowls = 0;
                 }
  
  
                  // large bowls
                  if(requestLargeBowls > trans.remainingNumberOfBowlsLarge)
                  {
                    console.log(11)
                    transactionPendingLargeBowls= trans.remainingNumberOfBowlsLarge;
                    requestLargeBowls = 	 parseInt(requestLargeBowls) - parseInt(trans.remainingNumberOfBowlsLarge);
  
                    var updatedUsedLargeBowlCountBorrowReturnTable=parseInt(trans.returnNumberOfUsedBowlsLarge) + parseInt(trans.remainingNumberOfBowlsLarge);                
                    var updatedBowlRemainingCountLarge=0;
                  }
                  else 
                   if(requestLargeBowls == trans.remainingNumberOfBowlsLarge)
                   {
                    console.log(22)
                    transactionPendingLargeBowls= requestLargeBowls;               
  
                    var updatedUsedLargeBowlCountBorrowReturnTable=parseInt(trans.returnNumberOfUsedBowlsLarge) + parseInt(requestLargeBowls);                
                    var updatedBowlRemainingCountLarge=0;
                    requestLargeBowls =   0;
                  }
  
                  else
                   if(requestLargeBowls < trans.remainingNumberOfBowlsLarge)    
                   {
                    console.log(33)
                    transactionPendingLargeBowls= requestLargeBowls;
  
                    var updatedUsedLargeBowlCountBorrowReturnTable=parseInt(trans.returnNumberOfUsedBowlsLarge) + parseInt(requestLargeBowls);
                    if(parseInt(trans.remainingNumberOfBowlsLarge) > parseInt(requestLargeBowls))
                    {
                     var updatedBowlRemainingCountLarge= parseInt(trans.remainingNumberOfBowlsLarge) - parseInt(requestLargeBowls);
  
                   }
                   else
                   {
                     var updatedBowlRemainingCountLarge=   parseInt(requestLargeBowls) - parseInt(trans.remainingNumberOfBowlsLarge);
                   }
  
  
                   requestLargeBowls =   0;
                 }


                 var totalUsedBowlCountBorrowReturnTable= parseInt(updatedUsedSmallBowlCountBorrowReturnTable) + parseInt(updatedUsedMediumBowlCountBorrowReturnTable) + parseInt(updatedUsedLargeBowlCountBorrowReturnTable);
                 var totalBowlCountRemaining= parseInt(updatedBowlRemainingCountSmall) + parseInt(updatedBowlRemainingCountMedium) + parseInt(updatedBowlRemainingCountLarge);
                
  
                 let updateBoxesRest= yield dbSchema.BorrowReturn.updateOne({_id:trans._id},{$set:{"returnNumberOfUsedBowlsMedium":updatedUsedMediumBowlCountBorrowReturnTable ,     
                   "returnNumberOfUsedBowlsLarge":updatedUsedLargeBowlCountBorrowReturnTable,"returnNumberOfUsedBowlsSmall":updatedUsedSmallBowlCountBorrowReturnTable  ,"returnNumberOfUsedBowls": parseInt(totalUsedBowlCountBorrowReturnTable),"remainingNumberOfBowls":totalBowlCountRemaining,
                   "remainingNumberOfBowlsMedium":updatedBowlRemainingCountMedium,"remainingNumberOfBowlsSmall":updatedBowlRemainingCountSmall,"remainingNumberOfBowlsLarge":updatedBowlRemainingCountLarge,updatedOn:new Date()}});
  
  
                 let finalUpdate= yield dbSchema.BorrowReturn.findOneAndUpdate({_id:trans._id,remainingNumberOfBowls:0},{$set:{isActive:0,updatedOn:new Date()}});	
  
                 if(requestMediumBowls == 0 && requestSmallBowls == 0 && requestLargeBowls == 0)
                 {
                  loopExit=1;
                    if(transactionPendingLargeBowls != 0 || transactionPendingMediumBowls != 0 || transactionPendingSmallBowls != 0 )
                 {
                 let newEntryTransaction= {type:"Return",userRole :"User","borrowReturnId":trans._id,'userId':req.body.userId ,"restaurantId":checkRest._id,"returnNumberOfUsedBowlsMedium":parseInt(req.body.returnNumberOfUsedBowlsMedium) ,     
                 "returnNumberOfUsedBowlsLarge":parseInt(req.body.returnNumberOfUsedBowlsLarge), "returnNumberOfUsedBowlsSmall":parseInt(req.body.returnNumberOfUsedBowlsSmall) ,"returnNumberOfUsedBowls": parseInt(req.body.returnNumberOfUsedBowlsSmall) + parseInt(req.body.returnNumberOfUsedBowlsMedium) + parseInt(req.body.returnNumberOfUsedBowlsLarge),createdOn:new Date()};
                 let newDataTran= new dbSchema.Transactions(newEntryTransaction);            
                 let newDataTranSave= yield newDataTran.save();
  
               }
                 
                }
  
              }
            }
  
            console.log(checkRest.isDishwasher)
            console.log("checkRest.isDishwasher")
            if(checkRest.isDishwasher == "true")
            {
  
              let updatedCleanMediumBowlCountResturant=parseInt(checkRest.numberOfCleanBowlsMedium) + parseInt(req.body.returnNumberOfUsedBowlsMedium);
              let updatedCleanLargeBowlCountResturant= parseInt(checkRest.numberOfCleanBowlsLarge) + parseInt(req.body.returnNumberOfUsedBowlsLarge);
              let updatedCleanSmallBowlCountResturant= parseInt(checkRest.numberOfCleanBowlsSmall) + parseInt(req.body.returnNumberOfUsedBowlsSmall);
              let totalCleanBowlCountResturant= parseInt(updatedCleanMediumBowlCountResturant) + parseInt(updatedCleanLargeBowlCountResturant) + parseInt(updatedCleanSmallBowlCountResturant);
  
              let updateBoxData= yield dbSchema.Restaurant.updateOne(reqObjectRest,{$set:{numberOfCleanBowls:totalCleanBowlCountResturant,numberOfCleanBowlsMedium:updatedCleanMediumBowlCountResturant ,numberOfCleanBowlsSmall:updatedCleanSmallBowlCountResturant,numberOfCleanBowlsLarge:updatedCleanLargeBowlCountResturant}});
            }
            else
            {
              let updatedUsedMediumBowlCountResturant=parseInt(checkRest.numberOfUsedBowlsMedium) + parseInt(req.body.returnNumberOfUsedBowlsMedium);
              let updatedUsedLargeBowlCountResturant= parseInt(checkRest.numberOfUsedBowlsLarge) + parseInt(req.body.returnNumberOfUsedBowlsLarge);
              let updatedUsedSmallBowlCountResturant= parseInt(checkRest.numberOfUsedBowlsLarge) + parseInt(req.body.returnNumberOfUsedBowlsSmall);
              let totalUsedBowlCountResturant= parseInt(updatedUsedMediumBowlCountResturant) + parseInt(updatedUsedLargeBowlCountResturant) + parseInt(updatedUsedSmallBowlCountResturant);
  
              let updateBoxData= yield dbSchema.Restaurant.updateOne(reqObjectRest,{$set:{numberOfUsedBowls:totalUsedBowlCountResturant,numberOfUsedBowlsMedium:updatedUsedMediumBowlCountResturant ,numberOfUsedBowlsLarge:updatedUsedLargeBowlCountResturant,numberOfUsedBowlsLarge:updatedUsedSmallBowlCountResturant}});
  
            }
  
  
            res.json({status:1,message: alertMessages.success,boxes:req.body,Rest:checkRest}); 
  
  
          }
          else
          {
           return res.status(200).json({status: 0, message: alertMessages.boxNotAvail, data: [] });	
         }
      }

     }

/*Caffeeeeeeeeeeeeeeeeee*/
/*Caffeeeeeeeeeeeeeeeeee*/
/*Caffeeeeeeeeeeeeeeeeee*/
/*Caffeeeeeeeeeeeeeeeeee*/
/*Caffeeeeeeeeeeeeeeeeee*/
     else
     {
         var countOfRemainingBoxes= yield dbSchema.BorrowReturn.aggregate([{$match:{userId:ObjectId(req.body.userId),isActive:1}},
        {$group:{"_id": 1,"remainingNumberOfCupsSmall": { $sum:"$remainingNumberOfCupsSmall"},"remainingNumberOfCupsLarge": { $sum:"$remainingNumberOfCupsLarge"}}}]);



      if( countOfRemainingBoxes[0].remainingNumberOfCupsSmall  >= req.body.returnNumberOfUsedCupsSmall && countOfRemainingBoxes[0].remainingNumberOfCupsLarge  >= req.body.returnNumberOfUsedCupsLarge)
      { 
       

        var totalRowsOfTransactions= yield dbSchema.BorrowReturn.find({userId:req.body.userId,isActive:1,type:'Cafe'}).sort({_id:1});
           //  var totalRowsOfTransactionsExceptRest= yield dbSchema.BorrowReturn.find({userId:req.body.userId,restaurantId:{$ne:checkRest._id},isActive:1}).sort({_id:1});
           if(!totalRowsOfTransactions)  return res.status(200).json({status: 0, message: "No transaction found!", data: [] });

                         //    var totalRowsOfTransactions= Array.prototype.push.apply(totalRowsOfTransactionsRest,totalRowsOfTransactionsExceptRest); 


                         var loopExit= 0;
                         requestCupsSmall= req.body.returnNumberOfUsedCupsSmall;
                         requestCupsLarge= req.body.returnNumberOfUsedCupsLarge;
                       
                         var transactionPendingCups= 0;
                     
                         for(let trans of totalRowsOfTransactions)
                         {
                         
                          console.log("date---", trans.createdOn);
                          console.log("id---", trans._id);
                           if(loopExit == 0) 
                           {
                // small cups
                if(requestCupsSmall > trans.remainingNumberOfCupsSmall)
                {

                 transactionPendingCupsSmall= trans.remainingNumberOfCupsSmall;
               
                   console.log("transactionPendingCupsSmall----1------",transactionPendingCupsSmall)
                  
                 requestCupsSmall = parseInt(requestCupsSmall) - parseInt(trans.remainingNumberOfCupsSmall);
                 var updatedUsedSMallCountBorrowReturnTable= parseInt(trans.returnNumberOfUsedCupsSmall) + parseInt(trans.remainingNumberOfCupsSmall);
                  console.log("updatedUsedSMallCountBorrowReturnTable----1------",updatedUsedSMallCountBorrowReturnTable)                
                 var updatedCupRemainingCountSmall=0;
                  console.log("requestCupsSmall----1------",requestCupsSmall)
               }

               else
                 if(requestCupsSmall == trans.remainingNumberOfCupsSmall)
                 {
                  console.log(2)
                  transactionPendingCupsSmall= requestCupsSmall;
                console.log("transactionPendingCupsSmall----2------",transactionPendingCupsSmall)
                  var updatedUsedSMallCountBorrowReturnTable=parseInt(trans.returnNumberOfUsedCupsSmall) + parseInt(requestCupsSmall);                
                  var updatedCupRemainingCountSmall=0;
                  requestCupsSmall = 0;
                  console.log("requestCupsSmall----2------",requestCupsSmall)
                }

                else
                 if(requestCupsSmall < trans.remainingNumberOfCupsSmall)    
                 {
                  console.log(3)
                  transactionPendingCupsSmall= requestCupsSmall;
   console.log("transactionPendingCupsSmall----3------",transactionPendingCupsSmall)
                  var updatedUsedSMallCountBorrowReturnTable=parseInt(trans.returnNumberOfUsedCupsSmall) + parseInt(requestCupsSmall);
                  if(parseInt(trans.remainingNumberOfCupsSmall) > parseInt(requestCupsSmall))
                  {
                   var updatedCupRemainingCountSmall=parseInt(trans.remainingNumberOfCupsSmall) - parseInt(requestCupsSmall);
                 }
                 else
                 {
                   var updatedCupRemainingCountSmall=parseInt(requestCupsSmall) - parseInt(trans.remainingNumberOfCupsSmall);
                 }
                      console.log("updatedUsedSMallCountBorrowReturnTable----3------",updatedUsedSMallCountBorrowReturnTable)  

                 requestCupsSmall = 0;

                 console.log("requestCupsSmall---3-------",requestCupsSmall)
               }



                 // Large cups
                 if(requestCupsLarge > trans.remainingNumberOfCupsLarge)
                 {
                  transactionPendingCupsLarge= trans.remainingNumberOfCupsLarge;
                  console.log(1)
                  requestCupsLarge = parseInt(requestCupsLarge) - parseInt(trans.remainingNumberOfCupsLarge);
                  var updatedUsedLargeCountBorrowReturnTable= parseInt(trans.returnNumberOfUsedCupsLarge) + parseInt(trans.remainingNumberOfCupsLarge);                
                  var updatedCupRemainingCountLarge=0;
                }
 
                else
                  if(requestCupsLarge == trans.remainingNumberOfCupsLarge)
                  {
                   console.log(2)
                   transactionPendingCupsLarge= requestCupsLarge;
 
                   var updatedUsedLargeCountBorrowReturnTable=parseInt(trans.returnNumberOfUsedCupsLarge) + parseInt(requestCupsLarge);                
                   var updatedCupRemainingCountLarge=0;
                   requestCupsLarge = 0;
                 }
 
                 else
                  if(requestCupsLarge < trans.remainingNumberOfCupsLarge)    
                  {
                   console.log(3)
                   transactionPendingCupsLarge= requestCupsLarge;
 
                   var updatedUsedLargeCountBorrowReturnTable=parseInt(trans.returnNumberOfUsedCupsLarge) + parseInt(requestCupsLarge);
                   if(parseInt(trans.remainingNumberOfCupsLarge) > parseInt(requestCupsLarge))
                   {
                    var updatedCupRemainingCountLarge=parseInt(trans.remainingNumberOfCupsLarge) - parseInt(requestCupsLarge);
                  }
                  else
                  {
                    var updatedCupRemainingCountLarge=parseInt(requestCupsLarge) - parseInt(trans.remainingNumberOfCupsLarge);
                  }
 
                  requestCupsLarge = 0;
                }
  
 


               var remainingNumberOfCupsSmall= parseInt(updatedUsedLargeCountBorrowReturnTable) + parseInt(updatedUsedSMallCountBorrowReturnTable);
               var totalCupsCountRemaining= parseInt(updatedCupRemainingCountLarge) + parseInt(updatedCupRemainingCountSmall);

              

               let updateBoxesRest= yield dbSchema.BorrowReturn.updateOne({_id:trans._id},{$set:{"returnNumberOfUsedCupsSmall":updatedUsedSMallCountBorrowReturnTable,     
               "returnNumberOfUsedCupsLarge":updatedUsedLargeCountBorrowReturnTable ,"returnNumberOfUsedCups": parseInt(remainingNumberOfCupsSmall),"remainingNumberOfCups":totalCupsCountRemaining,
               "remainingNumberOfCupsSmall":updatedCupRemainingCountSmall,"remainingNumberOfCupsLarge":updatedCupRemainingCountLarge,updatedOn:new Date()}});


               let finalUpdate= yield dbSchema.BorrowReturn.findOneAndUpdate({_id:trans._id,remainingNumberOfCups:0},{$set:{isActive:0,updatedOn:new Date()}});  


// console.log("requestCupsLarge---------", requestCupsLarge)
// console.log("requestCupsSmall---------", requestCupsSmall)

             if(requestCupsLarge == 0 && requestCupsSmall == 0)
             {
              loopExit=1;


// console.log("transactionPendingCupsLarge---------", transactionPendingCupsLarge)
// console.log("updatedCupRemainingCountSmall---------", updatedCupRemainingCountSmall)
              
                if(transactionPendingCupsLarge != 0 || transactionPendingCupsSmall != 0 )
             {
             let newEntryTransaction= {type:"Return",userRole :"User","borrowReturnId":trans._id,'userId':req.body.userId ,"restaurantId":checkRest._id,"numberOfUsedCupsSmall":parseInt(req.body.returnNumberOfUsedCupsSmall) ,     
             "numberOfUsedCups":parseInt(req.body.returnNumberOfUsedCupsLarge) ,"totalNumberOfUsedCups": parseInt(req.body.returnNumberOfUsedCupsLarge) + parseInt(req.body.returnNumberOfUsedCupsSmall),createdOn:new Date()};
             let newDataTran= new dbSchema.Transactions(newEntryTransaction);            
             let newDataTranSave= yield newDataTran.save();

           }
             
            }

          }
        }



  
          if(checkRest.isDishwasher == "true")
          {

            let updatedCleanLargeCupCountResturant=parseInt(checkRest.numberOfCleanCupsLarge) + parseInt(req.body.returnNumberOfUsedCupsLarge);
            let updatedCleanSmallCupCountResturant= parseInt(checkRest.numberOfCleanCupsSmall) + parseInt(req.body.returnNumberOfUsedCupsSmall);
            let totalCleanCupCountResturant= parseInt(updatedCleanSmallCupCountResturant) + parseInt(updatedCleanLargeCupCountResturant);

            let updateBoxData= yield dbSchema.Restaurant.updateOne(reqObjectRest,{$set:{numberOfCleanCups:totalCleanCupCountResturant,numberOfCleanCupsLarge:updatedCleanLargeCupCountResturant ,numberOfCleanCupsSmall:updatedCleanSmallCupCountResturant}});
          }
          else
          {

  let updatedCleanLargeCupCountResturant=parseInt(checkRest.numberOfUsedCupsLarge) + parseInt(req.body.returnNumberOfUsedCupsLarge);
            let updatedCleanSmallCupCountResturant= parseInt(checkRest.numberOfUsedCupsSmall) + parseInt(req.body.returnNumberOfUsedCupsSmall);
            let totalCleanCupCountResturant= parseInt(updatedCleanSmallCupCountResturant) + parseInt(updatedCleanLargeCupCountResturant);

            let updateBoxData= yield dbSchema.Restaurant.updateOne(reqObjectRest,{$set:{numberOfUsedCups:totalCleanCupCountResturant,numberOfUsedCupsLarge:updatedCleanLargeCupCountResturant ,numberOfUsedCupsSmall:updatedCleanSmallCupCountResturant}});
        
        
          }



      


          res.json({status:1,message: alertMessages.success,boxes:req.body,Rest:checkRest}); 


        }
        else
        {
         return res.status(200).json({status: 0, message: alertMessages.cupsNotAvail, data: [] }); 
       }
     }

     }).catch(function(err){
       console.log(err)
       err = err && err.errorCode ? err : {errorCode: 500, errorMessage: err};
       return res.status(200).json({status: 0, message: alertMessages.failure, data:err.errorMessage });
     });
   },







   passcodeVerification: function(req, res) { 
     co(function*(){
      if(!(req.body.userId) || !(req.body.type) || !(req.body.passcode)) return res.status(200).json({status: 0, message: "Bad Request!", data: [] });

      var reqObject= {_id :req.body.userId,isActive:1};  
      const checkUser= yield dbSchema.User.findOne(reqObject).exec();
      if(!checkUser) return res.status(200).json({status: 0, message: alertMessages.userNotFound, data: [] });



      if(req.body.type == "Borrow")
      {
       var restReqObject= {borrowPasscode :req.body.passcode};  
       const checkRest= yield dbSchema.Restaurant.findOne(restReqObject).exec(); 
       if(!checkRest) return res.status(200).json({status: 0, message: alertMessages.passCodeInvalid});
       if(checkRest.type == 'Restaurant')
       {
       if(checkRest.numberOfCleanBoxes == 0 && checkRest.numberOfCleanBowls == 0)
       {
       return res.status(200).json({status: 0, message: "No items available!"});
     } 
   }
   else
   {
      if(checkRest.numberOfCleanCups == 0)
       {
       return res.status(200).json({status: 0, message: "No cups available!"});
     } 
   }
 
 
   return res.status(200).json({status: 1, message: alertMessages.success,data:{rest:checkRest}}); 
  
   }

     else if(req.body.type == "Return")
     {
     	var restReqObject= {returnPasscode :req.body.passcode};  
       const checkRest= yield dbSchema.Restaurant.findOne(restReqObject).exec(); 
       if(!checkRest) return res.status(200).json({status: 0, message: alertMessages.passCodeInvalid});
       if(checkRest.type == 'Restaurant')
{
      
       var countOfRemainingBoxes= yield dbSchema.BorrowReturn.aggregate([{$match:{userId:ObjectId(req.body.userId),isActive:1}},
        {$group:{"_id": 1,"remainingNumberOfBowlsMedium": { $sum:"$remainingNumberOfBowlsMedium"},"remainingNumberOfBowlsSmall": { $sum:"$remainingNumberOfBowlsSmall"},"remainingNumberOfBowlsLarge": { $sum:"$remainingNumberOfBowlsLarge"},
        "remainingNumberOfBoxesMedium": { $sum:"$remainingNumberOfBoxesMedium"},"remainingNumberOfBoxesLarge": { $sum:"$remainingNumberOfBoxesLarge"}}}]);

       if(countOfRemainingBoxes.length > 0 && (countOfRemainingBoxes[0].remainingNumberOfBoxesMedium > 0 || countOfRemainingBoxes[0].remainingNumberOfBoxesLarge > 0  || countOfRemainingBoxes[0].remainingNumberOfBowlsMedium > 0 || countOfRemainingBoxes[0].remainingNumberOfBowlsSmall > 0 || countOfRemainingBoxes[0].remainingNumberOfBowlsLarge > 0) )
       { 
        return res.status(200).json({status: 1, message: alertMessages.success,data:{rest:checkRest,count:countOfRemainingBoxes}});
      }
      else
      {
        return res.status(200).json({status: 0, message: "No items available!"});
      }
}

else
{
   if(checkRest.type == 'Cafe')
{
       var countOfRemainingBoxes= yield dbSchema.BorrowReturn.aggregate([{$match:{userId:ObjectId(req.body.userId),isActive:1}},
        {$group:{"_id": 1,"remainingNumberOfCupsSmall": { $sum:"$remainingNumberOfCupsSmall"},"remainingNumberOfCupsLarge": { $sum:"$remainingNumberOfCupsLarge"}}}]);

       if(countOfRemainingBoxes.length > 0 && (countOfRemainingBoxes[0].remainingNumberOfCupsSmall > 0 || countOfRemainingBoxes[0].remainingNumberOfCupsLarge > 0))
       { 
        return res.status(200).json({status: 1, message: alertMessages.success,data:{rest:checkRest,count:countOfRemainingBoxes}});
      }
      else
      {
        return res.status(200).json({status: 0, message: "No cups available!"});
      }
}

    }
}

  }).catch(function(err){
    console.log(err)
    err = err && err.errorCode ? err : {errorCode: 500, errorMessage: err};
    return res.status(err.errorCode).json({status: 0, message: err.errorMessage, data: [] });
  });

},

passcodeVerificationNfc: function(req, res) { 
  console.log("passcod verify NFC")
  console.log(req.body)
  co(function*(){
    if(!(req.body.userId) || !(req.body.type) || !(req.body.nfcId)) return res.status(200).json({status: 0, message: "Bad Request!", data: [] });

    var reqObject= {_id :req.body.userId,isActive:1};  
    const checkUser= yield dbSchema.User.findOne(reqObject).exec();
    if(!checkUser) return res.status(200).json({status: 0, message: alertMessages.userNotFound, data: [] });
    


    if(req.body.type == "Borrow")
    {
     //var restReqObject= {borrowUID :req.body.nfcId};
	 var restReqObject= { $or:[ {'borrowUID':req.body.nfcId}, {'borrowUID2':req.body.nfcId}, {'borrowUID3':req.body.nfcId}, {'borrowUID4':req.body.nfcId}, {'borrowUID5':req.body.nfcId} ]};
     const checkRest= yield dbSchema.Restaurant.findOne(restReqObject).exec(); 
     if(!checkRest) return res.status(200).json({status: 0, message: "No restaurant found!"});
        if(checkRest.type == 'Restaurant')
       {
       if(checkRest.numberOfCleanBoxes == 0 && checkRest.numberOfCleanBowls == 0)
       {
       return res.status(200).json({status: 0, message: "No items available!"});
     } 
   }
   else
   {
      if(checkRest.numberOfCleanCups == 0)
       {
       return res.status(200).json({status: 0, message: "No cups available!"});
     } 
   }
 
 
   return res.status(200).json({status: 1, message: alertMessages.success,data:{rest:checkRest}}); 
  
   }

   else if(req.body.type == "Return")
   {
    //var restReqObject= {returnUID :req.body.nfcId};
	var restReqObject= { $or:[ {'returnUID':req.body.nfcId}, {'returnUID2':req.body.nfcId}, {'returnUID3':req.body.nfcId}, {'returnUID4':req.body.nfcId}, {'returnUID5':req.body.nfcId} ]};
    const checkRest= yield dbSchema.Restaurant.findOne(restReqObject).exec(); 
    if(!checkRest) return res.status(200).json({status: 0, message: "No restaurant found!"});
   if(checkRest.type == 'Restaurant')
{
       var countOfRemainingBoxes= yield dbSchema.BorrowReturn.aggregate([{$match:{userId:ObjectId(req.body.userId),isActive:1}},
        {$group:{"_id": 1,"remainingNumberOfBowlsMedium": { $sum:"$remainingNumberOfBowlsMedium"},"remainingNumberOfBowlsSmall": { $sum:"$remainingNumberOfBowlsSmall"},"remainingNumberOfBowlsLarge": { $sum:"$remainingNumberOfBowlsLarge"},
        "remainingNumberOfBoxesMedium": { $sum:"$remainingNumberOfBoxesMedium"},"remainingNumberOfBoxesLarge": { $sum:"$remainingNumberOfBoxesLarge"}}}]);

       if(countOfRemainingBoxes[0].remainingNumberOfBoxesMedium > 0 || countOfRemainingBoxes[0].remainingNumberOfBoxesLarge > 0  || countOfRemainingBoxes[0].remainingNumberOfBowlsMedium > 0 || countOfRemainingBoxes[0].remainingNumberOfBowlsSmall > 0 || countOfRemainingBoxes[0].remainingNumberOfBowlsLarge > 0 )
       { 
        return res.status(200).json({status: 1, message: alertMessages.success,data:{rest:checkRest,count:countOfRemainingBoxes}});
      }
      else
      {
        return res.status(200).json({status: 0, message: "No items available!"});
      }
}

else
{
   if(checkRest.type == 'Cafe')
{
       var countOfRemainingBoxes= yield dbSchema.BorrowReturn.aggregate([{$match:{userId:ObjectId(req.body.userId),isActive:1}},
        {$group:{"_id": 1,"remainingNumberOfCupsSmall": { $sum:"$remainingNumberOfCupsSmall"},"remainingNumberOfCupsLarge": { $sum:"$remainingNumberOfCupsLarge"}}}]);

       if(countOfRemainingBoxes[0].remainingNumberOfCupsSmall > 0 || countOfRemainingBoxes[0].remainingNumberOfCupsLarge > 0)
       { 
        return res.status(200).json({status: 1, message: alertMessages.success,data:{rest:checkRest,count:countOfRemainingBoxes}});
      }
      else
      {
        return res.status(200).json({status: 0, message: "No cups available!"});
      }
}

    }
}
  
}).catch(function(err){
  console.log(err)
  err = err && err.errorCode ? err : {errorCode: 500, errorMessage: err};
  return res.status(err.errorCode).json({status: 0, message: err.errorMessage, data: [] });
});

},

myBoxes: function(req, res) { 
  co(function*(){
    if(!(req.body.userId)) return res.status(200).json({status: 0, message: "Bad Request!", data: [] });

    var reqObject= {_id :req.body.userId,isActive:1};  
    const checkUser= yield dbSchema.User.findOne(reqObject).exec();
    if(!checkUser) return res.status(200).json({status: 0, message: alertMessages.userNotFound, data: [] });

    //Start: Surendar added new transaction list api.[12-01-2022]
    const LAST_THIRTY_DATES   =   new Date();
    LAST_THIRTY_DATES.setDate(LAST_THIRTY_DATES.getDate() - 30);
    LAST_THIRTY_DATES.setHours(23, 59, 59);
    const LAST_NINETY_DATES   =   new Date();
    LAST_NINETY_DATES.setDate(LAST_NINETY_DATES.getDate() - 90);
    LAST_NINETY_DATES.setHours(23, 59, 59);

    let borrowList        = [];
    let refundStatus      = false;
    let customRefundDate  = null;
    let lastReturnDate    = new Date();
    let isActiveCond      = { $match: { isActive: { $in: [1] } } };
    let refundCond        = { $match: { refunded: { $in: [0] } } };

    

    var borrowCondition = {
      userId :ObjectId(req.body.userId),
      refunded: 1,
      //refundedDate: { $gte: new Date(LAST_NINETY_DATES) }
    };  
    const refundedBorrows  = yield dbSchema.BorrowReturn.find(borrowCondition).sort({refundedDate:-1}).limit(1);

    if(refundedBorrows.length > 0) {
      let refundedDate  = new Date(refundedBorrows[0]["refundedDate"]);
      refundedDate.setDate(refundedDate.getDate() + 90);
      refundedDate.setHours(23, 59, 59);
      customRefundDate  = refundedDate;
      if(refundedDate.getTime() < new Date().getTime()) {
        refundStatus  = true;
        lastReturnDate  = LAST_THIRTY_DATES;
        isActiveCond      = { $match: { isActive: { $in: [0, 1] } } };
        refundCond        = { $match: { refunded: { $in: [0, 1] } } };
      }
    } else {
      refundStatus    = true;
      lastReturnDate  = LAST_THIRTY_DATES;
      isActiveCond    = { $match: { isActive: { $in: [0, 1] } } };
      refundCond      = { $match: { refunded: { $in: [0, 1] } } };
    }

    //let getRefunded = yield dbSchema.BorrowReturn.
    //if(checkUser["lastRefundDate"] !== undefined && checkUser["lastRefundDate"] !== null)

    //End: Surendar added new transaction list api.[12-01-2022]

    //Start: Surendar added for price details.[16-06-2022]
    const allPriceDetails = yield dbSchema.PriceDetails.find().exec();
    const userCountryDetails = yield getUserCountryDetails(checkUser.stripeCustomerId);
    const priceDetails = yield getPriceDetails(userCountryDetails.country, allPriceDetails);

    var mediumBowlsPrice = convertStripeAmount((priceDetails.mediumBowlsPrice != undefined) ? parseFloat(priceDetails.mediumBowlsPrice) : 10000);
    var largeBowlsPrice = convertStripeAmount((priceDetails.largeBowlsPrice != undefined) ? parseFloat(priceDetails.largeBowlsPrice) : 10000);
    var smallBowlsPrice = convertStripeAmount((priceDetails.smallBowlsPrice != undefined) ? parseFloat(priceDetails.smallBowlsPrice) : 10000);

    var mediumBoxesPrice = convertStripeAmount((priceDetails.mediumBoxesPrice != undefined) ? parseFloat(priceDetails.mediumBoxesPrice) : 10000);
    var largeBoxesPrice = convertStripeAmount((priceDetails.largeBoxesPrice != undefined) ? parseFloat(priceDetails.largeBoxesPrice) : 10000);

    var smallCupsPrice = convertStripeAmount((priceDetails.smallCupsPrice != undefined) ? parseFloat(priceDetails.smallCupsPrice) : 15000);
    var largeCupsPrice = convertStripeAmount((priceDetails.largeCupsPrice != undefined) ? parseFloat(priceDetails.largeCupsPrice) : 15000);

    //Extension
    var extensionPrices = {};
    extensionPrices['mediumBowlsExtensionPrice'] = convertStripeAmount((priceDetails.mediumBowlsExtensionPrice != undefined) ? parseFloat(priceDetails.mediumBowlsExtensionPrice) : 10000);
    extensionPrices['largeBowlsExtensionPrice'] = convertStripeAmount((priceDetails.largeBowlsExtensionPrice != undefined) ? parseFloat(priceDetails.largeBowlsExtensionPrice) : 10000);
    extensionPrices['smallBowlsExtensionPrice'] = convertStripeAmount((priceDetails.smallBowlsExtensionPrice != undefined) ? parseFloat(priceDetails.smallBowlsExtensionPrice) : 10000);

    extensionPrices['mediumBoxesExtensionPrice'] = convertStripeAmount((priceDetails.mediumBoxesExtensionPrice != undefined) ? parseFloat(priceDetails.mediumBoxesExtensionPrice) : 10000);
    extensionPrices['largeBoxesExtensionPrice'] = convertStripeAmount((priceDetails.largeBoxesExtensionPrice != undefined) ? parseFloat(priceDetails.largeBoxesExtensionPrice) : 10000);

    extensionPrices['smallCupsExtensionPrice'] = convertStripeAmount((priceDetails.smallCupsExtensionPrice != undefined) ? parseFloat(priceDetails.smallCupsExtensionPrice) : 15000);
    extensionPrices['largeCupsExtensionPrice'] = convertStripeAmount((priceDetails.largeCupsExtensionPrice != undefined) ? parseFloat(priceDetails.largeCupsExtensionPrice) : 15000);
    
    extensionPrices['currency'] = priceDetails.currency;
    
    //End: Surendar added for price details.[16-06-2022]

    var restReqObject= {userId :ObjectId(req.body.userId)};  
    let checkRest= yield dbSchema.BorrowReturn.aggregate([{$match:restReqObject},isActiveCond,{$match:{lastDateToRetrun:{$gte: lastReturnDate }}},{$match:{refunded: { $ne: 1 }}},{$sort: {lastDateToRetrun: 1}},
     {$project: {
      _id:1,
      remainingNumberOfCups:1,
      remainingNumberOfCupsSmall:1,
      remainingNumberOfCupsLarge:1,
      remainingNumberOfBoxes:1,
      remainingNumberOfBoxesMedium:1,
      remainingNumberOfBoxesLarge:1,
        remainingNumberOfBowls:1,
      remainingNumberOfBowlsSmall:1,
      remainingNumberOfBowlsMedium:1,
      remainingNumberOfBowlsLarge:1,
      isActive:1,
      type:1,
      isNotificationReminder:1, 
      createdOn:1,
      extendedCount:1,
      lastDateToRetrun:1,
      updatedOn:1,
      userId:1,
      restaurantId:1,
      DifferenceInHours: {$divide: [{$subtract: ["$lastDateToRetrun", "$$NOW"]}, 3600000]},
      /* cost: { $multiply: [ "$remainingNumberOfBoxes", 100 ] },
      costOfBowls: { $multiply: [ "$remainingNumberOfBowls", 150 ] },
      costOfCups: { $multiply: [ "$remainingNumberOfCups", 150 ] }, */
      //Start: Surendar added for price details.[16-06-2022]
      cost: { $add: [ { $multiply: [ "$remainingNumberOfBoxesMedium", mediumBoxesPrice ] }, { $multiply: [ "$remainingNumberOfBoxesLarge", largeBoxesPrice ] } ] },
      costOfBowls: { $add: [ { $multiply: [ "$remainingNumberOfBowlsSmall", smallBowlsPrice ] }, { $multiply: [ "$remainingNumberOfBowlsMedium", mediumBowlsPrice ] }, { $multiply: [ "$remainingNumberOfBowlsLarge", largeBowlsPrice ] } ] },
      costOfCups: { $add: [ { $multiply: [ "$remainingNumberOfCupsSmall", smallCupsPrice ] }, { $multiply: [ "$remainingNumberOfCupsLarge", largeCupsPrice ] } ] },
      currency: priceDetails.currency
      //End: Surendar added for price details.[16-06-2022]
    }}
    ]).exec(); 

    let count = 0;

    for(let borrowDetails of checkRest) {
      console.log("borrowDetails", borrowDetails);
      let getTransaction = yield dbSchema.Transactions.findOne({borrowReturnId: borrowDetails._id, type: 'Expired' }).exec();
      if(getTransaction) {
        if(refundStatus && getTransaction["transactionId"] !== undefined && getTransaction["transactionId"] !== null && getTransaction["transactionId"] !== '') {
          checkRest[count]["transaction"] = getTransaction;
        } else {
          checkRest[count]["transaction"] = {};
        }
      } else {
        checkRest[count]["transaction"] = {};
      }

      if(checkRest[count]["isActive"] === 1) {
        borrowList.push(checkRest[count]);
      } else if(checkRest[count]["remainingNumberOfBoxes"] !== 0 || checkRest[count]["remainingNumberOfBowls"] !== 0 || checkRest[count]["remainingNumberOfCups"] !== 0) {
        borrowList.push(checkRest[count]);
      }

      count = count + 1;
    }

      return res.status(200).json({status: 1, message: alertMessages.success,data:{rest:borrowList},extensionPrices: extensionPrices, refundedBorrows: refundedBorrows, refundedDate: customRefundDate});


  }).catch(function(err){
    console.log(err)
    err = err && err.errorCode ? err : {errorCode: 500, errorMessage: err};
    return res.status(err.errorCode).json({status: 0, message: err.errorMessage, data: [] });
  });

},



myBoxes1: function(req, res) { 
  co(function*(){
    

let chk= yield dbSchema.BorrowReturn.find({});

    console.log(chk.length)
    console.log(chk.length)
    console.log(chk.length)
    console.log(chk.length)
  let j=0;
for (let i of chk)
{
	//remainingNumberOfBowls
	//returnNumberOfUsedBowls
	if(i.returnNumberOfUsedBowls)
	{
		
	}
	else
	{
		let update= yield dbSchema.BorrowReturn.updateOne({_id: i._id},{$set:{returnNumberOfUsedBowlsLarge: 0, returnNumberOfUsedBowlsMedium: 0,returnNumberOfUsedBowlsSmall:0,returnNumberOfUsedBowls:0}});
		console.log("update---", j++)
	}
}

    return res.status(200).json({status: 1, message: alertMessages.success,data:{}});


  }).catch(function(err){
    console.log(err)
    err = err && err.errorCode ? err : {errorCode: 500, errorMessage: err};
    return res.status(err.errorCode).json({status: 0, message: err.errorMessage, data: [] });
  });

},

transactionHistory: function(req, res) { 
  co(function*(){
   var skip= req.body.skip * 10;
   var limit= 10;
   if(!(req.body.userId)) return res.status(200).json({status: 0, message: "Bad Request!", data: [] });

   var reqObject= {_id :req.body.userId};  
   const checkUser= yield dbSchema.User.findOne(reqObject).exec();
   if(!checkUser) return res.status(200).json({status: 0, message: alertMessages.userNotFound, data: [] });

   //Start: Surendar added for price details.[16-06-2022]
   const allPriceDetails = yield dbSchema.PriceDetails.find().exec();
   const userCountryDetails = yield getUserCountryDetails(checkUser.stripeCustomerId);
   const priceDetails = yield getPriceDetails(userCountryDetails.country, allPriceDetails);

   var mediumBowlsPrice = convertStripeAmount((priceDetails.mediumBowlsPrice != undefined) ? parseFloat(priceDetails.mediumBowlsPrice) : 10000);
   var largeBowlsPrice = convertStripeAmount((priceDetails.largeBowlsPrice != undefined) ? parseFloat(priceDetails.largeBowlsPrice) : 10000);
   var smallBowlsPrice = convertStripeAmount((priceDetails.smallBowlsPrice != undefined) ? parseFloat(priceDetails.smallBowlsPrice) : 10000);

   var mediumBoxesPrice = convertStripeAmount((priceDetails.mediumBoxesPrice != undefined) ? parseFloat(priceDetails.mediumBoxesPrice) : 10000);
   var largeBoxesPrice = convertStripeAmount((priceDetails.largeBoxesPrice != undefined) ? parseFloat(priceDetails.largeBoxesPrice) : 10000);

   var smallCupsPrice = convertStripeAmount((priceDetails.smallCupsPrice != undefined) ? parseFloat(priceDetails.smallCupsPrice) : 15000);
   var largeCupsPrice = convertStripeAmount((priceDetails.largeCupsPrice != undefined) ? parseFloat(priceDetails.largeCupsPrice) : 15000);

   //Prices
   var allPrices = {};
   allPrices['mediumBowlsPrice']  = mediumBowlsPrice;
   allPrices['largeBowlsPrice']   = largeBowlsPrice;
   allPrices['smallBowlsPrice']   = smallBowlsPrice;

   allPrices['mediumBoxesPrice']  = mediumBoxesPrice;
   allPrices['largeBoxesPrice']   = largeBoxesPrice;

   allPrices['smallCupsPrice']    = smallCupsPrice;
   allPrices['largeCupsPrice']    = largeCupsPrice;

   allPrices['currency']          = priceDetails.currency;

   //Extension
   var extensionPrices = {};
   extensionPrices['mediumBowlsExtensionPrice'] = convertStripeAmount((priceDetails.mediumBowlsExtensionPrice != undefined) ? parseFloat(priceDetails.mediumBowlsExtensionPrice) : 10000);
   extensionPrices['largeBowlsExtensionPrice'] = convertStripeAmount((priceDetails.largeBowlsExtensionPrice != undefined) ? parseFloat(priceDetails.largeBowlsExtensionPrice) : 10000);
   extensionPrices['smallBowlsExtensionPrice'] = convertStripeAmount((priceDetails.smallBowlsExtensionPrice != undefined) ? parseFloat(priceDetails.smallBowlsExtensionPrice) : 10000);

   extensionPrices['mediumBoxesExtensionPrice'] = convertStripeAmount((priceDetails.mediumBoxesExtensionPrice != undefined) ? parseFloat(priceDetails.mediumBoxesExtensionPrice) : 10000);
   extensionPrices['largeBoxesExtensionPrice'] = convertStripeAmount((priceDetails.largeBoxesExtensionPrice != undefined) ? parseFloat(priceDetails.largeBoxesExtensionPrice) : 10000);

   extensionPrices['smallCupsExtensionPrice'] = convertStripeAmount((priceDetails.smallCupsExtensionPrice != undefined) ? parseFloat(priceDetails.smallCupsExtensionPrice) : 15000);
   extensionPrices['largeCupsExtensionPrice'] = convertStripeAmount((priceDetails.largeCupsExtensionPrice != undefined) ? parseFloat(priceDetails.largeCupsExtensionPrice) : 15000);
   
   extensionPrices['currency'] = priceDetails.currency;
   
   //End: Surendar added for price details.[16-06-2022]


   var restReqObject= {userId :ObjectId(req.body.userId),userRole:"User"};  
   const checkRest=yield dbSchema.Transactions.find(restReqObject).sort({_id:-1}).skip(skip).limit(limit).populate( { "path": "restaurantId", 'model': 'Restaurant', "select":{name:1,type:1}});


   return res.status(200).json({status: 1, message: alertMessages.success,data:{rest:checkRest}, extensionPrices: extensionPrices, allPrices: allPrices});


 }).catch(function(err){
  console.log(err)
  err = err && err.errorCode ? err : {errorCode: 500, errorMessage: err};
  return res.status(err.errorCode).json({status: 0, message: err.errorMessage, data: [] });
});

},


deleteRest: function(req, res) { 
  co(function*(){
    var deleteRest= yield dbSchema.Restaurant.find({isActive:0});
    for(let i of deleteRest)
    {
     
  var deleteTrans= yield dbSchema.Transactions.remove({restaurantId:i._id});
  var deleteBorrowReturn= yield dbSchema.BorrowReturn.remove({restaurantId:i._id});
  console.log("done")
}
   return res.status(200).json({status: 1, message: alertMessages.success});


 }).catch(function(err){
  console.log(err)
  err = err && err.errorCode ? err : {errorCode: 500, errorMessage: err};
  return res.status(err.errorCode).json({status: 0, message: err.errorMessage, data: [] });
});

},



extendTime: function(req, res) { 
  co(function*(){
   var reqObjectUser= {_id :req.body.userId,isActive:1};  
    const checkUser= yield dbSchema.User.findOne(reqObjectUser).exec();
    if(!checkUser) return res.status(200).json({status: 0, message: alertMessages.userNotFound, data: [] });

  if(!checkUser.stripeCustomerId) return res.status(200).json({status: 2, message: "Please go to your account settings to add it.", data: [] });
   
    var getTrans= yield dbSchema.BorrowReturn.findOne({_id:req.body.borrowReturnId});

     //Start: Surendar added for price details.[16-06-2022]
    const allPriceDetails = yield dbSchema.PriceDetails.find().exec();
    const userCountryDetails = yield getUserCountryDetails(checkUser.stripeCustomerId);
    const priceDetails = yield getPriceDetails(userCountryDetails.country, allPriceDetails);
    //End: Surendar added for price details.[16-06-2022]

 if(getTrans.type == 'Restaurant')
 {
        var date= new Date(getTrans.lastDateToRetrun);
        date.setDate(date.getDate() + 3); 
         date.setSeconds(0);     
         date.setMilliseconds(0);  

         //Start: Surendar added for price details.[16-06-2022]
   var tranAmount= getTrans.borrowType == 'Box'?getTrans.remainingNumberOfBoxes * 1000:getTrans.remainingNumberOfBowls * 1000;

   if(getTrans.borrowType == 'Box') {
    var mediumBoxesExtensionPrice = (priceDetails.mediumBoxesExtensionPrice != undefined) ? parseFloat(priceDetails.mediumBoxesExtensionPrice) : 1000;
    var largeBoxesExtensionPrice = (priceDetails.largeBoxesExtensionPrice != undefined) ? parseFloat(priceDetails.largeBoxesExtensionPrice) : 1000;

    console.log('Box', mediumBoxesExtensionPrice, largeBoxesExtensionPrice) 

    var amount1 = getTrans.remainingNumberOfBoxesMedium * mediumBoxesExtensionPrice;
    var amount2 = getTrans.remainingNumberOfBoxesLarge * largeBoxesExtensionPrice;

    tranAmount = parseFloat(amount1) + parseFloat(amount2);
  } else {
    var mediumBowlsExtensionPrice = (priceDetails.mediumBowlsExtensionPrice != undefined) ? parseFloat(priceDetails.mediumBowlsExtensionPrice) : 1000;
    var largeBowlsExtensionPrice = (priceDetails.largeBowlsExtensionPrice != undefined) ? parseFloat(priceDetails.largeBowlsExtensionPrice) : 1000;
    var smallBowlsExtensionPrice = (priceDetails.smallBowlsExtensionPrice != undefined) ? parseFloat(priceDetails.smallBowlsExtensionPrice) : 1000;

    console.log('Bowl', mediumBowlsExtensionPrice, largeBowlsExtensionPrice, smallBowlsExtensionPrice);
    //var mediumBowlsPrice = 

    var amount1 = getTrans.remainingNumberOfBowlsMedium * mediumBowlsExtensionPrice;
    var amount2 = getTrans.remainingNumberOfBowlsLarge * largeBowlsExtensionPrice;
    var amount3 = getTrans.remainingNumberOfBowlsSmall * smallBowlsExtensionPrice;

    tranAmount = parseFloat(amount1) + parseFloat(amount2) + parseFloat(amount3);
  }
  //End: Surendar added for price details.[16-06-2022]

      var transaction= yield trans(checkUser.stripeCustomerId,checkUser.country,tranAmount,userCountryDetails.currency);

        if(!transaction) {  return res.status(200).json({status: 0, message: alertMessages.transactionError, data: [] }); }
      
  var updateTrans= yield dbSchema.BorrowReturn.updateOne({_id:req.body.borrowReturnId},{$set:{lastDateToRetrun: date,isTwoDaysReminder:1,isOneDayReminder:1,extendedCount: getTrans.extendedCount + 1,updatedOn:new Date()},$addToSet:{extendedTransactionId:transaction.charges.data[0].id}});

if(getTrans.borrowType == 'Box')
{
    //Edit: Surendar added for price details.[16-06-2022]
    var newEntryTransaction= {receiptUrl:transaction.charges.data[0].receipt_url .receipt_url ,type:"Extended",userRole :"User",borrowReturnId:req.body.borrowReturnId,'userId':req.body.userId ,"restaurantId":getTrans.restaurantId ,transactionId:transaction.charges.data[0].id,"borrowNumberOfCleanBoxesLarge":getTrans.remainingNumberOfBoxesLarge, 'currency': transaction.currency, 'amount': convertStripeAmount(transaction.amount), "borrowNumberOfCleanBoxesMedium":getTrans.remainingNumberOfBoxesMedium ,"borrowNumberOfCleanBoxes": parseInt(getTrans.remainingNumberOfBoxesMedium) + parseInt(getTrans.remainingNumberOfBoxesLarge),createdOn:new Date()};
    
}
else
{
  //Edit: Surendar added for price details.[16-06-2022]
 var newEntryTransaction= {receiptUrl:transaction.charges.data[0].receipt_url,type:"Extended",userRole :"User",borrowReturnId:req.body.borrowReturnId,'userId':req.body.userId ,"restaurantId":getTrans.restaurantId ,transactionId:transaction.charges.data[0].id,"borrowNumberOfCleanBowlsLarge":getTrans.remainingNumberOfBowlsLarge, 'currency': transaction.currency, 'amount': convertStripeAmount(transaction.amount), "borrowNumberOfCleanBowlsMedium":getTrans.remainingNumberOfBowlsMedium,"borrowNumberOfCleanBowlsSmall":getTrans.remainingNumberOfBowlsSmall ,"borrowNumberOfCleanBowls": parseInt(getTrans.remainingNumberOfBowlsLarge) + parseInt(getTrans.remainingNumberOfBowlsMedium) + parseInt(getTrans.remainingNumberOfBowlsSmall),createdOn:new Date()};
    
}
         let newDataTran= new dbSchema.Transactions(newEntryTransaction);            
         let newDataTranSave= yield newDataTran.save();

   return res.status(200).json({status: 1, message:"Done! You have now extended for 3 more days."});
}
else
{
  var date= new Date(getTrans.lastDateToRetrun);
        date.setDate(date.getDate() + 3); 
         date.setSeconds(0);     
         date.setMilliseconds(0);  

   var tranAmount= getTrans.remainingNumberOfCups * 1000;

   //Start: Surendar added for price details.[16-06-2022]
   var smallCupsExtensionPrice = (priceDetails.smallCupsExtensionPrice != undefined) ? parseFloat(priceDetails.smallCupsExtensionPrice) : 1000;
    var largeCupsExtensionPrice = (priceDetails.largeCupsExtensionPrice != undefined) ? parseFloat(priceDetails.largeCupsExtensionPrice) : 1000;

    var amount1 = getTrans.remainingNumberOfCupsSmall * smallCupsExtensionPrice;
    var amount2 = getTrans.remainingNumberOfCupsLarge * largeCupsExtensionPrice;

    tranAmount = parseFloat(amount1) + parseFloat(amount2);
   //End: Surendar added for price details.[16-06-2022]

      var transaction= yield trans(checkUser.stripeCustomerId,checkUser.country,tranAmount,userCountryDetails.currency);

        if(!transaction) {  return res.status(200).json({status: 0, message: alertMessages.transactionError, data: [] }); }
      
  var updateTrans= yield dbSchema.BorrowReturn.updateOne({_id:req.body.borrowReturnId},{$set:{lastDateToRetrun: date,isTwoDaysReminder:1,isOneDayReminder:1,extendedCount: getTrans.extendedCount + 1,updatedOn:new Date()},$addToSet:{extendedTransactionId:transaction.charges.data[0].id}});

  //Edit: Surendar added for price details.[16-06-2022]
    let newEntryTransaction= {receiptUrl:transaction.charges.data[0].receipt_url  ,type:"Extended",userRole :"User",borrowReturnId:req.body.borrowReturnId,'userId':req.body.userId ,"restaurantId":getTrans.restaurantId ,transactionId:transaction.charges.data[0].id, "numberOfCleanCupsSmall":getTrans.remainingNumberOfCupsSmall,"numberOfCleanCups":getTrans.remainingNumberOfCupsLarge, 'currency': transaction.currency, 'amount': convertStripeAmount(transaction.amount), totalNumberOfCleanCups: parseInt(getTrans.remainingNumberOfCupsSmall) + parseInt(getTrans.remainingNumberOfCupsLarge),createdOn:new Date()};
       

         let newDataTran= new dbSchema.Transactions(newEntryTransaction);            
         let newDataTranSave= yield newDataTran.save();

   return res.status(200).json({status: 1, message:"Done! You have now extended for 3 more days."});
}

 }).catch(function(err){
  console.log(err)
  err = err && err.errorCode ? err : {errorCode: 500, errorMessage: err};
  return res.status(err.errorCode).json({status: 0, message: err.errorMessage, data: [] });
});

},


updateNotificationAlert: function(req, res) { 
  co(function*(){
   var reqObjectUser= {_id :req.body.userId,isActive:1};  
    const checkUser= yield dbSchema.User.findOne(reqObjectUser).exec();
    if(!checkUser) return res.status(200).json({status: 0, message: alertMessages.userNotFound, data: [] });

      
  var updateTrans= yield dbSchema.BorrowReturn.updateOne({_id:req.body.borrowReturnId},{$set:{isNotificationReminder: req.body.status,updatedOn:new Date()}});

   return res.status(200).json({status: 1, message: alertMessages.success});


 }).catch(function(err){
  console.log(err)
  err = err && err.errorCode ? err : {errorCode: 500, errorMessage: err};
  return res.status(err.errorCode).json({status: 0, message: err.errorMessage, data: [] });
});

}



}




async function trans(custId,country,finalAmount,userCurrency)
{
   return new Promise(async function (resolve, reject) {
let courrency= 'DKK';
if(country == 'Denmark')
{
courrency= 'DKK';
}
else if(country == 'Norway')
{
  courrency= 'NOK';
}
else if(country == 'Sweden')
{
  courrency= 'SEK';
}

if(userCurrency != undefined && userCurrency != null && userCurrency != '') {
  courrency = userCurrency;
}
     

     console.log("country--------------", country)  
     console.log("courrency--------------", courrency)  
 await stripe.paymentMethods.list({
  customer: custId,
  type: 'card',
},
  async function(err, data) {
    if(err)
    {
      resolve([])
    }
    else
    {
      if(data.data.length > 0)
      {

 await stripe.paymentIntents.create({
    amount: finalAmount,
    currency: courrency,
    customer: custId,
    payment_method: data.data[0].id,
    off_session: true,
    confirm: true,
  },
  function(err, payment) {
    if(err)
    {
      resolve([])
    }
    else
    {
      resolve(payment)
    }
  });

      }
      else
      {
        resolve([])
      }
  
  }

})
})
}


//Start: Surendar added for price details.[16-06-2022]
async function getUserCountryDetails(stripeCustomerId) {
  return new Promise(async function (resolve, reject) {
    var cardID = '';
    var cardDetail= await stripe.customers.retrieve(stripeCustomerId);
    console.log('Card Details', cardDetail.default_source);
    if(cardDetail.default_source != undefined && cardDetail.default_source != null && cardDetail.default_source != '') {
      cardID = cardDetail.default_source;
    } else if(!(cardDetail.currency)) {
      resolve({'country': 'Denmark', 'countryCode': 'DK', 'currency': 'DKK'});
    } else if(cardDetail.currency != 'DKK' && cardDetail.currency != 'SEK' && cardDetail.currency != 'NOK' && cardDetail.currency != 'EUR') {
      resolve({'country': 'Denmark', 'countryCode': 'DK', 'currency': 'DKK'});
    } else {
      switch (cardDetail.currency) {
        case 'EUR':
          resolve({'country': 'Spain', 'countryCode': 'ES', 'currency': 'EUR'});
          break;
        case 'EUR':
          resolve({'country': 'Germany', 'countryCode': 'DE', 'currency': 'EUR'});
          break;
        case 'DKK':
          resolve({'country': 'Denmark', 'countryCode': 'DK', 'currency': 'DKK'});
          break;
        case 'SEK':
          resolve({'country': 'Sweden', 'countryCode': 'SE', 'currency': 'SEK'});
          break;
        case 'NOK':
          resolve({'country': 'Norway', 'countryCode': 'NO', 'currency': 'NOK'});
          break;
        default:
          resolve({'country': 'Denmark', 'countryCode': 'DK', 'currency': 'DKK'});
          break;
      }
    }

    if(cardID != '') {
      var cardsDetail= await stripe.customers.retrieveSource(stripeCustomerId, cardID);
      console.log('Find country', cardsDetail);
      if(cardsDetail.country != undefined && cardsDetail.country != null && cardsDetail.country != '') {
        switch (cardsDetail.country) {
          case 'ES':
            resolve({'country': 'Spain', 'countryCode': 'ES', 'currency': 'EUR'});
            break;
          case 'DE':
            resolve({'country': 'Germany', 'countryCode': 'DE', 'currency': 'EUR'});
            break;
          case 'DK':
            resolve({'country': 'Denmark', 'countryCode': 'DK', 'currency': 'DKK'});
            break;
          case 'SE':
            resolve({'country': 'Sweden', 'countryCode': 'SE', 'currency': 'SEK'});
            break;
          case 'NO':
            resolve({'country': 'Norway', 'countryCode': 'NO', 'currency': 'NOK'});
            break;
          default:
            resolve({'country': 'Denmark', 'countryCode': 'DK', 'currency': 'DKK'});
            break;
        }
      } else {
        resolve({'country': 'Denmark', 'countryCode': 'DK', 'currency': 'DKK'});
      }
    }

  });
}
function getPriceDetails(userCountry, allPriceDetails) {
  return new Promise(function (resolve, reject) {
    var priceDetail = {};
    var countrPriceKey = 'denmarkPrice';
    var countrExtensionPriceKey = 'denmarkExtensionPrice';

    if(userCountry == 'Denmark') {
      priceDetail['currency'] = 'DKK';
      priceDetail['country'] = 'Denmark';
      countrPriceKey = 'denmarkPrice';
      countrExtensionPriceKey = 'denmarkExtensionPrice';
    } else if(userCountry == 'Norway') {
      priceDetail['currency'] = 'NOK';
      priceDetail['country'] = 'Norway';
      countrPriceKey = 'norwayPrice';
      countrExtensionPriceKey = 'norwayExtensionPrice';
    } else if(userCountry == 'Sweden') {
      priceDetail['currency'] = 'SEK';
      priceDetail['country'] = 'Sweden';
      countrPriceKey = 'swedenPrice';
      countrExtensionPriceKey = 'swedenExtensionPrice';
    } else if(userCountry == 'Spain') {
      priceDetail['currency'] = 'EUR';
      priceDetail['country'] = 'Spain';
      countrPriceKey = 'spainPrice';
      countrExtensionPriceKey = 'spainExtensionPrice';
    } else if(userCountry == 'Germany') {
      priceDetail['currency'] = 'EUR';
      priceDetail['country'] = 'Germany';
      countrPriceKey = 'germanyPrice';
      countrExtensionPriceKey = 'germanyExtensionPrice';
    }

    for(var i = 0; i < allPriceDetails.length; i++) {
      var priceKey = allPriceDetails[i]['productName']+'Price';
      var extensionPriceKey = allPriceDetails[i]['productName']+'ExtensionPrice';

      priceKey = priceKey.replace(/\s/g,"");
      priceKey = `${priceKey[0].toLowerCase()}${priceKey.slice(1)}`;

      priceDetail[priceKey] = parseFloat(allPriceDetails[i][countrPriceKey] * 100);

      extensionPriceKey = extensionPriceKey.replace(/\s/g,"");
      extensionPriceKey = `${extensionPriceKey[0].toLowerCase()}${extensionPriceKey.slice(1)}`;

      priceDetail[extensionPriceKey] = parseFloat(allPriceDetails[i][countrExtensionPriceKey] * 100);
    }
    resolve(priceDetail);
  });
}
function convertStripeAmount(amount) {
  /* var tempAmount = amount.toString();
  tempAmount = tempAmount.substring(0, tempAmount.length - 2); */
  var tempAmount = parseFloat(amount) / 100;
  return tempAmount;
}
//End: Surendar added for price details.[16-06-2022]